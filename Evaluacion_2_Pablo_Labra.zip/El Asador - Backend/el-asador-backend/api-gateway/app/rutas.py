"""Tabla explícita de rutas que el API Gateway deja pasar. Lo que no esté aquí NO se reenvía.

El gateway no es un proxy genérico: cada fila dice quién puede entrar, qué datos viajan y a qué servicio
privado llega. Esta misma tabla alimenta la matriz de servicios del informe (S##), la de permisos y la de
rutas (scripts/generar_matrices.py), así el documento no se desfasa del código.
"""
from dataclasses import dataclass

PEDIDO = r"A-\d{3,9}"
PRODUCTO = r"[a-z0-9]{2,12}"
CLIENTE = r"c-[a-z0-9]{4,12}"
USUARIO = r"u-[a-z0-9]{2,20}"

PERSONAL = ("administrador", "despacho")
CATALOGO = ("administrador", "dueno")

PAGINAS = {
    "P01": "index.html · Inicio",
    "P02": "productos.html · Carta y carrito",
    "P03": "servicios.html · Servicios y cotizador de eventos",
    "P04": "empresa.html · Empresa",
    "P05": "contacto.html · Contacto",
    "P06": "registro.html · Registro de clientes",
    "P07": "pedidos.html · Mis pedidos, pago y boleta",
    "P08": "admin.html · Panel interno (ventas, productos, clientes, usuarios, despacho)",
    "P09": "Ventana «Acceder» y menú de cuenta (todas las páginas)",
}


@dataclass(frozen=True)
class Ruta:
    id: str
    metodo: str
    patron: str                 # ruta pública
    destino: str                # servicio privado
    ruta_interna: str
    acceso: str                 # "anonimo" | "sesion" | "firma" (aviso firmado del proveedor)
    roles: tuple = ()           # vacío = cualquier usuario con sesión
    query: tuple = ()           # parámetros de consulta que se reenvían (los demás se descartan)
    cuerpo: str = "ninguno"     # "ninguno" | "json" | "crudo"
    limite: str = "general"     # grupo de límite de solicitudes
    params: tuple = ()          # ((nombre en la ruta, expresión regular válida), ...)
    cache: int = 0              # segundos de caché en el gateway (solo GET anónimos)
    invalida: str = ""          # al tener éxito, vacía la caché de este grupo
    cabeceras: tuple = ()       # cabeceras del navegador que SÍ se reenvían
    especial: str = ""          # manejador propio del gateway (login, logout, me)
    datos: str = "publico"      # clasificación de lo que transporta: publico | personal | restringido | secreto
    rf: tuple = ()              # requisitos funcionales que cubre
    paginas: tuple = ()         # pantallas que la usan (ver PAGINAS)
    resumen: str = ""


RUTAS = [
    # ---- autenticación (RF12) ----
    Ruta("S01", "POST", "/api/auth/login", "auth", "/login", "anonimo", cuerpo="json", limite="login", especial="login", datos="secreto",
         rf=("RF12",), paginas=("P09", "P06"), resumen="Inicia sesión; el token viaja solo en cookie HttpOnly"),
    Ruta("S02", "POST", "/api/auth/logout", "auth", "/logout", "anonimo", especial="logout", datos="publico",
         rf=("RF12",), paginas=("P09", "P08"), resumen="Cierra la sesión y la revoca en el servidor"),
    Ruta("S03", "GET", "/api/auth/me", "auth", "/introspect", "anonimo", especial="me", datos="personal",
         rf=("RF12",), paginas=("P01", "P02", "P03", "P04", "P05", "P06", "P07", "P08"), resumen="Quién soy (null si no hay sesión)"),
    # ---- catálogo (RF1, RF7) ----
    Ruta("S04", "GET", "/api/products", "inventory", "/products", "anonimo", query=("categoria", "available", "q", "limit", "offset"), cache=10,
         rf=("RF1", "RF7"), paginas=("P01", "P02", "P08"), resumen="Carta de productos (pública)"),
    Ruta("S05", "GET", "/api/promos", "inventory", "/promos", "anonimo", cache=10,
         rf=("RF1",), paginas=("P01", "P02", "P08"), resumen="Promociones vigentes (públicas)"),
    Ruta("S06", "POST", "/api/products", "inventory", "/products", "sesion", roles=CATALOGO, cuerpo="json", invalida="catalogo",
         rf=("RF7", "RF10"), paginas=("P08",), resumen="Crea un producto"),
    Ruta("S07", "PUT", "/api/products/{producto}", "inventory", "/products/{producto}", "sesion", roles=CATALOGO, cuerpo="json", invalida="catalogo",
         params=(("producto", PRODUCTO),), rf=("RF7", "RF10"), paginas=("P08",), resumen="Modifica un producto"),
    Ruta("S08", "PUT", "/api/products/{producto}/availability", "inventory", "/products/{producto}/availability", "sesion", roles=CATALOGO, cuerpo="json",
         invalida="catalogo", params=(("producto", PRODUCTO),), rf=("RF7",), paginas=("P08",), resumen="Marca un producto disponible o agotado"),
    Ruta("S09", "DELETE", "/api/products/{producto}", "inventory", "/products/{producto}", "sesion", roles=CATALOGO, invalida="catalogo",
         params=(("producto", PRODUCTO),), rf=("RF10",), paginas=("P08",), resumen="Retira un producto de la carta (baja lógica)"),
    # ---- clientes (RF5, RF6, RF10) ----
    Ruta("S10", "POST", "/api/clients/register", "clients", "/clients/register", "anonimo", cuerpo="json", limite="registro", datos="restringido",
         rf=("RF5", "RF11"), paginas=("P06",), resumen="Registro de cliente por la web (valida que el correo exista)"),
    Ruta("S11", "GET", "/api/clients/me", "clients", "/clients/me", "sesion", roles=("cliente",), datos="restringido",
         rf=("RF5",), paginas=("P01",), resumen="Perfil del cliente con sesión (el carrito muestra adónde se despacha)"),
    Ruta("S12", "GET", "/api/clients", "clients", "/clients", "sesion", roles=("administrador",), query=("q", "limit", "offset"), datos="restringido",
         rf=("RF6", "RF10"), paginas=("P08",), resumen="Lista y busca clientes"),
    Ruta("S13", "POST", "/api/clients", "clients", "/clients", "sesion", roles=("administrador",), cuerpo="json", datos="restringido",
         rf=("RF6", "RF11"), paginas=("P08",), resumen="Alta de cliente hecha en el local"),
    Ruta("S14", "PUT", "/api/clients/{cliente}", "clients", "/clients/{cliente}", "sesion", roles=("administrador",), cuerpo="json", params=(("cliente", CLIENTE),),
         datos="restringido", rf=("RF10",), paginas=("P08",), resumen="Modifica los datos de un cliente"),
    Ruta("S15", "DELETE", "/api/clients/{cliente}", "clients", "/clients/{cliente}", "sesion", roles=("administrador",), params=(("cliente", CLIENTE),),
         datos="restringido", rf=("RF10",), paginas=("P08",), resumen="Desactiva un cliente y su acceso"),
    # ---- usuarios del personal (RF10, RF12) ----
    Ruta("S16", "GET", "/api/users", "auth", "/users", "sesion", roles=("administrador",), query=("limit", "offset"), datos="personal",
         rf=("RF10", "RF12"), paginas=("P08",), resumen="Lista usuarios del personal"),
    Ruta("S17", "POST", "/api/users", "auth", "/users", "sesion", roles=("administrador",), cuerpo="json", datos="secreto",
         rf=("RF10", "RF12"), paginas=("P08",), resumen="Crea un usuario del personal con su perfil"),
    Ruta("S18", "PUT", "/api/users/{usuario}", "auth", "/users/{usuario}", "sesion", roles=("administrador",), cuerpo="json", params=(("usuario", USUARIO),),
         datos="secreto", rf=("RF10", "RF12"), paginas=("P08",), resumen="Cambia nombre, perfil, estado o clave"),
    Ruta("S19", "DELETE", "/api/users/{usuario}", "auth", "/users/{usuario}", "sesion", roles=("administrador",), params=(("usuario", USUARIO),),
         datos="personal", rf=("RF10",), paginas=("P08",), resumen="Desactiva un usuario del personal"),
    # ---- pedidos (RF1, RF3, RF13) ----
    Ruta("S20", "GET", "/api/delivery-zones", "orders", "/delivery-zones", "anonimo", cache=30,
         rf=("RF1",), paginas=("P01", "P03", "P08"), resumen="Comunas con cobertura y costo de despacho"),
    Ruta("S21", "POST", "/api/orders", "orders", "/orders", "sesion", roles=("cliente",), cuerpo="json", cabeceras=("Idempotency-Key",), datos="restringido",
         rf=("RF1", "RF4"), paginas=("P01",), resumen="Crea un pedido: el servidor calcula precios, despacho y total"),
    Ruta("S22", "GET", "/api/orders", "orders", "/orders", "sesion", roles=("cliente",), query=("limit", "offset"), datos="restringido",
         rf=("RF1",), paginas=(), resumen="Pedidos del cliente con sesión (sin pantalla web: «Mis pedidos» usa la consulta GraphQL equivalente; queda como contrato REST)"),
    Ruta("S23", "GET", "/api/orders/{pedido}", "orders", "/orders/{pedido}", "sesion", roles=("cliente", "administrador", "despacho"), params=(("pedido", PEDIDO),),
         datos="restringido", rf=("RF1", "RF13"), paginas=(), resumen="Detalle de un pedido, el cliente solo el suyo (sin pantalla web: contrato REST para otros clientes y pruebas de propiedad)"),
    Ruta("S24", "POST", "/api/orders/{pedido}/cancellation", "orders", "/orders/{pedido}/cancellation", "sesion", roles=("cliente", "administrador"), cuerpo="json",
         params=(("pedido", PEDIDO),), datos="restringido", rf=("RF3",), paginas=("P07", "P08"), resumen="Anula un pedido indicando el motivo"),
    Ruta("S25", "GET", "/api/admin/orders", "orders", "/admin/orders", "sesion", roles=PERSONAL, query=("estado", "limit", "offset"), datos="restringido",
         rf=("RF13",), paginas=("P08",), resumen="Órdenes de despacho en el orden de llegada"),
    Ruta("S26", "PUT", "/api/admin/orders/{pedido}/status", "orders", "/admin/orders/{pedido}/status", "sesion", roles=PERSONAL, cuerpo="json",
         params=(("pedido", PEDIDO),), datos="restringido", rf=("RF13",), paginas=("P08",), resumen="Avanza el despacho: En camino / Entregado"),
    Ruta("S27", "GET", "/api/event-config", "orders", "/event-config", "anonimo", cache=30,
         rf=("RF1",), paginas=("P03",), resumen="Menús y precios del cotizador de eventos"),
    Ruta("S28", "POST", "/api/event-quotes", "orders", "/event-quotes", "anonimo", cuerpo="json", limite="formularios", datos="personal",
         rf=("RF1",), paginas=("P03",), resumen="Solicita la cotización de un evento (se calcula en el servidor)"),
    # ---- pagos, boleta y reembolso (RF2, RF3, RF4, RF8) ----
    Ruta("S29", "POST", "/api/orders/{pedido}/payment", "payments", "/orders/{pedido}/payment", "sesion", roles=("cliente",), params=(("pedido", PEDIDO),),
         datos="restringido", rf=("RF2", "RF4"), paginas=("P01", "P07"), resumen="Inicia el pago del pedido (monto desde el servidor)"),
    Ruta("S30", "GET", "/api/orders/{pedido}/payment", "payments", "/orders/{pedido}/payment", "sesion", roles=("cliente", "administrador"), params=(("pedido", PEDIDO),),
         datos="restringido", rf=("RF2",), paginas=("P07",), resumen="Estado del pago de un pedido (la pantalla lo consulta al volver del proveedor)"),
    Ruta("S31", "GET", "/api/orders/{pedido}/receipt", "payments", "/orders/{pedido}/receipt", "sesion", roles=("cliente", "administrador"), params=(("pedido", PEDIDO),),
         datos="restringido", rf=("RF8",), paginas=("P07",), resumen="Boleta digital del pedido pagado"),
    Ruta("S32", "POST", "/api/admin/orders/{pedido}/payment-confirmation", "payments", "/admin/orders/{pedido}/payment-confirmation", "sesion", roles=("administrador",),
         cuerpo="json", params=(("pedido", PEDIDO),), datos="restringido", rf=("RF2", "RF4"), paginas=("P08",),
         resumen="Confirma a mano una transferencia o depósito"),
    Ruta("S33", "POST", "/api/admin/orders/{pedido}/refund", "payments", "/admin/orders/{pedido}/refund", "sesion", roles=("administrador",), cuerpo="json",
         params=(("pedido", PEDIDO),), datos="restringido", rf=("RF3",), paginas=("P08",), resumen="Ejecuta el reembolso de un pedido anulado"),
    Ruta("S34", "GET", "/api/admin/payments", "payments", "/admin/payments", "sesion", roles=("administrador",), query=("estado", "reembolso", "modo", "limit", "offset"),
         datos="restringido", rf=("RF2",), paginas=("P08",), resumen="Lista pagos (por confirmar, reembolsos pendientes)"),
    Ruta("S35", "POST", "/api/webhooks/provider", "payments", "/webhooks/provider", "firma", cuerpo="crudo", limite="webhook", cabeceras=("X-Provider-Signature", "X-Provider-Event-Id"),
         datos="restringido", rf=("RF2",), paginas=(), resumen="Aviso firmado del proveedor de pagos (sin sesión; se valida la firma)"),
    # ---- mensajería (RF8, contacto) ----
    Ruta("S36", "POST", "/api/contact-messages", "notifications", "/contact-messages", "anonimo", cuerpo="json", limite="formularios", datos="personal",
         rf=(), paginas=("P05",), resumen="Mensaje del formulario de contacto"),
    Ruta("S37", "GET", "/api/admin/outbox", "notifications", "/outbox", "sesion", roles=("administrador",), query=("limit",), datos="restringido",
         rf=("RF8",), paginas=("P08",), resumen="Correos enviados (boletas y avisos), destinatario enmascarado"),
    # ---- agregación (RF1, RF9, RF13) ----
    Ruta("S38", "POST", "/api/graphql", "graphql-gateway", "/graphql", "sesion", cuerpo="json", limite="graphql", datos="restringido",
         rf=("RF1", "RF9", "RF13"), paginas=("P07", "P08"), resumen="Consulta GraphQL de solo lectura (pedidos con pago y boleta, panel, reporte de ventas)"),
]
