"""API Gateway de El Asador: ÚNICA puerta pública del sistema (junto con la página de pago del proveedor).

Orden de cada solicitud: límite de tasa -> control de origen (CSRF) -> sesión (Auth Service) -> rol de la ruta ->
validación de parámetros y cuerpo -> reenvío al servicio privado con SU secreto (Vault) y la identidad ya verificada.

Qué NO hace: lógica de negocio. Cada servicio vuelve a validar datos, roles y propiedad del recurso, de modo que
saltarse este gateway (o un error en él) no abre nada: los servicios privados rechazan a quien no traiga su credencial.
"""
import json
import logging
import os
import re
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager

from fastapi import Request
from fastapi.responses import JSONResponse, Response

from common import plazos
from common.app import crear_app
from common.cliente_interno import ClienteInterno, ServicioNoDisponible, cuerpo as cuerpo_de
from common.errores import ErrorNegocio
from common.seguridad import Identidad
from common.vault_secrets import VaultSecrets

from .rutas import RUTAS, Ruta

vault = VaultSecrets()
COOKIE = "session_token"
COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "false").lower() == "true"   # true cuando se publique con HTTPS
PUBLICO = (os.environ.get("PUBLIC_BASE_URL") or os.environ.get("GATEWAY_URL") or "http://localhost:8000").rstrip("/")
ORIGENES = tuple(o.strip().rstrip("/") for o in (os.environ.get("PUBLIC_ORIGINS") or f"{PUBLICO},http://localhost:8000,http://127.0.0.1:8000").split(",") if o.strip())
MAX_JSON = 16 * 1024
MAX_WEBHOOK = 64 * 1024
LIMITES = {"general": int(os.environ.get("RL_GENERAL", "300")), "login": int(os.environ.get("RL_LOGIN", "5")),
           "registro": int(os.environ.get("RL_REGISTRO", "5")), "formularios": int(os.environ.get("RL_FORMULARIOS", "5")),
           "webhook": int(os.environ.get("RL_WEBHOOK", "120")), "graphql": int(os.environ.get("RL_GRAPHQL", "60"))}
CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; "
       "frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'")
CABECERAS_DE_RESPUESTA = ("x-total-count", "retry-after")
VALOR_CABECERA = {"idempotency-key": re.compile(r"^[A-Za-z0-9_-]{8,64}$"), "x-provider-signature": re.compile(r"^[A-Za-z0-9=,]{10,300}$"),
                  "x-provider-event-id": re.compile(r"^evt_[A-Za-z0-9]{8,40}$")}
interno = None


@asynccontextmanager
async def lifespan(app):
    global interno
    urls = {"auth": "AUTH_URL", "clients": "CLIENTS_URL", "inventory": "INVENTORY_URL", "orders": "ORDERS_URL", "payments": "PAYMENTS_URL",
            "notifications": "NOTIFICATIONS_URL", "graphql-gateway": "GRAPHQL_URL"}
    interno = ClienteInterno("api-gateway", vault, {k: os.environ[v] for k, v in urls.items()}, timeout=plazos.upstream("gateway"),
                             pausa_circuito=float(os.environ.get("CIRCUITO_PAUSA", "5")))
    await interno.precalentar()
    app.state.chequeos.append(lambda: vault.aget("asador/svc/api-gateway-to-auth"))
    log.info("Gateway listo", extra={"ctx": {"rutas": len(RUTAS)}})
    yield
    await interno.cerrar()


app, log = crear_app("api-gateway", lifespan)
app.router.redirect_slashes = False
logging.getLogger("httpx").setLevel(logging.WARNING)


# ----------------------------- cabeceras de seguridad para TODAS las respuestas -----------------
@app.middleware("http")
async def cabeceras_seguridad(request: Request, call_next):
    r = await call_next(request)
    r.headers["X-Content-Type-Options"] = "nosniff"
    r.headers["X-Frame-Options"] = "DENY"
    r.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    r.headers["Permissions-Policy"] = "geolocation=(), camera=(), microphone=(), payment=()"
    r.headers["Content-Security-Policy"] = CSP
    if COOKIE_SECURE:
        r.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    if not request.url.path.startswith("/api/"):
        r.headers["Cache-Control"] = "no-cache"   # fuera de /api (por ejemplo /health) nada se reutiliza sin revalidar
    return r


# ----------------------------- límite de solicitudes ------------------------------------------
class Limitador:
    """Ventana deslizante en memoria. Con varias réplicas del gateway habría que moverlo a un almacén compartido (ver ADR)."""

    def __init__(self):
        self._h = defaultdict(deque)

    def permitir(self, clave, maximo, ventana=60.0):
        ahora = time.monotonic()
        if len(self._h) > 10_000:
            for k in [k for k, q in self._h.items() if not q or ahora - q[-1] > ventana]:
                del self._h[k]
        q = self._h[clave]
        while q and ahora - q[0] > ventana:
            q.popleft()
        if len(q) >= maximo:
            return False
        q.append(ahora)
        return True


limitador = Limitador()


def _ip(request):
    # No se confía en X-Forwarded-For: lo puede escribir cualquier cliente. Detrás de un proxy propio se configuraría su IP.
    return request.client.host if request.client else "desconocida"


def limitar(grupo, clave):
    if not limitador.permitir((grupo, clave), LIMITES[grupo]):
        log.warning("límite de solicitudes superado", extra={"ctx": {"grupo": grupo}})
        raise ErrorNegocio(429, "DEMASIADAS_SOLICITUDES", "Demasiadas solicitudes. Intenta nuevamente en un minuto.", headers={"Retry-After": "60"})


# ----------------------------- origen (defensa CSRF), sesión, cuerpo --------------------------------
def borrar_cookie_header():
    return f"{COOKIE}=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax" + ("; Secure" if COOKIE_SECURE else "")


def origen_ok(request, exigir):
    """Una solicitud que modifica datos debe venir de NUESTRO sitio. Se mira Origin y, si falta, Referer."""
    origen = request.headers.get("origin")
    if origen:
        return origen.rstrip("/") in ORIGENES
    ref = request.headers.get("referer")
    if ref:
        return any(ref == o or ref.startswith(o + "/") for o in ORIGENES)
    return not exigir


def verificar_origen(request, ruta):
    if request.method in ("GET", "HEAD") or ruta.acceso == "firma":
        return
    exigir = ruta.acceso == "sesion" or COOKIE in request.cookies   # con sesión (o cookie presente) el origen es obligatorio
    if not origen_ok(request, exigir):
        log.warning("origen no permitido", extra={"ctx": {"ruta": ruta.id}})
        raise ErrorNegocio(403, "ORIGEN_NO_PERMITIDO", "La solicitud no proviene de este sitio")


async def sesion(request, obligatoria=True):
    """Convierte la cookie en una identidad verificada por el Auth Service (en cada solicitud: el cierre de sesión y las bajas valen al instante)."""
    token = request.cookies.get(COOKIE)
    if not token:
        if obligatoria:
            raise ErrorNegocio(401, "NO_AUTENTICADO", "Sesión requerida")
        return None, None
    try:
        r = await interno.llamar("auth", "POST", "/introspect", request_id=request.state.request_id, json={"token": token})
    except ServicioNoDisponible as e:
        raise a_error(e)
    if r.status_code not in (200, 422):   # algo distinto a "sesión válida / no válida" es una falla nuestra: no se cierra la sesión del usuario por eso
        log.error("respuesta inesperada del Auth Service", extra={"ctx": {"status": r.status_code}})
        raise ErrorNegocio(502, "ERROR_DE_ORIGEN", "El servicio no pudo procesar la solicitud.")
    datos = r.json() if r.status_code == 200 else {}
    if r.status_code == 422 or not datos.get("active"):   # 422: la cookie ni siquiera tiene forma de token
        if obligatoria:
            raise ErrorNegocio(401, "SESION_NO_VALIDA", "Tu sesión terminó. Vuelve a ingresar.", headers={"Set-Cookie": borrar_cookie_header()})
        return None, "borrar"
    ident = Identidad(datos["user_id"], datos["username"], tuple(datos["roles"]), datos.get("client_id"))
    request.state.user_id = ident.user_id
    return ident, datos


async def leer_cuerpo(request, maximo, json_obligatorio=True, validar_json=True):
    if json_obligatorio and "application/json" not in request.headers.get("content-type", ""):
        raise ErrorNegocio(415, "CONTENT_TYPE_INVALIDO", "Se requiere Content-Type: application/json")
    largo = request.headers.get("content-length")
    if largo and largo.isdigit() and int(largo) > maximo:
        raise ErrorNegocio(413, "CUERPO_DEMASIADO_GRANDE", "El contenido enviado es demasiado grande")
    partes, total = [], 0
    async for trozo in request.stream():   # se corta apenas se supera el máximo, aunque no declare Content-Length
        total += len(trozo)
        if total > maximo:
            raise ErrorNegocio(413, "CUERPO_DEMASIADO_GRANDE", "El contenido enviado es demasiado grande")
        partes.append(trozo)
    crudo = b"".join(partes)
    if validar_json:
        try:
            json.loads(crudo)
        except (ValueError, RecursionError):
            raise ErrorNegocio(400, "JSON_INVALIDO", "El contenido enviado no es un JSON válido")
    return crudo


def a_error(e: ServicioNoDisponible):
    """Los fallos internos NUNCA se muestran tal cual: ni nombres de servicios, ni trazas, ni mensajes de la base de datos."""
    log.warning("servicio no disponible", extra={"ctx": {"destino": e.destino, "motivo": e.motivo}})
    if e.motivo == "dependencia" and e.respuesta is not None:
        # El servicio contestó un 503 propio (su dependencia está caída): se conserva su código y su mensaje, que ya vienen saneados.
        c = cuerpo_de(e.respuesta)
        codigo = c.get("codigo") if isinstance(c.get("codigo"), str) and re.fullmatch(r"[A-Z_]{3,60}", c["codigo"]) else "SERVICIO_NO_DISPONIBLE"
        detalle = c.get("detail") if isinstance(c.get("detail"), str) and len(c["detail"]) <= 300 else "El servicio no está disponible en este momento."
        espera = e.respuesta.headers.get("retry-after", "10")
        return ErrorNegocio(503, codigo, detalle, headers={"Retry-After": espera if espera.isdigit() and len(espera) <= 3 else "10"})
    if e.motivo == "timeout":
        return ErrorNegocio(504, "TIEMPO_AGOTADO", "El servicio tardó demasiado en responder. Intenta nuevamente.", headers={"Retry-After": "5"})
    if e.motivo == "credencial_rechazada" or e.motivo.startswith("http_"):
        return ErrorNegocio(502, "ERROR_DE_ORIGEN", "El servicio no pudo procesar la solicitud.")
    return ErrorNegocio(503, "SERVICIO_NO_DISPONIBLE", "El servicio no está disponible en este momento. Intenta nuevamente en unos minutos.", headers={"Retry-After": "10"})


def respuesta_de(r):
    h = {k: v for k, v in r.headers.items() if k.lower() in CABECERAS_DE_RESPUESTA}
    return Response(content=r.content, status_code=r.status_code, media_type="application/json", headers=h)


def usuario_publico(d):
    return {"user_id": d["user_id"], "nombre": d["nombre"], "username": d["username"], "roles": d["roles"], "client_id": d.get("client_id")}


# ----------------------------- rutas propias: sesión ------------------------------------------------
async def login(request: Request):
    crudo = await leer_cuerpo(request, 2048)
    datos = json.loads(crudo)
    if (not isinstance(datos, dict) or set(datos) != {"username", "password"} or not isinstance(datos["username"], str) or not isinstance(datos["password"], str)
            or not 3 <= len(datos["username"]) <= 120 or not 1 <= len(datos["password"]) <= 128):
        raise ErrorNegocio(400, "SOLICITUD_INVALIDA", "Escribe tu correo y tu contraseña.")
    try:   # se reenvían solo estos dos campos
        r = await interno.llamar("auth", "POST", "/login", request_id=request.state.request_id, json={"username": datos["username"], "password": datos["password"]})
    except ServicioNoDisponible as e:
        raise a_error(e)
    if r.status_code == 401:
        raise ErrorNegocio(401, "CREDENCIALES_INVALIDAS", "Correo o contraseña incorrectos.")
    if r.status_code in (400, 422):
        raise ErrorNegocio(400, "SOLICITUD_INVALIDA", "Escribe tu correo y tu contraseña.")
    if r.status_code != 200:
        raise ErrorNegocio(503, "SERVICIO_NO_DISPONIBLE", "El servicio no está disponible en este momento. Intenta nuevamente en unos minutos.")
    d = r.json()
    request.state.user_id = d["usuario"]["user_id"]
    # El token viaja SOLO en una cookie HttpOnly: no aparece en el cuerpo ni lo puede leer JavaScript.
    resp = JSONResponse({"usuario": d["usuario"], "expira_en": d["expires_in"]})
    resp.set_cookie(COOKIE, d["access_token"], max_age=d["expires_in"], httponly=True, samesite="lax", secure=COOKIE_SECURE, path="/")
    return resp


async def logout(request: Request):
    token = request.cookies.get(COOKIE)
    if token:
        try:
            await interno.llamar("auth", "POST", "/logout", request_id=request.state.request_id, json={"token": token})
        except ServicioNoDisponible:
            log.warning("no se pudo revocar la sesión en el Auth Service")   # igual se borra la cookie del navegador
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(COOKIE, path="/", httponly=True, samesite="lax", secure=COOKIE_SECURE)
    return resp


async def me(request: Request):
    ident, datos = await sesion(request, obligatoria=False)
    resp = JSONResponse({"usuario": usuario_publico(datos) if ident else None, "expira_en": datos["expires_in"] if ident else None})
    if datos == "borrar":
        resp.delete_cookie(COOKIE, path="/", httponly=True, samesite="lax", secure=COOKIE_SECURE)
    return resp


ESPECIALES = {"login": login, "logout": logout, "me": me}

# ----------------------------- caché del catálogo (solo GET anónimos) ------------------------------------
CACHE = {}


def cache_leer(clave):
    e = CACHE.get(clave)
    return e[1] if e and e[0] > time.monotonic() else None


def cache_guardar(clave, ttl, valor):
    if len(CACHE) > 200:
        CACHE.clear()
    CACHE[clave] = (time.monotonic() + ttl, valor)


# ----------------------------- rutas de negocio (tabla explícita) ----------------------------------------------
async def reenviar(request: Request, ruta: Ruta, ident, contenido):
    ruta_interna = ruta.ruta_interna.format(**request.path_params)
    params = {k: v for k, v in request.query_params.items() if k in ruta.query and len(v) <= 100}
    extra = {}
    for nombre in ruta.cabeceras:   # solo las cabeceras permitidas por la ruta, con formato validado
        valor = request.headers.get(nombre)
        if valor is not None:
            if not VALOR_CABECERA[nombre.lower()].fullmatch(valor):
                raise ErrorNegocio(400, "CABECERA_INVALIDA", f"La cabecera {nombre} no es válida")
            extra[nombre] = valor
    if contenido is not None:
        extra["Content-Type"] = "application/json"
    clave_cache = (ruta.id, tuple(sorted(params.items()))) if ruta.cache else None
    if clave_cache:
        guardado = cache_leer(clave_cache)
        if guardado:
            return Response(content=guardado[1], status_code=200, media_type="application/json", headers=guardado[0])
    try:
        r = await interno.llamar(ruta.destino, ruta.metodo, ruta_interna, request_id=request.state.request_id, identidad=ident, params=params or None,
                                 extra=extra or None, contenido=contenido)
    except ServicioNoDisponible as e:
        raise a_error(e)
    resp = respuesta_de(r)
    if clave_cache and r.status_code == 200:
        cache_guardar(clave_cache, ruta.cache, ({k: v for k, v in resp.headers.items() if k.lower() in CABECERAS_DE_RESPUESTA}, r.content))
    if ruta.invalida and r.status_code < 300:
        CACHE.clear()
    return resp


def registrar(ruta: Ruta):
    async def manejador(request: Request):
        request.state.user_id = None
        limitar("general", _ip(request))
        if ruta.limite != "general" and ruta.limite != "graphql":
            limitar(ruta.limite, _ip(request))
        verificar_origen(request, ruta)
        for nombre, patron in ruta.params:
            if not re.fullmatch(patron, request.path_params[nombre]):
                raise ErrorNegocio(400, "PARAMETRO_INVALIDO", "El identificador indicado no es válido")
        if ruta.especial:
            return await ESPECIALES[ruta.especial](request)
        ident = None
        if ruta.acceso == "sesion":
            ident, _ = await sesion(request)
            if ruta.roles and not ident.tiene(*ruta.roles):
                raise ErrorNegocio(403, "ROL_NO_AUTORIZADO", "No tiene permisos para esta operación")
            if ruta.limite == "graphql":
                limitar("graphql", ident.user_id)
        contenido = None
        if ruta.cuerpo == "json":
            contenido = await leer_cuerpo(request, MAX_JSON)
        elif ruta.cuerpo == "crudo":
            contenido = await leer_cuerpo(request, MAX_WEBHOOK, validar_json=False)
        return await reenviar(request, ruta, ident, contenido)

    app.add_api_route(ruta.patron, manejador, methods=[ruta.metodo], name=ruta.id)


for _ruta in RUTAS:
    registrar(_ruta)


@app.api_route("/api/{resto:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"], include_in_schema=False)
async def no_existe(resto: str):
    raise ErrorNegocio(404, "RUTA_NO_ENCONTRADA", "La ruta no existe")

