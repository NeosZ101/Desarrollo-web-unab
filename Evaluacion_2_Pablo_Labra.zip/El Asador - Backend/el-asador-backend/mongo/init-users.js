// Se ejecuta UNA vez, cuando MongoDB arranca con el volumen vacío (docker-entrypoint-initdb.d).
// Crea una base y un usuario por servicio: cada usuario solo puede leer y escribir en SU base (principio de mínimo privilegio).
// Las contraseñas llegan por variables de entorno (MONGO_PASS_<SERVICIO>, generadas por scripts/bootstrap.py); el mismo valor
// lo guarda scripts/seed_vault.py en Vault, de donde cada servicio lo lee al arrancar. Nada de esto vive en el código ni en imágenes.
const servicios = ["auth", "clients", "inventory", "orders", "payments", "notifications", "analytics"];

for (const servicio of servicios) {
  const variable = "MONGO_PASS_" + servicio.toUpperCase();
  const clave = process.env[variable];
  if (!clave) {
    throw new Error("Falta la variable " + variable + " (ejecuta scripts/bootstrap.py antes de levantar el sistema)");
  }
  const nombre = "asador_" + servicio;
  db.getSiblingDB(nombre).createUser({
    user: "u_" + servicio,
    pwd: clave,
    roles: [{ role: "readWrite", db: nombre }],
  });
  print("Usuario u_" + servicio + " creado con acceso solo a " + nombre);
}
