"""Pruebas en el mismo proceso de dos decisiones que de fuera no se pueden provocar con precisión, porque dependen del orden exacto
en que se intercalan dos solicitudes. Las dos nacen de un hallazgo de la ejecución con servidores reales (MongoDB y Vault de verdad):

  1. orders: confirmar un pago es IDEMPOTENTE aunque otra solicitud (la misma confirmación) gane de mano entre la lectura y la
     escritura. Lo que pasó: payments reenvía la confirmación mientras orders está pausado; al volver, orders procesa las dos juntas,
     una pierde la escritura y contestaba 409 CONFLICTO_DE_ESTADO.
  2. payments: solo un «no» definitivo de orders hace que el pago se devuelva. Lo que pasó: ese 409 se tomó como rechazo, el pago
     quedó marcado para reembolso con el pedido ya «En preparación» y nunca se emitió la boleta.

Con mongomock las operaciones no ceden el turno entre una y otra, así que esa carrera NO ocurre sola: aquí se provoca a propósito
(la «otra solicitud» escribe justo antes de la escritura condicionada). Con MongoDB real sí ocurre sola:
ver test_dos_confirmaciones_simultaneas_del_mismo_pago... en tests/test_negocio_pagos.py.
"""
import asyncio
import importlib
from types import SimpleNamespace

import httpx
import pytest
from mongomock_motor import AsyncMongoMockClient

from ayuda import cargar_paquete
from common.errores import ErrorNegocio
from common.seguridad import Llamada

LLAMADA = Llamada("payments", "unidad-carrera-1", None)


def _cargar(carpeta, nombre):
    with pytest.MonkeyPatch.context() as mp:   # el servicio lee su configuración al importarse; aquí no se conecta a nada
        mp.setenv("VAULT_ADDR", "http://127.0.0.1:9")
        mp.setenv("VAULT_TOKEN", "unidad")
        cargar_paquete(carpeta, nombre)
        return importlib.import_module(nombre + ".main")


@pytest.fixture(scope="module")
def orders():
    return _cargar("orders-service/app", "orders_app_unidad")


@pytest.fixture(scope="module")
def payments():
    return _cargar("payments-service/app", "payments_app_unidad")


# ----------------------------- 1. orders: la confirmación del pago es idempotente aun perdiendo la carrera --------------------------
class ColeccionConCarrera:
    """La colección real, salvo que justo antes de la primera escritura condicionada al estado «otra solicitud» escribe primero."""

    def __init__(self, real, ganadora=None, perder_siempre=False):
        self.real, self.ganadora, self.perder_siempre = real, ganadora, perder_siempre
        self.escrituras = 0   # cuántas veces se intentó la escritura condicionada

    def __getattr__(self, nombre):
        return getattr(self.real, nombre)

    async def update_one(self, filtro, cambios, *a, **kw):
        if "estado" not in filtro:   # solo la escritura que depende del estado que se leyó
            return await self.real.update_one(filtro, cambios, *a, **kw)
        self.escrituras += 1
        if self.perder_siempre:
            return SimpleNamespace(matched_count=0, modified_count=0)
        if self.ganadora is not None:
            ganadora, self.ganadora = self.ganadora, None
            await self.real.update_one({"_id": filtro["_id"]}, ganadora)   # la otra solicitud llegó antes
        return await self.real.update_one(filtro, cambios, *a, **kw)


class BaseConCarrera:
    def __init__(self, real, **carrera):
        self.real = real
        self.pedidos = ColeccionConCarrera(real.pedidos, **carrera)

    def __getattr__(self, nombre):
        return getattr(self.real, nombre)

    def __getitem__(self, nombre):   # common.auditoria escribe con db["auditoria"]
        return self.pedidos if nombre == "pedidos" else self.real[nombre]


def _escribe(pago, estado="En preparación"):
    """Lo que habría dejado escrito la otra solicitud."""
    return {"$set": {"estado": estado, "pagoId": pago, "pagadoEn": "2026-11-04T20:00:00-03:00"}}


def _confirmar(orders, monkeypatch, *, pago="pay-1", monto=15000, estado="Pago pendiente", **carrera):
    """Confirma el pago de un pedido que está «Pago pendiente». Devuelve (resultado o ErrorNegocio, pedido final, base)."""
    real = AsyncMongoMockClient()["asador_orders_unidad"]
    base = BaseConCarrera(real, **carrera)
    monkeypatch.setattr(orders, "db", base)

    async def correr():
        await real.pedidos.insert_one({"_id": "A-1001", "estado": estado, "total": 15000, "reembolso": "no_aplica", "historial": []})
        try:
            salida = await orders.pago_confirmado("A-1001", orders.PagoConfirmado(pagoId=pago, monto=monto), ll=LLAMADA)
        except ErrorNegocio as e:
            salida = e
        return salida, await real.pedidos.find_one({"_id": "A-1001"})

    resultado, pedido = asyncio.run(correr())
    return resultado, pedido, base


def test_sin_carrera_la_confirmacion_avanza_el_pedido_una_sola_vez(orders, monkeypatch):
    resultado, pedido, base = _confirmar(orders, monkeypatch)
    assert resultado == {"estado": "En preparación", "repetido": False}
    assert (pedido["estado"], pedido["pagoId"], len(pedido["historial"])) == ("En preparación", "pay-1", 1)
    assert base.pedidos.escrituras == 1


def test_la_misma_confirmacion_que_pierde_la_carrera_responde_igual_que_la_que_gano(orders, monkeypatch):
    resultado, pedido, base = _confirmar(orders, monkeypatch, ganadora=_escribe("pay-1"))
    assert resultado == {"estado": "En preparación", "repetido": True}   # NO un 409: el pago quedó aplicado, solo que por la otra solicitud
    assert (pedido["estado"], pedido["pagoId"]) == ("En preparación", "pay-1")
    assert base.pedidos.escrituras == 1                                   # y no la escribió dos veces


def test_la_confirmacion_de_otro_pago_que_pierde_la_carrera_es_un_rechazo_definitivo_y_no_pisa_al_primero(orders, monkeypatch):
    resultado, pedido, _ = _confirmar(orders, monkeypatch, pago="pay-2", ganadora=_escribe("pay-1"))
    assert isinstance(resultado, ErrorNegocio)
    assert (resultado.status, resultado.codigo) == (409, "TRANSICION_NO_PERMITIDA")   # payments devuelve el segundo cobro
    assert pedido["pagoId"] == "pay-1"


def test_si_el_pedido_se_anula_justo_antes_se_rechaza_como_anulado_y_queda_el_reembolso_pendiente(orders, monkeypatch):
    resultado, pedido, _ = _confirmar(orders, monkeypatch, ganadora={"$set": {"estado": "Anulado"}})
    assert isinstance(resultado, ErrorNegocio) and (resultado.status, resultado.codigo) == (409, "PEDIDO_ANULADO")
    assert pedido["estado"] == "Anulado" and pedido["reembolso"] == "pendiente"


def test_si_el_pedido_no_deja_de_cambiar_se_rinde_tras_unos_intentos_y_no_da_un_rechazo_definitivo(orders, monkeypatch):
    resultado, pedido, base = _confirmar(orders, monkeypatch, perder_siempre=True)
    assert isinstance(resultado, ErrorNegocio) and (resultado.status, resultado.codigo) == (409, "CONFLICTO_DE_ESTADO")
    assert base.pedidos.escrituras == orders.INTENTOS_DE_CONFIRMACION == 3   # acotado: no gira para siempre
    assert pedido["estado"] == "Pago pendiente"


@pytest.mark.parametrize("estado,codigo", [("Anulado", "PEDIDO_ANULADO"), ("Entregado", "TRANSICION_NO_PERMITIDA"), ("En camino", "TRANSICION_NO_PERMITIDA")])
def test_los_rechazos_de_siempre_siguen_siendo_definitivos(orders, monkeypatch, estado, codigo):
    resultado, _, _ = _confirmar(orders, monkeypatch, estado=estado)
    assert isinstance(resultado, ErrorNegocio) and (resultado.status, resultado.codigo) == (409, codigo)


def test_un_monto_distinto_al_total_se_rechaza(orders, monkeypatch):
    resultado, pedido, _ = _confirmar(orders, monkeypatch, monto=14999)
    assert isinstance(resultado, ErrorNegocio) and (resultado.status, resultado.codigo) == (409, "MONTO_NO_COINCIDE")
    assert pedido["estado"] == "Pago pendiente"


# ----------------------------- 2. payments: solo un «no» definitivo de orders devuelve el dinero ---------------------------------------
class InternoPorRuta:
    """Hace de los demás servicios. `confirmacion` es lo que contesta orders a «pago confirmado»; el resto responde lo normal."""

    def __init__(self, confirmacion):
        self.confirmacion = confirmacion
        self.llamadas = []

    async def llamar(self, destino, metodo, ruta, **kw):
        self.llamadas.append((destino, metodo, ruta))
        if ruta.endswith("/payment-confirmed"):
            return self.confirmacion
        if ruta.endswith("/payable"):
            return httpx.Response(200, json={
                "id": "A-1001", "clienteId": "c-0001", "estado": "En preparación", "total": 15000, "medioPago": "Servipag",
                "cliente": {"nombre": "Ana Prueba", "correo": "ana@correo.cl"}, "comuna": "Ñuñoa",
                "lineas": [{"itemId": "p01", "nombre": "Parrilla", "cantidad": 1, "precio": 12000}], "subtotal": 12000, "despacho": 3000})
        return httpx.Response(200, json={})   # analítica y correo


def _respuesta(status, codigo=None):
    return httpx.Response(status, json={"detail": "x", "codigo": codigo} if codigo else {"detail": "x"})


def _notificar(payments, monkeypatch, confirmacion):
    """Corre «avisar a orders que el pago está confirmado» para un pago aprobado. Devuelve (resultado, pago final, base, interno)."""
    base = AsyncMongoMockClient()["asador_payments_unidad"]
    interno = InternoPorRuta(confirmacion)
    monkeypatch.setattr(payments, "db", base)
    monkeypatch.setattr(payments, "interno", interno)

    async def correr():
        pago = {"_id": "pay-unidad-1", "pedidoId": "A-1001", "clienteId": "c-0001", "estado": "aprobado", "medio": "Servipag", "modo": "proveedor",
                "monto": 15000, "creadoEn": "2026-11-04T20:00:00-03:00", "aprobadoEn": "2026-11-04T20:00:01-03:00",
                "pedidoNotificado": False, "reembolso": None, "ventaId": None, "ventaLease": None}
        await base.pagos.insert_one(pago)
        resultado = await payments._notificar_pedido(pago, "unidad-carrera-2")
        return resultado, await base.pagos.find_one({"_id": "pay-unidad-1"})

    resultado, pago = asyncio.run(correr())
    return resultado, pago, base, interno


@pytest.mark.parametrize("status,codigo,notificado", [
    (409, "PEDIDO_ANULADO", "anulado"), (409, "MONTO_NO_COINCIDE", "rechazado"), (409, "TRANSICION_NO_PERMITIDA", "rechazado"),
    (404, "PEDIDO_NO_ENCONTRADO", "rechazado")])
def test_un_no_definitivo_de_orders_devuelve_el_dinero(payments, monkeypatch, status, codigo, notificado):
    resuelto, pago, _, _ = _notificar(payments, monkeypatch, _respuesta(status, codigo))
    assert resuelto is True
    assert pago["reembolso"]["estado"] == "pendiente" and pago["reembolso"]["automatico"] is True
    assert pago["pedidoNotificado"] == notificado
    assert pago["ventaId"] is None   # un pago que se devuelve no es una venta: sin boleta ni analítica


@pytest.mark.parametrize("status,codigo", [
    (409, "CONFLICTO_DE_ESTADO"),       # perdió una carrera con otra solicitud: el pedido puede estar ya confirmado con ESTE pago
    (409, "UN_CODIGO_QUE_NO_CONOCEMOS"), (409, None), (400, "SOLICITUD_INVALIDA"), (422, "VALIDACION"), (404, "NO_ENCONTRADO"), (404, None)])
def test_una_respuesta_que_no_es_un_no_definitivo_no_devuelve_el_dinero_y_queda_para_reintento(payments, monkeypatch, status, codigo):
    resuelto, pago, _, interno = _notificar(payments, monkeypatch, _respuesta(status, codigo))
    assert resuelto is False
    assert pago["reembolso"] is None and pago["pedidoNotificado"] is False and pago["ventaId"] is None
    assert [l[2] for l in interno.llamadas] == ["/internal/orders/A-1001/payment-confirmed"]   # y no hizo nada más con el pago
    if codigo == "CONFLICTO_DE_ESTADO":
        assert pago.get("alerta") is None                                  # lo esperable se resuelve solo
    else:
        assert pago["alerta"] == f"pedidos_respondio_{codigo or status}"   # lo inesperado queda anotado en el pago


def test_tras_el_conflicto_el_siguiente_ciclo_recibe_el_si_y_la_boleta_se_emite(payments, monkeypatch):
    """El escenario completo que falló: primero 409 por carrera, luego orders contesta «repetido» y la venta con su folio sale igual."""
    resuelto, pago, base, interno = _notificar(payments, monkeypatch, _respuesta(409, "CONFLICTO_DE_ESTADO"))
    assert resuelto is False and pago["reembolso"] is None

    interno.confirmacion = httpx.Response(200, json={"estado": "En preparación", "repetido": True})   # el ciclo vuelve a preguntar

    async def siguiente_ciclo():
        return await payments._notificar_pedido(await base.pagos.find_one({"_id": "pay-unidad-1"}), "unidad-ciclo")

    assert asyncio.run(siguiente_ciclo()) is True
    pago = asyncio.run(base.pagos.find_one({"_id": "pay-unidad-1"}))
    assert pago["pedidoNotificado"] is True and pago["reembolso"] is None
    assert pago["ventaId"] == "B-000001"                                                              # la boleta se emitió
    venta = asyncio.run(base.ventas.find_one({"_id": "B-000001"}))
    assert (venta["total"], venta["estado"], venta["pedidoId"]) == (15000, "vigente", "A-1001")
