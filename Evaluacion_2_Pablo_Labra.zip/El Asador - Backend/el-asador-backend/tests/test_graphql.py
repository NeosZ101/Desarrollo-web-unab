"""GraphQL Gateway: agregación de varios servicios, permisos por campo, límites de consulta y errores sin detalles internos.

Las consultas de las pantallas se leen del JavaScript real del frontend (consulta_del_frontend): si alguien cambia una
pantalla y su consulta deja de ser aceptada por el gateway, estas pruebas fallan.
"""
import json
import uuid

import pytest

from ayuda import consulta_del_frontend, hoy_santiago, llamadas_registradas, pedido_ok, pedido_pagado_con_proveedor, sumar_dias

pytestmark = pytest.mark.integracion
MIS_PEDIDOS = consulta_del_frontend("CONSULTA_PEDIDOS")
VENTAS = consulta_del_frontend("CONSULTA_VENTAS")
DESPACHO = consulta_del_frontend("CONSULTA_DESPACHO")
JSON_CT = {"Content-Type": "application/json"}


def codigos(r):
    return [e["extensions"]["codigo"] for e in r.json().get("errors", [])]


def hojas(valor):
    """Todos los valores finales de una respuesta (para comprobar que un campo prohibido no dejó pasar nada)."""
    if isinstance(valor, dict):
        for v in valor.values():
            yield from hojas(v)
    elif isinstance(valor, list):
        for v in valor:
            yield from hojas(v)
    else:
        yield valor


def sin_errores(r):
    assert r.status_code == 200 and "errors" not in r.json(), r.text
    return r.json()["data"]


# ----------------------------- agregación: una consulta, varios servicios -----------------------------------------------
def test_mis_pedidos_une_pedido_pago_y_boleta_en_una_sola_consulta(nuevo_cliente):
    c = nuevo_cliente()
    pedido, _ = pedido_pagado_con_proveedor(c)
    pagina = sin_errores(c.gql(MIS_PEDIDOS, {"desde": 0}))["misPedidos"]
    assert pagina["total"] == 1
    p = pagina["items"][0]
    assert p["id"] == pedido["id"] and p["estado"] == "En preparación" and p["medioPago"] == "Servipag"
    assert p["total"] == pedido["total"] and p["subtotal"] + p["despacho"] == p["total"]
    assert p["pago"]["estado"] == "aprobado" and p["pago"]["monto"] == p["total"]                    # dato del servicio de pagos
    assert p["boleta"]["folio"].startswith("B-") and p["boleta"]["total"] == p["total"]              # dato de la boleta
    assert all(l["subtotal"] == l["precio"] * l["cantidad"] for l in p["lineas"])
    assert p["cliente"]["comuna"] == "Ñuñoa"


def test_un_pedido_sin_pago_iniciado_muestra_pago_y_boleta_nulos(nuevo_cliente):
    c = nuevo_cliente()
    pedido_ok(c)
    p = sin_errores(c.gql(MIS_PEDIDOS, {"desde": 0}))["misPedidos"]["items"][0]
    assert p["estado"] == "Pago pendiente" and p["pago"] is None and p["boleta"] is None


def test_cada_cliente_ve_solo_sus_pedidos_en_graphql(andrea, felipe, nuevo_cliente):
    ids_andrea = {p["id"] for p in sin_errores(andrea.gql(MIS_PEDIDOS, {"desde": 0}))["misPedidos"]["items"]}
    ids_felipe = {p["id"] for p in sin_errores(felipe.gql(MIS_PEDIDOS, {"desde": 0}))["misPedidos"]["items"]}
    assert "A-1038" in ids_andrea and not ids_andrea & {"A-1039", "A-1040", "A-1041"}
    assert "A-1039" in ids_felipe and not ids_felipe & {"A-1038", "A-1040", "A-1041"}
    nuevo = nuevo_cliente()
    pedido_ok(nuevo)
    assert not {p["id"] for p in sin_errores(nuevo.gql(MIS_PEDIDOS, {"desde": 0}))["misPedidos"]["items"]} & (ids_andrea | ids_felipe)


def test_no_existe_ningun_argumento_para_pedir_pedidos_de_otro_cliente(andrea):
    for arg in ('clienteId: "c-0002"', 'cliente: "c-0002"', 'userId: "u-felipe"', 'id: "A-1039"'):
        r = andrea.gql("{ misPedidos(%s) { total items { id } } }" % arg)
        assert r.json()["data"] is None and codigos(r) == ["CONSULTA_INVALIDA"], (arg, r.text)


def test_paginacion_con_limit_offset_y_total(nuevo_cliente):
    c = nuevo_cliente()
    creados = [pedido_ok(c)["id"] for _ in range(3)]
    q = "query($l:Int!,$o:Int!){ misPedidos(limit:$l, offset:$o){ total items{ id } } }"
    # con la variable el costo estimado es el del máximo; esta consulta es pequeña y cabe sin problema
    p1 = sin_errores(c.gql(q, {"l": 2, "o": 0}))["misPedidos"]
    p2 = sin_errores(c.gql(q, {"l": 2, "o": 2}))["misPedidos"]
    assert p1["total"] == p2["total"] == 3 and len(p1["items"]) == 2 and len(p2["items"]) == 1
    assert {i["id"] for i in p1["items"]} | {i["id"] for i in p2["items"]} == set(creados)


@pytest.mark.parametrize("limit", [-5, 0])
def test_un_limit_fuera_de_rango_se_acota_en_vez_de_fallar(andrea, limit):
    d = sin_errores(andrea.gql("{ misPedidos(limit: %d){ total items { id } } }" % limit))["misPedidos"]
    assert len(d["items"]) == 1


def test_las_imagenes_de_las_lineas_vienen_del_servicio_de_inventario(andrea):
    d = sin_errores(andrea.gql('{ misPedidos(limit: 5){ items { id lineas { nombre imagen disponible } } } }'))["misPedidos"]["items"]
    lineas = [l for p in d for l in p["lineas"]]
    assert lineas and any(l["imagen"] and l["imagen"].startswith("img/") for l in lineas)
    assert all(l["disponible"] in (True, False, None) for l in lineas)


def test_una_consulta_pide_cada_servicio_una_sola_vez_sin_problema_n_mas_1(sistema, nuevo_cliente):
    """Con 5 pedidos, el gateway hace UNA llamada a pagos y UNA a inventario (DataLoader), no una por pedido."""
    c = nuevo_cliente()
    for _ in range(5):
        pedido_ok(c, items=[{"id": "p07", "cantidad": 1}, {"id": "p02", "cantidad": 1}])
    rid = "prueba-nm1-" + uuid.uuid4().hex[:8]
    consulta = "{ misPedidos(limit: 5) { total items { id pago { estado } boleta { folio } lineas { nombre imagen disponible } } } }"
    r = c.gql(consulta, headers={"X-Request-ID": rid})
    assert len(sin_errores(r)["misPedidos"]["items"]) == 5 and r.headers["x-request-id"] == rid
    assert [l["ruta"] for l in llamadas_registradas(sistema, "payments", rid)] == ["/internal/payments/by-orders"]
    assert [l["ruta"] for l in llamadas_registradas(sistema, "inventory", rid)] == ["/internal/items"]
    assert [l["ruta"] for l in llamadas_registradas(sistema, "orders", rid)] == ["/orders"]
    assert len(llamadas_registradas(sistema, "graphql-gateway", rid)) == 1 and len(llamadas_registradas(sistema, "api-gateway", rid)) == 1


def test_el_panel_del_pie_pide_cada_dato_a_su_servicio(admin):
    d = sin_errores(admin.gql("query Panel { panelAdmin { pedidosPorEstado { estado cantidad } productos { activos agotados } "
                              "pagos { pagosManualesPorConfirmar reembolsosPendientes iniciados aprobados } } }"))["panelAdmin"]
    assert {x["estado"] for x in d["pedidosPorEstado"]} == {"Pago pendiente", "En preparación", "En camino", "Entregado", "Anulado"}
    assert d["productos"]["activos"] >= 1 and isinstance(d["productos"]["agotados"], list)
    assert set(d["pagos"]) == {"pagosManualesPorConfirmar", "reembolsosPendientes", "iniciados", "aprobados"}


def test_la_consulta_de_despacho_trae_pedido_cliente_y_pago(admin, nuevo_cliente):
    c = nuevo_cliente()
    pedido, _ = pedido_pagado_con_proveedor(c)
    d = sin_errores(admin.gql(DESPACHO, {"estado": "activos", "desde": 0}))["pedidosAdmin"]
    p = next(x for x in d["items"] if x["id"] == pedido["id"])
    assert p["cliente"]["nombre"] == c.datos["nombre"] and p["cliente"]["comuna"] == "Ñuñoa" and p["pago"]["estado"] == "aprobado"
    assert d["total"] >= 1


def test_el_reporte_de_ventas_de_la_pantalla_funciona_para_administrador_y_dueno(admin, dueno):
    hoy = hoy_santiago()
    for quien in (admin, dueno):
        r = sin_errores(quien.gql(VENTAS, {"desde": hoy, "hasta": hoy}))["reporteVentas"]
        assert set(r) == {"dias", "totales", "porMedioPago", "topProductos"}
        assert set(r["totales"]) == {"ventas", "pedidos", "ticketPromedio", "mejorDia"}


# ----------------------------- permisos por campo (segunda capa, dentro del GraphQL Gateway) ---------------------------------
CAMPOS = {
    "misPedidos": "{ misPedidos(limit: 1) { total } }",
    "pedidosAdmin": "{ pedidosAdmin(limit: 1) { total } }",
    "panel.pedidosPorEstado": "{ panelAdmin { pedidosPorEstado { estado } } }",
    "panel.productos": "{ panelAdmin { productos { activos } } }",
    "panel.pagos": "{ panelAdmin { pagos { iniciados } } }",
    "reporteVentas": "{ reporteVentas(desde: \"%s\", hasta: \"%s\") { totales { ventas } } }" % ("2026-01-01", "2026-01-02"),
}
# Quién puede pedir cada campo. Esta tabla ES la matriz de permisos de GraphQL del informe.
PERMITIDOS = {
    "misPedidos": {"cliente"},
    "pedidosAdmin": {"administrador", "despacho"},
    "panel.pedidosPorEstado": {"administrador", "despacho"},
    "panel.productos": {"administrador", "dueno"},
    "panel.pagos": {"administrador"},
    "reporteVentas": {"administrador", "dueno"},
}
ROLES = ("cliente", "administrador", "dueno", "despacho")


@pytest.fixture(scope="module")
def por_rol(admin, dueno, despacho, andrea):
    return {"cliente": andrea, "administrador": admin, "dueno": dueno, "despacho": despacho}


@pytest.mark.parametrize("campo", list(CAMPOS))
@pytest.mark.parametrize("rol", ROLES)
def test_matriz_de_permisos_de_campos_graphql(por_rol, campo, rol):
    r = por_rol[rol].gql(CAMPOS[campo])
    assert r.status_code == 200
    cuerpo = r.json()
    if rol in PERMITIDOS[campo]:
        assert "errors" not in cuerpo, (campo, rol, r.text)
    else:
        assert codigos(r) == ["PROHIBIDO"], (campo, rol, r.text)
        assert all(v is None for v in hojas(cuerpo["data"])), "un campo prohibido no debe devolver datos"


def test_un_alias_o_un_fragmento_no_saltan_el_permiso_del_campo(andrea):
    r = andrea.gql("query { inocente: pedidosAdmin(limit: 5) { items { id cliente { correo } } } }")
    assert r.json()["data"] == {"inocente": None} and codigos(r) == ["PROHIBIDO"]
    r = andrea.gql("fragment F on Query { pedidosAdmin(limit: 5) { total } } query { ...F }")
    assert codigos(r) == ["PROHIBIDO"] and r.json()["data"]["pedidosAdmin"] is None
    r = andrea.gql("query { ... on Query { reporteVentas(desde: \"2026-01-01\", hasta: \"2026-01-02\") { totales { ventas } } } }")
    assert codigos(r) == ["PROHIBIDO"]


def test_mezclar_un_campo_permitido_y_uno_prohibido_devuelve_solo_lo_permitido(andrea):
    r = andrea.gql("{ misPedidos(limit: 1) { total } pedidosAdmin(limit: 1) { total } }")
    d = r.json()
    assert d["data"]["misPedidos"]["total"] >= 1 and d["data"]["pedidosAdmin"] is None
    assert [e["path"] for e in d["errors"]] == [["pedidosAdmin"]] and codigos(r) == ["PROHIBIDO"]


def test_el_dueno_no_alcanza_ningun_pedido_ni_dato_personal_por_graphql(dueno):
    """El dueño ve ventas y catálogo, pero ninguna ruta GraphQL le entrega pedidos ni datos de clientes."""
    for consulta in ("{ misPedidos(limit: 1) { items { id cliente { correo } } } }", "{ pedidosAdmin(limit: 1) { items { id cliente { correo telefono } } } }"):
        r = dueno.gql(consulta)
        assert codigos(r) == ["PROHIBIDO"] and "@" not in r.text
    ventas = dueno.gql(VENTAS, {"desde": sumar_dias(hoy_santiago(), -30), "hasta": hoy_santiago()})
    assert "errors" not in ventas.json() and "@" not in ventas.text and "telefono" not in ventas.text


def test_el_panel_para_un_cliente_es_nulo_y_prohibido(andrea):
    r = andrea.gql("{ panelAdmin { pagos { iniciados } } }")
    assert r.json()["data"] == {"panelAdmin": None} and codigos(r) == ["PROHIBIDO"]


def test_graphql_exige_sesion(anon):
    r = anon.gql("{ __typename }")
    assert r.status_code == 401 and r.json()["codigo"] == "NO_AUTENTICADO"


# ----------------------------- límites de la consulta ------------------------------------------------------------------------
def test_la_introspeccion_esta_desactivada(andrea):
    for consulta in ("{ __schema { types { name fields { name } } } }", '{ __type(name: "Pedido") { fields { name } } }'):
        r = andrea.gql(consulta)
        assert r.json()["data"] is None and set(codigos(r)) == {"CONSULTA_INVALIDA"}, r.text
        assert "misPedidos" not in r.text and "pedidosAdmin" not in r.text           # el esquema no se filtra ni en el mensaje


@pytest.mark.parametrize("operacion", ["mutation { crearPedido(total: 1) { id } }", "mutation M { x }", "subscription { pedidos { id } }"])
def test_no_hay_mutaciones_ni_suscripciones(andrea, operacion):
    r = andrea.gql(operacion)
    assert r.json()["data"] is None and codigos(r) == ["CONSULTA_INVALIDA"], r.text


def test_profundidad_maxima(andrea, sistema):
    rid = "prueba-prof-" + uuid.uuid4().hex[:8]
    r = andrea.gql("query{ misPedidos(limit:1){ items{ lineas{ a{ b{ c{ d{ e } } } } } } } }", headers={"X-Request-ID": rid})
    assert r.json()["data"] is None and any("depth" in e["message"] for e in r.json()["errors"]), r.text
    assert llamadas_registradas(sistema, "orders", rid) == []                         # se rechaza sin tocar ningún servicio


def test_maximo_de_alias(andrea, sistema):
    def con(n):
        return "query{ %s }" % " ".join(f"a{i}: misPedidos(limit:1){{ total }}" for i in range(n))
    assert len(sin_errores(andrea.gql(con(10)))) == 10
    rid = "prueba-alias-" + uuid.uuid4().hex[:8]
    r = andrea.gql(con(11), headers={"X-Request-ID": rid})
    assert r.json()["data"] is None and "11 aliases" in r.text and llamadas_registradas(sistema, "orders", rid) == []


def test_maximo_de_tokens(andrea, sistema):
    """Un documento con más de 1200 tokens se aborta al analizarlo, antes de validar o ejecutar nada."""
    rid = "prueba-tok-" + uuid.uuid4().hex[:8]
    r = andrea.gql("query{ misPedidos(limit:1){ " + "total " * 1300 + "} }", headers={"X-Request-ID": rid})
    assert r.json()["data"] is None and "1200 tokens" in r.text and llamadas_registradas(sistema, "orders", rid) == []
    assert len(sin_errores(andrea.gql("query{ misPedidos(limit:1){ " + "total " * 300 + "} }"))["misPedidos"]) == 1


def test_campos_repetidos_que_harian_trabajo_cuadratico_se_rechazan(andrea, sistema):
    rid = "prueba-cuad-" + uuid.uuid4().hex[:8]
    r = andrea.gql("query{ misPedidos(limit:1){ " + "total " * 1000 + "} }", headers={"X-Request-ID": rid})
    assert r.json()["data"] is None and codigos(r) == ["CONSULTA_INVALIDA"] and llamadas_registradas(sistema, "orders", rid) == []


def test_costo_maximo_con_la_consulta_real_de_la_pantalla(andrea, sistema):
    assert "errors" not in andrea.gql(MIS_PEDIDOS, {"desde": 0}).json()                     # limit literal 20: cabe
    rid = "prueba-costo-" + uuid.uuid4().hex[:8]
    r = andrea.gql(MIS_PEDIDOS.replace("limit: 20", "limit: 50"), {"desde": 0}, headers={"X-Request-ID": rid})
    assert codigos(r) == ["CONSULTA_DEMASIADO_COSTOSA"] and "máximo 1500" in r.text
    assert llamadas_registradas(sistema, "orders", rid) == [] and llamadas_registradas(sistema, "payments", rid) == []


def test_un_limit_en_variable_cuenta_como_el_maximo(andrea):
    q = MIS_PEDIDOS.replace("limit: 20", "limit: $n").replace("($desde: Int!)", "($desde: Int!, $n: Int)")
    assert codigos(andrea.gql(q, {"desde": 0, "n": 1})) == ["CONSULTA_DEMASIADO_COSTOSA"]


def test_un_limit_negativo_o_gigante_no_evita_el_costo(andrea):
    pesada = MIS_PEDIDOS.replace("limit: 20", "limit: 50")
    r = andrea.gql(pesada.replace("{ misPedidos(", "{ x: misPedidos(limit: -1000) { total } misPedidos(", 1), {"desde": 0})
    assert "CONSULTA_DEMASIADO_COSTOSA" in codigos(r)
    r = andrea.gql("{ misPedidos(limit: %s) { total } }" % ("9" * 6000))                # se acota; no revienta
    assert r.status_code == 200 and "data" in r.json()


def test_tamano_maximo_de_la_consulta(andrea):
    relleno = "{ __typename } # " + "x" * 9000
    r = andrea.post("/api/graphql", content=json.dumps({"query": relleno}), headers=JSON_CT)       # pasa el gateway (16 KB), cae en el GraphQL Gateway (8 KB)
    assert r.status_code == 413 and r.json()["codigo"] == "CUERPO_DEMASIADO_GRANDE"
    r = andrea.post("/api/graphql", content=json.dumps({"query": "{ __typename } # " + "x" * 17000}), headers=JSON_CT)   # cae en el API Gateway
    assert r.status_code == 413 and r.json()["codigo"] == "CUERPO_DEMASIADO_GRANDE"


@pytest.mark.parametrize("cuerpo,estado,codigo", [
    (b'[{"query":"{ __typename }"}]', 400, "SOLICITUD_INVALIDA"),                    # lotes de consultas: no se aceptan
    (b'{"query":"{ __typename }","extensions":{"persistedQuery":1}}', 400, "SOLICITUD_INVALIDA"),
    (b'{"query":"{ __typename }","variables":[1]}', 400, "SOLICITUD_INVALIDA"),
    (b'{"query":123}', 400, "SOLICITUD_INVALIDA"),
    (b'{"variables":{}}', 400, "SOLICITUD_INVALIDA"),
    (b'{"query":"{ __typename }"', 400, "JSON_INVALIDO"),
])
def test_formas_de_solicitud_no_aceptadas(andrea, cuerpo, estado, codigo):
    r = andrea.post("/api/graphql", content=cuerpo, headers=JSON_CT)
    assert r.status_code == estado and r.json()["codigo"] == codigo, r.text


def test_solo_se_acepta_json_y_solo_post(andrea):
    assert andrea.post("/api/graphql", content="{ __typename }", headers={"Content-Type": "application/graphql"}).status_code == 415
    assert andrea.get("/api/graphql?query=%7B__typename%7D").status_code in (404, 405)       # GET con la consulta en la URL: no existe
    assert andrea.pedir("PUT", "/api/graphql", json={"query": "{ __typename }"}).status_code in (404, 405)


def test_los_errores_no_revelan_el_esquema_ni_detalles_internos(andrea):
    pruebas = {
        "sintaxis": "query { misPedidos( }",
        "campo": "{ misPedidosX { id } }",
        "sugerencia": "{ misPedido { id } }",
        "variable": "query($d:Int!){ misPedidos(offset:$d){ total } }",
    }
    for nombre, consulta in pruebas.items():
        r = andrea.gql(consulta, {"d": "texto"} if nombre == "variable" else None)
        assert r.status_code == 200 and r.json()["data"] is None, (nombre, r.text)
        texto = r.text.lower()
        for prohibido in ("traceback", "strawberry", "graphql-core", "did you mean", "pedidosadmin", "reporteventas", "mongo", "payments", "inventory",
                          "orders-service", ".py", "asador/svc"):
            assert prohibido not in texto, (nombre, prohibido, r.text)
        assert all(set(e) == {"message", "path", "extensions"} and "locations" not in e for e in r.json()["errors"])


def test_una_variable_mal_escrita_dice_que_la_consulta_es_invalida_y_no_error_interno(andrea):
    r = andrea.gql("query($d:Int!){ misPedidos(offset:$d){ total } }", {"d": "texto"})
    assert codigos(r) == ["CONSULTA_INVALIDA"] and "Error interno" not in r.text


def test_limite_de_solicitudes_graphql_no_afecta_al_resto_de_la_api(andrea):
    """El límite de GraphQL es por usuario y propio de la ruta: en esta configuración es muy alto y no interfiere con REST."""
    assert andrea.get("/api/auth/me").status_code == 200
    assert "errors" not in andrea.gql("{ __typename }").json()


def test_la_respuesta_graphql_no_se_guarda_en_cache(andrea):
    r = andrea.gql("{ misPedidos(limit: 1) { total } }")
    assert "no-store" in r.headers.get("cache-control", "")
