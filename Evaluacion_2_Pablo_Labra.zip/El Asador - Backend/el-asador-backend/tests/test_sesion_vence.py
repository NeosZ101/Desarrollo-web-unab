"""Vencimiento de la sesión (módulo 4: la sesión dura un tiempo fijo y el servidor la rechaza al vencer).

La duración es la variable SESSION_TTL_SECONDS del Auth Service (7200 s por defecto). Aquí se levanta un sistema propio con 2 s para
comprobar tres cosas sin esperar horas: la cookie nace con esa duración, el servidor rechaza el token vencido aunque alguien lo
conserve, y el rechazo ocurre en el gateway (el servicio de pedidos no llega a ver la solicitud).
"""
import tempfile
import time

import pytest

from ayuda import Api, lineas_de_log
from conftest import ENTORNO
from stack import Stack

pytestmark = pytest.mark.integracion
TTL = 2  # segundos


@pytest.fixture(scope="module")
def corto():
    with Stack(tempfile.mkdtemp(prefix="asador-logs-ttl-"), extra_env={**ENTORNO, "SESSION_TTL_SECONDS": str(TTL)}) as s:
        yield s


def test_la_sesion_vence_y_el_servidor_rechaza_el_token_que_alguien_conserve(corto):
    gw = corto.urls["api-gateway"]
    a = Api(gw)
    login = a.login("andrea.molina@correo.cl", "cliente123")
    assert login.status_code == 200
    assert f"max-age={TTL}" in login.headers["set-cookie"].lower()          # la cookie nace con la duración de la sesión
    guardada = a.c.cookies.get("session_token")
    assert a.get("/api/orders").status_code == 200                           # dentro del plazo funciona

    time.sleep(TTL + 1.5)

    copia = Api(gw)                                                          # alguien que guardó la cookie y la reenvía a mano
    copia.c.cookies.set("session_token", guardada)
    r = copia.get("/api/orders")
    assert r.status_code == 401 and r.json()["codigo"] == "SESION_NO_VALIDA"
    assert "max-age=0" in r.headers["set-cookie"].lower()                    # además se le pide al navegador que la borre

    # el navegador de verdad ya no manda la cookie vencida: queda como visitante, sin sesión
    assert a.get("/api/orders").status_code == 401
    assert a.get("/api/auth/me").json()["usuario"] is None


def test_el_rechazo_por_sesion_vencida_no_llega_al_servicio_de_pedidos(corto):
    gw = corto.urls["api-gateway"]
    a = Api(gw)
    a.login("andrea.molina@correo.cl", "cliente123")
    guardada = a.c.cookies.get("session_token")
    time.sleep(TTL + 1.5)
    copia = Api(gw)
    copia.c.cookies.set("session_token", guardada)
    r = copia.get("/api/orders")
    assert r.status_code == 401
    id_solicitud = r.headers["x-request-id"]
    visto = {l["request_id"] for l in lineas_de_log(corto, "orders") if l.get("msg") == "solicitud"}
    assert id_solicitud not in visto                                        # la solicitud murió en el gateway: orders no registró nada
