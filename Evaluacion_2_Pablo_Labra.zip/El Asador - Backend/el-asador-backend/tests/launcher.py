"""Arranca UN servicio real con uvicorn, usando MongoDB simulado en memoria (mongomock).

Solo se usa en las pruebas automáticas: el código de los servicios no contiene ninguna rama de prueba.
Aquí se reemplaza el cliente de MongoDB ANTES de importar el servicio, de modo que cada proceso tiene su
propia "base" aislada (igual que en producción cada servicio tiene su propia base).
Con ASADOR_REAL=1 no se reemplaza nada: el servicio habla con el MongoDB real que levantó tests/stack.py.

Uso:  python launcher.py <carpeta-del-servicio> <puerto> [modulo]
"""
import os
import sys

if os.environ.get("ASADOR_REAL") != "1":
    import mongomock_motor
    import motor.motor_asyncio as motor

    motor.AsyncIOMotorClient = mongomock_motor.AsyncMongoMockClient

import uvicorn  # noqa: E402

carpeta, puerto = sys.argv[1], int(sys.argv[2])
modulo = sys.argv[3] if len(sys.argv) > 3 else "app.main:app"
os.chdir(carpeta)
sys.path.insert(0, carpeta)
uvicorn.run(modulo, host="127.0.0.1", port=puerto, log_level="warning", server_header=False)
