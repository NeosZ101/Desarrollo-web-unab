#!/usr/bin/env python3
"""Pruebas de mutación manuales: ¿las pruebas detectan que se rompió una regla crítica?

Cómo funciona: copia el proyecto a una carpeta temporal, rompe A PROPÓSITO una regla de seguridad o de negocio (cambia una línea),
ejecuta las pruebas que deberían notarlo y exige que FALLEN. Una mutación «sobrevive» si las pruebas siguen pasando: eso significa
que la regla no está protegida por ninguna prueba (o que otra capa la cubre; se anota en la columna «nota»).
El proyecto real nunca se modifica.

Uso:
    python tests/mutaciones.py                 # todas las mutaciones
    python tests/mutaciones.py M03 M07         # solo algunas
    python tests/mutaciones.py --lista         # muestra la lista sin ejecutar
Resultado: docs/evidencia/mutaciones.md (y .json).
"""
import argparse
import json
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent

PAGOS = ["tests/test_negocio_pagos.py", "tests/test_unidad_reglas.py"]
PEDIDOS = ["tests/test_negocio_pedidos.py", "tests/test_unidad_reglas.py"]
ACCESO = ["tests/test_seguridad_acceso.py"]
CAPA2 = ["tests/test_segunda_capa.py", "tests/test_unidad_guardia_graphql.py"]
GQL = ["tests/test_graphql.py", "tests/test_unidad_reglas.py", "tests/test_unidad_guardia_graphql.py"]
LIMITES = ["tests/test_limites_tasa.py"]
VAULT = ["tests/test_secretos_vault.py"]
CARRERAS = ["tests/test_unidad_carreras.py"]
VAULT_CAIDA = ["tests/test_secretos_vault.py", "-k", "vault_cae"]   # solo la prueba de sistema: ¿sigue atendiendo con Vault colgado?
LOGS = ["tests/test_zz_logs_y_secretos.py"]
LOGS_UNIDAD = ["tests/test_unidad_logs.py"]
CAPA2_DINAMICA = ["tests/test_segunda_capa.py", "-k", "not coincide_con_el_contrato"]   # sin la comparación con el contrato: solo llamadas reales
ADMINISTRACION = ["tests/test_negocio_administracion.py"]


@dataclass
class Mutacion:
    id: str
    riesgo: str            # qué se rompe, en palabras de negocio
    archivo: str
    buscar: str            # texto EXACTO que existe una sola vez
    reemplazo: str
    pruebas: list = field(default_factory=list)
    nota: str = ""


MUTACIONES = [
    # ---------------- pagos ----------------
    Mutacion("M01", "El aviso del proveedor se acepta aunque su firma sea falsa", "payments-service/app/reglas.py",
             "    if not any(hmac.compare_digest(c.encode(), esperada.encode()) for c in candidatas):", "    if False:", PAGOS),
    Mutacion("M02", "Se aceptan avisos antiguos o del futuro (sin ventana de tiempo)", "payments-service/app/reglas.py",
             "    if abs(ahora - t) > tolerancia:", "    if False:", PAGOS),
    Mutacion("M03", "El monto del aviso no se compara con lo cobrado", "payments-service/app/main.py",
             '    if ev.data.amount != pago["monto"] or ev.data.currency != "CLP":', "    if False:", PAGOS),
    Mutacion("M04", "Un pago ya cerrado puede volver a aprobarse", "payments-service/app/main.py",
             '        {"_id": pid, "estado": "iniciado"},\n        {"$set": {"estado": "aprobado", "aprobadoEn": ahora, "actualizadoEn": ahora, "origenAprobacion": origen,',
             '        {"_id": pid},\n        {"$set": {"estado": "aprobado", "aprobadoEn": ahora, "actualizadoEn": ahora, "origenAprobacion": origen,', PAGOS),
    Mutacion("M05", "Un cliente puede iniciar el pago del pedido de otra persona", "payments-service/app/main.py",
             '    if not staff and p["clienteId"] != ll.identidad.client_id:', "    if False:", PAGOS + ACCESO),
    Mutacion("M06", "El administrador puede «confirmar a mano» un pago con el proveedor en línea", "payments-service/app/main.py",
             '    if p["medioPago"] not in MEDIOS_MANUALES:', "    if False:", PAGOS),
    Mutacion("M07", "El IVA de la boleta se calcula mal", "payments-service/app/reglas.py",
             "    neto = (total * 100 + divisor // 2) // divisor", "    neto = total * 100 // divisor + 1", PAGOS),
    Mutacion("M08", "Un cliente puede confirmar pagos y reembolsos (rol administrador ampliado)", "payments-service/app/main.py",
             'ADMIN = Depends(guardia.dep(GW, identidad="requerida", roles=("administrador",)))',
             'ADMIN = Depends(guardia.dep(GW, identidad="requerida", roles=("administrador", "cliente")))', CAPA2 + PAGOS),
    # ---------------- pedidos ----------------
    Mutacion("M09", "Un cliente puede ver o anular pedidos de otros (IDOR)", "orders-service/app/main.py",
             '    if not d or not ident.client_id or d["clienteId"] != ident.client_id:', "    if not d:", PEDIDOS + ACCESO),
    Mutacion("M10", "Se puede anular un pedido ya entregado", "orders-service/app/main.py",
             '    if d["estado"] not in ANULABLES:', "    if False:", PEDIDOS),
    Mutacion("M11", "El despacho puede saltarse el ciclo de estados", "orders-service/app/main.py",
             '    if d["estado"] != desde or not transicion_permitida(desde, datos.estado, actor):', "    if False:", PEDIDOS),
    Mutacion("M12", "Un cliente puede acumular pedidos pendientes sin tope", "orders-service/app/main.py",
             '"estado": "Pago pendiente"}) >= MAX_PENDIENTES:', '"estado": "Pago pendiente"}) >= 10**9:', PEDIDOS),
    Mutacion("M13", "Repetir el envío (doble clic) crea otro pedido", "orders-service/app/main.py",
             '    if idem:\n        previo = await db.pedidos.find_one({"clienteId": cid, "claveIdempotencia": idem})',
             '    if False:\n        previo = await db.pedidos.find_one({"clienteId": cid, "claveIdempotencia": idem})', PEDIDOS),
    Mutacion("M14", "El costo de despacho se redondea hacia abajo", "orders-service/app/reglas.py",
             '    return cfg["base"] + math.ceil(km - cfg["kmGratis"]) * cfg["porKm"]', '    return cfg["base"] + math.floor(km - cfg["kmGratis"]) * cfg["porKm"]', PEDIDOS),
    Mutacion("M15", "El GraphQL gateway (solo lectura) puede crear pedidos", "orders-service/app/main.py",
             'CLIENTE_ESCRIBE = Depends(guardia.dep(GW, identidad="requerida", roles=("cliente",)))',
             'CLIENTE_ESCRIBE = Depends(guardia.dep(tuple(GW) + ("graphql-gateway",), identidad="requerida", roles=("cliente",)))', ACCESO),
    Mutacion("M16", "El gateway público puede marcar un pedido como pagado", "orders-service/app/main.py",
             'async def pago_confirmado(id: ID, datos: PagoConfirmado, ll=Depends(guardia.dep(("payments",)))):',
             'async def pago_confirmado(id: ID, datos: PagoConfirmado, ll=Depends(guardia.dep(("payments", "api-gateway")))):', CAPA2),
    Mutacion("M17", "Un cliente puede avanzar el estado de despacho", "orders-service/app/main.py",
             'DESPACHO_ESCRIBE = Depends(guardia.dep(GW, identidad="requerida", roles=("administrador", "despacho")))',
             'DESPACHO_ESCRIBE = Depends(guardia.dep(GW, identidad="requerida", roles=("administrador", "despacho", "cliente")))', CAPA2 + PEDIDOS),
    Mutacion("M18", "Se vende un producto agotado", "inventory-service/app/main.py",
             "        if not disp:\n            agotados.append(it.id)", "        if False:\n            agotados.append(it.id)", PEDIDOS),
    # ---------------- gateway ----------------
    Mutacion("M19", "El gateway reenvía cabeceras de identidad escritas por el navegador (suplantación)", "api-gateway/app/main.py",
             '    if contenido is not None:\n        extra["Content-Type"] = "application/json"',
             '    extra.update({"X-Authenticated-" + k[16:].title(): v for k, v in request.headers.items() if k.lower().startswith("x-authenticated-")})\n'
             '    if contenido is not None:\n        extra["Content-Type"] = "application/json"', ACCESO,
             nota="Las cabeceras del navegador se copian con el MISMO nombre que usa el gateway, así que pisan a las verdaderas."),
    Mutacion("M20", "El gateway deja de revisar el rol de la ruta", "api-gateway/app/main.py",
             "        if ruta.roles and not ident.tiene(*ruta.roles):", "        if False:", ACCESO,
             nota="La segunda capa también diría 403; por eso la prueba comprueba que el servicio NI SIQUIERA vio la solicitud."),
    Mutacion("M21", "No se revisa el origen de las solicitudes que modifican datos (CSRF)", "api-gateway/app/main.py",
             "    if not origen_ok(request, exigir):", "    if False:", ACCESO),
    Mutacion("M22", "El límite de solicitudes cree en X-Forwarded-For", "api-gateway/app/main.py",
             '    return request.client.host if request.client else "desconocida"',
             '    return request.headers.get("x-forwarded-for") or (request.client.host if request.client else "desconocida")', LIMITES),
    Mutacion("M23", "La cookie de sesión queda legible por JavaScript", "api-gateway/app/main.py",
             'max_age=d["expires_in"], httponly=True,', 'max_age=d["expires_in"], httponly=False,', LIMITES),
    Mutacion("M24", "No hay tope para el tamaño del cuerpo de una solicitud", "api-gateway/app/main.py",
             "        if total > maximo:", "        if False:", ACCESO),
    Mutacion("M25", "El servicio privado no verifica el secreto del llamador", "common/seguridad.py",
             "            if not hmac.compare_digest(presentado.encode(), esperado.encode()):", "            if False:", ACCESO + VAULT),
    Mutacion("M26", "Un servicio acepta a cualquier llamador conocido en cualquier ruta", "common/seguridad.py",
             "            if not NOMBRE_RE.fullmatch(nombre) or nombre not in permitidos:", "            if not NOMBRE_RE.fullmatch(nombre):", CAPA2 + ACCESO),
    Mutacion("M27", "Se acepta identidad de usuario enviada por cualquier servicio", "common/seguridad.py",
             'IDENTIDAD_CONFIABLE = frozenset({"api-gateway", "graphql-gateway", "orders"})',
             'IDENTIDAD_CONFIABLE = frozenset({"api-gateway", "graphql-gateway", "orders", "payments", "notifications", "analytics", "inventory", "clients", "auth"})', CAPA2),
    Mutacion("M28", "El servicio privado no aplica la segunda capa de roles", "common/seguridad.py",
             "            if roles and not (ident and ident.tiene(*roles)):", "            if False:", CAPA2 + PEDIDOS,
             nota="Antes sobrevivía: el gateway ya filtra por rol. Ahora la prueba de segunda capa llama a cada servicio directo con un rol equivocado."),
    # ---------------- GraphQL ----------------
    Mutacion("M29", "Los permisos por campo de GraphQL no se aplican", "graphql-gateway/app/schema.py",
             "            return info.context.identidad.tiene(*roles)", "            return True", GQL),
    Mutacion("M30", "No hay límite de costo en las consultas GraphQL", "graphql-gateway/app/limites.py",
             "COSTO_MAXIMO = 1500", "COSTO_MAXIMO = 10**9", GQL),
    Mutacion("M31", "La introspección de GraphQL queda abierta", "graphql-gateway/app/schema.py",
             "        DisableIntrospection,                             # el esquema no se puede explorar desde fuera", "", GQL),
    Mutacion("M32", "No hay límite de profundidad en GraphQL", "graphql-gateway/app/schema.py",
             "MAX_PROFUNDIDAD = 6", "MAX_PROFUNDIDAD = 1000", GQL),
    Mutacion("M33", "GraphQL muestra errores internos al usuario", "graphql-gateway/app/schema.py",
             "    registrar_inesperado(e)\n    return True", "    return False", GQL),
    Mutacion("M34", "Un «limit» negativo resta costo a la consulta", "graphql-gateway/app/limites.py",
             "                    return max(1, min(int(a.value.value), LIMITE_MAXIMO))", "                    return min(int(a.value.value), LIMITE_MAXIMO)", GQL),
    # ---------------- auth ----------------
    Mutacion("M35", "Las cuentas no se bloquean tras varios intentos fallidos", "auth-service/app/main.py",
             "            if n >= MAX_FALLIDOS:", "            if False:", LIMITES),
    Mutacion("M36", "Un usuario desactivado puede seguir entrando", "auth-service/app/main.py",
             '    if not (coincide and u and u["activo"] and not bloqueado):', "    if not (coincide and u and not bloqueado):", ADMINISTRACION),
    Mutacion("M37", "Las sesiones de usuarios desactivados siguen válidas", "auth-service/app/main.py",
             '    if not u or not u["activo"]:\n        return {"active": False}', '    if not u:\n        return {"active": False}', ADMINISTRACION,
             nota="SOBREVIVE A PROPÓSITO (defensa en profundidad): desactivar a alguien YA revoca sus sesiones (_revocar), así que por HTTP no hay "
                  "forma de verlo. Esta comprobación solo cierra la carrera «login en curso mientras se desactiva la cuenta»."),
    Mutacion("M38", "Se aceptan contraseñas muy cortas", "auth-service/app/reglas.py",
             "    if len(clave) < 8:", "    if len(clave) < 1:", ADMINISTRACION + PAGOS),
    # ---------------- Vault y analítica ----------------
    Mutacion("M39", "Un secreto revocado en Vault se sigue usando desde la memoria", "common/vault_secrets.py",
             "        if respuesta.status_code in (403, 404):   # revocado a propósito: no se sigue usando el valor viejo", "        if False:", VAULT),
    Mutacion("M40", "Una anulación puede ser «revivida» por un registro de venta posterior", "analytics-service/app/main.py",
             '{"$set": campos, "$setOnInsert": {"estado": "vigente"}}', '{"$set": {**campos, "estado": "vigente"}}', ["tests/test_analitica.py"]),
    # ---------------- logs ----------------
    Mutacion("M41", "El log de un login fallido deja la contraseña escrita", "auth-service/app/main.py",
             '        log.info("login rechazado")  # sin usuario ni clave en el log', '        log.info("login rechazado " + username + " " + datos.password)', LOGS),
    Mutacion("M42", "El log del registro deja el correo y el RUN del cliente", "clients-service/app/main.py",
             "    await _bienvenida(client_id, datos.nombre, datos.correo, ll)\n    return dto(doc)",
             '    log.info("cliente registrado %s %s", datos.correo, datos.run)\n    await _bienvenida(client_id, datos.nombre, datos.correo, ll)\n    return dto(doc)', LOGS),
    Mutacion("M43", "El log del gateway deja escrito el token de sesión", "api-gateway/app/main.py",
             '    try:\n        r = await interno.llamar("auth", "POST", "/introspect", request_id=request.state.request_id, json={"token": token})',
             '    log.info("introspect " + token)\n    try:\n        r = await interno.llamar("auth", "POST", "/introspect", request_id=request.state.request_id, json={"token": token})', LOGS),
    # ---------------- las mismas rupturas de permisos, vistas solo por llamadas reales (sin comparar con el contrato) ----------------
    Mutacion("M44", "(como M08) Un cliente puede confirmar pagos y reembolsos, visto solo por llamadas reales", "payments-service/app/main.py",
             'ADMIN = Depends(guardia.dep(GW, identidad="requerida", roles=("administrador",)))',
             'ADMIN = Depends(guardia.dep(GW, identidad="requerida", roles=("administrador", "cliente")))', CAPA2_DINAMICA,
             nota="Sin la prueba que compara el código con el contrato: la llamada real al servicio con rol «cliente» debe dar 403 y no lo da."),
    Mutacion("M45", "(como M16) El gateway puede marcar un pedido como pagado, visto solo por llamadas reales", "orders-service/app/main.py",
             'async def pago_confirmado(id: ID, datos: PagoConfirmado, ll=Depends(guardia.dep(("payments",)))):',
             'async def pago_confirmado(id: ID, datos: PagoConfirmado, ll=Depends(guardia.dep(("payments", "api-gateway")))):', CAPA2_DINAMICA),
    Mutacion("M46", "(como M17) Un cliente puede avanzar el despacho, visto solo por llamadas reales", "orders-service/app/main.py",
             'DESPACHO_ESCRIBE = Depends(guardia.dep(GW, identidad="requerida", roles=("administrador", "despacho")))',
             'DESPACHO_ESCRIBE = Depends(guardia.dep(GW, identidad="requerida", roles=("administrador", "despacho", "cliente")))', CAPA2_DINAMICA),
    # ---------------- formato de los logs ----------------
    Mutacion("M47", "El log de una librería deja escrito el texto de la excepción (puede traer credenciales o datos personales)", "common/logs.py",
             '        ajeno = record.name.split(".")[0] in _AJENOS', "        ajeno = False", LOGS_UNIDAD),
    Mutacion("M48", "Las líneas de log pierden el identificador de correlación", "common/logs.py",
             '        if rid:\n            base["request_id"] = rid', '        if False:\n            base["request_id"] = rid', LOGS_UNIDAD),
    Mutacion("M49", "El servicio no fija el identificador de correlación al empezar la solicitud", "common/app.py",
             "        marca = RID.set(request.state.request_id)", "        marca = RID.set(None)", LOGS_UNIDAD),
    # ---------------- Vault colgado (hallazgo de las pruebas contra el Vault real) ----------------
    Mutacion("M50", "El plazo para hablar con Vault vuelve a ser largo (3 s): con Vault colgado el usuario recibe 504", "common/vault_secrets.py",
             '        self.timeout = float(timeout if timeout is not None else os.environ.get("VAULT_TIMEOUT_SECONDS", "1.0"))', "        self.timeout = 3.0", VAULT_CAIDA),
    Mutacion("M51", "Tras un fallo de Vault no se abre la pausa: cada lectura espera otra vez el plazo completo", "common/vault_secrets.py",
             "        self._pausa_hasta = time.monotonic() + self.pausa\n        self._caido = True", "        self._pausa_hasta = 0.0\n        self._caido = True", VAULT),
    Mutacion("M52", "Al arrancar se respeta la pausa y el servicio se rinde sin volver a preguntarle a Vault", "common/vault_secrets.py",
             "            self._pausa_hasta = 0.0\n            try:\n                self.get(ruta)", "            try:\n                self.get(ruta)", VAULT),
    # ---------------- carreras entre pedidos y pagos (hallazgo de la ejecución con MongoDB real) ----------------
    Mutacion("M53", "Si orders pierde la carrera al confirmar un pago, responde 409 en vez de reconocer la confirmación ya aplicada", "orders-service/app/main.py",
             "    for _ in range(INTENTOS_DE_CONFIRMACION):", "    for _ in range(1):", CARRERAS),
    Mutacion("M54", "Cualquier respuesta de orders que no sea 200 hace que payments devuelva el dinero (aunque el pedido sí avanzó)", "payments-service/app/main.py",
             "    if codigo not in RECHAZOS_DE_PEDIDOS:", "    if False:", CARRERAS),
    Mutacion("M55", "Un segundo cobro del mismo pedido (TRANSICION_NO_PERMITIDA) deja de devolverse", "payments-service/app/main.py",
             'frozenset({"PEDIDO_ANULADO", "MONTO_NO_COINCIDE", "TRANSICION_NO_PERMITIDA", "PEDIDO_NO_ENCONTRADO"})',
             'frozenset({"PEDIDO_ANULADO", "MONTO_NO_COINCIDE", "PEDIDO_NO_ENCONTRADO"})', CARRERAS),
    # ---------------- cliente que se desconecta (hallazgo de la prueba de caos con Vault real) ----------------
    Mutacion("M56", "Si quien llamó ya se desconectó, el servicio lo trata como error inesperado y deja una traza que no es JSON en el log", "common/app.py",
             "        except ClientDisconnect:", "        except ZeroDivisionError:", LOGS_UNIDAD),
    Mutacion("M57", "El plazo del gateway vuelve a ser menor que la suma de llamadas internas: cortaría antes que los servicios y el usuario vería un 504 genérico", "common/plazos.py",
             'POR_OMISION = {"gateway": 6.0, "servicio": 2.0, "graphql": 2.0}', 'POR_OMISION = {"gateway": 3.0, "servicio": 2.0, "graphql": 2.0}', ["tests/test_unidad_plazos.py"]),
    Mutacion("M58", "Un servicio vuelve a fijar su propio plazo sin pasar por plazos.py", "payments-service/app/main.py",
             "timeout=plazos.upstream(\"servicio\")", "timeout=float(os.environ.get(\"UPSTREAM_TIMEOUT\", \"4\"))", ["tests/test_unidad_plazos.py"]),
    Mutacion("M59", "El total de ventas del reporte vuelve a ser un Int de 32 bits: un período largo con más de 2.147 millones falla con «Error interno»", "graphql-gateway/app/schema.py",
             "class TotalesVenta:\n    ventas: Monto", "class TotalesVenta:\n    ventas: int", ["tests/test_analitica.py"]),
    Mutacion("M60", "Un error inesperado de GraphQL vuelve a enmascararse sin dejar rastro en el log", "graphql-gateway/app/schema.py",
             "    registrar_inesperado(e)\n    return True", "    return True", ["tests/test_unidad_guardia_graphql.py"]),
    Mutacion("M61", "El enmascarado vuelve a depender de que el error traiga una excepción asociada: un error con ruta pero sin excepción muestra su texto al navegador", "graphql-gateway/app/schema.py",
             "    registrar_inesperado(e)\n    return True", "    registrar_inesperado(e)\n    return e.original_error is not None", ["tests/test_unidad_guardia_graphql.py"]),
    Mutacion("M62", "El Auth Service acepta una sesión vencida: quien conserve la cookie puede seguir usándola", "auth-service/app/main.py",
             'if s["expira"] <= ahora:', "if False:", ["tests/test_sesion_vence.py"]),
]

IGNORAR = shutil.ignore_patterns("__pycache__", "*.pyc", ".git", "docs", "*.zip", ".pytest_cache", "node_modules", "evidencia")


def clasificar(codigo, salida):
    if codigo == 0:
        return "SOBREVIVE"
    if "terminó antes de tiempo" in salida or "no respondió en" in salida or "seed_vault.py falló" in salida:
        return "NO ARRANCA"
    if codigo == 1:
        return "DETECTADA"
    return "ERROR"


def primera_falla(salida):
    lineas = salida.splitlines()
    for prefijo in ("FAILED ", "ERROR tests/"):   # primero la prueba que falló; los «ERROR» sueltos son líneas de log capturadas
        for linea in lineas:
            if linea.startswith(prefijo):
                return linea[:200]
    return ""


def ejecutar(m, copia, timeout):
    destino = copia / m.archivo
    original = destino.read_text(encoding="utf-8")
    if original.count(m.buscar) != 1:
        return {"id": m.id, "resultado": "NO APLICA", "detalle": f"el texto buscado aparece {original.count(m.buscar)} veces"}
    destino.write_text(original.replace(m.buscar, m.reemplazo), encoding="utf-8")
    t0 = time.time()
    intentos = 0
    try:
        while True:
            intentos += 1
            try:
                r = subprocess.run([sys.executable, "-m", "pytest", "-x", "-q", "-p", "no:cacheprovider", "--no-header", *m.pruebas],
                                   cwd=copia, capture_output=True, text=True, timeout=timeout)
                salida = r.stdout + r.stderr
                res = clasificar(r.returncode, salida)
                detalle = primera_falla(salida)
            except subprocess.TimeoutExpired:
                res, detalle = "DETECTADA", "las pruebas se colgaron (tiempo agotado)"
            if res != "NO ARRANCA" or intentos == 2:      # el sistema que no arranca se repite una vez: puede ser una demora del equipo y no el defecto
                break
    finally:
        destino.write_text(original, encoding="utf-8")
    return {"id": m.id, "resultado": res, "detalle": detalle, "segundos": round(time.time() - t0), "intentos": intentos}


def informe(resultados, ruta):
    por_id = {m.id: m for m in MUTACIONES}
    detectadas = sum(1 for r in resultados if r["resultado"] == "DETECTADA")
    total = sum(1 for r in resultados if r["resultado"] in ("DETECTADA", "SOBREVIVE"))
    lineas = ["# Pruebas de mutación", "",
              "Cada fila rompe a propósito UNA regla del sistema (en una copia temporal) y ejecuta las pruebas que deberían notarlo.",
              "**DETECTADA** = alguna prueba falló, como debe ser. **SOBREVIVE** = las pruebas siguen pasando (ver nota).", "",
              f"Resultado: **{detectadas} de {total}** mutaciones detectadas.", "",
              "| Id | Qué se rompió | Resultado | Primera prueba que falló | Nota |", "|---|---|---|---|---|"]
    for r in resultados:
        m = por_id[r["id"]]
        falla = r["detalle"].replace("|", "\\|")
        if r.get("intentos", 1) > 1:
            falla += " (el primer intento no arrancó y se repitió)"
        lineas.append(f"| {m.id} | {m.riesgo} | {r['resultado']} | {falla} | {m.nota} |")
    ruta.parent.mkdir(parents=True, exist_ok=True)
    ruta.write_text("\n".join(lineas) + "\n", encoding="utf-8")
    ruta.with_suffix(".json").write_text(json.dumps(resultados, ensure_ascii=False, indent=1), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ids", nargs="*")
    ap.add_argument("--lista", action="store_true")
    ap.add_argument("--timeout", type=int, default=900)
    ap.add_argument("--salida", default=str(RAIZ / "docs" / "evidencia" / "mutaciones.md"))
    a = ap.parse_args()
    elegidas = [m for m in MUTACIONES if not a.ids or m.id in a.ids]
    if a.lista:
        for m in elegidas:
            print(f"{m.id}  {m.riesgo}  [{m.archivo}]")
        return 0
    with tempfile.TemporaryDirectory(prefix="asador-mutaciones-") as tmp:
        copia = Path(tmp) / "proyecto"
        shutil.copytree(RAIZ, copia, ignore=IGNORAR)
        resultados = []
        for m in elegidas:
            r = ejecutar(m, copia, a.timeout)
            resultados.append(r)
            print(f"{m.id} {r['resultado']:<10} {m.riesgo}  {r.get('detalle', '')[:110]}", flush=True)
        informe(resultados, Path(a.salida))
    sobreviven = [r["id"] for r in resultados if r["resultado"] != "DETECTADA"]
    print("Sobreviven / no aplican:", sobreviven or "ninguna")
    return 0


if __name__ == "__main__":
    sys.exit(main())
