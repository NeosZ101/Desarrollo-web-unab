"""Seguridad de acceso: roles, propiedad de los recursos, acceso directo a servicios privados, sesión, CSRF y entradas hostiles.

Cada prueba cita la regla que comprueba (matriz de permisos del módulo 4) y la capa que la aplica
(gateway = primera capa, servicio = segunda capa).
"""
import itertools

import httpx
import pytest

from ayuda import Api, cargar, lineas_de_log, llamar_servicio, sin_id

pytestmark = pytest.mark.integracion
rutas = cargar("api-gateway/app/rutas.py", "t_rutas")
RUTAS = rutas.RUTAS
ROLES = ("cliente", "administrador", "dueno", "despacho")
EJEMPLOS = {"pedido": "A-999999", "producto": "p01", "cliente": "c-zzzz9999", "usuario": "u-zzzz9999"}
SESION_NECESARIA = [r for r in RUTAS if r.acceso == "sesion"]


@pytest.fixture(scope="module")
def por_rol(admin, dueno, despacho, andrea):
    return {"cliente": andrea, "administrador": admin, "dueno": dueno, "despacho": despacho}


def _ruta(r):
    return r.patron.format(**EJEMPLOS)


def _llamar(api, r):
    return api.pedir(r.metodo, _ruta(r), json={} if r.cuerpo == "json" else None) if r.cuerpo == "json" else api.pedir(r.metodo, _ruta(r))


# ----------------------------- primera capa: el gateway ---------------------------------------------------------
@pytest.mark.parametrize("r", SESION_NECESARIA, ids=lambda r: r.id)
def test_sin_sesion_toda_ruta_protegida_responde_401(anon, r):
    resp = _llamar(anon, r)
    assert resp.status_code == 401 and resp.json()["codigo"] == "NO_AUTENTICADO", (r.id, resp.status_code, resp.text)


@pytest.mark.parametrize("r", [r for r in SESION_NECESARIA if r.roles], ids=lambda r: r.id)
def test_un_rol_no_listado_recibe_403_en_el_gateway(por_rol, r):
    for rol in ROLES:
        if rol in r.roles:
            continue
        resp = _llamar(por_rol[rol], r)
        assert resp.status_code == 403 and resp.json()["codigo"] == "ROL_NO_AUTORIZADO", (r.id, rol, resp.status_code, resp.text)


def _ids_vistos_por(sistema, servicio):
    """Identificadores de correlación que un servicio registró. El gateway consulta SIEMPRE a `auth` (/introspect) para validar la sesión,
    así que esas líneas no cuentan como «la solicitud llegó a la ruta de negocio»."""
    return {l["request_id"] for l in lineas_de_log(sistema, servicio) if l.get("msg") == "solicitud" and l.get("ruta") != "/introspect"}


def test_el_gateway_corta_el_rol_equivocado_antes_de_molestar_al_servicio(sistema, por_rol):
    """Primera capa de verdad: la solicitud de un rol no listado muere en el gateway. El servicio de destino no registra NI UNA línea con
    su identificador de correlación (si el gateway dejara pasar la solicitud, el servicio igual diría 403, pero ya habría sido tocado)."""
    enviados = {}
    for r in (r for r in SESION_NECESARIA if r.roles):
        rol = next(x for x in ROLES if x not in r.roles)
        resp = _llamar(por_rol[rol], r)
        assert resp.status_code == 403 and resp.json()["codigo"] == "ROL_NO_AUTORIZADO", (r.id, rol, resp.status_code, resp.text)
        enviados.setdefault(r.destino, set()).add(resp.json()["request_id"])
    assert len(enviados) >= 5
    for destino, ids in enviados.items():
        vistos = _ids_vistos_por(sistema, destino)
        assert not (ids & vistos), f"{destino} recibió solicitudes que el gateway debió cortar: {sorted(ids & vistos)[:3]}"


def test_sin_sesion_la_solicitud_tampoco_llega_al_servicio(sistema, anon):
    enviados = {}
    for r in SESION_NECESARIA[:20]:
        resp = _llamar(anon, r)
        assert resp.status_code == 401, (r.id, resp.status_code)
        enviados.setdefault(r.destino, set()).add(resp.json()["request_id"])
    for destino, ids in enviados.items():
        vistos = _ids_vistos_por(sistema, destino)
        assert not (ids & vistos), f"{destino} recibió solicitudes sin sesión"


@pytest.mark.parametrize("r", SESION_NECESARIA, ids=lambda r: r.id)
def test_un_rol_listado_pasa_el_gateway_y_nunca_provoca_un_error_500(por_rol, r):
    for rol in (r.roles or ROLES):
        resp = _llamar(por_rol[rol], r)
        assert resp.status_code != 401, (r.id, rol, resp.text)
        assert not (resp.status_code == 403 and resp.json().get("codigo") == "ROL_NO_AUTORIZADO"), (r.id, rol, resp.text)
        assert resp.status_code < 500, (r.id, rol, resp.status_code, resp.text)


def test_la_matriz_de_permisos_del_informe_coincide_con_el_gateway(por_rol):
    """La tabla RUTAS es la fuente única: si alguien edita un rol, la matriz del informe y esta prueba cambian juntas."""
    permitidos = {(r.id, rol) for r in SESION_NECESARIA for rol in (r.roles or ROLES)}
    obtenidos = set()
    for r, rol in itertools.product(SESION_NECESARIA, ROLES):
        resp = _llamar(por_rol[rol], r)
        if not (resp.status_code == 403 and resp.json().get("codigo") == "ROL_NO_AUTORIZADO"):
            obtenidos.add((r.id, rol))
    assert obtenidos == permitidos


@pytest.mark.parametrize("metodo", ["GET", "POST", "PUT", "DELETE", "PATCH"])
@pytest.mark.parametrize("ruta", ["/api/no-existe", "/api/internal/orders/A-1038/payable", "/api/admin/orders/summary", "/api/orders/A-1038/payment-confirmed",
                                  "/api/auth/introspect", "/api/users/u-admin/password", "/api/%2e%2e/%2e%2e/etc/passwd"])
def test_lo_que_no_esta_en_la_tabla_no_se_reenvia(anon, metodo, ruta):
    r = anon.pedir(metodo, ruta, json={} if metodo != "GET" else None) if metodo != "GET" else anon.get(ruta)
    assert r.status_code in (404,) and r.json()["codigo"] in ("RUTA_NO_ENCONTRADA", "NO_ENCONTRADO"), (metodo, ruta, r.status_code, r.text)


def test_metodo_no_listado_en_una_ruta_existente(admin):
    assert admin.pedir("PATCH", "/api/products/p01", json={"precio": 1}).status_code == 404
    assert admin.put("/api/orders/A-1038", json={"estado": "Entregado"}).status_code == 404
    assert admin.delete("/api/orders/A-1038").status_code == 404


@pytest.mark.parametrize("ruta", ["/api/orders/A-1038;rm", "/api/orders/a-1038", "/api/orders/A-1", "/api/orders/A-1038%00", "/api/orders/A-1038%2F..%2F..",
                                  "/api/products/P01", "/api/products/p01'--", "/api/clients/C-0001"])
def test_parametros_de_ruta_con_formato_invalido(admin, ruta):
    r = admin.get(ruta) if "/products/" not in ruta else admin.put(ruta, json={})
    assert r.status_code in (400, 404), (ruta, r.status_code, r.text)
    assert r.status_code != 500


# ----------------------------- segunda capa: propiedad de los recursos (BOLA) ----------------------------------------
def test_un_cliente_no_ve_el_pedido_de_otro_y_la_respuesta_no_revela_si_existe(andrea):
    ajeno = andrea.get("/api/orders/A-1039")            # pedido real de Felipe
    inexistente = andrea.get("/api/orders/A-999999")
    assert ajeno.status_code == inexistente.status_code == 403
    assert sin_id(ajeno.json()) == sin_id(inexistente.json())
    assert "Felipe" not in ajeno.text and "felipe" not in ajeno.text and "Las Condes" not in ajeno.text
    assert andrea.get("/api/orders/A-1038").status_code == 200                       # el suyo, sí


def test_un_cliente_solo_lista_sus_pedidos(andrea, felipe):
    mios = andrea.get("/api/orders?limit=50").json()
    assert {p["id"] for p in mios} >= {"A-1038"} and "A-1039" not in {p["id"] for p in mios}
    assert all("clienteId" not in p for p in mios)                                    # el cliente no recibe identificadores internos
    assert felipe.get("/api/orders?limit=50&clienteId=c-0001").json() == felipe.get("/api/orders?limit=50").json()   # el parámetro se descarta


@pytest.mark.parametrize("metodo,ruta,cuerpo", [("GET", "/api/orders/A-1039/payment", None), ("GET", "/api/orders/A-1039/receipt", None),
                                                ("POST", "/api/orders/A-1041/payment", None),
                                                ("POST", "/api/orders/A-1039/cancellation", {"motivo": "Ya no lo necesito"}),
                                                ("POST", "/api/orders/A-1041/cancellation", {"motivo": "Ya no lo necesito"})])
def test_un_cliente_no_opera_sobre_pedidos_ajenos(andrea, metodo, ruta, cuerpo):
    r = andrea.pedir(metodo, ruta, json=cuerpo) if cuerpo else andrea.pedir(metodo, ruta)
    assert r.status_code == 403 and r.json()["codigo"] == "PROHIBIDO", (ruta, r.status_code, r.text)


def test_el_pedido_ajeno_sigue_intacto_tras_los_intentos(admin):
    assert admin.get("/api/orders/A-1041").json()["estado"] == "Pago pendiente"
    assert admin.get("/api/orders/A-1039").json()["estado"] in ("En camino", "Entregado")


def test_el_personal_si_ve_cualquier_pedido_y_los_datos_de_despacho(admin, despacho):
    for api in (admin, despacho):
        d = api.get("/api/orders/A-1039").json()
        assert d["clienteId"] == "c-0002" and d["cliente"]["direccion"]
    assert admin.get("/api/orders/A-999999").status_code == 404


def test_el_perfil_de_cliente_es_siempre_el_de_la_sesion(andrea, felipe):
    assert andrea.get("/api/clients/me").json()["id"] == "c-0001" and felipe.get("/api/clients/me").json()["id"] == "c-0002"
    assert andrea.get("/api/clients/c-0002").status_code == 404           # no existe ruta para leer un cliente por id desde un cliente
    assert andrea.get("/api/clients").status_code == 403


def test_cabeceras_de_identidad_enviadas_por_el_navegador_se_ignoran(gw, andrea):
    falsas = {"X-Authenticated-User": "u-admin", "X-Authenticated-Username": "admin@elasador.cl", "X-Authenticated-Roles": "administrador",
              "X-Authenticated-Client": "c-0002", "X-Service-Name": "api-gateway", "X-Service-Secret": "cualquiera"}
    assert andrea.get("/api/clients/me", headers=falsas).json()["id"] == "c-0001"
    assert andrea.get("/api/clients", headers=falsas).status_code == 403
    assert andrea.get("/api/orders/A-1039", headers=falsas).status_code == 403
    anonimo = Api(gw)
    assert anonimo.get("/api/admin/orders", headers=falsas).status_code == 401
    assert anonimo.get("/api/auth/me", headers=falsas).json()["usuario"] is None


# ----------------------------- el dueño no ve datos personales ----------------------------------------------------
def test_el_dueno_ve_catalogo_y_reportes_pero_no_clientes_pedidos_ni_pagos(dueno):
    assert dueno.get("/api/products").status_code == 200
    for ruta in ("/api/clients", "/api/admin/orders", "/api/admin/payments", "/api/users", "/api/admin/outbox", "/api/orders/A-1038"):
        assert dueno.get(ruta).status_code == 403, ruta
    r = dueno.gql("{ pedidosAdmin { items { id cliente { correo } } } }")
    assert r.json()["errors"][0]["extensions"]["codigo"] == "PROHIBIDO" and r.json()["data"] is None or r.json()["data"]["pedidosAdmin"] is None


# ----------------------------- acceso directo a los servicios privados --------------------------------------------
PRIVADOS = [("auth", "GET", "/users", "api-gateway"), ("clients", "GET", "/clients", "api-gateway"), ("inventory", "GET", "/internal/summary", "graphql-gateway"),
            ("orders", "GET", "/orders", "api-gateway"), ("payments", "GET", "/admin/payments", "api-gateway"), ("notifications", "GET", "/outbox", "api-gateway"),
            ("analytics", "GET", "/internal/reports/sales?desde=2026-01-01&hasta=2026-01-02", "graphql-gateway"), ("graphql-gateway", "POST", "/graphql", "api-gateway")]


@pytest.mark.parametrize("servicio,metodo,ruta,llamador", PRIVADOS, ids=[p[0] for p in PRIVADOS])
def test_servicio_privado_rechaza_llamadas_sin_credencial(sistema, servicio, metodo, ruta, llamador):
    r = llamar_servicio(sistema, servicio, metodo, ruta, como=llamador, sin_credencial=True)
    assert r.status_code == 403 and r.json()["codigo"] == "LLAMADOR_NO_PERMITIDO"


@pytest.mark.parametrize("servicio,metodo,ruta,llamador", PRIVADOS, ids=[p[0] for p in PRIVADOS])
def test_servicio_privado_rechaza_secreto_equivocado(sistema, servicio, metodo, ruta, llamador):
    r = llamar_servicio(sistema, servicio, metodo, ruta, como=llamador, secreto="secreto-inventado")
    assert r.status_code == 403 and r.json()["codigo"] == "SECRETO_INVALIDO", (servicio, r.text)


def test_el_secreto_de_un_par_no_sirve_para_otro_destino(sistema):
    secreto_a_orders = sistema.secreto("svc/api-gateway-to-orders")
    r = llamar_servicio(sistema, "inventory", "GET", "/internal/summary", como="graphql-gateway", secreto=secreto_a_orders)
    assert r.status_code == 403 and r.json()["codigo"] == "SECRETO_INVALIDO"
    r = llamar_servicio(sistema, "inventory", "GET", "/products", como="api-gateway", secreto=secreto_a_orders)
    assert r.status_code == 403 and r.json()["codigo"] == "SECRETO_INVALIDO"


def test_los_secretos_de_cada_par_son_distintos(sistema):
    pares = ["svc/api-gateway-to-orders", "svc/api-gateway-to-payments", "svc/api-gateway-to-inventory", "svc/orders-to-payments", "svc/payments-to-orders",
             "svc/graphql-gateway-to-orders", "svc/clients-to-auth", "provider/api-key", "provider/webhook-secret"]
    valores = [sistema.secreto(p) for p in pares]
    assert len(set(valores)) == len(valores) and all(len(v) >= 32 for v in valores)


def test_un_servicio_no_puede_llamar_rutas_que_no_le_corresponden(sistema):
    # payments solo conoce de orders las rutas /internal/orders/... : el resto de orders le está vedado aunque tenga secreto válido
    r = llamar_servicio(sistema, "orders", "GET", "/orders/A-1038", como="payments")
    assert r.status_code == 403 and r.json()["codigo"] == "LLAMADOR_NO_PERMITIDO"
    # y el gateway no puede invocar los contratos internos entre servicios
    r = llamar_servicio(sistema, "orders", "GET", "/internal/orders/A-1038/payable", como="api-gateway")
    assert r.status_code == 403 and r.json()["codigo"] == "LLAMADOR_NO_PERMITIDO"
    r = llamar_servicio(sistema, "payments", "POST", "/internal/orders/A-1041/payment-cancel", como="api-gateway", json={"motivo": "x"})
    assert r.status_code == 403
    r = llamar_servicio(sistema, "analytics", "POST", "/internal/events/sale-reversed", como="graphql-gateway", json={"eventoId": "reverso:B-000001", "ventaId": "B-000001"})
    assert r.status_code == 403 and r.json()["codigo"] == "LLAMADOR_NO_PERMITIDO"


CLIENTE_C1 = {"user": "u-c0001", "username": "andrea.molina@correo.cl", "roles": "cliente", "client": "c-0001"}


def test_el_graphql_gateway_es_de_solo_lectura_aunque_tenga_su_secreto(sistema):
    """Mínimo privilegio por operación: orders acepta al GraphQL Gateway para leer, nunca para crear, anular ni avanzar pedidos."""
    leer = llamar_servicio(sistema, "orders", "GET", "/orders", como="graphql-gateway", identidad=CLIENTE_C1)
    assert leer.status_code == 200
    escribir = [
        llamar_servicio(sistema, "orders", "POST", "/orders", como="graphql-gateway", identidad=CLIENTE_C1, json={"items": [{"id": "p07", "cantidad": 1}], "comuna": "Ñuñoa"}),
        llamar_servicio(sistema, "orders", "POST", "/orders/A-1041/cancellation", como="graphql-gateway", identidad=CLIENTE_C1, json={"motivo": "Ya no lo necesito"}),
        llamar_servicio(sistema, "orders", "PUT", "/admin/orders/A-1040/status", como="graphql-gateway",
                        identidad={"user": "u-despacho", "roles": "despacho"}, json={"estado": "En camino"}),
    ]
    assert [r.status_code for r in escribir] == [403, 403, 403] and all(r.json()["codigo"] == "LLAMADOR_NO_PERMITIDO" for r in escribir)


def test_solo_los_llamadores_de_confianza_pueden_afirmar_una_identidad(sistema):
    admin_falso = {"user": "u-admin", "username": "admin@elasador.cl", "roles": "administrador"}
    # `clients` tiene secreto válido hacia notifications, pero el outbox solo admite al API Gateway
    r = llamar_servicio(sistema, "notifications", "GET", "/outbox", como="clients", identidad=admin_falso)
    assert r.status_code == 403 and r.json()["codigo"] == "LLAMADOR_NO_PERMITIDO"
    # `payments` tampoco puede hacerse pasar por un cliente al hablar con auth/orders
    r = llamar_servicio(sistema, "orders", "GET", "/orders", como="payments", identidad=CLIENTE_C1)
    assert r.status_code == 403
    # Frontera de confianza documentada: el API Gateway SÍ puede afirmar una identidad (por eso su secreto es el más protegido)
    r = llamar_servicio(sistema, "notifications", "GET", "/outbox", como="api-gateway", identidad=admin_falso)
    assert r.status_code == 200


def test_una_identidad_mal_formada_o_sin_roles_validos_se_trata_como_ausente(sistema):
    for roles in ("superusuario", "", "ADMINISTRADOR"):
        r = llamar_servicio(sistema, "notifications", "GET", "/outbox", como="api-gateway", identidad={"user": "u-x", "roles": roles})
        assert r.status_code == 401, roles
    r = llamar_servicio(sistema, "notifications", "GET", "/outbox", como="api-gateway", identidad={"user": "../../etc", "roles": "administrador"})
    assert r.status_code == 401
    r = llamar_servicio(sistema, "notifications", "GET", "/outbox", como="api-gateway", identidad={"user": "u-x", "roles": "cliente"})
    assert r.status_code == 403        # rol válido pero sin permiso: segunda capa


@pytest.mark.parametrize("servicio", ["auth", "clients", "inventory", "orders", "payments", "notifications", "analytics", "graphql-gateway", "api-gateway"])
def test_documentacion_automatica_desactivada_y_health_minimo(sistema, servicio):
    base = sistema.urls[servicio]
    for ruta in ("/docs", "/redoc", "/openapi.json"):
        assert httpx.get(base + ruta, timeout=5).status_code in (404,), (servicio, ruta)
    h = httpx.get(base + "/health", timeout=5)
    assert h.status_code == 200 and set(h.json()) == {"status", "service"}
    ready = httpx.get(base + "/ready", timeout=5)
    assert ready.status_code == 200 and ready.json()["status"] == "LISTO"


# ----------------------------- sesión y cookie -----------------------------------------------------------------------
def test_la_cookie_de_sesion_es_httponly_y_el_token_no_viaja_en_el_cuerpo(gw):
    a = Api(gw)
    r = a.post("/api/auth/login", json={"username": "andrea.molina@correo.cl", "password": "cliente123"})
    cookie = r.headers["set-cookie"].lower()
    assert r.status_code == 200 and "session_token=" in cookie and "httponly" in cookie and "samesite=lax" in cookie and "path=/" in cookie
    token = a.c.cookies.get("session_token")
    assert token and len(token) >= 40 and token not in r.text
    assert set(r.json()) == {"usuario", "expira_en"} and "token" not in r.text.lower() and "password" not in r.text.lower()
    me = a.get("/api/auth/me")
    assert me.json()["usuario"]["client_id"] == "c-0001" and token not in me.text


def test_credenciales_incorrectas_no_revelan_si_el_usuario_existe(anon):
    a = anon.post("/api/auth/login", json={"username": "andrea.molina@correo.cl", "password": "incorrecta1"})
    b = anon.post("/api/auth/login", json={"username": "no.existe@correo.cl", "password": "incorrecta1"})
    assert a.status_code == b.status_code == 401 and sin_id(a.json()) == sin_id(b.json())
    assert "set-cookie" not in a.headers


@pytest.mark.parametrize("cuerpo", [{"username": {"$ne": ""}, "password": {"$ne": ""}}, {"username": "a@b.cl"}, {"username": "a@b.cl", "password": "x", "extra": 1},
                                    {"username": ["a@b.cl"], "password": "x"}, [], "texto", {"username": "x" * 200, "password": "x"}])
def test_login_rechaza_entradas_que_no_son_texto(anon, cuerpo):
    r = anon.post("/api/auth/login", json=cuerpo)
    assert r.status_code == 400 and r.json()["codigo"] == "SOLICITUD_INVALIDA"


def test_cerrar_sesion_la_revoca_en_el_servidor(gw):
    a = Api(gw)
    a.login("andrea.molina@correo.cl", "cliente123")
    robada = a.c.cookies.get("session_token")
    assert a.get("/api/orders").status_code == 200
    out = a.post("/api/auth/logout")
    assert out.status_code == 200 and "max-age=0" in out.headers["set-cookie"].lower()
    atacante = Api(gw)
    atacante.c.cookies.set("session_token", robada)
    r = atacante.get("/api/orders")
    assert r.status_code == 401 and r.json()["codigo"] == "SESION_NO_VALIDA"        # la cookie robada ya no sirve
    assert atacante.get("/api/auth/me").json()["usuario"] is None


def test_cookie_basura_se_trata_como_sin_sesion(gw):
    a = Api(gw)
    a.c.cookies.set("session_token", "no-es-un-token")
    assert a.get("/api/auth/me").json()["usuario"] is None
    r = a.get("/api/orders")
    assert r.status_code == 401 and "session_token" in r.headers.get("set-cookie", "")


# ----------------------------- CSRF: el origen debe ser el sitio -----------------------------------------------------------
def test_una_solicitud_que_modifica_datos_debe_venir_de_este_sitio(gw, andrea):
    cuerpo = {"items": [{"id": "p07", "cantidad": 1}], "comuna": "Ñuñoa"}
    for origen in ("https://evil.example", "http://localhost:9999", "null", gw + ".evil.example"):
        r = andrea.post("/api/orders", json=cuerpo, headers={"Origin": origen})
        assert r.status_code == 403 and r.json()["codigo"] == "ORIGEN_NO_PERMITIDO", origen
    sin_origen = httpx.Client(base_url=gw, cookies=dict(andrea.c.cookies), timeout=10)
    r = sin_origen.post("/api/orders", json=cuerpo)
    assert r.status_code == 403 and r.json()["codigo"] == "ORIGEN_NO_PERMITIDO"                       # con cookie y sin Origin ni Referer
    r = sin_origen.post("/api/orders", json={}, headers={"Referer": gw + "/index.html"})
    assert r.status_code == 422                                                                       # Referer del sitio: pasa el control de origen
    r = sin_origen.post("/api/orders", json={}, headers={"Referer": "https://evil.example/" + gw})
    assert r.status_code == 403


def test_el_login_tampoco_acepta_un_origen_ajeno(anon):
    r = anon.post("/api/auth/login", json={"username": "andrea.molina@correo.cl", "password": "cliente123"}, headers={"Origin": "https://evil.example"})
    assert r.status_code == 403 and "set-cookie" not in r.headers


def test_las_lecturas_no_exigen_origen(gw, andrea):
    solo_cookie = httpx.Client(base_url=gw, cookies=dict(andrea.c.cookies), timeout=10)
    assert solo_cookie.get("/api/orders").status_code == 200


# ----------------------------- cabeceras de seguridad -------------------------------------------------------------------------
def test_cabeceras_de_seguridad_en_todas_las_respuestas(anon):
    for ruta in ("/api/products", "/api/no-existe", "/", "/no-existe"):
        h = anon.get(ruta).headers
        csp = h["content-security-policy"]
        assert "script-src 'self'" in csp and "'unsafe-eval'" not in csp and "frame-ancestors 'none'" in csp and "object-src 'none'" in csp, ruta
        assert "script-src 'self' 'unsafe-inline'" not in csp
        assert h["x-content-type-options"] == "nosniff" and h["x-frame-options"] == "DENY"
        assert h["referrer-policy"] == "strict-origin-when-cross-origin" and "camera=()" in h["permissions-policy"]
    assert anon.get("/api/products").headers["cache-control"] in ("no-store",)
    assert "strict-transport-security" not in anon.get("/api/products").headers          # sin HTTPS no se envía HSTS


# ----------------------------- entradas hostiles ---------------------------------------------------------------------------------
def test_cuerpo_que_no_es_json_o_demasiado_grande(admin, anon):
    assert admin.post("/api/products", content="{no es json", headers={"Content-Type": "application/json"}).json()["codigo"] == "JSON_INVALIDO"
    assert admin.post("/api/products", content="a=1", headers={"Content-Type": "application/x-www-form-urlencoded"}).status_code == 415
    grande = admin.post("/api/products", content='{"x":"' + "a" * 20000 + '"}', headers={"Content-Type": "application/json"})
    assert grande.status_code == 413 and grande.json()["codigo"] == "CUERPO_DEMASIADO_GRANDE"
    profundo = admin.post("/api/products", content="[" * 8000 + "]" * 8000, headers={"Content-Type": "application/json"})
    assert profundo.status_code in (400, 422) and "codigo" in profundo.json()                                 # el servidor sigue respondiendo con un error controlado
    assert anon.get("/api/auth/me").status_code == 200
    assert anon.get("/api/products?q=" + "a" * 5000).status_code in (200, 400)                                  # parámetros largos se descartan


def test_el_tope_de_tamano_tambien_corta_cuerpos_enviados_por_trozos(admin):
    """Quien envía el cuerpo «por trozos» no declara su tamaño: el gateway lo corta apenas supera el máximo, sin leerlo completo."""
    leidos = []

    def trozos():
        yield b'{"x":"'
        for _ in range(60):
            leidos.append(1)
            yield b"a" * 1000
        yield b'"}'

    r = admin.post("/api/products", content=trozos(), headers={"Content-Type": "application/json"})
    assert r.status_code == 413 and r.json()["codigo"] == "CUERPO_DEMASIADO_GRANDE", r.text


def test_inyeccion_en_busquedas_y_filtros_se_trata_como_texto(admin, anon):
    assert anon.get("/api/products?q=.*").json() == []                                # la búsqueda escapa los metacaracteres
    assert anon.get("/api/products?q=%24ne").json() == []
    assert admin.get("/api/clients?q=.*").json() == []
    assert admin.get("/api/clients?q[$ne]=x").status_code == 200                      # parámetros anidados: se descartan
    assert admin.get("/api/clients?q=" + "%7B%22%24ne%22%3A1%7D").json() == []
    assert anon.get("/api/products?categoria=parrilladas'%20OR%20'1'='1").status_code == 400


def test_paginacion_con_limites(admin):
    assert admin.get("/api/clients?limit=1000000").status_code == 400
    assert admin.get("/api/clients?limit=0").status_code == 400
    assert admin.get("/api/clients?offset=-1").status_code == 400
    assert admin.get("/api/clients?limit=abc").status_code == 400
    assert admin.get("/api/orders?limit=1").status_code in (200, 403)


def test_asignacion_masiva_y_campos_internos_no_se_aceptan(admin, anon):
    producto = {"nombre": "Producto de prueba", "categoria": "bebidas", "precio": 2500, "descripcion": "Descripción de prueba.", "imagen": "img/cerveza.svg"}
    for extra in ({"eliminado": False}, {"_id": "p99"}, {"creadoEn": "2020-01-01"}, {"id": "p99"}):
        assert admin.post("/api/products", json={**producto, **extra}).status_code == 422, extra
    registro = {"run": "11.111.111-1", "nombre": "Prueba Hostil", "telefono": "+56 9 1234 5678", "direccion": "Calle Falsa 123", "comuna": "Ñuñoa",
                "correo": "hostil@correo.cl", "nacimiento": "1990-01-01", "sexo": "Otro", "region": "Región Metropolitana de Santiago", "provincia": "Santiago",
                "clave": "clave-segura-123"}
    for extra in ({"rol": "administrador"}, {"estado": "activo"}, {"origen": "Local"}, {"authUserId": "u-admin"}, {"roles": ["administrador"]}):
        assert anon.post("/api/clients/register", json={**registro, **extra}).status_code == 422, extra
    for extra in ({"activo": True}, {"roles": ["administrador"]}, {"passwordHash": "x"}):
        assert admin.post("/api/users", json={"username": "x@elasador.cl", "nombre": "Prueba", "rol": "despacho", "password": "Clave-Larga-123", **extra}).status_code == 422


def test_los_errores_nunca_filtran_detalles_internos(admin, anon, andrea):
    respuestas = [anon.get("/api/orders"), andrea.get("/api/orders/A-1039"), admin.post("/api/products", json={"x": 1}), admin.get("/api/clients?limit=abc"),
                  anon.post("/api/auth/login", content="{", headers={"Content-Type": "application/json"}), anon.get("/api/nada"),
                  admin.gql("{ campoInexistente }"), admin.post("/api/graphql", json={"query": "{"})]
    prohibido = ("Traceback", 'File "', "pymongo", "mongomock", "motor", "uvicorn", "starlette", "pydantic", "127.0.0.1", "orders-service", "inventory-service",
                 "payments-service", "auth-service", "VAULT", "Vault", "asador/", "X-Service", "secret", "NoneType", "KeyError")
    for r in respuestas:
        for palabra in prohibido:
            assert palabra not in r.text, (r.request.url.path, palabra, r.text[:300])
        if r.headers.get("content-type", "").startswith("application/json") and r.status_code >= 400 and "errors" not in r.text:
            assert {"detail", "codigo"} <= set(r.json()), r.text
