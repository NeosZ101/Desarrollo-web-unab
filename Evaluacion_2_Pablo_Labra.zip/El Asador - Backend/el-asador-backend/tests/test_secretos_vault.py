"""Secretos: mínimo privilegio en Vault, valores aleatorios, rotación, revocación y comportamiento si Vault cae.

Alcance: por defecto estas pruebas usan un Vault FALSO (tests/fake_vault.py) que imita la lectura KV v2 y las políticas por ruta.
Con ASADOR_REAL=1 (ver tests/stack.py) corren contra un HashiCorp Vault REAL en modo desarrollo: son las MISMAS pruebas, y las tres que
necesitan romper cosas lo hacen con la API de Vault (borrar el secreto) o congelando su proceso, en vez de usar los ganchos del falso.
"""
import asyncio
import csv
import logging
import os
import re
import subprocess
import sys
import time

import httpx
import pytest

from ayuda import RAIZ, Api, cliente_nuevo, crear_pedido, esperar, llamar_servicio
from analisis_codigo import SERVICIOS, guardias, nombre_propio, pares_aceptados
from stack import CARPETAS, REAL

pytestmark = pytest.mark.integracion
OPCIONALES = {"email/smtp"}      # solo existen si el operador entrega el valor real


def manifiesto():
    with open(RAIZ / "secrets" / "manifest.tsv", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f, delimiter="\t"))


def partes(texto):
    return [x for x in texto.split(",") if x]


def usan(fila):
    return set(partes(fila["consumidores"])) | set(partes(fila["verificadores"]))


def leer(stack, token, ref):
    return httpx.get(f"{stack.vault_url}/v1/secret/data/asador/{ref}", headers={"X-Vault-Token": token}, timeout=5)


# ----------------------------- mínimo privilegio ---------------------------------------------------------------------------------
@pytest.mark.parametrize("servicio", sorted(CARPETAS))
def test_cada_servicio_solo_lee_los_secretos_que_el_inventario_le_asigna(sistema, servicio):
    for fila in manifiesto():
        r = leer(sistema, sistema.tokens[servicio], fila["ref"])
        if servicio in usan(fila):
            assert r.status_code == 200 or (r.status_code == 404 and fila["ref"] in OPCIONALES), (servicio, fila["ref"], r.status_code)
        else:
            assert r.status_code == 403, (servicio, fila["ref"], r.status_code)


def test_los_llamadores_que_acepta_cada_servicio_son_exactamente_los_del_inventario_de_secretos():
    """Se lee el código: si un servicio acepta a un llamador que no tiene secreto propio (o existe un secreto que nadie usa), la prueba falla."""
    en_inventario = {tuple(f["ref"][4:].split("-to-")) for f in manifiesto() if f["ref"].startswith("svc/")}
    assert pares_aceptados() == en_inventario, (pares_aceptados() - en_inventario, en_inventario - pares_aceptados())
    assert len(en_inventario) == 20
    for fila in manifiesto():
        if fila["ref"].startswith("svc/"):
            origen, destino = fila["ref"][4:].split("-to-")
            assert partes(fila["consumidores"]) == [origen] and partes(fila["verificadores"]) == [destino]     # una credencial por par, nunca compartida


def test_cada_servicio_se_identifica_con_su_propio_nombre_en_la_guardia():
    for svc in SERVICIOS:
        if svc != "api-gateway":                                                          # el gateway no recibe llamadas de servicios
            assert nombre_propio(svc) == svc


def test_solo_los_llamadores_de_confianza_pueden_afirmar_la_identidad_de_un_usuario():
    """Una ruta que exige identidad de usuario solo puede admitir servicios que verifican la sesión o propagan la ya verificada."""
    from common.seguridad import IDENTIDAD_CONFIABLE, ROLES
    for svc in SERVICIOS:
        for llamadores, identidad, roles in guardias(svc):
            assert set(roles) <= set(ROLES), (svc, roles)
            if identidad != "ninguna":
                assert set(llamadores) <= IDENTIDAD_CONFIABLE, (svc, llamadores)
            if roles:
                assert identidad == "requerida", (svc, roles)                                # un rol sin identidad requerida no protegería nada


def test_ningun_servicio_puede_escribir_secretos_ni_crear_politicas_ni_tokens(sistema):
    for servicio, token in sistema.tokens.items():
        h = {"X-Vault-Token": token}
        assert httpx.post(f"{sistema.vault_url}/v1/secret/data/asador/svc/{servicio}-to-x", headers=h, json={"data": {"value": "x"}}).status_code == 403
        assert httpx.put(f"{sistema.vault_url}/v1/sys/policies/acl/otra", headers=h, json={"policy": "{}"}).status_code == 403
        assert httpx.post(f"{sistema.vault_url}/v1/auth/token/create", headers=h, json={"id": "s.nuevo", "policies": [servicio]}).status_code == 403


def test_un_token_inventado_o_vacio_no_lee_nada(sistema):
    for token in ("", "s.inventado", "x" * 64):
        assert leer(sistema, token, "svc/api-gateway-to-auth").status_code == 403


# ----------------------------- los valores ----------------------------------------------------------------------------------------
def test_los_secretos_son_aleatorios_distintos_y_con_entropia_suficiente(sistema):
    vistos = {}
    for fila in manifiesto():
        ref = fila["ref"]
        if fila["tipo"] == "credencial-bd" or ref in OPCIONALES:
            continue
        for campo in partes(fila["campos"]):
            v = sistema.secreto(ref, campo)
            assert len(v) >= 43 and re.fullmatch(r"[A-Za-z0-9_-]+", v), (ref, campo)      # token_urlsafe(32) = 256 bits
            assert v not in vistos, f"{ref} repite el valor de {vistos[v]}"
            vistos[v] = f"{ref}.{campo}"
    assert len(vistos) == 22                                                                # 20 pares de servicio + clave del proveedor + clave de firma


def test_cada_servicio_tiene_su_propio_usuario_de_base_de_datos(sistema):
    usuarios, claves = set(), set()
    for fila in manifiesto():
        if fila["tipo"] != "credencial-bd":
            continue
        servicio = fila["consumidores"]
        u, c = sistema.secreto(fila["ref"], "user"), sistema.secreto(fila["ref"], "password")
        assert u == f"u_{servicio}" and len(c) >= 20
        usuarios.add(u)
        claves.add(c)
    assert len(usuarios) == len(claves) == 7


# ----------------------------- semillero: idempotencia y rotación -----------------------------------------------------------------------
def semillar(stack, *args):
    env = {**os.environ, "VAULT_ADDR": stack.vault_url, "VAULT_ROOT_TOKEN": stack.root_token}
    for n in CARPETAS:
        clave = n.upper().replace("-", "_")
        env[f"VAULT_TOKEN_{clave}"], env[f"MONGO_PASS_{clave}"] = stack.tokens[n], "clave-de-relleno-" + clave
    return subprocess.run([sys.executable, str(RAIZ / "scripts" / "seed_vault.py"), *args], env=env, capture_output=True, text=True, timeout=60)


def todos_los_valores(stack):
    return {(f["ref"], c): stack.secreto(f["ref"], c) for f in manifiesto() if f["ref"] not in OPCIONALES for c in partes(f["campos"])}


def test_el_semillero_es_idempotente_y_no_imprime_secretos(aislado):
    antes = todos_los_valores(aislado)
    r = semillar(aislado)
    assert r.returncode == 0 and "0 escritos" in r.stdout and "Vault listo" in r.stdout, r.stdout + r.stderr
    assert todos_los_valores(aislado) == antes
    for valor in list(antes.values()) + list(aislado.tokens.values()) + [aislado.root_token]:
        assert valor not in r.stdout + r.stderr


def test_rotar_un_secreto_cambia_solo_ese_el_viejo_deja_de_valer_y_el_sistema_sigue(aislado):
    gw = aislado.urls["api-gateway"]
    cliente = cliente_nuevo(gw)
    ruta = "svc/orders-to-clients"
    antes = todos_los_valores(aislado)
    viejo = antes[(ruta, "value")]
    r = semillar(aislado, "--rotar", ruta)
    assert r.returncode == 0 and "1 escritos" in r.stdout, r.stdout + r.stderr
    despues = todos_los_valores(aislado)
    cambiados = {k for k in antes if antes[k] != despues[k]}
    assert cambiados == {(ruta, "value")}
    nuevo = despues[(ruta, "value")]
    # Los servicios recogen el valor nuevo al vencer el TTL de su caché (1 s en las pruebas): el sistema se recompone solo.
    esperar(lambda: crear_pedido(cliente).status_code == 201, segundos=15, mensaje="crear pedidos no volvió a funcionar tras rotar el secreto")
    identidad = {"user": "u-c0001", "roles": "cliente", "client": "c-0001"}
    mal = llamar_servicio(aislado, "clients", "GET", "/internal/clients/c-0001/delivery-profile", como="orders", secreto=viejo, identidad=identidad)
    assert mal.status_code == 403 and mal.json()["codigo"] == "SECRETO_INVALIDO"
    bien = llamar_servicio(aislado, "clients", "GET", "/internal/clients/c-0001/delivery-profile", como="orders", secreto=nuevo, identidad=identidad)
    assert bien.status_code == 200 and bien.json()["id"] == "c-0001"


# ----------------------------- revocación y caída de Vault -------------------------------------------------------------------------
def poner_vault(stack, caido, como="colgado"):
    """Vault «caído». `colgado`: el proceso sigue ahí, acepta la conexión y no contesta (el real se congela con SIGSTOP; el falso retiene las lecturas).
    `sellado` (solo el falso): contesta 503 al instante. Lo colgado es lo difícil: cada espera suma tiempo a la solicitud del usuario."""
    if REAL:
        (stack.congelar if caido else stack.descongelar)("vault")
    else:
        httpx.put(f"{stack.vault_url}/_test/caido/{como if caido else 0}", timeout=5).raise_for_status()


def borrar_secreto(stack, ruta):
    """Revoca un secreto: lo borra de Vault. (Real: borrado lógico de KV v2, la lectura posterior da 404.)"""
    if REAL:
        httpx.delete(f"{stack.vault_url}/v1/secret/data/asador/{ruta}", headers={"X-Vault-Token": stack.root_token}, timeout=5).raise_for_status()
    else:
        httpx.delete(f"{stack.vault_url}/_test/secret/asador/{ruta}", timeout=5).raise_for_status()


def restituir_secreto(stack, ruta, valor):
    if REAL:   # una versión nueva del mismo secreto
        httpx.post(f"{stack.vault_url}/v1/secret/data/asador/{ruta}", headers={"X-Vault-Token": stack.root_token}, json={"data": {"value": valor}}, timeout=5).raise_for_status()
    else:
        httpx.put(f"{stack.vault_url}/_test/secret/asador/{ruta}", json={"value": valor}, timeout=5).raise_for_status()


def test_borrar_un_secreto_lo_revoca_aunque_los_servicios_lo_tengan_en_cache(aislado):
    gw = aislado.urls["api-gateway"]
    c = cliente_nuevo(gw)
    ruta = "svc/api-gateway-to-clients"
    valor = aislado.secreto(ruta)
    assert c.get("/api/clients/me").status_code == 200                                   # caché caliente
    borrar_secreto(aislado, ruta)
    try:
        time.sleep(1.5)                                                                  # vence el TTL de la caché (1 s)
        r = c.get("/api/clients/me")
        assert r.status_code == 503 and r.json()["codigo"] == "SERVICIO_NO_DISPONIBLE"  # el gateway ya no tiene credencial para ese destino
        identidad = {"user": c.usuario["user_id"], "roles": "cliente", "client": c.client_id}
        directo = llamar_servicio(aislado, "clients", "GET", "/clients/me", como="api-gateway", secreto=valor, identidad=identidad)
        assert directo.status_code == 403 and directo.json()["codigo"] == "SECRETO_INVALIDO"      # el destino tampoco acepta la copia vieja
    finally:
        restituir_secreto(aislado, ruta, valor)
    esperar(lambda: c.get("/api/clients/me").status_code == 200, segundos=15, mensaje="no se recuperó al restituir el secreto")


@pytest.mark.parametrize("como", ["colgado", pytest.param("sellado", marks=pytest.mark.skipif(REAL, reason="el Vault real no se puede sellar sin perder sus datos de desarrollo"))])
def test_si_vault_cae_el_sistema_sigue_con_los_secretos_que_ya_tenia_y_se_recupera(aislado, como):
    """Con Vault colgado cada lectura esperaría su plazo; si ese plazo no fuera corto (y la espera no se hiciera una sola vez por pausa),
    las solicitudes de los usuarios superarían el plazo del gateway y responderían 504. Esta prueba lo encontró contra el Vault real."""
    from ayuda import lineas_de_log
    gw = aislado.urls["api-gateway"]
    c = cliente_nuevo(gw)
    crear_pedido(c)                                                                      # calienta orders, clients, inventory
    poner_vault(aislado, True, como)
    try:
        time.sleep(1.5)                                                                  # las cachés ya vencieron: cada servicio debe ir a Vault, que no responde
        inicio = time.monotonic()
        assert c.get("/api/orders").status_code == 200                                   # la primera paga el plazo corto de Vault en cada proceso de la cadena
        assert time.monotonic() - inicio < 2.0, "la espera a Vault no puede acercarse al plazo del gateway"
        assert crear_pedido(c).status_code == 201
        assert "errors" not in c.gql("{ misPedidos(limit: 1) { total } }").json()
        assert Api(gw).get("/api/products").status_code == 200
        assert httpx.get(gw + "/ready", timeout=5).status_code == 200
        time.sleep(1.5)                                                                  # otra vez vencidas: ninguna sola solicitud se queda esperando a Vault
        for _ in range(4):
            inicio = time.monotonic()
            assert c.get("/api/orders").status_code == 200
            assert time.monotonic() - inicio < 2.0
    finally:
        poner_vault(aislado, False)
    avisos = [l for l in lineas_de_log(aislado, "api-gateway") if l.get("logger") == "secretos" and l["msg"].startswith("Vault no disponible")]
    assert avisos, "debía quedar constancia de que se usó la caché"
    assert len(avisos) < 40, "tras un fallo se hace una pausa: el aviso no se repite en cada solicitud"
    valores = [aislado.secreto(f["ref"], cam) for f in manifiesto() if f["tipo"] != "credencial-bd" and f["ref"] not in OPCIONALES for cam in partes(f["campos"])]
    texto = (aislado.logdir / "api-gateway.log").read_text(encoding="utf-8", errors="ignore")
    assert not [v for v in valores if v in texto]                                       # el aviso nombra la ruta, nunca el valor
    time.sleep(1.2)                                                                      # pasada la pausa, la primera lectura vuelve a hablar con Vault
    assert c.get("/api/orders").status_code == 200
    assert any(l.get("logger") == "secretos" and l["msg"] == "Vault respondió de nuevo" for l in lineas_de_log(aislado, "api-gateway"))


def test_un_servicio_no_arranca_sin_vault_ni_inventa_secretos_por_defecto(aislado):
    poner_vault(aislado, True)
    try:
        aislado.apagar("notifications")
        with pytest.raises(RuntimeError, match="terminó antes de tiempo"):
            aislado.encender("notifications")
    finally:
        poner_vault(aislado, False)
    aislado.encender("notifications")                                                    # con Vault de vuelta arranca con normalidad
    assert httpx.get(aislado.urls["notifications"] + "/ready", timeout=5).status_code == 200


# ----------------------------- el cliente de Vault, sin red ---------------------------------------------------------------------------
from common.vault_secrets import SecretUnavailable, VaultSecrets   # noqa: E402


class RespuestaFalsa:
    def __init__(self, estado, datos=None):
        self.status_code, self._datos = estado, datos

    def json(self):
        return {"data": {"data": self._datos, "metadata": {}}}


@pytest.fixture
def vault(monkeypatch):
    """Un «Vault» controlable: `estado['respuesta']` es lo que contesta, `estado['error']` lo que lanza la red y `estado['plazos']` los plazos con que se le habló."""
    estado = {"respuesta": RespuestaFalsa(200, {"value": "valor-1"}), "error": None, "llamadas": 0, "plazos": []}

    def get(url, headers=None, timeout=None):
        estado["llamadas"] += 1
        estado["plazos"].append(timeout)
        if estado["error"]:
            raise estado["error"]
        return estado["respuesta"]

    class ClienteAsincrono:
        def __init__(self, *a, **k):
            self.plazo = k.get("timeout")

        async def __aenter__(self):
            return self

        async def __aexit__(self, *a):
            return False

        async def get(self, url, headers=None):
            return get(url, headers, self.plazo)

    monkeypatch.setattr(httpx, "get", get)
    monkeypatch.setattr(httpx, "AsyncClient", ClienteAsincrono)
    # pausa=0: sin pausa tras un fallo (las pruebas de la pausa piden una explícitamente)
    estado["cliente"] = lambda ttl=60.0, pausa=0.0, timeout=1.0: VaultSecrets(addr="http://vault.invalido", token="s.token-de-prueba", ttl=ttl,
                                                                                timeout=timeout, pausa_tras_fallo=pausa)
    return estado


def test_el_valor_se_reutiliza_durante_el_ttl_y_se_renueva_al_vencer(vault):
    v = vault["cliente"](ttl=0.2)
    assert v.valor("x") == "valor-1" and v.valor("x") == "valor-1" and vault["llamadas"] == 1
    vault["respuesta"] = RespuestaFalsa(200, {"value": "valor-2"})
    assert v.valor("x") == "valor-1"                                                     # aún vigente: no consulta
    time.sleep(0.3)
    assert v.valor("x") == "valor-2" and vault["llamadas"] == 2                          # rotación recogida sin reiniciar nada


@pytest.mark.parametrize("falla", [httpx.ConnectError("sin red"), httpx.ReadTimeout("lento"), RespuestaFalsa(503), RespuestaFalsa(500)], ids=["red", "plazo", "503", "500"])
def test_si_vault_no_responde_se_usa_la_cache_y_sin_cache_se_falla_cerrado(vault, falla):
    v = vault["cliente"](ttl=0.0)
    assert v.valor("x") == "valor-1"
    if isinstance(falla, Exception):
        vault["error"] = falla
    else:
        vault["respuesta"] = falla
    assert v.valor("x") == "valor-1"                                                     # degradación controlada
    with pytest.raises(SecretUnavailable) as e:
        v.valor("otra-ruta-sin-cache")
    assert e.value.revocado is False


@pytest.mark.parametrize("estado", [403, 404])
def test_si_vault_responde_que_el_secreto_ya_no_existe_se_descarta_la_cache(vault, estado):
    v = vault["cliente"](ttl=0.0)
    assert v.valor("x") == "valor-1"
    vault["respuesta"] = RespuestaFalsa(estado)
    with pytest.raises(SecretUnavailable) as e:
        v.valor("x")
    assert e.value.revocado is True
    vault["respuesta"], vault["error"] = RespuestaFalsa(200, {"value": "valor-1"}), httpx.ConnectError("sin red")
    with pytest.raises(SecretUnavailable):                                               # una caída posterior NO resucita el valor revocado
        v.valor("x")


def test_el_cliente_asincrono_se_comporta_igual(vault):
    async def prueba():
        v = vault["cliente"](ttl=0.0)
        assert await v.avalor("x") == "valor-1"
        vault["error"] = httpx.ConnectError("sin red")
        assert await v.avalor("x") == "valor-1"
        vault["error"], vault["respuesta"] = None, RespuestaFalsa(404)
        with pytest.raises(SecretUnavailable) as e:
            await v.avalor("x")
        assert e.value.revocado
    asyncio.run(prueba())


def test_los_avisos_del_cliente_de_vault_no_incluyen_el_valor(vault, caplog):
    v = vault["cliente"](ttl=0.0)
    secreto = v.valor("asador/svc/a-to-b")
    vault["error"] = httpx.ConnectError("sin red")
    with caplog.at_level(logging.DEBUG):
        v.valor("asador/svc/a-to-b")
        with pytest.raises(SecretUnavailable):
            v.valor("asador/svc/otra")
    assert caplog.records and secreto not in caplog.text and "s.token-de-prueba" not in caplog.text


def test_esperar_reintenta_y_luego_falla_con_un_mensaje_claro(vault):
    vault["respuesta"] = RespuestaFalsa(503)
    v = vault["cliente"](ttl=0.0, pausa=60)                                              # aunque haya una pausa abierta, al arrancar cada intento consulta de verdad
    with pytest.raises(SecretUnavailable, match="tras 3 intentos"):
        v.esperar("x", intentos=3, pausa=0)
    assert vault["llamadas"] == 3


# ----------------------------- Vault colgado: plazo corto y pausa tras el fallo -----------------------------------------------------
def test_el_plazo_de_vault_es_corto_y_se_puede_configurar(vault, monkeypatch):
    monkeypatch.delenv("VAULT_TIMEOUT_SECONDS", raising=False)
    monkeypatch.delenv("VAULT_RETRY_AFTER_SECONDS", raising=False)
    v = VaultSecrets(addr="http://vault.invalido", token="s.token-de-prueba")
    assert (v.timeout, v.pausa) == (1.0, 5.0)
    v.valor("x")
    assert vault["plazos"] == [1.0]                                                      # el plazo configurado es el que se le pasa a la red, no el de la librería
    monkeypatch.setenv("VAULT_TIMEOUT_SECONDS", "0.25")
    monkeypatch.setenv("VAULT_RETRY_AFTER_SECONDS", "2")
    w = VaultSecrets(addr="http://vault.invalido", token="s.token-de-prueba")
    assert (w.timeout, w.pausa) == (0.25, 2.0)
    asyncio.run(w.aget("otra"))
    assert vault["plazos"][-1] == 0.25


def test_tras_un_fallo_no_se_vuelve_a_consultar_a_vault_durante_la_pausa(vault):
    v = vault["cliente"](ttl=0.0, pausa=0.3)
    assert v.valor("x") == "valor-1" and vault["llamadas"] == 1
    vault["error"] = httpx.ReadTimeout("colgado")
    assert v.valor("x") == "valor-1" and vault["llamadas"] == 2                          # el sondeo que falla abre la pausa
    for _ in range(5):
        assert v.valor("x") == "valor-1"                                                 # en pausa: copia en caché, sin esperar a Vault
    with pytest.raises(SecretUnavailable) as e:
        v.valor("sin-copia")                                                             # sin copia: falla cerrado al instante
    assert e.value.revocado is False and vault["llamadas"] == 2
    time.sleep(0.35)
    vault["error"], vault["respuesta"] = None, RespuestaFalsa(200, {"value": "valor-2"})
    assert v.valor("x") == "valor-2" and vault["llamadas"] == 3                          # terminada la pausa, UNA prueba y se recupera
    assert v.valor("x") == "valor-2" and vault["llamadas"] == 4                          # ya no hay pausa (ttl=0 consulta cada vez)


def test_una_prueba_fallida_renueva_la_pausa(vault):
    v = vault["cliente"](ttl=0.0, pausa=0.2)
    v.valor("x")
    vault["error"] = httpx.ConnectError("sin red")
    v.valor("x")
    time.sleep(0.25)
    v.valor("x")                                                                         # la prueba vuelve a fallar...
    v.valor("x")
    v.valor("x")                                                                         # ...y las siguientes no insisten
    assert vault["llamadas"] == 3


def test_la_revocacion_se_recoge_cuando_termina_la_pausa_no_antes(vault):
    """Mientras Vault no contesta es imposible enterarse de una revocación; en cuanto se le vuelve a consultar, tiene efecto."""
    v = vault["cliente"](ttl=0.0, pausa=0.2)
    v.valor("x")
    vault["error"] = httpx.ConnectError("sin red")
    v.valor("x")
    vault["error"], vault["respuesta"] = None, RespuestaFalsa(404)
    assert v.valor("x") == "valor-1"                                                     # todavía en pausa: se usa la copia
    time.sleep(0.25)
    with pytest.raises(SecretUnavailable) as e:
        v.valor("x")
    assert e.value.revocado is True


def test_la_pausa_tambien_rige_para_el_cliente_asincrono_y_al_arrancar_se_ignora(vault):
    async def prueba():
        v = vault["cliente"](ttl=0.0, pausa=60)
        assert await v.avalor("x") == "valor-1"
        vault["error"] = httpx.ReadTimeout("colgado")
        assert await v.avalor("x") == "valor-1"
        llamadas = vault["llamadas"]
        for _ in range(5):
            assert await v.avalor("x") == "valor-1"
        with pytest.raises(SecretUnavailable):
            await v.avalor("sin-copia")
        assert vault["llamadas"] == llamadas
        vault["error"] = None
        await v.aesperar("otra", intentos=2, pausa=0)                                    # arrancando no hay copia que proteger: consulta de verdad
        assert vault["llamadas"] == llamadas + 1
        assert await v.avalor("x") == "valor-1" and vault["llamadas"] == llamadas + 2    # y la respuesta de Vault cerró la pausa
    asyncio.run(prueba())


def test_el_aviso_de_vault_no_disponible_sale_una_vez_por_pausa_y_el_regreso_se_registra(vault, caplog):
    v = vault["cliente"](ttl=0.0, pausa=0.2)
    v.valor("x")
    vault["error"] = httpx.ConnectError("sin red")
    with caplog.at_level(logging.INFO, logger="secretos"):
        for _ in range(6):
            v.valor("x")
        assert len([r for r in caplog.records if r.getMessage().startswith("Vault no disponible")]) == 1
        time.sleep(0.25)
        vault["error"] = None
        v.valor("x")
    assert [r.getMessage() for r in caplog.records if r.getMessage() == "Vault respondió de nuevo"] == ["Vault respondió de nuevo"]
