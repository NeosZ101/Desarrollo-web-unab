"""Plazos escalonados (common/plazos.py): cada capa se rinde antes que la de arriba, con los valores POR OMISIÓN que usa el despliegue.

Sin esto, el gateway cortaría primero y el usuario recibiría un 504 genérico mientras un servicio de abajo sigue trabajando.
Las pruebas de resiliencia (tests/test_resiliencia.py) comprueban el comportamiento real con plazos cortos; aquí se protegen los valores finales.
"""
import re

import pytest

from ayuda import RAIZ
from common import plazos
from common.vault_secrets import VaultSecrets

VARIABLES = ("UPSTREAM_TIMEOUT", "GRAPHQL_TIMEOUT", "PROVIDER_TIMEOUT", "VAULT_TIMEOUT_SECONDS")


@pytest.fixture(autouse=True)
def sin_variables(monkeypatch):
    for v in VARIABLES:
        monkeypatch.delenv(v, raising=False)
    monkeypatch.setenv("VAULT_ADDR", "http://vault.invalido:8200")
    monkeypatch.setenv("VAULT_TOKEN", "token-de-prueba")


def test_la_cadena_mas_larga_de_llamadas_internas_cabe_en_el_plazo_del_gateway():
    gw, servicio = plazos.upstream("gateway"), plazos.upstream("servicio")
    assert 2 * servicio < gw, "crear pedido (orders→clients y orders→inventory) y registrar (clients→notifications y clients→auth) hacen dos llamadas seguidas"
    assert servicio + plazos.proveedor() < gw, "iniciar un pago: payments→orders y luego payments→proveedor"


def test_una_consulta_graphql_termina_antes_que_el_gateway_y_cabe_su_doble_tanda_de_llamadas():
    assert 2 * plazos.upstream("graphql") <= plazos.graphql_maximo() < plazos.upstream("gateway")


def test_vault_colgado_en_todos_los_procesos_de_la_cadena_no_alcanza_el_plazo_del_gateway():
    vault = VaultSecrets().timeout
    assert 3 * vault < plazos.upstream("gateway"), "gateway + servicio + servicio de abajo leen secretos en la misma solicitud"


def test_ningun_servicio_fija_su_propio_plazo_por_fuera_de_plazos_py():
    for archivo in RAIZ.glob("*/app/*.py"):
        texto = archivo.read_text(encoding="utf-8")
        assert not re.search(r'environ\.get\("(UPSTREAM_TIMEOUT|GRAPHQL_TIMEOUT|PROVIDER_TIMEOUT)"', texto), f"{archivo.relative_to(RAIZ)} lee el plazo directamente"
