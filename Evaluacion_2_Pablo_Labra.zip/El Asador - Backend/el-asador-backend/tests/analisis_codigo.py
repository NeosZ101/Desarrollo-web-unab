"""Lectura del código fuente (sin ejecutarlo) para comprobar que las reglas escritas en el informe son las que de verdad hay en el código."""
import ast
from collections import namedtuple
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
SERVICIOS = {"auth": "auth-service", "clients": "clients-service", "inventory": "inventory-service", "orders": "orders-service", "payments": "payments-service",
             "notifications": "notifications-service", "analytics": "analytics-service", "graphql-gateway": "graphql-gateway", "api-gateway": "api-gateway"}


def _evaluar(nodo, entorno):
    if isinstance(nodo, ast.Constant):
        return nodo.value
    if isinstance(nodo, ast.Tuple):
        return tuple(_evaluar(e, entorno) for e in nodo.elts)
    if isinstance(nodo, ast.Name):
        return entorno[nodo.id]
    if isinstance(nodo, ast.BinOp) and isinstance(nodo.op, ast.Add):
        return _evaluar(nodo.left, entorno) + _evaluar(nodo.right, entorno)
    raise ValueError(ast.dump(nodo)[:80])


def _constantes(arbol):
    """Constantes de módulo hechas de tuplas de textos: GW = (...), GW, GWQL = (...), (...), X = GW + (...)."""
    entorno = {}
    for n in arbol.body:
        if not isinstance(n, ast.Assign) or len(n.targets) != 1:
            continue
        destino, valor = n.targets[0], n.value
        try:
            if isinstance(destino, ast.Name):
                entorno[destino.id] = _evaluar(valor, entorno)
            elif isinstance(destino, ast.Tuple) and isinstance(valor, ast.Tuple):
                for d, v in zip(destino.elts, valor.elts):
                    entorno[d.id] = _evaluar(v, entorno)
        except (ValueError, KeyError):
            continue
    return entorno


def guardias(servicio):
    """Lista de (llamadores permitidos, identidad, roles) de cada `guardia.dep(...)` del servicio, en el orden del archivo."""
    arbol = ast.parse((RAIZ / SERVICIOS[servicio] / "app" / "main.py").read_text(encoding="utf-8"))
    entorno = _constantes(arbol)
    salida = []
    for n in ast.walk(arbol):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "dep" and isinstance(n.func.value, ast.Name) and n.func.value.id == "guardia":
            llamadores = _evaluar(n.args[0], entorno)
            kw = {k.arg: _evaluar(k.value, entorno) for k in n.keywords}
            salida.append((tuple(llamadores), kw.get("identidad", "ninguna"), tuple(kw.get("roles", ()))))
    return salida


def nombre_propio(servicio):
    """El nombre con el que el servicio se identifica en `Guardia("<nombre>", vault)`."""
    arbol = ast.parse((RAIZ / SERVICIOS[servicio] / "app" / "main.py").read_text(encoding="utf-8"))
    for n in ast.walk(arbol):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "Guardia":
            return n.args[0].value
    return None


def pares_aceptados():
    """{(llamador, destino)}: quién puede llamar a quién según las guardias escritas en cada servicio."""
    pares = set()
    for svc in SERVICIOS:
        for llamadores, _, _ in guardias(svc):
            pares.update((c, svc) for c in llamadores)
    return pares


METODOS_HTTP = ("get", "post", "put", "delete", "patch")
RutaServicio = namedtuple("RutaServicio", "servicio metodo ruta guardia")   # guardia = (llamadores, identidad, roles) o None si la ruta NO tiene guardia


def _es_guardia(n):
    return (isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "dep"
            and isinstance(n.func.value, ast.Name) and n.func.value.id == "guardia")


def rutas(servicio):
    """Cada ruta (`@app.get("/x")`...) de un servicio privado con la guardia que la protege, leída del código sin ejecutarlo.

    Resuelve las dos formas que usa el código: `ll=Depends(guardia.dep(...))` y los alias `ADMIN = Depends(guardia.dep(...))`."""
    arbol = ast.parse((RAIZ / SERVICIOS[servicio] / "app" / "main.py").read_text(encoding="utf-8"))
    entorno = _constantes(arbol)

    def leer(nodo):
        kw = {k.arg: _evaluar(k.value, entorno) for k in nodo.keywords}
        return tuple(_evaluar(nodo.args[0], entorno)), kw.get("identidad", "ninguna"), tuple(kw.get("roles", ()))

    def es_depends(n):
        return isinstance(n, ast.Call) and getattr(n.func, "id", "") == "Depends" and n.args and _es_guardia(n.args[0])

    alias = {n.targets[0].id: leer(n.value.args[0]) for n in arbol.body
             if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and es_depends(n.value)}
    salida = []
    for f in ast.walk(arbol):
        if not isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        guardia = None
        for d in list(f.args.defaults) + [x for x in f.args.kw_defaults if x is not None]:
            if isinstance(d, ast.Name) and d.id in alias:
                guardia = alias[d.id]
            elif es_depends(d):
                guardia = leer(d.args[0])
        for dec in f.decorator_list:
            if (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute) and isinstance(dec.func.value, ast.Name)
                    and dec.func.value.id == "app" and dec.func.attr in METODOS_HTTP):
                salida.append(RutaServicio(servicio, dec.func.attr.upper(), dec.args[0].value, guardia))
    return sorted(salida, key=lambda r: (r.ruta, r.metodo))


def todas_las_rutas_privadas():
    """Rutas de todos los servicios privados (el API Gateway es público y se prueba con su propia tabla RUTAS)."""
    return [r for s in SERVICIOS if s != "api-gateway" for r in rutas(s)]
