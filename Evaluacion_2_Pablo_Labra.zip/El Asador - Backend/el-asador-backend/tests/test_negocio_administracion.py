"""Administración y formularios: usuarios del personal, clientes, catálogo, contacto, cotización de eventos y correos (RF5-RF8, RF10-RF12).

Regla común: lo que el navegador manda es solo una petición. Roles, estados, precios y folios los decide el servidor,
y cualquier campo que el servicio no espera se rechaza (asignación masiva).
"""
import uuid

import pytest

from ayuda import (CLAVES_USADAS, DATOS_PERSONALES, Api, crear_pedido, datos_registro, esperar, hoy_santiago, pedido_ok, pedido_pagado_manual,
                   run_valido, sin_id, sumar_dias)

pytestmark = pytest.mark.integracion
CLAVE = "Clave-Segura-2026"


# ----------------------------- usuarios del personal (S16-S19) ---------------------------------------------------------
@pytest.fixture
def personal(admin, gw):
    """Fábrica de usuarios del personal con sesión iniciada. Nunca se toca a los usuarios sembrados (otras pruebas usan su sesión)."""
    abiertos = []

    def crear(rol="despacho", clave=CLAVE):
        correo = f"personal.{uuid.uuid4().hex[:8]}@elasador.cl"
        CLAVES_USADAS.add(clave)
        r = admin.post("/api/users", json={"username": correo, "nombre": "Persona De Prueba", "rol": rol, "password": clave})
        assert r.status_code == 201, r.text
        api = Api(gw)
        assert api.login(correo, clave).status_code == 200
        abiertos.append(api)
        return api, r.json(), correo, clave

    yield crear
    for a in abiertos:
        a.cerrar()


def test_el_administrador_crea_un_usuario_que_entra_con_su_rol_y_nada_mas(personal, admin):
    api, u, correo, clave = personal("despacho")
    assert set(u) == {"id", "username", "nombre", "rol", "roles", "activo", "creadoEn"} and u["rol"] == "despacho" and u["activo"] is True
    assert api.usuario["roles"] == ["despacho"]
    assert api.get("/api/admin/orders").status_code == 200                           # su rol alcanza para el tablero de despacho
    assert api.get("/api/users").status_code == 403 and api.get("/api/admin/outbox").status_code == 403
    listado = admin.get("/api/users?limit=100").json()
    assert any(x["id"] == u["id"] for x in listado["items"]) and "password" not in str(listado).lower()


def test_no_se_repite_un_correo_de_usuario(personal, admin):
    _, _, correo, _ = personal("despacho")
    r = admin.post("/api/users", json={"username": correo.upper(), "nombre": "Otra Persona", "rol": "dueno", "password": CLAVE})
    assert r.status_code == 409 and r.json()["codigo"] == "USUARIO_EXISTE"


@pytest.mark.parametrize("clave", ["corta1", "password1", "a" * 129, "zz.usuario.zz"], ids=["corta", "comun", "demasiado-larga", "igual-al-usuario"])
def test_politica_de_claves_del_personal(admin, clave):
    CLAVES_USADAS.add(clave)
    r = admin.post("/api/users", json={"username": "zz.usuario.zz@elasador.cl", "nombre": "Persona De Prueba", "rol": "despacho", "password": clave})
    assert r.status_code == 422 and r.json()["codigo"] == "CLAVE_DEBIL", r.text
    assert clave not in r.text                                                       # la respuesta nunca repite la clave


@pytest.mark.parametrize("cambio", [
    {"username": "no-es-un-correo"}, {"nombre": "N"}, {"rol": "cliente"}, {"rol": "superadmin"},
    {"activo": True}, {"passwordHash": "x"}, {"clientId": "c-0001"}, {"id": "u-admin"},
], ids=lambda c: next(iter(c)) + "=" + str(next(iter(c.values())))[:12])
def test_el_alta_de_usuarios_rechaza_datos_invalidos_y_campos_ajenos(admin, cambio):
    base = {"username": f"alta.{uuid.uuid4().hex[:6]}@elasador.cl", "nombre": "Nombre Valido", "rol": "despacho", "password": CLAVE}
    r = admin.post("/api/users", json={**base, **cambio})
    assert r.status_code == 422 and r.json()["codigo"] == "VALIDACION", r.text


def test_cambiar_la_clave_cierra_las_sesiones_abiertas_y_la_clave_vieja_deja_de_servir(personal, admin, gw):
    api, u, correo, clave = personal("despacho")
    assert api.get("/api/admin/orders").status_code == 200
    nueva = "Otra-Clave-2026-xyz"
    CLAVES_USADAS.add(nueva)
    assert admin.put(f"/api/users/{u['id']}", json={"nombre": u["nombre"], "rol": "despacho", "activo": True, "password": nueva}).status_code == 200
    despues = api.get("/api/admin/orders")
    assert despues.status_code == 401 and despues.json()["codigo"] == "SESION_NO_VALIDA"
    assert Api(gw).login(correo, clave).status_code == 401
    assert Api(gw).login(correo, nueva).status_code == 200


def test_cambiar_el_rol_cierra_la_sesion_y_el_nuevo_rol_rige_al_volver_a_entrar(personal, admin, gw):
    api, u, correo, clave = personal("despacho")
    r = admin.put(f"/api/users/{u['id']}", json={"nombre": u["nombre"], "rol": "dueno", "activo": True})
    assert r.status_code == 200 and r.json()["rol"] == "dueno"
    assert api.get("/api/admin/orders").status_code == 401
    nuevo = Api(gw)
    assert nuevo.login(correo, clave).status_code == 200
    assert nuevo.usuario["roles"] == ["dueno"] and nuevo.get("/api/admin/orders").status_code == 403


def test_desactivar_un_usuario_cierra_su_sesion_le_impide_entrar_y_se_puede_reactivar(personal, admin, gw):
    api, u, correo, clave = personal("despacho")
    r = admin.delete(f"/api/users/{u['id']}")
    assert r.status_code == 200 and r.json() == {"id": u["id"], "activo": False}
    assert api.get("/api/admin/orders").status_code == 401
    intento = Api(gw).login(correo, clave)
    assert intento.status_code == 401 and intento.json()["codigo"] == "CREDENCIALES_INVALIDAS"      # mismo mensaje que una clave mala
    assert admin.put(f"/api/users/{u['id']}", json={"nombre": u["nombre"], "rol": "despacho", "activo": True}).status_code == 200
    assert Api(gw).login(correo, clave).status_code == 200


def test_un_administrador_no_puede_quitarse_el_acceso_a_si_mismo(personal):
    api, u, _, _ = personal("administrador")
    intentos = [api.delete(f"/api/users/{u['id']}"),
                api.put(f"/api/users/{u['id']}", json={"nombre": u["nombre"], "rol": "dueno", "activo": True}),
                api.put(f"/api/users/{u['id']}", json={"nombre": u["nombre"], "rol": "administrador", "activo": False})]
    for r in intentos:
        assert r.status_code == 409 and r.json()["codigo"] == "AUTOEDICION_NO_PERMITIDA", r.text
    assert api.get("/api/users").status_code == 200                                  # sigue con su acceso


def test_un_administrador_puede_desactivar_a_otro_mientras_quede_alguno(personal):
    a, _, _, _ = personal("administrador")
    b, ub, _, _ = personal("administrador")
    assert a.delete(f"/api/users/{ub['id']}").status_code == 200
    assert b.get("/api/users").status_code == 401 and a.get("/api/users").status_code == 200


def test_las_cuentas_de_clientes_no_se_gestionan_desde_el_mantenedor_del_personal(admin, andrea):
    """Si se pudiera editar una cuenta de cliente desde aquí, bastaría un PUT para convertirla en administradora."""
    uid = andrea.usuario["user_id"]
    for r in (admin.put(f"/api/users/{uid}", json={"nombre": "Andrea Molina", "rol": "administrador", "activo": True}), admin.delete(f"/api/users/{uid}")):
        assert r.status_code == 404 and r.json()["codigo"] == "USUARIO_NO_ENCONTRADO"
    assert uid not in {x["id"] for x in admin.get("/api/users?limit=100").json()["items"]}
    assert andrea.get("/api/auth/me").json()["usuario"]["roles"] == ["cliente"]


# ----------------------------- registro de clientes (S10) ---------------------------------------------------------------
def _recordar(d):
    DATOS_PERSONALES.update({d["run"], d["run"].replace("-", ""), d["correo"]})
    CLAVES_USADAS.add(d["clave"])


def test_el_registro_web_crea_una_cuenta_con_rol_cliente_y_no_devuelve_secretos(gw):
    api, d = Api(gw), datos_registro()
    _recordar(d)
    r = api.post("/api/clients/register", json=d)
    assert r.status_code == 201, r.text
    c = r.json()
    assert c["run"].replace(".", "") == d["run"] and c["origen"] == "Web" and c["estado"] == "activo" and c["tieneAcceso"] is True
    for prohibido in ("clave", "password", "passwordHash", "authUserId"):
        assert prohibido not in r.text
    assert api.login(d["correo"], d["clave"]).status_code == 200
    assert api.usuario["roles"] == ["cliente"] and api.client_id == c["id"]


REGISTROS_INVALIDOS = [
    ({"run": "12.345.678-9"}, "VALIDACION"),                                         # dígito verificador incorrecto
    ({"telefono": "abc"}, "VALIDACION"),
    ({"nacimiento": "31-12-1990"}, "VALIDACION"),
    ({"nacimiento": "2999-01-01"}, "VALIDACION"),
    ({"clave": "corta"}, "VALIDACION"),
    ({"clave": "password1"}, "CLAVE_DEBIL"),                                         # la rechaza el Auth Service
    ({"comuna": "Rancagua"}, "UBICACION_INVALIDA"),                                  # sin cobertura
    ({"comuna": "Puente Alto", "provincia": "Santiago"}, "UBICACION_INVALIDA"),      # provincia incoherente con la comuna
    ({"sexo": "Robot"}, "VALIDACION"),
    ({"rol": "administrador"}, "VALIDACION"),                                        # asignación masiva
    ({"estado": "activo", "origen": "Local"}, "VALIDACION"),
    ({"authUserId": "u-admin"}, "VALIDACION"),
    ({"correo": "no-es-correo"}, "CORREO_NO_EXISTE"),
    ({"correo": "alguien@correo.invalid"}, "CORREO_NO_EXISTE"),                      # dominio reservado: no recibe correo
    ({"correo": "noexiste.alguien@correo.cl"}, "CORREO_NO_EXISTE"),                  # el buzón no existe (convención del sandbox)
    ({"correo": "temporal@mailinator.com"}, "CORREO_NO_EXISTE"),                     # correos desechables
]


@pytest.mark.parametrize("cambio,codigo", REGISTROS_INVALIDOS, ids=lambda x: next(iter(x)) + "=" + str(next(iter(x.values())))[:16] if isinstance(x, dict) else x)
def test_el_registro_rechaza_datos_invalidos(gw, cambio, codigo):
    d = datos_registro(**cambio)
    _recordar(d)
    r = Api(gw).post("/api/clients/register", json=d)
    assert r.status_code == 422 and r.json()["codigo"] == codigo, r.text
    assert d["clave"] not in r.text


def test_un_registro_con_clave_debil_no_deja_un_perfil_a_medias(gw):
    """El perfil se crea antes que la credencial; si la clave no pasa, el perfil se borra (compensación)."""
    d = datos_registro(clave="password1")
    _recordar(d)
    api = Api(gw)
    assert api.post("/api/clients/register", json=d).json()["codigo"] == "CLAVE_DEBIL"
    d["clave"] = "una-clave-larga-y-unica-77"
    _recordar(d)
    assert api.post("/api/clients/register", json=d).status_code == 201             # con un perfil huérfano habría un 409


def test_un_registro_repetido_no_revela_si_ya_existe_el_rut_o_el_correo(nuevo_cliente, gw):
    c = nuevo_cliente()
    mismo_run = datos_registro(run=c.datos["run"], correo=f"otro{uuid.uuid4().hex[:6]}@correo.cl")
    mismo_correo = datos_registro(correo=c.datos["correo"])
    a = Api(gw).post("/api/clients/register", json=mismo_run)
    b = Api(gw).post("/api/clients/register", json=mismo_correo)
    assert a.status_code == b.status_code == 409 and a.json()["codigo"] == b.json()["codigo"] == "CUENTA_NO_DISPONIBLE"
    assert sin_id(a.json()) == sin_id(b.json())


def test_un_cliente_dado_de_alta_en_el_local_puede_activar_su_acceso_web(admin, gw):
    run = run_valido()
    correo = f"local{run.split('-')[0]}@correo.cl"
    DATOS_PERSONALES.update({run, run.replace("-", ""), correo})
    r = admin.post("/api/clients", json={"run": run, "nombre": "Cliente Del Local", "correo": correo, "telefono": "+56 9 5555 4444",
                                         "direccion": "Av. Siempre Viva 742", "comuna": "Santiago"})
    assert r.status_code == 201 and r.json()["origen"] == "Local" and r.json()["tieneAcceso"] is False, r.text
    cid = r.json()["id"]
    ajeno = Api(gw).post("/api/clients/register", json=datos_registro(run=run, correo=f"otro{uuid.uuid4().hex[:6]}@correo.cl", comuna="Santiago"))
    assert ajeno.status_code == 409                                                  # el RUN solo no alcanza para apropiarse de la cuenta
    propio, d = Api(gw), datos_registro(run=run, correo=correo, comuna="Santiago")
    CLAVES_USADAS.add(d["clave"])
    r = propio.post("/api/clients/register", json=d)
    assert r.status_code == 201 and r.json()["id"] == cid and r.json()["tieneAcceso"] is True
    assert propio.login(correo, d["clave"]).status_code == 200 and propio.client_id == cid
    assert Api(gw).post("/api/clients/register", json=d).status_code == 409         # y solo una vez


# ----------------------------- mantenedor de clientes (S12-S15) ---------------------------------------------------------
def test_el_administrador_busca_y_pagina_clientes(admin, nuevo_cliente):
    c = nuevo_cliente(nombre="Zulema Probando Busqueda")
    cid = c.client_id
    por_nombre = admin.get("/api/clients", params={"q": "zulema probando"})
    assert por_nombre.status_code == 200 and cid in {x["id"] for x in por_nombre.json()} and int(por_nombre.headers["x-total-count"]) >= 1
    run_con_puntos = next(x for x in por_nombre.json() if x["id"] == cid)["run"]
    assert cid in {x["id"] for x in admin.get("/api/clients", params={"q": run_con_puntos}).json()}
    assert cid in {x["id"] for x in admin.get("/api/clients", params={"q": c.datos["correo"][:12]}).json()}
    assert len(admin.get("/api/clients", params={"limit": 1}).json()) == 1
    assert admin.get("/api/clients", params={"q": ".*"}).json() == []               # el texto buscado no se interpreta como patrón
    for mal in ({"limit": 0}, {"limit": 101}, {"offset": -1}, {"limit": "x"}):
        r = admin.get("/api/clients", params=mal)
        assert r.status_code == 400 and r.json()["codigo"] == "FILTRO_INVALIDO", (mal, r.text)


def test_el_administrador_edita_datos_pero_no_el_rut_ni_el_correo(admin, nuevo_cliente):
    c = nuevo_cliente()
    cuerpo = {"nombre": "Nombre Corregido", "telefono": "+56 9 8888 7777", "direccion": "Calle Nueva 456", "comuna": "Providencia"}
    r = admin.put(f"/api/clients/{c.client_id}", json=cuerpo)
    assert r.status_code == 200 and r.json()["nombre"] == "Nombre Corregido" and r.json()["comuna"] == "Providencia"
    assert c.get("/api/clients/me").json()["direccion"] == "Calle Nueva 456"       # el cliente ve el cambio
    for extra in ({"run": "11.111.111-1"}, {"correo": "otro@correo.cl"}, {"estado": "activo"}, {"authUserId": "u-admin"}):
        r = admin.put(f"/api/clients/{c.client_id}", json={**cuerpo, **extra})
        assert r.status_code == 422 and r.json()["codigo"] == "VALIDACION", (extra, r.text)
    assert admin.put("/api/clients/c-zzzz9999", json=cuerpo).json()["codigo"] == "CLIENTE_NO_ENCONTRADO"
    assert admin.put(f"/api/clients/{c.client_id}", json={**cuerpo, "comuna": "Rancagua"}).json()["codigo"] == "UBICACION_INVALIDA"


def test_el_alta_en_el_local_no_acepta_duplicados_ni_campos_ajenos(admin, nuevo_cliente):
    c = nuevo_cliente()
    base = {"nombre": "Cliente Del Local", "telefono": "+56 9 5555 4444", "direccion": "Av. Siempre Viva 742", "comuna": "Santiago"}
    r = admin.post("/api/clients", json={**base, "run": c.datos["run"], "correo": f"local{uuid.uuid4().hex[:6]}@correo.cl"})
    assert r.status_code == 409 and r.json()["codigo"] == "CLIENTE_EXISTE"
    run = run_valido()
    r = admin.post("/api/clients", json={**base, "run": run, "correo": f"local{uuid.uuid4().hex[:6]}@correo.cl", "estado": "activo"})
    assert r.status_code == 422 and r.json()["codigo"] == "VALIDACION"


def test_desactivar_un_cliente_cierra_su_sesion_bloquea_su_acceso_y_conserva_sus_pedidos(admin, nuevo_cliente, gw):
    c = nuevo_cliente()
    p = pedido_ok(c)
    r = admin.delete(f"/api/clients/{c.client_id}")
    assert r.status_code == 200 and r.json() == {"id": c.client_id, "estado": "inactivo"}
    assert c.get("/api/orders").status_code == 401                                  # su sesión terminó de inmediato
    assert Api(gw).login(c.datos["correo"], c.datos["clave"]).status_code == 401
    assert admin.get(f"/api/orders/{p['id']}").json()["id"] == p["id"]              # el pedido queda como respaldo
    assert next(x for x in admin.get("/api/clients", params={"q": c.datos["correo"]}).json())["estado"] == "inactivo"


# ----------------------------- catálogo (S04-S09) -----------------------------------------------------------------------
@pytest.fixture
def producto_nuevo(admin):
    creados = []

    def crear(**cambios):
        d = {"nombre": f"Producto prueba {uuid.uuid4().hex[:6]}", "categoria": "bebidas", "precio": 2500,
             "descripcion": "Producto creado por las pruebas automáticas.", "imagen": "img/cerveza.svg", **cambios}
        r = admin.post("/api/products", json=d)
        assert r.status_code == 201, r.text
        creados.append(r.json()["id"])
        return r.json()

    yield crear
    for pid in creados:
        admin.delete(f"/api/products/{pid}")


def _cuerpo(p, **cambios):
    return {"nombre": p["nombre"], "categoria": p["categoria"], "precio": p["precio"], "descripcion": p["descripcion"], "imagen": p["imagen"], **cambios}


@pytest.mark.parametrize("quien", ["admin", "dueno"])
def test_ciclo_completo_del_catalogo_y_la_carta_publica_se_actualiza_al_instante(request, anon, producto_nuevo, quien):
    api = request.getfixturevalue(quien)
    p = producto_nuevo()
    assert p["id"].startswith("p") and p["disponible"] is True and p["incluye"] == [p["nombre"]]
    carta = lambda: {x["id"]: x for x in anon.get("/api/products?limit=200").json()}   # noqa: E731  (la carta pública está en caché 10 s en el gateway)
    assert carta()[p["id"]]["precio"] == 2500
    r = api.put(f"/api/products/{p['id']}", json=_cuerpo(p, precio=3000))
    assert r.status_code == 200 and carta()[p["id"]]["precio"] == 3000               # la escritura vacía la caché
    r = api.put(f"/api/products/{p['id']}/availability", json={"disponible": False})
    assert r.status_code == 200 and carta()[p["id"]]["disponible"] is False
    assert api.delete(f"/api/products/{p['id']}").json() == {"id": p["id"], "retirado": True}
    assert p["id"] not in carta()
    again = api.delete(f"/api/products/{p['id']}")
    assert again.status_code == 404 and again.json()["codigo"] == "PRODUCTO_NO_ENCONTRADO"


PRODUCTOS_INVALIDOS = [
    {"precio": 499}, {"precio": 200001}, {"precio": -5}, {"nombre": "ab"}, {"categoria": "postres"}, {"descripcion": "corta"},
    {"imagen": "https://evil.test/x.svg"}, {"imagen": "img/../../etc/passwd"}, {"imagen": "img/x.png"}, {"imagen": "//evil.test/img/x.svg"},
    {"personas": 0}, {"incluye": [f"cosa {i}" for i in range(13)]}, {"incluye": [""]},
    {"eliminado": True}, {"_id": "p99"}, {"id": "p99"}, {"creadoEn": "2020-01-01"},
]


@pytest.mark.parametrize("cambio", PRODUCTOS_INVALIDOS, ids=lambda c: next(iter(c)) + "=" + str(next(iter(c.values())))[:14])
def test_el_catalogo_rechaza_productos_invalidos_y_campos_ajenos(admin, cambio):
    base = {"nombre": "Producto invalido", "categoria": "bebidas", "precio": 2500, "descripcion": "Producto creado por las pruebas.", "imagen": "img/cerveza.svg"}
    r = admin.post("/api/products", json={**base, **cambio})
    assert r.status_code == 422 and r.json()["codigo"] == "VALIDACION", r.text


def test_el_precio_del_pedido_es_el_vigente_en_el_servidor_y_no_cambia_despues(admin, nuevo_cliente, producto_nuevo):
    p = producto_nuevo(precio=5000)
    c = nuevo_cliente()
    antes = pedido_ok(c, items=[{"id": p["id"], "cantidad": 2}])
    assert antes["subtotal"] == 10000
    assert admin.put(f"/api/products/{p['id']}", json=_cuerpo(p, precio=6000)).status_code == 200
    despues = pedido_ok(c, items=[{"id": p["id"], "cantidad": 2}])
    assert despues["subtotal"] == 12000                                              # el precio nuevo rige para los pedidos nuevos
    assert c.get(f"/api/orders/{antes['id']}").json()["subtotal"] == 10000          # el pedido ya hecho conserva su copia


def test_un_producto_retirado_no_se_puede_pedir(admin, nuevo_cliente, producto_nuevo):
    p = producto_nuevo()
    assert admin.delete(f"/api/products/{p['id']}").status_code == 200
    r = crear_pedido(nuevo_cliente(), items=[{"id": p["id"], "cantidad": 1}])
    assert r.status_code == 422 and r.json()["codigo"] == "ITEM_INEXISTENTE"


def test_un_producto_que_forma_parte_de_una_promocion_activa_no_se_puede_retirar(admin, anon):
    promos = anon.get("/api/promos").json()
    componente = promos[0]["componentes"][0]["id"]
    r = admin.delete(f"/api/products/{componente}")
    assert r.status_code == 409 and r.json()["codigo"] == "PRODUCTO_EN_PROMO"
    assert any(x["id"] == componente for x in anon.get("/api/products?limit=200").json())


def test_la_carta_publica_solo_muestra_campos_de_catalogo(anon):
    permitidos = {"id", "categoria", "nombre", "precio", "disponible", "imagen", "descripcion", "incluye", "alcohol", "personas"}
    productos = anon.get("/api/products?limit=200").json()
    assert productos and all(set(p) <= permitidos for p in productos)
    promos = anon.get("/api/promos").json()
    assert promos and all({"eliminado", "creadoEn", "actualizadoEn", "_id"}.isdisjoint(p) for p in promos + productos)


def test_filtros_del_catalogo(anon):
    bebidas = anon.get("/api/products", params={"categoria": "bebidas"}).json()
    assert bebidas and all(p["categoria"] == "bebidas" for p in bebidas)
    r = anon.get("/api/products", params={"categoria": "postres"})
    assert r.status_code == 400 and r.json()["codigo"] == "FILTRO_INVALIDO"
    assert anon.get("/api/products", params={"q": ".*"}).json() == []               # la búsqueda es literal
    assert anon.get("/api/products", params={"limit": 0}).status_code == 400
    assert anon.get("/api/products", params={"foo": "bar"}).status_code == 200      # parámetros no declarados se ignoran, no llegan al servicio


# ----------------------------- formularios públicos y correos (S27, S28, S36, S37) --------------------------------------
def _bandeja(admin):
    r = admin.get("/api/admin/outbox?limit=100")
    assert r.status_code == 200, r.text
    return r.json()


def _nuevos(admin, antes):
    vistos = {x["id"] for x in antes}
    return [x for x in _bandeja(admin) if x["id"] not in vistos]


def _contacto(**cambios):
    return {"nombre": "Persona Contacto", "correo": f"contacto{uuid.uuid4().hex[:8]}@correo.cl", "asunto": "Sugerencia",
            "mensaje": "Me gustaría sugerir más opciones vegetarianas en la carta.", **cambios}


def test_el_formulario_de_contacto_guarda_avisa_al_local_y_responde_al_remitente(anon, admin):
    antes = _bandeja(admin)
    d = _contacto()
    DATOS_PERSONALES.add(d["correo"])
    r = anon.post("/api/contact-messages", json=d)
    assert r.status_code == 201 and len(r.json()["id"]) == 32
    nuevos = _nuevos(admin, antes)
    assert sorted(x["tipo"] for x in nuevos) == ["autorespuesta", "contacto"] and all(x["estado"] == "enviado" for x in nuevos)
    assert d["correo"].split("@")[0] not in str(nuevos)                              # la bandeja enmascara a los destinatarios


def test_la_autorespuesta_se_envia_una_vez_por_hora_a_cada_direccion(anon, admin):
    antes = _bandeja(admin)
    d = _contacto()
    DATOS_PERSONALES.add(d["correo"])
    assert anon.post("/api/contact-messages", json=d).status_code == 201
    assert anon.post("/api/contact-messages", json={**d, "mensaje": "Segundo mensaje de la misma persona, seguido del primero."}).status_code == 201
    tipos = sorted(x["tipo"] for x in _nuevos(admin, antes))
    assert tipos == ["autorespuesta", "contacto", "contacto"]                        # dos avisos al local, una sola respuesta automática


@pytest.mark.parametrize("cambio", [
    {"asunto": "Otro tema que no existe"}, {"mensaje": "corto"}, {"mensaje": "x" * 2001}, {"nombre": "ab"}, {"para": "otro@correo.cl"},
    {"correo": "alguien@correo.invalid"}, {"correo": "no-es-correo"},
], ids=lambda c: next(iter(c)))
def test_el_formulario_de_contacto_rechaza_datos_invalidos(anon, cambio):
    r = anon.post("/api/contact-messages", json=_contacto(**cambio))
    assert r.status_code == 422 and r.json()["codigo"] in ("VALIDACION", "CORREO_INVALIDO"), r.text


def test_la_bandeja_enmascara_destinatarios_no_muestra_el_texto_y_registra_las_boletas(admin, nuevo_cliente):
    antes = _bandeja(admin)
    c = nuevo_cliente()
    pedido_pagado_manual(c, admin)
    boletas = esperar(lambda: [x for x in _nuevos(admin, antes) if x["tipo"] == "boleta"], mensaje="no se envió la boleta por correo")
    assert boletas[0]["estado"] == "enviado"
    for x in _bandeja(admin):
        assert set(x) == {"id", "tipo", "para", "asunto", "estado", "intentos", "creadoEn"}
        assert "***@" in x["para"] and x["para"].index("***") == 1
    assert c.datos["correo"] not in str(_bandeja(admin))


def test_la_cotizacion_de_un_evento_se_calcula_en_el_servidor(anon, admin):
    cfg = anon.get("/api/event-config").json()
    menu = next(m for m in cfg["menus"] if m["id"] == "premium")
    antes = _bandeja(admin)
    d = {"nombre": "Evento Prueba", "correo": f"evento{uuid.uuid4().hex[:6]}@correo.cl", "fecha": sumar_dias(hoy_santiago(), 20), "personas": 40,
         "menu": "premium", "bebidas": True, "ensaladas": True, "parrillero": True, "comuna": "Providencia"}
    DATOS_PERSONALES.add(d["correo"])
    r = anon.post("/api/event-quotes", json=d)
    assert r.status_code == 201, r.text
    q = r.json()
    cada_cuatro = 10                                                                 # una bebida y una ensalada cada 4 personas
    esperado = 40 * menu["precioPersona"] + cada_cuatro * cfg["extras"]["bebida"]["precio"] + cada_cuatro * cfg["extras"]["ensalada"]["precio"] + cfg["precioParrillero"]
    assert q["estimado"] == esperado and sum(x["valor"] for x in q["detalle"]) == esperado    # Providencia está a 1,5 km: despacho gratis
    assert q["folio"].startswith("COT-") and len(q["folio"]) == 9
    assert sorted(x["tipo"] for x in _nuevos(admin, antes)) == ["cotizacion", "cotizacion"]   # aviso al cliente y al local


@pytest.mark.parametrize("cambio,codigo", [
    ({"personas": 9}, "COTIZACION_INVALIDA"), ({"personas": 301}, "COTIZACION_INVALIDA"), ({"fecha": "2020-01-01"}, "FECHA_PASADA"),
    ({"comuna": "Rancagua"}, "COMUNA_SIN_COBERTURA"), ({"menu": "gratis"}, "VALIDACION"), ({"correo": "no-es-correo"}, "VALIDACION"),
    ({"estimado": 1}, "VALIDACION"), ({"total": 1}, "VALIDACION"), ({"precioPersona": 1}, "VALIDACION"), ({"fecha": "mañana"}, "VALIDACION"),
], ids=lambda c: next(iter(c)) if isinstance(c, dict) else c)
def test_la_cotizacion_rechaza_datos_invalidos_y_no_acepta_precios_del_navegador(anon, cambio, codigo):
    d = {"nombre": "Evento Prueba", "correo": "evento@correo.cl", "fecha": sumar_dias(hoy_santiago(), 20), "personas": 40, "menu": "clasico", **cambio}
    r = anon.post("/api/event-quotes", json=d)
    assert r.status_code == 422 and r.json()["codigo"] == codigo, r.text
