"""Vault FALSO, solo para las pruebas automáticas.

Imita lo mínimo de la API real (KV v2 + políticas + tokens):
  GET/POST /v1/secret/data/<ruta>          leer / escribir secretos (X-Vault-Token)
  PUT      /v1/sys/policies/acl/<nombre>   crear política (solo token raíz)
  POST     /v1/auth/token/create           crear token con id y políticas (solo token raíz)
  POST     /v1/auth/token/lookup           consultar un token y sus políticas (solo token raíz)
  GET      /v1/sys/health
Aplica las políticas (rutas exactas o con '*' final), de modo que las pruebas comprueban de verdad que
un servicio NO puede leer secretos que no le corresponden. Las conclusiones valen para el contrato
de lectura y los permisos mínimos, no para HashiCorp Vault real (para eso: docker-compose.yml + smoke_test.py).
Ganchos de prueba (/_test/...): simular caída de Vault (sellado = responde 503 al instante; colgado = acepta la conexión y no
contesta, como un proceso congelado), rotar o borrar un secreto y revocar un token.
"""
import json
import os
import threading

from fastapi import FastAPI, Header, HTTPException, Request

app = FastAPI()
RAIZ = os.environ["FAKE_VAULT_ROOT"]
DATOS = {}        # "asador/svc/x-to-y" -> {"value": ...}
POLITICAS = {}    # nombre -> {ruta o prefijo*: ["read"]}
TOKENS = {}       # token -> [políticas]
ESTADO = {"caido": False, "colgado": False, "liberar": threading.Event()}


def _permitido(token, ruta, capacidad):
    if token == RAIZ:
        return True
    completa = f"secret/data/{ruta}"
    for nombre in TOKENS.get(token, []):
        for patron, caps in POLITICAS.get(nombre, {}).items():
            coincide = completa.startswith(patron[:-1]) if patron.endswith("*") else completa == patron
            if coincide and capacidad in caps:
                return True
    return False


def _vivo(puede_colgar=False):
    """`puede_colgar`: solo las lecturas (que son funciones normales, no asíncronas) se quedan esperando cuando Vault está «colgado»."""
    if ESTADO["colgado"] and puede_colgar:
        ESTADO["liberar"].wait(30)
    if ESTADO["caido"] or ESTADO["colgado"]:
        raise HTTPException(503, {"errors": ["Vault is sealed"]})


@app.get("/v1/sys/health")
def salud():
    _vivo(puede_colgar=True)
    return {"initialized": True, "sealed": False}


@app.get("/v1/secret/data/{ruta:path}")
def leer(ruta: str, x_vault_token: str = Header(default="")):
    _vivo(puede_colgar=True)
    if not _permitido(x_vault_token, ruta, "read"):
        raise HTTPException(403, {"errors": ["permission denied"]})
    if ruta not in DATOS:
        raise HTTPException(404, {"errors": []})
    return {"data": {"data": DATOS[ruta], "metadata": {"version": 1}}}


@app.post("/v1/secret/data/{ruta:path}")
async def escribir(ruta: str, request: Request, x_vault_token: str = Header(default="")):
    _vivo()
    if x_vault_token != RAIZ:
        raise HTTPException(403, {"errors": ["permission denied"]})
    DATOS[ruta] = (await request.json())["data"]
    return {"data": {"version": 1}}


@app.put("/v1/sys/policies/acl/{nombre}")
async def politica(nombre: str, request: Request, x_vault_token: str = Header(default="")):
    _vivo()
    if x_vault_token != RAIZ:
        raise HTTPException(403, {"errors": ["permission denied"]})
    doc = json.loads((await request.json())["policy"])
    POLITICAS[nombre] = {p: v["capabilities"] for p, v in doc["path"].items()}
    return {}


@app.post("/v1/auth/token/create")
async def crear_token(request: Request, x_vault_token: str = Header(default="")):
    _vivo()
    if x_vault_token != RAIZ:
        raise HTTPException(403, {"errors": ["permission denied"]})
    cuerpo = await request.json()
    if cuerpo["id"] in TOKENS:
        raise HTTPException(400, {"errors": ["token ID in use"]})
    TOKENS[cuerpo["id"]] = cuerpo["policies"]
    return {"auth": {"client_token": "***"}}


@app.post("/v1/auth/token/lookup")
async def consultar_token(request: Request, x_vault_token: str = Header(default="")):
    _vivo()
    if x_vault_token != RAIZ:
        raise HTTPException(403, {"errors": ["permission denied"]})
    token = (await request.json()).get("token", "")
    if token not in TOKENS:
        raise HTTPException(403, {"errors": ["bad token"]})
    return {"data": {"id": token, "policies": TOKENS[token]}}


@app.put("/_test/secret/{ruta:path}")
async def rotar(ruta: str, request: Request):
    DATOS[ruta] = await request.json()
    return {"ok": True}


@app.delete("/_test/secret/{ruta:path}")
def borrar(ruta: str):
    """Como `vault kv delete`: el secreto deja de existir y las lecturas responden 404."""
    DATOS.pop(ruta, None)
    return {"ok": True}


@app.delete("/_test/token/{token}")
def revocar_token(token: str):
    """Como `vault token revoke`: el token deja de tener permisos (las lecturas responden 403)."""
    TOKENS.pop(token, None)
    return {"ok": True}


@app.put("/_test/caido/{valor}")
def caido(valor: str):
    """0 = normal · 1 = sellado (503 al instante) · colgado = no contesta (las lecturas esperan hasta que vuelva a 0)."""
    ESTADO["caido"] = valor == "1"
    ESTADO["colgado"] = valor == "colgado"
    if valor != "colgado":
        ESTADO["liberar"].set()                       # suelta las lecturas que estaban esperando
        ESTADO["liberar"] = threading.Event()
    return {"caido": ESTADO["caido"], "colgado": ESTADO["colgado"]}
