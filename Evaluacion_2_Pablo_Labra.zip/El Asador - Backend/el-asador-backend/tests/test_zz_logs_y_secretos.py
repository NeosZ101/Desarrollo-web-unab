"""Revisión final de lo que SALE del sistema: logs, respuestas y código del navegador.

El nombre empieza con «zz» para que pytest lo ejecute al final, cuando ya se acumularon los logs y el tráfico de todas las demás
pruebas (todos los sistemas que levantó esta ejecución: el compartido, el estricto, el de resiliencia, los aislados...).
Además genera tráfico propio con valores únicos («marcas») para que la revisión siempre tenga algo concreto que buscar,
incluso si este archivo se ejecuta solo.

Se comprueba que NO aparecen:
  * secretos de Vault (de servicio, del proveedor, de bases de datos) ni tokens de Vault;
  * contraseñas escritas por las pruebas ni tokens de sesión;
  * datos personales (RUN, correo, teléfono, dirección) de los clientes de prueba.
Y que SÍ existe el identificador de correlación para seguir una solicitud entre servicios.
"""
import json
import re
import uuid

import pytest

from ayuda import (Api, CLAVES_USADAS, DATOS_PERSONALES, RAIZ, TOKENS_DE_SESION, TRAFICO, crear_pedido, datos_registro, iniciar_pago, lineas_de_log, run_valido)
from stack import REGISTRO

pytestmark = pytest.mark.integracion


# ----------------------------- tráfico propio con valores únicos -----------------------------------
@pytest.fixture(scope="module")
def marcas(sistema, gw):
    u = uuid.uuid4().hex[:10]
    d = datos_registro(run=run_valido(), nombre=f"Marca Persona{u}", telefono="+56 9 8" + str(int(u, 16))[:7].ljust(7, "3"),
                       direccion=f"Calle Marca {u} 4321", clave=f"Clave-{u}-Larga")
    web = Api(gw)
    assert web.post("/api/clients/register", json=d).status_code == 201
    mala = f"MALA-{u}-clave"
    assert web.post("/api/auth/login", json={"username": d["correo"], "password": mala}).status_code == 401
    assert web.login(d["correo"], d["clave"]).status_code == 200
    DATOS_PERSONALES.update({d["run"], d["run"].replace("-", ""), d["correo"]})
    rid = "corr-" + u
    # un recorrido completo: perfil, pedido, inicio de pago, GraphQL y formulario de contacto, todos con el mismo identificador de correlación
    cab = {"X-Request-ID": rid}
    assert web.get("/api/clients/me", headers=cab).status_code == 200
    r = crear_pedido(web, items=[{"id": "p07", "cantidad": 1}], medio="Servipag")
    assert r.status_code == 201
    pedido = r.json()
    web.post("/api/orders", json={"items": [{"id": "p07", "cantidad": 1}], "comuna": "Ñuñoa", "medioPago": "Servipag"},
             headers={"Idempotency-Key": "k" * 12, "X-Request-ID": rid})
    iniciar_pago(web, pedido["id"])
    assert web.gql("{ misPedidos(limit: 3) { total items { id pago { estado } } } }").status_code == 200
    contacto = {"nombre": f"Contacto {u}", "correo": f"contacto{u}@correo.cl", "asunto": "Sugerencia", "mensaje": f"Mensaje con marca {u} para revisar los logs."}
    DATOS_PERSONALES.add(contacto["correo"])
    assert web.post("/api/contact-messages", json=contacto).status_code == 201
    return {"datos": d, "mala": mala, "contacto": contacto, "rid": rid, "pedido": pedido, "unico": u}


def _logs():
    """(nombre del sistema, servicio, texto) de cada archivo de log de cada sistema que se levantó."""
    for i, s in enumerate(REGISTRO):
        for f in sorted(s.logdir.glob("*.log")):
            yield i, s, f.stem, f.read_text(encoding="utf-8", errors="ignore")


def _buscar(valores, minimo=8):
    """Devuelve [(sistema, servicio, qué valor)] donde aparece alguno. No imprime el valor (podría ser un secreto)."""
    encontrados = []
    valores = sorted(v for v in valores if isinstance(v, str) and len(v) >= minimo)
    for i, s, servicio, texto in _logs():
        for n, v in enumerate(valores):
            if v in texto:
                encontrados.append((i, servicio, f"valor #{n} ({len(v)} caracteres)"))
    return encontrados


# ----------------------------- logs -----------------------------------------------------------------
def test_ningun_secreto_de_vault_ni_token_de_servicio_aparece_en_los_logs(marcas):
    assert REGISTRO and all(s.secretos_conocidos for s in REGISTRO), "no se pudo leer la lista de secretos de algún sistema"
    todos = set()
    for s in REGISTRO:
        todos |= s.secretos_conocidos | {s.root_token} | set(s.tokens.values())
    assert len(todos) >= 30
    assert _buscar(todos, minimo=12) == []


def test_ninguna_contrasena_ni_token_de_sesion_aparece_en_los_logs(marcas):
    assert marcas["mala"] in CLAVES_USADAS and marcas["datos"]["clave"] in CLAVES_USADAS and len(TOKENS_DE_SESION) >= 1
    assert _buscar(CLAVES_USADAS | TOKENS_DE_SESION) == []


def test_ningun_dato_personal_de_los_clientes_de_prueba_aparece_en_los_logs(marcas):
    d = marcas["datos"]
    personales = set(DATOS_PERSONALES) | {d["nombre"], d["telefono"], d["direccion"], marcas["contacto"]["mensaje"], marcas["contacto"]["nombre"]}
    assert _buscar(personales, minimo=7) == []


def test_los_logs_no_dejan_correos_ni_ruts_completos(marcas):
    correo = re.compile(r"[A-Za-z0-9._%+-]{2,}@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+")
    run = re.compile(r"\b\d{1,2}\.?\d{3}\.?\d{3}-[\dkK]\b")
    permitidos = {"noreply@elasador.cl", "pedidos@elasador.cl", "contacto@elasador.cl"}   # direcciones del propio negocio, no de clientes
    ajenos = []
    for i, s, servicio, texto in _logs():
        ajenos += [(servicio, "correo") for c in set(correo.findall(texto)) if c not in permitidos]
        ajenos += [(servicio, "run") for _ in set(run.findall(texto))]
    assert ajenos == [], f"datos personales completos en los logs: {sorted(set(ajenos))}"


def test_los_logs_son_json_y_cada_solicitud_tiene_identificador_de_correlacion(marcas):
    servicios_con_solicitudes = set()
    for i, s, servicio, texto in _logs():
        if servicio in ("vault",):
            continue
        for linea in texto.splitlines():
            try:
                reg = json.loads(linea)
            except ValueError:
                pytest.fail(f"{servicio}: línea que no es JSON: {linea[:120]}")
            assert {"ts", "nivel", "logger", "msg"} <= set(reg), reg
            if reg["msg"] == "solicitud":
                servicios_con_solicitudes.add(servicio)
                assert re.fullmatch(r"[A-Za-z0-9-]{8,64}", reg["request_id"] or ""), reg
                assert {"metodo", "ruta", "status", "ms", "user_id"} <= set(reg), reg
                assert "?" not in reg["ruta"], f"la ruta registrada no debe incluir la cadena de consulta: {reg['ruta']}"
    assert {"api-gateway", "auth", "clients", "orders", "payments", "inventory", "notifications", "graphql-gateway"} <= servicios_con_solicitudes


def test_el_identificador_de_correlacion_del_cliente_viaja_del_gateway_a_los_servicios(sistema, marcas):
    rid = marcas["rid"]
    vistos = {}
    for servicio in ("api-gateway", "auth", "clients"):
        vistos[servicio] = [l for l in lineas_de_log(sistema, servicio) if l.get("request_id") == rid and l.get("msg") == "solicitud"]
    assert vistos["api-gateway"] and vistos["auth"] and vistos["clients"], f"el identificador {rid} no llegó a todos los servicios: { {k: len(v) for k, v in vistos.items()} }"
    rutas = {l["ruta"] for l in vistos["clients"]}
    assert "/clients/me" in rutas
    # la ruta de pedidos, con la misma clave de idempotencia dos veces, deja rastro del mismo identificador en orders
    assert [l for l in lineas_de_log(sistema, "orders") if l.get("request_id") == rid and l.get("msg") == "solicitud"]


def test_un_identificador_de_correlacion_malicioso_no_entra_a_los_logs(sistema, gw):
    mal = "x\"}{\"ts\":\"falso\",\"nivel\":\"INFO\",\"msg\":\"inyectado"
    r = Api(gw).get("/api/products?limit=1", headers={"X-Request-ID": "no-valido-" + "a" * 100})
    assert r.status_code == 200 and re.fullmatch(r"[A-Za-z0-9-]{8,64}", r.headers["x-request-id"]) and "no-valido" not in r.headers["x-request-id"]
    try:
        Api(gw).get("/api/products?limit=1", headers={"X-Request-ID": mal.encode("latin-1", "ignore").decode("latin-1")})
    except Exception:
        pass
    for linea in lineas_de_log(sistema, "api-gateway"):
        assert linea.get("msg") != "inyectado" and linea.get("ts") != "falso"


# ----------------------------- respuestas -----------------------------------------------------------
CAMPOS_PROHIBIDOS = {"passwordhash", "password", "clave", "clavehash", "hash", "authuserid", "secret", "secreto", "apikey", "webhooksecret",
                     "accesstoken", "token", "vaulttoken", "xservicesecret", "proveedorpagoid", "claveidempotencia", "intentosfallidos", "bloqueadohasta"}


def _claves(objeto):
    if isinstance(objeto, dict):
        for k, v in objeto.items():
            yield k
            yield from _claves(v)
    elif isinstance(objeto, list):
        for v in objeto:
            yield from _claves(v)


def test_ninguna_respuesta_expone_campos_internos_secretos_ni_cabeceras_de_servicio(marcas):
    assert len(TRAFICO) >= 10
    for metodo, ruta, status, texto, cabeceras in TRAFICO:
        try:
            cuerpo = json.loads(texto)
        except ValueError:
            cuerpo = None
        if cuerpo is not None:
            for k in _claves(cuerpo):
                normal = re.sub(r"[^a-z]", "", k.lower())
                assert normal not in CAMPOS_PROHIBIDOS, f"{metodo} {ruta} ({status}) devuelve el campo interno «{k}»"
        bajas = {k.lower(): v for k, v in cabeceras.items()}
        for k in bajas:
            assert not k.startswith(("x-service-", "x-authenticated-")), f"{metodo} {ruta} deja salir la cabecera interna {k}"
        assert "uvicorn" not in bajas.get("server", "").lower(), "el servidor no debe anunciar su software"
        assert "traceback" not in texto.lower() and "pymongo" not in texto.lower() and "mongomock" not in texto.lower(), f"{metodo} {ruta} deja ver detalles internos"


def test_las_respuestas_nunca_contienen_secretos_de_vault(sistema, marcas):
    secretos = [v for v in sistema.secretos_conocidos if len(v) >= 12]
    assert len(secretos) >= 25
    for metodo, ruta, status, texto, cabeceras in TRAFICO:
        junto = texto + json.dumps(cabeceras)
        for v in secretos:
            assert v not in junto, f"{metodo} {ruta} ({status}) contiene un secreto de Vault"


def test_ninguna_respuesta_trae_las_contrasenas_ni_los_tokens_de_sesion(marcas):
    for metodo, ruta, status, texto, cabeceras in TRAFICO:
        cuerpo = texto
        for c in CLAVES_USADAS:
            if len(c) >= 8 and c in cuerpo:
                pytest.fail(f"{metodo} {ruta} ({status}) repite una contraseña")
        if ruta != "/api/auth/login":   # solo el login entrega la cookie, y lo hace en la cabecera Set-Cookie (HttpOnly), no en el cuerpo
            for t in TOKENS_DE_SESION:
                assert t not in cuerpo, f"{metodo} {ruta} repite un token de sesión en el cuerpo"
        assert not any(t in cuerpo for t in TOKENS_DE_SESION), f"{metodo} {ruta} deja el token de sesión en el cuerpo"
