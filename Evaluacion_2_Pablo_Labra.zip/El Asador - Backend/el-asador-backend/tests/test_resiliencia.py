"""Resiliencia: qué pasa cuando un servicio deja de responder (colgado) o desaparece (apagado).

Se hace con procesos reales: `congelar` detiene el proceso (SIGSTOP) para que acepte conexiones pero no conteste, y `apagar`
lo mata. Cada prueba deja el sistema sano al terminar y comprueba cuatro cosas:
  1. el usuario recibe un error CONTROLADO y rápido (503/504 con Retry-After), nunca un cuelgue ni una traza;
  2. lo que NO depende del servicio caído sigue funcionando (no hay caídas en cascada);
  3. no quedan datos a medias (pedidos fantasma, perfiles sin cuenta, ventas dobles);
  4. al volver el servicio, el sistema converge solo (reintentos, conciliación, idempotencia).
Este módulo levanta su propio sistema (plazos cortos y escalonados: servicios 1 s < GraphQL 2 s < gateway 3 s; cortacircuitos 2 s).
"""
import contextlib
import tempfile
import time

import httpx
import pytest

from ayuda import (Api, DATOS_PERSONALES, consulta_del_frontend, crear_pedido, datos_registro, esperar, estado_pedido, iniciar_pago, pagar_en_proveedor,
                   hoy_santiago, pedido_ok, pedido_pagado_manual, ventas_del_dia)
from conftest import ENTORNO
from stack import Stack

pytestmark = pytest.mark.resiliencia

PAUSA = 2          # CIRCUITO_PAUSA de este sistema
PLAZO_INTERNO = 1  # UPSTREAM_TIMEOUT de los servicios internos
PLAZO_GRAPHQL = 2  # el GraphQL gateway espera más que los servicios internos...
PLAZO_GATEWAY = 3  # ...y el gateway público más que todos: cada capa debe rendirse ANTES que la de arriba para poder contestar un error limpio

MIS_PEDIDOS = consulta_del_frontend("CONSULTA_PEDIDOS")


@pytest.fixture(scope="module")
def caos():
    env = {**ENTORNO, "UPSTREAM_TIMEOUT": str(PLAZO_INTERNO), "CIRCUITO_PAUSA": str(PAUSA), "WEBHOOK_REINTENTOS": "1"}
    por_servicio = {"api-gateway": {"UPSTREAM_TIMEOUT": str(PLAZO_GATEWAY)}, "graphql-gateway": {"UPSTREAM_TIMEOUT": str(PLAZO_GRAPHQL)}}
    with Stack(tempfile.mkdtemp(prefix="asador-logs-caos-"), extra_env=env, por_servicio=por_servicio) as s:
        yield s


@pytest.fixture(scope="module")
def gw(caos):
    return caos.urls["api-gateway"]


def _entrar(gw, correo, clave):
    api = Api(gw)
    assert api.login(correo, clave).status_code == 200
    return api


@pytest.fixture(scope="module")
def admin(gw):
    return _entrar(gw, "admin@elasador.cl", "admin123")


@pytest.fixture(scope="module")
def despacho(gw):
    return _entrar(gw, "despacho@elasador.cl", "despacho123")


@pytest.fixture
def cliente(gw):
    """Un cliente nuevo (con su propio pedido) por prueba."""
    api = Api(gw)
    d = datos_registro()
    assert api.post("/api/clients/register", json=d).status_code == 201
    assert api.login(d["correo"], d["clave"]).status_code == 200
    api.datos = d
    DATOS_PERSONALES.update({d["run"], d["run"].replace("-", ""), d["correo"]})
    yield api
    api.cerrar()


def _boleta(api, pedido_id):
    """La boleta del pedido, o None mientras todavía no se emite (404)."""
    r = api.get(f"/api/orders/{pedido_id}/receipt")
    return r.json() if r.status_code == 200 else None


def _saludable(s, nombre):
    try:
        return httpx.get(s.urls[nombre] + "/health", timeout=3).status_code == 200
    except httpx.HTTPError:
        return False


@contextlib.contextmanager
def congelado(s, *nombres):
    """El servicio acepta conexiones pero no contesta. Al salir se descongela y se espera a que los circuitos vuelvan a cerrar."""
    for n in nombres:
        s.congelar(n)
    try:
        yield
    finally:
        for n in nombres:
            s.descongelar(n)
        for n in nombres:
            esperar(lambda n=n: _saludable(s, n), segundos=15, mensaje=f"{n} no volvió a responder")
        time.sleep(PAUSA + 0.5)


def _error_controlado(r, codigos):
    """503/504 con el formato de error común, plazo de reintento y sin rastros internos."""
    assert r.status_code in (503, 504), (r.status_code, r.text)
    cuerpo = r.json()
    assert cuerpo["codigo"] in codigos, cuerpo
    assert set(cuerpo) <= {"detail", "codigo", "request_id"}, cuerpo
    assert "Retry-After" in r.headers
    for rastro in ("Traceback", "httpx", "ConnectTimeout", "ReadTimeout", "127.0.0.1", "mongo", "vault", "inventory", "payments"):
        assert rastro.lower() not in r.text.lower(), f"la respuesta de error deja ver «{rastro}»: {r.text}"


# ----------------------------- inventario colgado ------------------------------------------------
def test_con_inventario_colgado_no_se_crean_pedidos_a_medias_y_lo_demas_sigue(caos, gw, cliente):
    llave = "reintento-sin-inventario"
    with congelado(caos, "inventory"):
        tiempos = []
        for _ in range(7):   # más fallos que los que abren el cortacircuitos
            t0 = time.time()
            r = crear_pedido(cliente, llave=llave)
            tiempos.append(time.time() - t0)
            _error_controlado(r, {"SERVICIO_NO_DISPONIBLE", "TIEMPO_AGOTADO"})
        assert max(tiempos) < PLAZO_GATEWAY + 2, f"el usuario esperó demasiado: {tiempos}"
        # La caída de inventario NO contagia a pedidos: ver mis pedidos y mi sesión siguen respondiendo.
        assert cliente.get("/api/orders").status_code == 200
        assert cliente.get("/api/auth/me").status_code == 200
        assert cliente.get("/api/clients/me").status_code == 200
    assert cliente.get("/api/orders").json() == [], "quedó un pedido fantasma de un intento fallido"
    # El mismo intento (misma Idempotency-Key) se completa cuando inventario vuelve, y una repetición no crea otro pedido.
    primero = crear_pedido(cliente, llave=llave)
    assert primero.status_code == 201, primero.text
    segundo = crear_pedido(cliente, llave=llave)
    assert segundo.status_code == 200 and segundo.json()["id"] == primero.json()["id"]
    assert len(cliente.get("/api/orders").json()) == 1


def test_el_catalogo_en_cache_sigue_visible_unos_segundos_sin_inventario(caos, gw):
    anon = Api(gw)
    assert anon.get("/api/products?limit=5").status_code == 200   # deja la consulta en la caché del gateway (10 s)
    with congelado(caos, "inventory"):
        t0 = time.time()
        r = anon.get("/api/products?limit=5")
        assert r.status_code == 200 and time.time() - t0 < 1, "el catálogo cacheado debe responder sin esperar a inventario"
        # otra consulta no está en la caché y sí necesita a inventario: error controlado
        _error_controlado(anon.get("/api/products?limit=6"), {"SERVICIO_NO_DISPONIBLE", "TIEMPO_AGOTADO"})


# ----------------------------- cortacircuitos ----------------------------------------------------
def test_el_cortacircuitos_deja_de_esperar_y_se_recupera_solo(caos, gw, admin):
    with congelado(caos, "notifications"):
        tiempos, codigos = [], []
        for _ in range(8):
            t0 = time.time()
            r = admin.get("/api/admin/outbox")
            tiempos.append(time.time() - t0)
            codigos.append(r.status_code)
            _error_controlado(r, {"SERVICIO_NO_DISPONIBLE", "TIEMPO_AGOTADO"})
        assert tiempos[0] >= PLAZO_INTERNO, "la primera llamada debería haber esperado el plazo"
        assert all(t < 0.7 for t in tiempos[-2:]), f"con el circuito abierto la respuesta debe ser inmediata: {tiempos}"
        assert codigos[-1] == 503
        assert admin.get("/api/auth/me").status_code == 200   # el resto del sitio no se entera
    # Pasada la pausa del circuito, la primera llamada de prueba sale bien y todo vuelve a la normalidad.
    assert admin.get("/api/admin/outbox").status_code == 200
    assert admin.get("/api/admin/outbox").status_code == 200


# ----------------------------- pagos colgado -----------------------------------------------------
def test_con_pagos_colgado_mis_pedidos_se_ven_sin_el_dato_del_pago(caos, gw, cliente):
    p = pedido_ok(cliente)
    iniciar_pago(cliente, p["id"])
    sano = cliente.gql(MIS_PEDIDOS, {"desde": 0}).json()
    assert sano["data"]["misPedidos"]["items"][0]["pago"]["estado"] == "iniciado" and "extensions" not in sano
    with congelado(caos, "payments"):
        t0 = time.time()
        r = cliente.gql(MIS_PEDIDOS, {"desde": 0})
        assert time.time() - t0 < PLAZO_GATEWAY + 2
        assert r.status_code == 200, r.text
        d = r.json()
        assert "errors" not in d, d
        fila = d["data"]["misPedidos"]["items"][0]
        assert fila["id"] == p["id"] and fila["estado"] == "Pago pendiente" and fila["total"] == p["total"]   # lo de pedidos se ve completo
        assert fila["pago"] is None and fila["boleta"] is None                                              # lo de pagos queda vacío
        assert d["extensions"]["avisos"] == ["PAGOS_NO_DISPONIBLES"]                                        # y la web puede avisarlo
        # Pagar no es posible mientras tanto, pero el error es claro y el pedido sigue intacto.
        _error_controlado(cliente.post(f"/api/orders/{p['id']}/payment"), {"SERVICIO_NO_DISPONIBLE", "TIEMPO_AGOTADO"})
        assert cliente.get(f"/api/orders/{p['id']}").json()["estado"] == "Pago pendiente"
    otra = cliente.gql(MIS_PEDIDOS, {"desde": 0}).json()
    assert "extensions" not in otra and otra["data"]["misPedidos"]["items"][0]["pago"]["estado"] == "iniciado"


def test_con_analitica_colgada_el_reporte_falla_solo_en_su_campo(caos, gw, admin, despacho):
    consulta = ("query($d:String!){ panelAdmin { pedidosPorEstado { estado cantidad } } "
                "reporteVentas(desde:$d, hasta:$d){ totales{ ventas } } }")
    with congelado(caos, "analytics"):
        r = admin.gql(consulta, {"d": hoy_santiago()})
        assert r.status_code == 200
        d = r.json()
        assert d["data"]["reporteVentas"] is None and d["data"]["panelAdmin"]["pedidosPorEstado"], d   # el tablero de pedidos sí llega
        assert [e["extensions"]["codigo"] for e in d["errors"]] == ["SERVICIO_NO_DISPONIBLE"]
        assert "analytics" not in r.text.lower()
        # La pantalla de despacho no usa analítica y sigue completa.
        despacho_q = consulta_del_frontend("CONSULTA_DESPACHO")
        ok = despacho.gql(despacho_q, {"estado": "En preparación", "desde": 0})
        assert ok.status_code == 200 and "errors" not in ok.json()


# ----------------------------- auth colgado ------------------------------------------------------
def test_con_auth_colgado_nadie_pierde_la_sesion_y_el_catalogo_sigue_publico(caos, gw, cliente):
    anon = Api(gw)
    with congelado(caos, "auth"):
        r = cliente.get("/api/orders")
        _error_controlado(r, {"SERVICIO_NO_DISPONIBLE", "TIEMPO_AGOTADO"})
        assert "set-cookie" not in {k.lower() for k in r.headers}, "un fallo del Auth Service no debe cerrar la sesión del usuario"
        _error_controlado(anon.post("/api/auth/login", json={"username": "admin@elasador.cl", "password": "admin123"}), {"SERVICIO_NO_DISPONIBLE", "TIEMPO_AGOTADO"})
        assert anon.get("/api/delivery-zones").status_code == 200   # público: no necesita sesión ni a Auth
        assert anon.get("/api/products?limit=3").status_code == 200
    # La sesión sobrevive: el token sigue siendo válido apenas Auth vuelve.
    assert cliente.get("/api/orders").status_code == 200
    assert _entrar(gw, "admin@elasador.cl", "admin123").get("/api/auth/me").json()["usuario"]["username"] == "admin@elasador.cl"


def test_si_auth_no_responde_al_registrarse_repetir_el_registro_lo_completa_sin_duplicar(caos, gw):
    d = datos_registro()
    DATOS_PERSONALES.update({d["run"], d["run"].replace("-", ""), d["correo"]})
    web = Api(gw)
    with congelado(caos, "auth"):
        _error_controlado(web.post("/api/clients/register", json=d), {"SERVICIO_NO_DISPONIBLE", "TIEMPO_AGOTADO"})
    # Auth pudo haber creado la cuenta justo antes de rendirse: repetir con los mismos datos debe terminar bien y una sola vez.
    r = web.post("/api/clients/register", json=d)
    assert r.status_code == 201, r.text
    assert web.login(d["correo"], d["clave"]).status_code == 200
    yo = web.get("/api/clients/me")
    assert yo.status_code == 200 and yo.json()["correo"] == d["correo"]
    # y ahora sí es un registro repetido de verdad: no se crea nada más y no se revela que ya existe
    assert Api(gw).post("/api/clients/register", json=d).status_code == 409


# ----------------------------- notificaciones apagado ---------------------------------------------
def test_sin_servicio_de_correo_no_hay_registros_a_medias_y_la_boleta_llega_al_volver(caos, gw, admin):
    d = datos_registro()   # el registro que se intenta durante la caída
    DATOS_PERSONALES.update({d["run"], d["run"].replace("-", ""), d["correo"]})
    web = Api(gw)
    cliente = Api(gw)      # un cliente que ya existía antes de la caída
    base = datos_registro()
    DATOS_PERSONALES.update({base["run"], base["run"].replace("-", ""), base["correo"]})
    assert cliente.post("/api/clients/register", json=base).status_code == 201
    assert cliente.login(base["correo"], base["clave"]).status_code == 200

    caos.apagar("notifications")
    try:
        # (a) Registrarse necesita validar el correo: sin el servicio se rechaza SIN crear nada.
        _error_controlado(web.post("/api/clients/register", json=d), {"VALIDACION_CORREO_NO_DISPONIBLE", "SERVICIO_NO_DISPONIBLE"})
        # (b) Pagar NO depende del correo: el pedido se paga y avanza aunque la boleta no pueda enviarse todavía.
        p, _ = pedido_pagado_manual(cliente, admin, referencia="TRF-CAIDA-1")
        assert estado_pedido(cliente, p["id"]) == "En preparación"
        boleta = cliente.get(f"/api/orders/{p['id']}/receipt")
        assert boleta.status_code == 200, boleta.text
        folio = boleta.json()["folio"]
    finally:
        caos.encender("notifications")
    # (a) tras la caída el mismo registro funciona: no quedó un perfil «reclamado» a medias
    assert web.post("/api/clients/register", json=d).status_code == 201
    # (b) la boleta pendiente se envía sola cuando el servicio de correo vuelve
    def entregada():
        return any(folio in f["asunto"] for f in admin.get("/api/admin/outbox?limit=100").json())
    esperar(entregada, segundos=25, mensaje=f"la boleta {folio} no se envió al volver el servicio de correo")
    time.sleep(3)
    asuntos = [f["asunto"] for f in admin.get("/api/admin/outbox?limit=100").json() if folio in f["asunto"]]
    assert len(asuntos) == 1, f"la boleta se envió {len(asuntos)} veces"


# ----------------------------- analítica colgada: la venta se cuenta una sola vez -----------------
def test_con_analitica_colgada_el_pago_avanza_y_la_venta_se_cuenta_una_vez_al_volver(caos, gw, admin, cliente):
    antes = ventas_del_dia(admin)
    with congelado(caos, "analytics"):
        p, _ = pedido_pagado_manual(cliente, admin, referencia="TRF-ANALITICA-1")   # el pago y el pedido NO esperan a la analítica
        assert estado_pedido(cliente, p["id"]) == "En preparación"
        assert cliente.get(f"/api/orders/{p['id']}/receipt").status_code == 200
    esperar(lambda: ventas_del_dia(admin)[0] == antes[0] + p["total"], segundos=25, mensaje="la venta no llegó a la analítica al volver")
    time.sleep(4)   # espera por si hubiera un segundo envío (el original encolado + el reintento)
    despues = ventas_del_dia(admin)
    assert despues == (antes[0] + p["total"], antes[1] + 1), f"la venta se contó mal: antes={antes} después={despues}"


# ----------------------------- pedidos colgado mientras el proveedor cobra ------------------------
def test_con_pedidos_colgado_el_pago_queda_aprobado_y_el_pedido_avanza_al_volver(caos, gw, admin, cliente):
    antes = ventas_del_dia(admin)
    p = pedido_ok(cliente)
    pago = iniciar_pago(cliente, p["id"])
    with congelado(caos, "orders"):
        pagar_en_proveedor(pago["checkoutUrl"])      # el proveedor cobra y avisa por webhook; payments aprueba pero no puede avisar a pedidos
        time.sleep(1)
    esperar(lambda: estado_pedido(cliente, p["id"]) == "En preparación", segundos=25, mensaje="el pedido no avanzó cuando pedidos volvió")
    r = cliente.get(f"/api/orders/{p['id']}/payment").json()
    assert r["estado"] == "aprobado"
    boleta = esperar(lambda: _boleta(cliente, p["id"]), segundos=20, mensaje="no se emitió la boleta")
    assert boleta["total"] == p["total"]
    esperar(lambda: ventas_del_dia(admin)[1] == antes[1] + 1, segundos=25, mensaje="la venta no se registró")
    time.sleep(3)
    assert ventas_del_dia(admin) == (antes[0] + p["total"], antes[1] + 1)


def test_un_aviso_del_proveedor_que_no_llega_se_recupera_al_volver_pagos(caos, gw, admin, cliente):
    """Con WEBHOOK_REINTENTOS=1 el proveedor no insiste: si payments está colgado, ese aviso no lo procesa nadie a tiempo."""
    antes = ventas_del_dia(admin)
    p = pedido_ok(cliente)
    pago = iniciar_pago(cliente, p["id"])
    with congelado(caos, "payments"):
        pagar_en_proveedor(pago["checkoutUrl"])
        time.sleep(PLAZO_GATEWAY + 1)
        assert estado_pedido(cliente, p["id"]) == "Pago pendiente"   # nadie ha confirmado el pago todavía
    esperar(lambda: estado_pedido(cliente, p["id"]) == "En preparación", segundos=30, mensaje="el pago quedó sin confirmar después de recuperarse payments")
    assert cliente.get(f"/api/orders/{p['id']}/payment").json()["estado"] == "aprobado"
    folio = esperar(lambda: _boleta(cliente, p["id"]), segundos=20, mensaje="no se emitió la boleta")["folio"]
    esperar(lambda: ventas_del_dia(admin) == (antes[0] + p["total"], antes[1] + 1), segundos=25, mensaje="la venta no llegó a la analítica")
    assert _boleta(cliente, p["id"])["folio"] == folio


# ----------------------------- anular con pagos colgado -------------------------------------------
def test_anular_con_pagos_colgado_anula_al_instante_y_el_reembolso_se_registra_al_volver(caos, gw, admin, cliente):
    p, _ = pedido_pagado_manual(cliente, admin, referencia="TRF-ANULAR-1")
    antes = ventas_del_dia(admin)   # incluye la venta de este pedido (la confirmación manual espera a que se registre)
    with congelado(caos, "payments"):
        t0 = time.time()
        r = cliente.post(f"/api/orders/{p['id']}/cancellation", json={"motivo": "Ya no lo necesito"})
        assert r.status_code == 200, r.text
        assert time.time() - t0 < PLAZO_GATEWAY + 1
        anulado = r.json()
        assert anulado["estado"] == "Anulado" and anulado["reembolso"] == "pendiente"   # orders manda sobre el estado: no espera a payments
    # Al volver payments, orders completa el aviso: el pago queda con reembolso pendiente y la venta se descuenta de los reportes.
    def reembolso_registrado():
        filas = admin.get("/api/admin/payments?reembolso=pendiente&limit=100").json()
        return any(f["pedidoId"] == p["id"] for f in filas)
    esperar(reembolso_registrado, segundos=30, mensaje="el reembolso pendiente no quedó registrado en payments")
    esperar(lambda: ventas_del_dia(admin)[1] == antes[1] - 1, segundos=30, mensaje="la venta anulada siguió contando en los reportes")
    time.sleep(3)
    assert ventas_del_dia(admin) == (antes[0] - p["total"], antes[1] - 1)


# ----------------------------- GraphQL colgado ---------------------------------------------------
def test_con_graphql_colgado_el_resto_de_la_web_sigue_y_se_recupera(caos, gw, cliente):
    with congelado(caos, "graphql-gateway"):
        for _ in range(6):
            _error_controlado(cliente.gql(MIS_PEDIDOS, {"desde": 0}), {"SERVICIO_NO_DISPONIBLE", "TIEMPO_AGOTADO"})
        assert cliente.get("/api/orders").status_code == 200          # la versión REST de la lista sigue disponible
        assert cliente.get("/api/auth/me").status_code == 200
    ok = cliente.gql(MIS_PEDIDOS, {"desde": 0})
    assert ok.status_code == 200 and "errors" not in ok.json()


# ----------------------------- al final todo sigue sano -------------------------------------------
def test_despues_de_todas_las_caidas_el_sistema_entero_esta_sano(caos, gw, admin):
    for n in caos.urls:
        assert _saludable(caos, n), f"{n} no está sano"
    assert admin.get("/api/admin/outbox").status_code == 200
    assert admin.get("/api/admin/payments").status_code == 200
    assert admin.get("/api/admin/orders").status_code == 200
