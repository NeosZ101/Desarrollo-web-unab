"""Pruebas unitarias de las reglas puras del negocio y de la seguridad (sin red ni base de datos).

Cada regla crítica tiene casos de borde. Las mismas reglas se «mutan» en tests/mutaciones.py para comprobar que estas pruebas
realmente fallan cuando alguien rompe la regla.
"""
import itertools
import json
from datetime import date

import pytest
from graphql import build_schema, parse, validate

from ayuda import RAIZ, cargar

clientes = cargar("clients-service/app/reglas.py", "u_clientes")
pedidos = cargar("orders-service/app/reglas.py", "u_pedidos")
pagos = cargar("payments-service/app/reglas.py", "u_pagos")
inventario = cargar("inventory-service/app/reglas.py", "u_inventario")
auth = cargar("auth-service/app/reglas.py", "u_auth")
limites = cargar("graphql-gateway/app/limites.py", "u_limites")
rutas = cargar("api-gateway/app/rutas.py", "u_rutas")

from common import logs, seguridad, tiempo  # noqa: E402


# ----------------------------- RUN, teléfono, ubicación, edad (clients) ---------------------------------------
def test_run_valido_se_normaliza_y_se_formatea():
    assert clientes.normalizar_run("12.345.678-5") == "123456785"
    assert clientes.normalizar_run(" 12345678-5 ") == "123456785"
    assert clientes.formatear_run("123456785") == "12.345.678-5"


def test_run_con_digito_verificador_incorrecto_se_rechaza():
    with pytest.raises(ValueError, match="verificador"):
        clientes.normalizar_run("12.345.678-9")


@pytest.mark.parametrize("texto", ["", "abc", "1-9", "123456789012-3", "12.345.678-", None, "12.345.678-KK"])
def test_run_con_formato_invalido_se_rechaza(texto):
    with pytest.raises(ValueError):
        clientes.normalizar_run(texto)


def test_run_con_k_acepta_minuscula_y_mayuscula():
    cuerpo = next(n for n in range(10_000_000, 10_000_200) if clientes.digito_verificador(n) == "K")
    assert clientes.normalizar_run(f"{cuerpo}-k") == f"{cuerpo}K" == clientes.normalizar_run(f"{cuerpo}-K")


def test_digito_verificador_cubre_los_tres_casos_del_modulo_11():
    vistos = {clientes.digito_verificador(n) for n in range(10_000_000, 10_000_300)}
    assert "K" in vistos and "0" in vistos and {"1", "2", "3"} <= vistos


@pytest.mark.parametrize("telefono", ["+56 9 1234 5678", "912345678", "+56912345678"])
def test_telefono_valido(telefono):
    assert clientes.validar_telefono(telefono) == telefono


@pytest.mark.parametrize("telefono", ["", "123", "abcdefgh", "+56 9 1234 5678 9999 000", "12345678; DROP TABLE"])
def test_telefono_invalido(telefono):
    with pytest.raises(ValueError):
        clientes.validar_telefono(telefono)


def test_ubicacion_exige_coherencia_region_provincia_comuna():
    clientes.validar_ubicacion("Región Metropolitana de Santiago", "Santiago", "Ñuñoa")
    clientes.validar_ubicacion("Región Metropolitana de Santiago", "Cordillera", "Puente Alto")
    with pytest.raises(ValueError):
        clientes.validar_ubicacion("Región Metropolitana de Santiago", "Cordillera", "Ñuñoa")
    with pytest.raises(ValueError):
        clientes.validar_ubicacion("Región de Valparaíso", "Valparaíso", "Viña del Mar")


def test_ubicacion_sin_region_solo_comprueba_cobertura():
    clientes.validar_ubicacion(None, None, "Maipú")
    with pytest.raises(ValueError, match="cobertura"):
        clientes.validar_ubicacion(None, None, "Valparaíso")


def test_mayoria_de_edad_en_el_borde_del_cumpleanos():
    hoy = date(2026, 11, 4)
    assert clientes.es_mayor_de_edad("2008-11-04", hoy) is True       # cumple 18 hoy
    assert clientes.es_mayor_de_edad("2008-11-05", hoy) is False      # cumple 18 mañana
    assert clientes.es_mayor_de_edad("1990-01-01", hoy) is True
    assert clientes.es_mayor_de_edad(None, hoy) is False
    assert clientes.es_mayor_de_edad("", hoy) is False


@pytest.mark.parametrize("fecha", ["2999-01-01", "1800-01-01", "no-es-fecha", "2026-13-40"])
def test_fecha_de_nacimiento_implausible_se_rechaza(fecha):
    with pytest.raises(ValueError):
        clientes.validar_nacimiento(fecha, date(2026, 11, 4))


# ----------------------------- despacho, totales, anulación, eventos (orders) --------------------------------
CFG_DESPACHO = {"kmGratis": 3, "base": 2000, "porKm": 400}


@pytest.mark.parametrize("km,esperado", [(0, 0), (1.5, 0), (3.0, 0), (3.01, 2400), (3.6, 2400), (5.2, 3200), (15.8, 7200), (18.5, 8400)])
def test_costo_de_despacho(km, esperado):
    assert pedidos.costo_despacho(km, CFG_DESPACHO) == esperado


def test_despacho_nunca_baja_al_alejarse():
    costos = [pedidos.costo_despacho(km / 10, CFG_DESPACHO) for km in range(0, 400)]
    assert costos == sorted(costos)


def test_totales_suman_lineas_y_despacho():
    lineas = [{"precio": 24990, "cantidad": 1}, {"precio": 2990, "cantidad": 2}]
    assert pedidos.totales(lineas, 2400) == (30970, 33370)
    assert pedidos.totales([], 0) == (0, 0)


def test_maquina_de_estados_coincide_con_la_tabla():
    estados, actores = pedidos.ESTADOS, ("cliente", "administrador", "despacho", "payments", "dueno", "anonimo")
    permitidas = {(d, h, a) for (d, h), quienes in pedidos.TRANSICIONES.items() for a in quienes}
    for desde, hasta, actor in itertools.product(estados, estados, actores):
        assert pedidos.transicion_permitida(desde, hasta, actor) == ((desde, hasta, actor) in permitidas)


def test_solo_payments_confirma_el_pago():
    for actor in ("cliente", "administrador", "despacho", "dueno"):
        assert not pedidos.transicion_permitida("Pago pendiente", "En preparación", actor)
    assert pedidos.transicion_permitida("Pago pendiente", "En preparación", "payments")


def test_estados_finales_no_tienen_salida():
    for final in ("Entregado", "Anulado"):
        for hasta in pedidos.ESTADOS:
            for actor in ("cliente", "administrador", "despacho", "payments"):
                assert not pedidos.transicion_permitida(final, hasta, actor)


def test_el_despacho_avanza_solo_en_orden_y_no_anula():
    assert pedidos.transicion_permitida("En preparación", "En camino", "despacho")
    assert pedidos.transicion_permitida("En camino", "Entregado", "despacho")
    assert not pedidos.transicion_permitida("En preparación", "Entregado", "despacho")
    assert not pedidos.transicion_permitida("En preparación", "Anulado", "despacho")
    assert not pedidos.transicion_permitida("En camino", "Anulado", "cliente")


def test_motivo_de_anulacion():
    assert pedidos.validar_anulacion("Ya no lo necesito", "") == "Ya no lo necesito"
    assert pedidos.validar_anulacion("Ya no lo necesito", " llegó tarde ") == "Ya no lo necesito: llegó tarde"
    with pytest.raises(ValueError):
        pedidos.validar_anulacion("Porque sí", "")
    with pytest.raises(ValueError):
        pedidos.validar_anulacion("Otro motivo", "ab")
    assert pedidos.validar_anulacion("Otro motivo", "se cayó la comida").startswith("Otro motivo: ")


CFG_EVENTO = json.loads((RAIZ / "orders-service/app/seed/config.json").read_text(encoding="utf-8"))["config"][1]


def _cotizar(**kw):
    base = dict(personas=10, menu_id="clasico", bebidas=False, ensaladas=False, parrillero=False, precio_bebida=2990, precio_ensalada=3990, despacho=0, comuna=None)
    base.update(kw)
    return pedidos.cotizar_evento(CFG_EVENTO, **base)


def test_cotizacion_de_evento_suma_cada_concepto():
    detalle, total = _cotizar(personas=10, bebidas=True, ensaladas=True, parrillero=True, despacho=2400, comuna="Santiago")
    # menú 9.990 × 10 + 3 bebidas + 3 ensaladas (una cada 4 personas, redondeando hacia arriba) + parrillero + despacho
    assert total == 99900 + 3 * 2990 + 3 * 3990 + 60000 + 2400
    assert [d["valor"] for d in detalle] == [99900, 8970, 11970, 60000, 2400]


def test_cotizacion_de_evento_valida_cantidad_y_menu():
    with pytest.raises(ValueError, match="desde 10"):
        _cotizar(personas=9)
    with pytest.raises(ValueError, match="más de 300"):
        _cotizar(personas=301)
    with pytest.raises(ValueError, match="Menú"):
        _cotizar(menu_id="inexistente")
    assert _cotizar(personas=10)[1] == 99900 and _cotizar(personas=300)[1] == 9990 * 300


# ----------------------------- IVA, firma del proveedor (payments) -----------------------------------------
def test_desglose_de_iva():
    assert pagos.desglose_iva(11900) == (10000, 1900)
    assert pagos.desglose_iva(0) == (0, 0)
    for total in (1, 990, 21190, 30970, 123457, 9_999_999):
        neto, iva = pagos.desglose_iva(total)
        assert neto + iva == total
        assert abs(iva - total * 19 / 119) <= 0.5 + 1e-9


def test_formato_de_pesos():
    assert pagos.clp(0) == "$0" and pagos.clp(21190) == "$21.190" and pagos.clp(1234567) == "$1.234.567"


SECRETO = "secreto-de-prueba-0123456789"
CUERPO = b'{"id":"evt_abcdefgh12345678","type":"payment.succeeded"}'


def _cabecera(t, cuerpo=CUERPO, secreto=SECRETO):
    return f"t={t},v1={pagos.firmar(secreto, t, cuerpo)}"


def test_firma_correcta_se_acepta():
    ahora = 1_800_000_000
    assert pagos.verificar_firma(SECRETO, _cabecera(ahora), CUERPO, ahora) == (True, "ok")


@pytest.mark.parametrize("cabecera,motivo", [
    ("", "firma_ausente"), (None, "firma_ausente"), ("basura", "formato_invalido"), ("t=abc,v1=00", "formato_invalido"),
    ("v1=" + "0" * 64, "formato_invalido"), ("t=1800000000", "formato_invalido"),
])
def test_firma_ausente_o_mal_formada(cabecera, motivo):
    assert pagos.verificar_firma(SECRETO, cabecera, CUERPO, 1_800_000_000) == (False, motivo)


def test_firma_de_cuerpo_alterado_secreto_distinto_o_hora_alterada():
    ahora = 1_800_000_000
    assert pagos.verificar_firma(SECRETO, _cabecera(ahora), CUERPO + b" ", ahora) == (False, "firma_incorrecta")
    assert pagos.verificar_firma(SECRETO, _cabecera(ahora, secreto="otro"), CUERPO, ahora) == (False, "firma_incorrecta")
    cabecera = _cabecera(ahora)
    adulterada = cabecera.replace(f"t={ahora}", f"t={ahora + 1}")
    assert pagos.verificar_firma(SECRETO, adulterada, CUERPO, ahora) == (False, "firma_incorrecta")


def test_ventana_de_tiempo_de_la_firma():
    t = 1_800_000_000
    assert pagos.verificar_firma(SECRETO, _cabecera(t), CUERPO, t + 300)[0] is True
    assert pagos.verificar_firma(SECRETO, _cabecera(t), CUERPO, t + 301) == (False, "fuera_de_ventana")
    assert pagos.verificar_firma(SECRETO, _cabecera(t), CUERPO, t - 300)[0] is True
    assert pagos.verificar_firma(SECRETO, _cabecera(t), CUERPO, t - 301) == (False, "fuera_de_ventana")


def test_firma_con_varias_candidatas_acepta_si_alguna_coincide():
    t = 1_800_000_000
    buena = pagos.firmar(SECRETO, t, CUERPO)
    assert pagos.verificar_firma(SECRETO, f"t={t},v1={'0' * 64},v1={buena}", CUERPO, t)[0] is True
    assert pagos.verificar_firma(SECRETO, f"t={t},v1={'0' * 64},v1={'1' * 64}", CUERPO, t)[0] is False


def test_instrucciones_de_pago_manual_indican_monto_pedido_y_titular():
    texto = pagos.instrucciones_manual("Transferencia bancaria", 21190, "A-1050")
    assert "$21.190" in texto and "A-1050" in texto and pagos.DATOS_BANCARIOS["titular"] in texto and texto.startswith("Transfiere")
    assert pagos.instrucciones_manual("Depósito bancario", 1000, "A-1051").startswith("Deposita")


# ----------------------------- catálogo (inventory) --------------------------------------------------------
def test_precio_de_promo_con_aritmetica_entera():
    comps = [{"id": "p02", "cantidad": 1}, {"id": "p12", "cantidad": 2}, {"id": "p11", "cantidad": 1}]
    precios = {"p02": 44990, "p12": 2990, "p11": 2990}
    assert inventario.precio_promo(comps, precios, 20) == (53960, 43170)
    assert inventario.precio_promo(comps, precios, 0) == (53960, 53960)
    normal, final = inventario.precio_promo(comps, precios, 50)
    assert final < normal and final % 10 == 0


@pytest.mark.parametrize("imagen,valida", [("img/cerveza.svg", True), ("img/a-b-1.svg", True), ("../img/x.svg", False), ("http://evil.example/x.svg", False),
                                           ("img/x.png", False), ("img/X.svg", False), ("//evil/x.svg", False), ("img/../x.svg", False), ("javascript:alert(1)", False)])
def test_imagen_de_producto_solo_ruta_local(imagen, valida):
    if valida:
        assert inventario.validar_imagen(imagen) == imagen
    else:
        with pytest.raises(ValueError):
            inventario.validar_imagen(imagen)


# ----------------------------- política de contraseñas y usuarios (auth) -----------------------------------
def test_politica_de_claves():
    assert auth.validar_clave("Parrilla-Segura-2026", "admin@elasador.cl")
    for mala in ("corta", "12345678", "PASSWORD", "x" * 129):
        with pytest.raises(ValueError):
            auth.validar_clave(mala, "a@b.cl")
    with pytest.raises(ValueError, match="igual al usuario"):
        auth.validar_clave("admin@elasador.cl", "admin@elasador.cl")
    with pytest.raises(ValueError, match="igual al usuario"):
        auth.validar_clave("pablo.labra", "pablo.labra@correo.cl")


def test_usuario_es_un_correo_normalizado():
    assert auth.normalizar_username("  Admin@ElAsador.CL ") == "admin@elasador.cl"
    for malo in ("", "sin-arroba", "a@b", "a b@c.cl", "@x.cl"):
        with pytest.raises(ValueError):
            auth.normalizar_username(malo)


# ----------------------------- confianza entre servicios, logs y fechas (common) -----------------------------
def test_solo_tres_servicios_pueden_propagar_una_identidad():
    assert seguridad.IDENTIDAD_CONFIABLE == frozenset({"api-gateway", "graphql-gateway", "orders"})


def test_lectura_de_la_identidad_propagada():
    h = {"x-authenticated-user": "u-1", "x-authenticated-username": "a@b.cl", "x-authenticated-roles": "cliente,superusuario", "x-authenticated-client": "c-1"}
    i = seguridad.leer_identidad(h)
    assert i.user_id == "u-1" and i.roles == ("cliente",) and i.client_id == "c-1" and not i.es_personal
    assert seguridad.leer_identidad({}) is None
    assert seguridad.leer_identidad({**h, "x-authenticated-user": "../etc/passwd"}) is None
    assert seguridad.leer_identidad({**h, "x-authenticated-roles": "superusuario"}) is None
    assert seguridad.leer_identidad({**h, "x-authenticated-client": "c 1; drop"}) is None


def test_el_log_enmascara_claves_sensibles_en_el_contexto():
    limpio = logs._limpiar({"request_id": "abc", "password": "x", "token_sesion": "y", "correo": "a@b.cl", "run": "1-9", "ruta": "/api/orders", "user_id": "u-1"})
    assert limpio["request_id"] == "abc" and limpio["ruta"] == "/api/orders" and limpio["user_id"] == "u-1"
    assert limpio["password"] == limpio["token_sesion"] == limpio["correo"] == limpio["run"] == "***"


def test_el_dia_de_los_reportes_es_el_dia_local_de_santiago():
    assert tiempo.fecha_local("2026-11-05T02:30:00Z") == "2026-11-04"      # 23:30 del día anterior en Santiago (UTC-3)
    assert tiempo.fecha_local("2026-11-05T03:30:00Z") == "2026-11-05"
    assert tiempo.fecha_local("2026-07-05T03:30:00Z") == "2026-07-04"      # invierno: UTC-4
    assert tiempo.iso().endswith("Z") and tiempo.sumar_dias("2026-02-28", 1) == "2026-03-01"


# ----------------------------- costo de las consultas GraphQL ----------------------------------------------------
ESQUEMA_MINIMO = build_schema("type Query { x: Int }")


def _errores_de_costo(consulta):
    return [e.message for e in validate(ESQUEMA_MINIMO, parse(consulta), [limites.LimiteDeCosto])]


def _consulta_de_pedidos(limit):
    """La consulta REAL de la pantalla «Mis pedidos» (datos-frontend/consultas-graphql.json) con otro valor en `limit`."""
    consulta = json.loads((RAIZ / "datos-frontend" / "consultas-graphql.json").read_text(encoding="utf-8"))["CONSULTA_PEDIDOS"]
    assert "misPedidos(limit: 20," in consulta
    return consulta.replace("misPedidos(limit: 20,", f"misPedidos(limit: {limit},").replace("($desde: Int!)", "($desde: Int!, $n: Int)")


def test_consulta_de_pantalla_con_limit_literal_cabe_en_el_presupuesto():
    assert _errores_de_costo(_consulta_de_pedidos("20")) == []


def test_limit_en_variable_se_cuenta_como_el_maximo():
    errores = _errores_de_costo(_consulta_de_pedidos("$n"))
    assert any("demasiado costosa" in m for m in errores), errores


def test_limit_mayor_al_maximo_se_acota_al_maximo():
    errores = _errores_de_costo(_consulta_de_pedidos("9999"))
    assert any("demasiado costosa" in m for m in errores), errores


def test_omitir_limit_usa_el_valor_por_defecto_de_la_lista():
    sin_limit = "query{ misPedidos{ items{ id lineas{ nombre } } } }"
    assert _errores_de_costo(sin_limit) == []


def test_un_limit_negativo_no_baja_el_costo():
    """Si un limit negativo restara costo, se podría compensar una consulta carísima con otra «negativa»."""
    cara = _consulta_de_pedidos("50").replace("($desde: Int!, $n: Int)", "($desde: Int!)")
    barata = "misPedidos(limit: -1000) { total }"
    assert any("demasiado costosa" in m for m in _errores_de_costo(cara.replace("{ misPedidos(", "{ x: " + barata + " misPedidos(", 1)))


def test_un_limit_de_miles_de_digitos_no_rompe_el_calculo():
    consulta = "query{ misPedidos(limit: " + "9" * 6000 + ") { total items { id } } }"
    errores = _errores_de_costo(consulta)      # antes: ValueError de Python por exceder los dígitos permitidos
    assert errores == [] or all("demasiado costosa" in m or "Int" in m for m in errores)


def test_fragmentos_recursivos_no_cuelgan_el_calculo():
    consulta = "query{ ...A } fragment A on Query { x ...B } fragment B on Query { x ...A }"
    _errores_de_costo(consulta)   # no debe quedarse en un bucle


# ----------------------------- invariantes de la tabla de rutas del gateway --------------------------------------
def test_la_tabla_de_rutas_es_coherente():
    ids = [r.id for r in rutas.RUTAS]
    assert ids == [f"S{n:02d}" for n in range(1, len(ids) + 1)]
    assert len({(r.metodo, r.patron) for r in rutas.RUTAS}) == len(ids)
    for r in rutas.RUTAS:
        assert r.patron.startswith("/api/")
        assert r.acceso in ("anonimo", "sesion", "firma")
        assert r.datos in ("publico", "personal", "restringido", "secreto")
        assert set(r.paginas) <= set(rutas.PAGINAS)
        assert all(f"{{{nombre}}}" in r.patron for nombre, _ in r.params)
        if r.metodo in ("GET", "DELETE"):
            assert r.cuerpo == "ninguno"
        if r.cache:
            assert r.metodo == "GET" and r.acceso == "anonimo"
        if r.invalida:
            assert r.metodo != "GET"
        if r.roles:
            assert r.acceso == "sesion"
        if r.datos in ("restringido", "secreto") and r.acceso == "anonimo":
            assert r.especial or r.limite != "general", f"{r.id}: una ruta anónima con datos sensibles debe tener su propio límite de tasa"


def test_toda_ruta_con_cuerpo_o_cabecera_define_su_formato():
    for r in rutas.RUTAS:
        if r.metodo in ("POST", "PUT"):
            assert r.cuerpo in ("json", "crudo", "ninguno")
    assert [r.id for r in rutas.RUTAS if r.cuerpo == "crudo"] == ["S35"]


def test_las_rutas_de_escritura_del_catalogo_son_solo_para_administrador_y_dueno():
    for r in rutas.RUTAS:
        if r.destino == "inventory" and r.metodo != "GET":
            assert set(r.roles) == {"administrador", "dueno"}


def test_la_ventana_de_firma_es_de_cinco_minutos():
    assert pagos.TOLERANCIA_SEGUNDOS == 300
