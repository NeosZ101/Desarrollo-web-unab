"""Segunda capa de seguridad, ruta por ruta: cada servicio privado se defiende solo, sin confiar en que el gateway ya filtró.

El criterio NO sale del código que se prueba sino del contrato aprobado (tests/contratos/*.json, generado por scripts/generar_matrices.py
y publicado en el informe). Así, si alguien amplía un rol o un llamador en el código, hay dos pruebas que fallan: la que compara el
código con el contrato y la que llama de verdad a la ruta y espera el rechazo.
  * el código coincide con el contrato aprobado (y toda ruta tiene guardia);
  * solo los llamadores declarados alcanzan cada ruta (cualquier otro servicio, aunque tenga secreto válido, recibe 403);
  * quien SÍ puede llamar pero sin identidad recibe 401, y con un rol que la ruta no admite recibe 403.
"""
import json

import pytest

from ayuda import RAIZ, cargar, llamar_servicio

pytestmark = pytest.mark.integracion

generador = cargar("scripts/generar_matrices.py", "generar_matrices")
CONTRATO = json.loads((RAIZ / "tests" / "contratos" / "rutas_servicios.json").read_text(encoding="utf-8"))
PARES = {tuple(p) for p in json.loads((RAIZ / "tests" / "contratos" / "pares_de_servicios.json").read_text(encoding="utf-8"))}
NOMBRES = sorted({p[0] for p in PARES} | {p[1] for p in PARES})   # todos los servicios del sistema, incluidos los dos gateways
ROLES = ("cliente", "administrador", "dueno", "despacho")
CONFIABLES = {"api-gateway", "graphql-gateway", "orders"}          # los únicos que pueden afirmar la identidad de un usuario (módulo 4)
ID_EJEMPLO = {"id": "A-999999", "user_id": "u-zzzz9999"}
_SECRETOS = {}


def _ruta(r):
    camino = r["ruta"]
    for nombre, valor in ID_EJEMPLO.items():
        camino = camino.replace("{" + nombre + "}", valor)
    return camino


def _etiqueta(r):
    return f"{r['servicio']}:{r['metodo']} {r['ruta']}"


def _cuerpo(r):
    return {"json": {}} if r["metodo"] in ("POST", "PUT", "PATCH") else {}


def _secreto(sistema, como, destino):
    """El secreto REAL del par (si existe) para actuar como un servicio comprometido; si no existe, uno inventado."""
    if (como, destino) not in PARES:
        return "secreto-inventado-123"
    if (como, destino) not in _SECRETOS:
        _SECRETOS[(como, destino)] = sistema.secreto(f"svc/{como}-to-{destino}")
    return _SECRETOS[(como, destino)]


def _identidad(rol):
    return {"user": "u-prueba-" + rol, "username": f"{rol}@prueba.cl", "roles": rol, **({"client": "c-0001"} if rol == "cliente" else {})}


# ----------------------------- el contrato -----------------------------------------------------------------
@pytest.mark.parametrize("nombre", ["rutas_gateway", "rutas_servicios", "pares_de_servicios"])
def test_el_codigo_coincide_con_el_contrato_aprobado(nombre):
    """Quién puede llamar a qué es una decisión de seguridad: cambiarla exige aprobarla (scripts/generar_matrices.py --escribir)."""
    aprobado = json.loads((RAIZ / "tests" / "contratos" / f"{nombre}.json").read_text(encoding="utf-8"))
    actual = json.loads(json.dumps(generador.contratos_actuales()[nombre]))
    if nombre == "pares_de_servicios":
        assert {tuple(p) for p in actual} == {tuple(p) for p in aprobado}
        return
    clave = (lambda f: f["id"]) if nombre == "rutas_gateway" else (lambda f: (f["servicio"], f["ruta"], f["metodo"]))
    por_aprobado, por_actual = {clave(f): f for f in aprobado}, {clave(f): f for f in actual}
    assert set(por_actual) == set(por_aprobado), f"rutas nuevas o retiradas: {sorted(set(por_actual) ^ set(por_aprobado))}"
    cambios = [(k, {c: (por_aprobado[k][c], por_actual[k][c]) for c in por_actual[k] if por_actual[k][c] != por_aprobado[k].get(c)})
               for k in por_actual if por_actual[k] != por_aprobado[k]]
    assert not cambios, f"cambios sin aprobar en {nombre}: {cambios[:3]}"


def test_el_contrato_cubre_todos_los_servicios_privados():
    por_servicio = {}
    for r in CONTRATO:
        por_servicio[r["servicio"]] = por_servicio.get(r["servicio"], 0) + 1
    assert set(por_servicio) == {"auth", "clients", "inventory", "orders", "payments", "notifications", "analytics", "graphql-gateway"}, por_servicio
    assert len(CONTRATO) >= 50


@pytest.mark.parametrize("r", CONTRATO, ids=_etiqueta)
def test_toda_ruta_de_un_servicio_privado_declara_su_guardia(r):
    assert r["llamadores"], f"{_etiqueta(r)} no pasa por guardia.dep(...): cualquiera con acceso a la red podría llamarla"
    assert set(r["llamadores"]) <= set(NOMBRES), (_etiqueta(r), r["llamadores"])
    assert r["identidad"] in ("ninguna", "opcional", "requerida")
    assert not r["roles"] or r["identidad"] == "requerida", f"{_etiqueta(r)}: pide roles sin exigir identidad"
    assert set(r["roles"]) <= set(ROLES), (_etiqueta(r), r["roles"])


# ----------------------------- quién puede llamar ------------------------------------------------------------
@pytest.mark.parametrize("r", CONTRATO, ids=_etiqueta)
def test_solo_los_llamadores_declarados_alcanzan_la_ruta(sistema, r):
    """Cada servicio del sistema prueba suerte con esta ruta. Si tiene secreto hacia el destino lo usa (el caso peligroso: un servicio
    comprometido con credencial válida que se sale de lo que le toca); si no, presenta uno inventado."""
    permitidos = set(r["llamadores"])
    cuerpo = _cuerpo(r)
    for como in NOMBRES + ["intruso", "API-GATEWAY", "api_gateway"]:
        if como in permitidos:
            continue
        resp = llamar_servicio(sistema, r["servicio"], r["metodo"], _ruta(r), como=como, secreto=_secreto(sistema, como, r["servicio"]),
                               identidad=_identidad("administrador"), **cuerpo)
        assert resp.status_code == 403 and resp.json()["codigo"] == "LLAMADOR_NO_PERMITIDO", (_etiqueta(r), como, resp.status_code, resp.text[:200])


CON_IDENTIDAD = [r for r in CONTRATO if r["identidad"] == "requerida"]


@pytest.mark.parametrize("r", CON_IDENTIDAD, ids=_etiqueta)
def test_sin_identidad_la_ruta_responde_401_aunque_el_llamador_sea_el_correcto(sistema, r):
    for como in r["llamadores"]:
        resp = llamar_servicio(sistema, r["servicio"], r["metodo"], _ruta(r), como=como, **_cuerpo(r))
        assert resp.status_code == 401 and resp.json()["codigo"] == "NO_AUTENTICADO", (_etiqueta(r), como, resp.status_code, resp.text[:200])


@pytest.mark.parametrize("r", [r for r in CON_IDENTIDAD if r["roles"]], ids=_etiqueta)
def test_el_servicio_vuelve_a_comprobar_el_rol_sin_fiarse_del_gateway(sistema, r):
    """Aun si el gateway dejara pasar a un rol equivocado, el servicio de destino lo rechaza con 403 ROL_NO_AUTORIZADO."""
    for como in (c for c in r["llamadores"] if c in CONFIABLES):
        for rol in (x for x in ROLES if x not in r["roles"]):
            resp = llamar_servicio(sistema, r["servicio"], r["metodo"], _ruta(r), como=como, identidad=_identidad(rol), **_cuerpo(r))
            assert resp.status_code == 403 and resp.json()["codigo"] == "ROL_NO_AUTORIZADO", (_etiqueta(r), como, rol, resp.status_code, resp.text[:200])
        for rol in r["roles"]:   # y el rol correcto sí pasa la guardia (puede fallar después por datos inexistentes, pero no por permisos)
            resp = llamar_servicio(sistema, r["servicio"], r["metodo"], _ruta(r), como=como, identidad=_identidad(rol), **_cuerpo(r))
            assert resp.status_code != 401 and not (resp.status_code == 403 and resp.json().get("codigo") in ("ROL_NO_AUTORIZADO", "LLAMADOR_NO_PERMITIDO")), \
                (_etiqueta(r), como, rol, resp.status_code, resp.text[:200])
            assert resp.status_code < 500, (_etiqueta(r), como, rol, resp.status_code, resp.text[:200])
