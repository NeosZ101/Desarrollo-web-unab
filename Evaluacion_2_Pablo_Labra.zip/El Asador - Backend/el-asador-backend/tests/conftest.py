"""Fixtures de las pruebas automáticas de El Asador.

El sistema completo se levanta como procesos reales (ver tests/stack.py) y las pruebas hablan con él solo por HTTP.
Hay dos configuraciones:
  * `sistema`          límites de tasa muy altos y reintentos rápidos: sirve para todas las pruebas funcionales.
  * `sistema_estricto` límites de tasa y bloqueo de cuentas reducidos y cookie «Secure»: sirve para comprobar el 429 y el bloqueo.
"""
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

from ayuda import RAIZ, Api, datos_registro  # noqa: E402
from stack import Stack  # noqa: E402

ENTORNO = {
    "RL_GENERAL": "1000000", "RL_LOGIN": "100000", "RL_REGISTRO": "100000", "RL_FORMULARIOS": "100000", "RL_GRAPHQL": "1000000", "RL_WEBHOOK": "1000000",
    "UPSTREAM_TIMEOUT": "2", "CIRCUITO_PAUSA": "1", "REINTENTO_SEGUNDOS": "1", "CONCILIAR_DESPUES_SEGUNDOS": "3", "WEBHOOK_PAUSA": "0.1",
}
ENTORNO_ESTRICTO = {
    "RL_GENERAL": "150", "RL_LOGIN": "8", "RL_REGISTRO": "3", "RL_FORMULARIOS": "3", "RL_GRAPHQL": "5", "RL_WEBHOOK": "1000000",
    "MAX_LOGIN_FALLIDOS": "3", "LOGIN_BLOQUEO_SEGUNDOS": "60", "COOKIE_SECURE": "true",
    "UPSTREAM_TIMEOUT": "2", "CIRCUITO_PAUSA": "1", "REINTENTO_SEGUNDOS": "1",
}


def pytest_configure(config):
    for marca in ("integracion: levanta el sistema completo (procesos reales)", "estricto: usa límites de tasa reducidos",
                  "resiliencia: congela o apaga servicios y comprueba la recuperación"):
        config.addinivalue_line("markers", marca)


@pytest.fixture(scope="session")
def sistema():
    with Stack(tempfile.mkdtemp(prefix="asador-logs-"), extra_env=ENTORNO) as s:
        yield s


@pytest.fixture(scope="session")
def sistema_estricto():
    with Stack(tempfile.mkdtemp(prefix="asador-logs-estricto-"), extra_env=ENTORNO_ESTRICTO) as s:
        yield s


@pytest.fixture(scope="module")
def aislado():
    """Un sistema propio de cada módulo para las pruebas que ROMPEN cosas (borran secretos, apagan servicios, tumban Vault).
    Así lo que se rompe nunca contamina a las demás pruebas, que comparten `sistema`."""
    with Stack(tempfile.mkdtemp(prefix="asador-logs-aislado-"), extra_env=ENTORNO) as s:
        yield s


@pytest.fixture(scope="session")
def gw(sistema):
    return sistema.urls["api-gateway"]


@pytest.fixture
def anon(gw):
    return Api(gw)


def _con_sesion(gw, correo, clave):
    api = Api(gw)
    r = api.login(correo, clave)
    assert r.status_code == 200, f"no se pudo iniciar sesión como {correo}: {r.text}"
    return api


@pytest.fixture(scope="session")
def admin(gw):
    return _con_sesion(gw, "admin@elasador.cl", "admin123")


@pytest.fixture(scope="session")
def dueno(gw):
    return _con_sesion(gw, "dueno@elasador.cl", "dueno123")


@pytest.fixture(scope="session")
def despacho(gw):
    return _con_sesion(gw, "despacho@elasador.cl", "despacho123")


@pytest.fixture(scope="session")
def andrea(gw):
    """Cliente sembrado c-0001. Dueña del pedido A-1038."""
    return _con_sesion(gw, "andrea.molina@correo.cl", "cliente123")


@pytest.fixture(scope="session")
def felipe(gw):
    """Cliente sembrado c-0002. Dueño del pedido A-1039."""
    return _con_sesion(gw, "felipe.araya@correo.cl", "cliente123")


@pytest.fixture
def nuevo_cliente(gw):
    """Fábrica de clientes nuevos (registrados por la web y con sesión), para que cada prueba tenga sus propios pedidos."""
    creados = []

    def crear(**cambios):
        d = datos_registro(**cambios)
        api = Api(gw)
        r = api.post("/api/clients/register", json=d)
        assert r.status_code == 201, r.text
        l = api.login(d["correo"], d["clave"])
        assert l.status_code == 200, l.text
        api.datos = d
        creados.append(api)
        from ayuda import DATOS_PERSONALES
        DATOS_PERSONALES.update({d["run"], d["run"].replace("-", ""), d["correo"]})
        return api

    yield crear
    for a in creados:
        a.cerrar()


@pytest.fixture
def producto_agotado(admin):
    """Un producto de prueba marcado como agotado (se retira al terminar)."""
    r = admin.post("/api/products", json={"nombre": "Producto agotado de prueba", "categoria": "bebidas", "precio": 1990,
                                          "descripcion": "Solo existe para las pruebas.", "imagen": "img/cerveza.svg", "disponible": False})
    assert r.status_code == 201, r.text
    p = r.json()
    yield p
    admin.delete(f"/api/products/{p['id']}")
