"""Analítica de ventas (modelo de lectura): eventos idempotentes, llegada desordenada y reglas del reporte.

Aquí se prueba el contrato de los eventos que envía Pagos y lo que el reporte calcula con ellos. El flujo real
(pagar -> la venta aparece; anular -> desaparece; avisos repetidos) está en test_negocio_pagos.py.
Cada prueba usa su propio día del pasado (sin historial de ejemplo) para que los totales sean exactos.
"""
import itertools
import random

import pytest

from ayuda import consulta_del_frontend, hoy_santiago, llamar_servicio, pedido_pagado_manual, sumar_dias

pytestmark = pytest.mark.integracion
VENTAS = consulta_del_frontend("CONSULTA_VENTAS")
_dias = itertools.count(40)           # el historial de ejemplo cubre los últimos 28 días: más atrás no hay nada


def dia_limpio():
    return sumar_dias(hoy_santiago(), -next(_dias))


def folio_nuevo():
    return "B-9%05d" % random.randint(0, 99999)


def venta(folio, dia, total=10000, medio="Servipag", lineas=None, **cambios):
    neto = round(total / 1.19)
    ev = {"eventoId": f"venta:{folio}", "ventaId": folio, "pedidoId": "A-" + folio[2:], "fecha": f"{dia}T15:00:00.000Z", "fechaLocal": dia,
          "total": total, "neto": neto, "iva": total - neto, "medio": medio, "comuna": "Ñuñoa",
          "lineas": lineas or [{"itemId": "p07", "nombre": "Producto de prueba", "cantidad": 1, "subtotal": total}]}
    ev.update(cambios)
    return ev


def anulacion(folio):
    return {"eventoId": f"reverso:{folio}", "ventaId": folio}


def registrar(sistema, ev):
    return llamar_servicio(sistema, "analytics", "POST", "/internal/events/sale-registered", como="payments", json=ev)


def anular(sistema, ev):
    return llamar_servicio(sistema, "analytics", "POST", "/internal/events/sale-reversed", como="payments", json=ev)


def reporte(api, desde, hasta=None):
    r = api.gql(VENTAS, {"desde": desde, "hasta": hasta or desde})
    assert r.status_code == 200 and "errors" not in r.json(), r.text
    return r.json()["data"]["reporteVentas"]


def error_de_reporte(api, desde, hasta):
    r = api.gql(VENTAS, {"desde": desde, "hasta": hasta})
    assert r.status_code == 200 and r.json()["data"]["reporteVentas"] is None, r.text
    return r.json()["errors"][0]["extensions"]["codigo"]


# ----------------------------- idempotencia y orden de llegada ------------------------------------------------------------
def test_un_evento_repetido_no_cambia_el_reporte(sistema, admin):
    dia, folio = dia_limpio(), folio_nuevo()
    primero = registrar(sistema, venta(folio, dia, 12000))
    segundo = registrar(sistema, venta(folio, dia, 12000))
    assert primero.json() == {"ok": True, "duplicado": False} and segundo.json() == {"ok": True, "duplicado": True}
    assert reporte(admin, dia)["totales"] == {"ventas": 12000, "pedidos": 1, "ticketPromedio": 12000, "mejorDia": dia}


def test_un_evento_que_llega_diez_veces_en_paralelo_cuenta_una_sola_venta(sistema, admin):
    from concurrent.futures import ThreadPoolExecutor
    dia, folio = dia_limpio(), folio_nuevo()
    with ThreadPoolExecutor(10) as pool:
        respuestas = list(pool.map(lambda _: registrar(sistema, venta(folio, dia, 8000)), range(10)))
    assert all(r.status_code == 200 for r in respuestas)
    assert reporte(admin, dia)["totales"]["pedidos"] == 1 and reporte(admin, dia)["totales"]["ventas"] == 8000


def test_la_anulacion_resta_la_venta_y_repetirla_no_resta_dos_veces(sistema, admin):
    dia, a, b = dia_limpio(), folio_nuevo(), folio_nuevo()
    registrar(sistema, venta(a, dia, 10000))
    registrar(sistema, venta(b, dia, 5000))
    assert reporte(admin, dia)["totales"]["ventas"] == 15000
    assert anular(sistema, anulacion(a)).json() == {"ok": True, "duplicado": False}
    assert anular(sistema, anulacion(a)).json() == {"ok": True, "duplicado": True}
    assert reporte(admin, dia)["totales"] == {"ventas": 5000, "pedidos": 1, "ticketPromedio": 5000, "mejorDia": dia}


def test_si_la_anulacion_llega_antes_que_el_registro_la_venta_no_se_cuenta(sistema, admin):
    """Los eventos pueden llegar desordenados (reintentos). La venta anulada no «resucita» con un registro tardío."""
    dia, folio = dia_limpio(), folio_nuevo()
    anular(sistema, anulacion(folio))
    registrar(sistema, venta(folio, dia, 9000))
    registrar(sistema, venta(folio, dia, 9000))
    assert reporte(admin, dia)["totales"]["pedidos"] == 0


def test_un_registro_posterior_con_otros_datos_no_reactiva_una_venta_anulada(sistema, admin):
    dia, folio = dia_limpio(), folio_nuevo()
    registrar(sistema, venta(folio, dia, 9000))
    anular(sistema, anulacion(folio))
    registrar(sistema, venta(folio, dia, 99999))
    assert reporte(admin, dia)["totales"]["ventas"] == 0


# ----------------------------- reglas del reporte -----------------------------------------------------------------------------
def test_los_totales_agrupan_por_dia_medio_de_pago_y_producto(sistema, admin):
    dia = dia_limpio()
    l = lambda nombre, cantidad, subtotal: {"itemId": None, "nombre": nombre, "cantidad": cantidad, "subtotal": subtotal}   # noqa: E731
    registrar(sistema, venta(folio_nuevo(), dia, 10000, "Servipag", [l("Asado", 2, 6000), l("Bebida", 1, 4000)]))
    registrar(sistema, venta(folio_nuevo(), dia, 20000, "Transferencia bancaria", [l("Asado", 1, 3000), l("Papas", 5, 17000)]))
    registrar(sistema, venta(folio_nuevo(), dia, 30000, "Servipag", [l("Papas", 1, 3400), l("Ensalada", 1, 2000), l("Pan", 4, 4000),
                                                                      l("Salsa", 3, 3000), l("Postre", 2, 17600)]))
    r = reporte(admin, dia)
    assert r["dias"] == [{"fecha": dia, "pedidos": 3, "ventas": 60000, "ticketPromedio": 20000}]
    assert r["totales"] == {"ventas": 60000, "pedidos": 3, "ticketPromedio": 20000, "mejorDia": dia}
    assert r["porMedioPago"] == [{"medio": "Servipag", "pedidos": 2, "ventas": 40000}, {"medio": "Transferencia bancaria", "pedidos": 1, "ventas": 20000}]
    top = r["topProductos"]
    assert len(top) == 5 and top[0] == {"nombre": "Papas", "unidades": 6, "ventas": 20400}          # solo los 5 más vendidos, por unidades
    assert [t["unidades"] for t in top] == sorted((t["unidades"] for t in top), reverse=True)
    assert {t["nombre"] for t in top} == {"Papas", "Pan", "Asado", "Salsa", "Postre"}                # Bebida y Ensalada (1 unidad) quedan fuera


def test_un_periodo_de_varios_dias_incluye_los_dias_sin_ventas_y_el_mejor_dia(sistema, admin):
    base = dia_limpio()
    for _ in range(4):
        dia_limpio()                                                                                # este período usa 5 días seguidos: se reservan todos
    d0, d1, d2 = sumar_dias(base, -4), sumar_dias(base, -3), sumar_dias(base, -1)
    registrar(sistema, venta(folio_nuevo(), d0, 7000))
    registrar(sistema, venta(folio_nuevo(), d2, 9000))
    registrar(sistema, venta(folio_nuevo(), d2, 3000))
    r = reporte(admin, d0, d2)
    assert [x["fecha"] for x in r["dias"]] == [sumar_dias(base, -4 + i) for i in range(4)]            # un renglón por día, también los vacíos
    assert next(x for x in r["dias"] if x["fecha"] == d1) == {"fecha": d1, "pedidos": 0, "ventas": 0, "ticketPromedio": 0}
    assert r["totales"] == {"ventas": 19000, "pedidos": 3, "ticketPromedio": 6333, "mejorDia": d2}


def test_un_dia_sin_ventas_da_ceros_y_sin_mejor_dia(admin):
    r = reporte(admin, sumar_dias(hoy_santiago(), -95))
    assert r["totales"] == {"ventas": 0, "pedidos": 0, "ticketPromedio": 0, "mejorDia": None}
    assert r["porMedioPago"] == [] and r["topProductos"] == [] and len(r["dias"]) == 1


def test_el_reporte_lo_ven_el_administrador_y_el_dueno_y_no_trae_datos_personales(sistema, admin, dueno, nuevo_cliente):
    c = nuevo_cliente()
    pedido_pagado_manual(c, admin)
    for quien in (admin, dueno):
        r = quien.gql(VENTAS, {"desde": hoy_santiago(), "hasta": hoy_santiago()})
        texto = r.text
        assert "errors" not in r.json()
        for dato in (c.datos["correo"], c.datos["run"], c.datos["telefono"], c.datos["direccion"], c.datos["nombre"], "@"):
            assert dato not in texto, dato


def test_una_venta_real_aparece_con_su_producto(admin, nuevo_cliente, producto_para_analitica):
    p = producto_para_analitica
    c = nuevo_cliente()
    pedido_pagado_manual(c, admin, items=[{"id": p["id"], "cantidad": 20}])
    top = reporte(admin, hoy_santiago())["topProductos"]
    assert {"nombre": p["nombre"], "unidades": 20, "ventas": 20 * p["precio"]} in top


@pytest.fixture
def producto_para_analitica(admin):
    r = admin.post("/api/products", json={"nombre": "Producto Analitica XYZ", "categoria": "bebidas", "precio": 1234,
                                          "descripcion": "Producto único para comprobar el top de ventas.", "imagen": "img/cerveza.svg"})
    assert r.status_code == 201, r.text
    p = r.json()
    yield p
    admin.delete(f"/api/products/{p['id']}")


# ----------------------------- periodos inválidos (se validan en el servicio de analítica) ---------------------------------------------
def test_periodos_invalidos(admin):
    hoy = hoy_santiago()
    assert error_de_reporte(admin, sumar_dias(hoy, -1), sumar_dias(hoy, -5)) == "PERIODO_INVALIDO"          # «desde» posterior a «hasta»
    assert error_de_reporte(admin, hoy, sumar_dias(hoy, 1)) == "PERIODO_INVALIDO"                          # fechas futuras
    assert error_de_reporte(admin, sumar_dias(hoy, -92), hoy) == "PERIODO_DEMASIADO_LARGO"                   # 93 días
    for mal in ("2026-13-45", "abc", "2026/01/01", ""):
        assert error_de_reporte(admin, mal, hoy) == "FILTRO_INVALIDO", mal


def test_un_periodo_de_exactamente_92_dias_es_valido(admin):
    hoy = hoy_santiago()
    r = reporte(admin, sumar_dias(hoy, -91), hoy)
    assert len(r["dias"]) == 92


def test_un_total_mayor_a_2147_millones_se_informa_completo_y_no_como_error_interno(sistema, admin):
    """GraphQL Int es de 32 bits: la suma de ventas de un período largo lo supera. Se detectó en la prueba de carga con 10 veces el volumen proyectado."""
    dia = dia_limpio()
    for _ in range(3):
        assert registrar(sistema, venta(folio_nuevo(), dia, 1_000_000_000)).status_code == 200
    r = reporte(admin, dia)
    assert r["totales"]["ventas"] == 3_000_000_000 and r["dias"][0]["ventas"] == 3_000_000_000
    assert r["porMedioPago"][0]["ventas"] == 3_000_000_000 and r["topProductos"][0]["ventas"] == 3_000_000_000


# ----------------------------- el contrato del evento -------------------------------------------------------------------------------
INVALIDOS = [
    ("eventoId distinto del folio", {"eventoId": "venta:B-111111"}),
    ("folio mal formado", {"ventaId": "X-1", "eventoId": "venta:X-1"}),
    ("evento mal formado", {"eventoId": "cualquier-cosa"}),
    ("pedido mal formado", {"pedidoId": "pedido-1"}),
    ("total negativo", {"total": -1, "neto": -1, "iva": 0}),
    ("neto + IVA no suman el total", {"neto": 1}),
    ("fecha local mal formada", {"fechaLocal": "ayer"}),
    ("medio demasiado largo", {"medio": "x" * 41}),
    ("campo ajeno: datos personales", {"cliente": {"correo": "alguien@correo.cl"}}),
    ("campo ajeno: estado", {"estado": "vigente"}),
    ("cantidad cero", {"lineas": [{"itemId": None, "nombre": "x", "cantidad": 0, "subtotal": 1}]}),
    ("demasiadas líneas", {"lineas": [{"itemId": None, "nombre": "x", "cantidad": 1, "subtotal": 1}] * 61}),
    ("línea con campo ajeno", {"lineas": [{"itemId": None, "nombre": "x", "cantidad": 1, "subtotal": 1, "correo": "a@b.cl"}]}),
]


@pytest.mark.parametrize("caso,cambio", INVALIDOS, ids=[c[0] for c in INVALIDOS])
def test_el_evento_de_venta_invalido_se_rechaza_y_no_cambia_nada(sistema, admin, caso, cambio):
    dia, folio = dia_limpio(), folio_nuevo()
    ev = venta(folio, dia, 10000)
    ev.update(cambio)
    r = registrar(sistema, ev)
    assert r.status_code == 422 and r.json()["codigo"] == "VALIDACION", r.text
    assert reporte(admin, dia)["totales"]["pedidos"] == 0


@pytest.mark.parametrize("ev", [{"eventoId": "reverso:B-111111", "ventaId": "B-222222"}, {"eventoId": "venta:B-111111", "ventaId": "B-111111"},
                                {"eventoId": "reverso:B-111111", "ventaId": "B-111111", "motivo": "x"}, {"ventaId": "B-111111"}])
def test_el_evento_de_anulacion_invalido_se_rechaza(sistema, ev):
    assert anular(sistema, ev).status_code == 422
