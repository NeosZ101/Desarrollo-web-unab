"""Reglas de negocio de los pedidos, probadas de punta a punta a través del API Gateway (RF1, RF3, RF4, RF13).

Lo central: el servidor calcula precios y totales, decide el estado y nunca confía en lo que mande el navegador.
"""
import uuid

import pytest

from ayuda import crear_pedido, esperar, estado_pedido, iniciar_pago, pedido_ok, sin_id

pytestmark = pytest.mark.integracion


# ----------------------------- el servidor decide precios, despacho y estado -----------------------------------
def test_el_servidor_calcula_el_total_y_el_navegador_no_puede_fijarlo(nuevo_cliente):
    c = nuevo_cliente(comuna="Ñuñoa")
    p = pedido_ok(c, items=[{"id": "p01", "cantidad": 1}, {"id": "p12", "cantidad": 2}], comuna="Ñuñoa")
    assert p["subtotal"] == 24990 + 2 * 2990
    assert p["despacho"] == 0                      # Ñuñoa está a 2,8 km: gratis
    assert p["total"] == p["subtotal"] == 30970
    assert p["estado"] == "Pago pendiente" and p["historial"][0]["estado"] == "Pago pendiente"
    assert p["cliente"]["nombre"] == "Cliente De Prueba" and p["cliente"]["direccion"] == "Calle Falsa 123"   # sale del perfil, no del pedido


@pytest.mark.parametrize("campo,valor", [("total", 1), ("subtotal", 1), ("despacho", 0), ("estado", "En preparación"), ("pagado", True),
                                         ("precio", 1), ("clienteId", "c-0001"), ("cliente", {"nombre": "Otro"})])
def test_campos_que_el_navegador_no_puede_enviar_se_rechazan(nuevo_cliente, campo, valor):
    c = nuevo_cliente()
    r = c.post("/api/orders", json={"items": [{"id": "p07", "cantidad": 1}], "comuna": "Ñuñoa", campo: valor})
    assert r.status_code == 422 and r.json()["codigo"] == "VALIDACION"
    assert {"campo": campo, "mensaje": "Este dato no se acepta."} in r.json()["campos"]


def test_un_precio_enviado_dentro_de_una_linea_se_rechaza(nuevo_cliente):
    c = nuevo_cliente()
    r = c.post("/api/orders", json={"items": [{"id": "p01", "cantidad": 1, "precio": 1}], "comuna": "Ñuñoa"})
    assert r.status_code == 422 and r.json()["campos"][0]["campo"] == "items.0.precio"


@pytest.mark.parametrize("comuna,costo", [("Providencia", 0), ("Ñuñoa", 0), ("Santiago", 2400), ("Las Condes", 3200), ("Maipú", 7200), ("Puente Alto", 8400)])
def test_costo_de_despacho_segun_la_comuna(nuevo_cliente, comuna, costo):
    c = nuevo_cliente(comuna=comuna)
    p = pedido_ok(c, items=[{"id": "p07", "cantidad": 1}], comuna=comuna)
    assert p["despacho"] == costo and p["total"] == 7990 + costo


def test_zonas_de_despacho_publicas_coinciden_con_el_cobro(anon, nuevo_cliente):
    zonas = {z["nombre"]: z["costo"] for z in anon.get("/api/delivery-zones").json()["comunas"]}
    c = nuevo_cliente(comuna="Maipú")
    assert pedido_ok(c, comuna="Maipú")["despacho"] == zonas["Maipú"] == 7200


def test_precio_de_una_promo_lo_define_el_servidor(nuevo_cliente, anon):
    promos = {p["id"]: p for p in anon.get("/api/promos").json()}
    c = nuevo_cliente()
    p = pedido_ok(c, items=[{"id": "promo1", "cantidad": 1}])
    assert p["lineas"][0]["precio"] == promos["promo1"]["precio"] == 43170 and p["lineas"][0]["nombre"].endswith("(promo)")


def test_comuna_sin_cobertura(nuevo_cliente):
    c = nuevo_cliente()
    r = crear_pedido(c, comuna="Valparaíso")
    assert r.status_code == 422 and r.json()["codigo"] == "COMUNA_SIN_COBERTURA"


def test_producto_inexistente_y_producto_agotado(nuevo_cliente, producto_agotado):
    c = nuevo_cliente()
    r = crear_pedido(c, items=[{"id": "zz99", "cantidad": 1}])
    assert r.status_code == 422 and r.json()["codigo"] == "ITEM_INEXISTENTE"
    r = crear_pedido(c, items=[{"id": producto_agotado["id"], "cantidad": 1}])
    assert r.status_code == 409 and r.json()["codigo"] == "ITEM_NO_DISPONIBLE" and r.json()["items"] == [producto_agotado["id"]]


# ----------------------------- límites de cantidad y de pedidos abiertos --------------------------------------
def test_limites_de_cantidad(nuevo_cliente):
    c = nuevo_cliente()
    assert crear_pedido(c, items=[{"id": "p07", "cantidad": 21}]).status_code == 422
    assert crear_pedido(c, items=[{"id": "p07", "cantidad": 0}]).status_code == 422
    r = crear_pedido(c, items=[{"id": "p07", "cantidad": 12}, {"id": "p07", "cantidad": 12}])
    assert r.status_code == 422 and r.json()["codigo"] == "CANTIDAD_EXCEDIDA"           # la suma por producto también se limita
    assert crear_pedido(c, items=[{"id": f"p{n:02d}", "cantidad": 1} for n in range(1, 14)] * 3).status_code == 422     # más de 30 líneas
    assert crear_pedido(c, items=[]).status_code == 422


def test_maximo_de_pedidos_pendientes_por_cliente(nuevo_cliente):
    c = nuevo_cliente()
    for _ in range(5):
        pedido_ok(c)
    r = crear_pedido(c)
    assert r.status_code == 409 and r.json()["codigo"] == "DEMASIADOS_PEDIDOS_PENDIENTES"


def test_reintentar_el_ultimo_pedido_permitido_devuelve_el_mismo(nuevo_cliente):
    """Un corte de red justo después de crear el 5.º pedido pendiente: el reintento debe devolver ESE pedido, no un «demasiados pendientes»."""
    c = nuevo_cliente()
    for _ in range(4):
        pedido_ok(c)
    llave = uuid.uuid4().hex
    quinto = crear_pedido(c, llave=llave)
    assert quinto.status_code == 201
    otra_vez = crear_pedido(c, llave=llave)
    assert otra_vez.status_code == 200 and otra_vez.json()["id"] == quinto.json()["id"]
    assert crear_pedido(c).status_code == 409                       # el tope sigue vigente para pedidos NUEVOS


def test_los_reintentos_no_gastan_numeros_de_pedido(nuevo_cliente):
    """La numeración A-<n> no tiene saltos: repetir una solicitud no debe consumir un número."""
    c = nuevo_cliente()
    llave = uuid.uuid4().hex
    primero = crear_pedido(c, llave=llave).json()["id"]
    for _ in range(3):
        assert crear_pedido(c, llave=llave).json()["id"] == primero
    siguiente = pedido_ok(c)["id"]
    assert int(siguiente.split("-")[1]) == int(primero.split("-")[1]) + 1


def test_idempotency_key_evita_duplicar_el_pedido(nuevo_cliente):
    c = nuevo_cliente()
    llave = uuid.uuid4().hex
    a = crear_pedido(c, llave=llave)
    b = crear_pedido(c, llave=llave)
    assert a.status_code == 201 and b.status_code == 200 and a.json()["id"] == b.json()["id"]
    assert c.get("/api/orders").headers["x-total-count"] == "1"
    otro = nuevo_cliente()
    assert crear_pedido(otro, llave=llave).json()["id"] != a.json()["id"]            # la llave vale por cliente


@pytest.mark.parametrize("llave", ["corta", "con espacios no vale!!", "x" * 65, "<script>alert(1)</script>"])
def test_idempotency_key_con_formato_invalido(nuevo_cliente, llave):
    r = crear_pedido(nuevo_cliente(), llave=llave)
    assert r.status_code == 400 and r.json()["codigo"] == "CABECERA_INVALIDA"


# ----------------------------- venta de alcohol ---------------------------------------------------------------
def test_alcohol_exige_ser_mayor_de_edad_y_confirmarlo(nuevo_cliente):
    menor = nuevo_cliente(nacimiento="2015-06-01")
    r = crear_pedido(menor, items=[{"id": "p13", "cantidad": 1}], confirmaMayorEdad=True)
    assert r.status_code == 422 and r.json()["codigo"] == "MENOR_DE_EDAD"
    adulto = nuevo_cliente(nacimiento="1990-01-01")
    r = crear_pedido(adulto, items=[{"id": "p13", "cantidad": 1}])
    assert r.status_code == 422 and r.json()["codigo"] == "CONFIRMAR_MAYORIA_EDAD"
    assert crear_pedido(adulto, items=[{"id": "p13", "cantidad": 1}], confirmaMayorEdad=True).status_code == 201


def test_una_promo_con_alcohol_tambien_exige_mayoria_de_edad(nuevo_cliente):
    menor = nuevo_cliente(nacimiento="2015-06-01")
    r = crear_pedido(menor, items=[{"id": "promo3", "cantidad": 1}], confirmaMayorEdad=True)
    assert r.status_code == 422 and r.json()["codigo"] == "MENOR_DE_EDAD"


# ----------------------------- sesión y rol para pedir ---------------------------------------------------------
def test_crear_pedido_requiere_sesion_de_cliente(anon, admin, despacho):
    cuerpo = {"items": [{"id": "p07", "cantidad": 1}], "comuna": "Ñuñoa"}
    assert anon.post("/api/orders", json=cuerpo).status_code == 401
    for personal in (admin, despacho):
        r = personal.post("/api/orders", json=cuerpo)
        assert r.status_code == 403 and r.json()["codigo"] == "ROL_NO_AUTORIZADO"


# ----------------------------- anulación -------------------------------------------------------------------------
def test_el_cliente_anula_su_pedido_pendiente_y_se_cancela_el_cobro(nuevo_cliente):
    c = nuevo_cliente()
    p = pedido_ok(c)
    pago = iniciar_pago(c, p["id"])
    r = c.post(f"/api/orders/{p['id']}/cancellation", json={"motivo": "Ya no lo necesito"})
    assert r.status_code == 200
    d = r.json()
    assert d["estado"] == "Anulado" and d["anuladoPor"] == "Cliente" and d["motivoAnulacion"] == "Ya no lo necesito" and d["reembolso"] == "no_aplica"
    assert [h["estado"] for h in d["historial"]] == ["Pago pendiente", "Anulado"]          # no se borra: queda el historial
    assert esperar(lambda: c.get(f"/api/orders/{p['id']}/payment").json()["estado"] == "cancelado", mensaje="el cobro no se canceló")
    assert pago["estado"] == "iniciado"


def test_motivo_de_anulacion_invalido(nuevo_cliente):
    c = nuevo_cliente()
    p = pedido_ok(c)
    assert c.post(f"/api/orders/{p['id']}/cancellation", json={"motivo": "porque sí"}).status_code == 422
    r = c.post(f"/api/orders/{p['id']}/cancellation", json={"motivo": "Otro motivo", "detalle": "ab"})
    assert r.status_code == 422 and r.json()["codigo"] == "MOTIVO_INVALIDO"
    assert estado_pedido(c, p["id"]) == "Pago pendiente"
    assert c.post(f"/api/orders/{p['id']}/cancellation", json={"motivo": "Otro motivo", "detalle": "me equivoqué de comuna"}).status_code == 200


def test_un_pedido_anulado_no_se_puede_anular_ni_pagar(nuevo_cliente):
    c = nuevo_cliente()
    p = pedido_ok(c)
    c.post(f"/api/orders/{p['id']}/cancellation", json={"motivo": "Ya no lo necesito"})
    r = c.post(f"/api/orders/{p['id']}/cancellation", json={"motivo": "Ya no lo necesito"})
    assert r.status_code == 409 and r.json()["codigo"] == "NO_SE_PUEDE_ANULAR"
    r = c.post(f"/api/orders/{p['id']}/payment")
    assert r.status_code == 409 and r.json()["codigo"] == "PEDIDO_NO_PAGABLE"


# ----------------------------- despacho (RF13) ----------------------------------------------------------------------
def test_cola_de_despacho_en_orden_de_llegada(admin, despacho):
    r = despacho.get("/api/admin/orders?estado=activos&limit=200")
    fechas = [p["fecha"] for p in r.json()]
    assert r.status_code == 200 and fechas == sorted(fechas) and "x-total-count" in r.headers
    assert all(p["estado"] in ("Pago pendiente", "En preparación", "En camino") for p in r.json())
    assert all("clienteId" in p for p in r.json())                  # el personal ve el identificador; el cliente no
    assert despacho.get("/api/admin/orders?estado=Inventado").status_code == 400


def test_el_despacho_solo_avanza_en_orden(nuevo_cliente, admin, despacho):
    from ayuda import pedido_pagado_manual
    c = nuevo_cliente()
    p, _ = pedido_pagado_manual(c, admin)
    url = f"/api/admin/orders/{p['id']}/status"
    r = despacho.put(url, json={"estado": "Entregado"})                          # saltarse «En camino»
    assert r.status_code == 409 and r.json()["codigo"] == "TRANSICION_NO_PERMITIDA"
    assert despacho.put(url, json={"estado": "En preparación"}).status_code == 422       # ese estado solo lo pone el sistema de pagos
    assert despacho.put(url, json={"estado": "Anulado"}).status_code == 422
    assert despacho.put(url, json={"estado": "En camino"}).json()["estado"] == "En camino"
    r = despacho.put(url, json={"estado": "En camino"})                          # repetir
    assert r.status_code == 409
    d = despacho.put(url, json={"estado": "Entregado"}).json()
    assert d["estado"] == "Entregado" and [h["estado"] for h in d["historial"]] == ["Pago pendiente", "En preparación", "En camino", "Entregado"]
    assert d["historial"][2]["por"] == "Encargado de despacho"
    r = c.post(f"/api/orders/{p['id']}/cancellation", json={"motivo": "Ya no lo necesito"})
    assert r.status_code == 409 and r.json()["codigo"] == "NO_SE_PUEDE_ANULAR"      # entregado: no se anula


def test_no_se_avanza_un_pedido_sin_pagar(nuevo_cliente, despacho):
    c = nuevo_cliente()
    p = pedido_ok(c)
    r = despacho.put(f"/api/admin/orders/{p['id']}/status", json={"estado": "En camino"})
    assert r.status_code == 409 and r.json()["codigo"] == "TRANSICION_NO_PERMITIDA"
    assert estado_pedido(c, p["id"]) == "Pago pendiente"


def test_pedido_inexistente_para_el_personal_es_404(admin):
    r = admin.get("/api/orders/A-999999")
    assert r.status_code == 404 and r.json()["codigo"] == "PEDIDO_NO_ENCONTRADO"
    assert sin_id(r.json())["detail"] == "Pedido no encontrado"
