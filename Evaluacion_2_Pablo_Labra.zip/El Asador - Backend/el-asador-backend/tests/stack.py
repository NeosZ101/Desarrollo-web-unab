"""Levanta el sistema completo como procesos reales (uno por servicio) para pruebas y demostraciones.

Vault falso (con políticas) -> scripts/seed_vault.py -> cada servicio con SU token de Vault y SU base
simulada en memoria. Los servicios se hablan por HTTP igual que en Docker; los logs de cada proceso
quedan en archivos para poder comprobar que no contienen secretos ni datos personales.

Con ASADOR_REAL=1 y ASADOR_BIN=<carpeta con los binarios `vault` y `mongod`> el mismo sistema corre contra un HashiCorp Vault REAL
(modo desarrollo) y un MongoDB REAL con autenticación y un usuario por servicio, igual que docker-compose.yml. Las pruebas son las mismas.
"""
import os
import secrets
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx

RAIZ = Path(__file__).resolve().parent.parent
PYTHON = sys.executable
REAL = os.environ.get("ASADOR_REAL") == "1"      # servidores de verdad en lugar de mongomock y del Vault falso
BIN = Path(os.environ.get("ASADOR_BIN", "."))
SERVICIOS_BD = ("auth", "clients", "inventory", "orders", "payments", "notifications", "analytics")
REGISTRO = []   # todos los sistemas levantados en esta ejecución: al final, test_zz_logs_y_secretos revisa los logs de cada uno

# nombre del servicio -> carpeta
CARPETAS = {
    "auth": "auth-service", "clients": "clients-service", "inventory": "inventory-service",
    "orders": "orders-service", "payments": "payments-service", "notifications": "notifications-service",
    "analytics": "analytics-service", "graphql-gateway": "graphql-gateway", "api-gateway": "api-gateway",
    "provider-sandbox": "provider-sandbox",
}
# variable de entorno con la URL de cada servicio
URL_ENV = {
    "auth": "AUTH_URL", "clients": "CLIENTS_URL", "inventory": "INVENTORY_URL", "orders": "ORDERS_URL",
    "payments": "PAYMENTS_URL", "notifications": "NOTIFICATIONS_URL", "analytics": "ANALYTICS_URL",
    "graphql-gateway": "GRAPHQL_URL", "provider-sandbox": "PROVIDER_URL", "api-gateway": "GATEWAY_URL",
}


_ENTREGADOS = set()


def puerto_libre():
    """Un puerto libre que no se haya entregado antes: el sistema puede repetir uno recién liberado y dos servicios chocarían."""
    while True:
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            puerto = s.getsockname()[1]
        if puerto not in _ENTREGADOS:
            _ENTREGADOS.add(puerto)
            return puerto


class Proceso:
    def __init__(self, nombre, argumentos, env, logdir):
        self.nombre = nombre
        self.log = Path(logdir) / f"{nombre}.log"
        self._f = open(self.log, "wb")
        self.proc = subprocess.Popen(argumentos, env={**os.environ, **env}, stdout=self._f, stderr=subprocess.STDOUT)

    def esperar(self, url, ruta="/health", segundos=40):
        limite = time.time() + segundos
        while time.time() < limite:
            if self.proc.poll() is not None:
                raise RuntimeError(f"{self.nombre} terminó antes de tiempo:\n{self.log.read_text(errors='ignore')[-3000:]}")
            try:
                if httpx.get(url + ruta, timeout=1).status_code == 200:
                    return self
            except httpx.HTTPError:
                time.sleep(0.2)
        raise RuntimeError(f"{self.nombre} no respondió en {segundos}s:\n{self.log.read_text(errors='ignore')[-3000:]}")

    def detener(self):
        if self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(8)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        self._f.close()


class Stack:
    def __init__(self, logdir, extra_env=None, por_servicio=None, omitir=(), puertos=None):
        """extra_env: variables para TODOS los servicios. por_servicio: {"orders": {"X": "1"}}. puertos: {"api-gateway": 8000} fija algunos puertos."""
        self.logdir = Path(logdir)
        self.logdir.mkdir(parents=True, exist_ok=True)
        self.logdir_infra = self.logdir / "infra"        # logs de Vault y MongoDB REALES: son de terceros y no se miden con las reglas de los logs propios
        self.logdir_infra.mkdir(exist_ok=True)
        self.extra_env = extra_env or {}
        self.por_servicio = por_servicio or {}
        self.procesos = []
        self.puertos = {n: (puertos or {}).get(n) or puerto_libre() for n in CARPETAS if n not in omitir}
        self.urls = {n: f"http://127.0.0.1:{p}" for n, p in self.puertos.items()}
        self.root_token = secrets.token_hex(16)
        self.tokens = {n: secrets.token_hex(16) for n in CARPETAS}
        self.clave_bd = {n: secrets.token_urlsafe(18) for n in CARPETAS}      # MONGO_PASS_<SERVICIO>
        self.mongo_puerto = puerto_libre() if REAL else None
        self.mongo_root = ("root_admin", secrets.token_urlsafe(24))
        self.omitir = set(omitir)
        self.secretos_conocidos = set()
        REGISTRO.append(self)

    # ----- Vault + secretos -----------------------------------------------------------------
    def iniciar_mongo(self):
        """MongoDB real con autenticación. Equivale a mongo/init-users.js: un usuario por servicio, con permisos solo sobre SU base."""
        from pymongo import MongoClient
        datos = self.logdir / "mongo-datos"
        datos.mkdir(exist_ok=True)
        p = Proceso("mongo", [str(BIN / "mongod"), "--auth", "--bind_ip", "127.0.0.1", "--port", str(self.mongo_puerto), "--dbpath", str(datos),
                              "--nounixsocket", "--wiredTigerCacheSizeGB", "0.25", "--quiet"], {}, self.logdir_infra)
        self.procesos.append(p)
        limite = time.time() + 40
        while True:
            if p.proc.poll() is not None:
                raise RuntimeError("mongod terminó antes de tiempo:\n" + p.log.read_text(errors="ignore")[-3000:])
            try:
                MongoClient(f"mongodb://127.0.0.1:{self.mongo_puerto}", serverSelectionTimeoutMS=500).admin.command("ping")
                break
            except Exception:  # noqa: BLE001
                if time.time() > limite:
                    raise RuntimeError("mongod no respondió en 40 s")
                time.sleep(0.2)
        # excepción de localhost: el primer usuario (administrador) se puede crear sin autenticarse
        MongoClient(f"mongodb://127.0.0.1:{self.mongo_puerto}").admin.command("createUser", self.mongo_root[0], pwd=self.mongo_root[1], roles=["root"])
        raiz = MongoClient(f"mongodb://127.0.0.1:{self.mongo_puerto}", username=self.mongo_root[0], password=self.mongo_root[1], authSource="admin")
        for servicio in SERVICIOS_BD:
            raiz[f"asador_{servicio}"].command("createUser", f"u_{servicio}", pwd=self.clave_bd[servicio],
                                               roles=[{"role": "readWrite", "db": f"asador_{servicio}"}])
        raiz.close()

    def iniciar_vault(self):
        vp = puerto_libre()
        if REAL:
            self.iniciar_mongo()
            p = Proceso("vault", [str(BIN / "vault"), "server", "-dev", f"-dev-root-token-id={self.root_token}", f"-dev-listen-address=127.0.0.1:{vp}"],
                        {}, self.logdir_infra)
        else:
            p = Proceso("vault", [PYTHON, "-m", "uvicorn", "fake_vault:app", "--app-dir", str(RAIZ / "tests"), "--host", "127.0.0.1",
                                  "--port", str(vp), "--log-level", "warning"], {"FAKE_VAULT_ROOT": self.root_token}, self.logdir)
        self.procesos.append(p)
        self.vault_url = f"http://127.0.0.1:{vp}"
        p.esperar(self.vault_url, "/v1/sys/health")
        env = {"VAULT_ADDR": self.vault_url, "VAULT_ROOT_TOKEN": self.root_token}
        for n in CARPETAS:
            clave = n.upper().replace("-", "_")
            env[f"VAULT_TOKEN_{clave}"] = self.tokens[n]
            env[f"MONGO_PASS_{clave}"] = self.clave_bd[n]
        r = subprocess.run([PYTHON, str(RAIZ / "scripts" / "seed_vault.py")], env={**os.environ, **env}, capture_output=True, text=True, timeout=60)
        if r.returncode != 0:
            raise RuntimeError("seed_vault.py falló:\n" + r.stdout + r.stderr)
        self.salida_seed = r.stdout
        self.secretos_conocidos = self.valores_secretos()

    # ----- servicios ------------------------------------------------------------------------
    def entorno(self, nombre):
        env = {
            "PYTHONPATH": str(RAIZ), "VAULT_ADDR": self.vault_url, "VAULT_TOKEN": self.tokens[nombre],
            "SECRET_TTL_SECONDS": "1", "SEED_DEMO_DATA": "true", "MONGO_HOST": "127.0.0.1" if REAL else "mongo-simulado",
            "VAULT_STARTUP_RETRIES": "5", "MONGO_STARTUP_RETRIES": "3",
            "VAULT_TIMEOUT_SECONDS": "0.4", "VAULT_RETRY_AFTER_SECONDS": "0.5",   # a escala del plazo de 2 s del gateway en las pruebas
        }
        if REAL:
            env["MONGO_PORT"] = str(self.mongo_puerto)
        for n, u in self.urls.items():
            env[URL_ENV[n]] = u
        env.update(self.extra_env)
        env.update(self.por_servicio.get(nombre, {}))
        return env

    def lanzar(self, nombre, alias=None, puerto=None, extra=None):
        alias = alias or nombre
        puerto = puerto or self.puertos[nombre]
        env = {**self.entorno(nombre), **(extra or {})}
        carpeta = RAIZ / CARPETAS[nombre]
        p = Proceso(alias, [PYTHON, str(RAIZ / "tests" / "launcher.py"), str(carpeta), str(puerto)], env, self.logdir)
        self.procesos.append(p)
        return p

    def iniciar(self):
        try:
            self.iniciar_vault()
            pendientes = [(n, self.lanzar(n)) for n in CARPETAS if n not in self.omitir and (RAIZ / CARPETAS[n] / "app" / "main.py").exists()]
            for n, p in pendientes:
                p.esperar(self.urls[n])
        except BaseException:
            self.detener()      # si algo no arranca, no deja procesos huérfanos
            raise
        return self

    def detener(self):
        for p in reversed(self.procesos):
            p.detener()

    # ----- fallas controladas (para las pruebas de resiliencia) ---------------------------------
    def proceso(self, nombre):
        return next(p for p in self.procesos if p.nombre == nombre)

    def congelar(self, nombre):
        """El servicio sigue aceptando conexiones pero deja de responder (como un proceso colgado). Conserva sus datos."""
        os.kill(self.proceso(nombre).proc.pid, signal.SIGSTOP)

    def descongelar(self, nombre):
        os.kill(self.proceso(nombre).proc.pid, signal.SIGCONT)

    def apagar(self, nombre):
        """El servicio desaparece: las conexiones son rechazadas. Su base simulada en memoria se pierde."""
        self.proceso(nombre).detener()

    def encender(self, nombre):
        """Vuelve a lanzar un servicio apagado (mismo puerto, base vacía + datos de prueba)."""
        self.procesos = [p for p in self.procesos if p.nombre != nombre]
        p = self.lanzar(nombre)
        p.esperar(self.urls[nombre])
        return p

    def secreto(self, ruta, campo="value"):
        """Lee un secreto del Vault falso con el token raíz (solo para que las pruebas actúen como un atacante informado)."""
        r = httpx.get(f"{self.vault_url}/v1/secret/data/asador/{ruta}", headers={"X-Vault-Token": self.root_token}, timeout=5)
        r.raise_for_status()
        return r.json()["data"]["data"][campo]

    def valores_secretos(self):
        """Todos los valores que Vault guarda según secrets/manifest.tsv (las pruebas buscan si alguno se filtró a un log o a una respuesta)."""
        valores = set()
        for linea in (RAIZ / "secrets" / "manifest.tsv").read_text(encoding="utf-8").splitlines()[1:]:
            ref, _tipo, campos = linea.split("\t")[:3]
            for campo in campos.split(","):
                if campo in ("user", "host"):
                    continue   # nombres de usuario y servidores no son secretos (MongoDB los escribe en su log al autenticar)
                try:
                    valores.add(self.secreto(ref, campo))
                except httpx.HTTPError:
                    pass   # p. ej. email/smtp, que solo existe con un proveedor de correo real
        return valores

    def __enter__(self):
        return self.iniciar()

    def __exit__(self, *a):
        self.detener()


if __name__ == "__main__":
    # Modo demostración: python tests/stack.py  -> deja el sistema corriendo y muestra la URL del gateway
    import tempfile
    d = tempfile.mkdtemp(prefix="asador-logs-")
    with Stack(d) as s:
        print("Gateway:", s.urls.get("api-gateway"), "| logs en", d, flush=True)
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            pass
