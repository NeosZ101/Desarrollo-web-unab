"""El modelo editable docs/diagramas/El-Asador.dsl debe describir lo que se entrega (pauta: «los diagramas deben describir la implementación»).

No levanta servicios. Lee el .dsl como texto y lo compara con las fuentes de verdad del repositorio:
  * docker-compose.yml        servicios, puertos publicados, red interna, imágenes, endurecimiento y bases de datos,
  * tests/contratos/*.json    los 20 pares de servicios autorizados a llamarse (el contrato que la segunda capa hace cumplir),
  * api-gateway/app/rutas.py  la tabla de rutas S01–S38,
  * tests/                    cada prueba que un escenario dinámico cita existe de verdad,
  * docs/diagramas/render     los SVG exportados corresponden al .dsl actual.
Si el .dsl está disponible el CLI oficial de Structurizr (variable STRUCTURIZR_CLI) también lo valida.
"""
import json
import os
import re
import shutil
import subprocess
import sys

import pytest
import yaml

from ayuda import RAIZ, cargar

DSL_RUTA = RAIZ / "docs" / "diagramas" / "El-Asador.dsl"
DSL = DSL_RUTA.read_text(encoding="utf-8")
MODELO = DSL[:DSL.index("views {")]
VISTAS = DSL[DSL.index("views {"):]
COMPOSE = yaml.safe_load((RAIZ / "docker-compose.yml").read_text(encoding="utf-8"))
SERVICIOS = COMPOSE["services"]
RUTAS = cargar("api-gateway/app/rutas.py", "t_rutas_dsl").RUTAS

# contenedor del DSL -> servicio de docker-compose.yml
SERVICIO_DE = {"apiGateway": "api-gateway", "authService": "auth", "clients": "clients", "inventory": "inventory", "orders": "orders",
               "payments": "payments", "notifications": "notifications", "analytics": "analytics", "graphqlGateway": "graphql-gateway",
               "sandbox": "provider-sandbox"}
BASES = ("dbIdentity", "dbClients", "dbInventory", "dbOrders", "dbPayments", "dbNotifications", "dbAnalytics")

RELACION = re.compile(r'^\s*([\w.]+)\s*->\s*([\w.]+)\s+"([^"]*)"(?:\s+"([^"]*)")?(?:\s+"([^"]*)")?\s*$', re.M)
CONTENEDOR = re.compile(r'^\s*(\w+)\s*=\s*container\s+"([^"]+)"', re.M)


def _relaciones():
    """[(origen, destino, descripcion, tecnologia, etiqueta)] declaradas en el modelo (no cuenta los pasos de los escenarios)."""
    return [m.groups(default="") for m in RELACION.finditer(MODELO)]


def _contenedor(identificador):
    """'sistema.apiGateway.entrada' -> 'apiGateway'; 'proveedor.sandbox' -> 'sandbox'; una persona o sistema externo -> None."""
    partes = identificador.split(".")
    if partes[0] == "sistema":
        return partes[1] if len(partes) > 1 else None
    if partes[0] == "proveedor" and len(partes) > 1:
        return partes[1]
    return None


def _pares(solo_contenedores):
    """Pares (origen, destino) entre servicios, con los nombres de docker-compose.yml. Sin respuestas, bases ni secretos."""
    pares = set()
    for origen, destino, _, _, etiqueta in _relaciones():
        if etiqueta == "Respuesta":
            continue
        o, d = _contenedor(origen), _contenedor(destino)
        if o not in SERVICIO_DE or d not in SERVICIO_DE or o == "sandbox" or d == "sandbox" or o == d:
            continue
        if solo_contenedores and (origen.count(".") != 1 or destino.count(".") != 1):
            continue
        pares.add((SERVICIO_DE[o], SERVICIO_DE[d]))
    return pares


# ----------------------------- el archivo mismo -----------------------------------------------------------------------
def test_el_dsl_usa_solo_ascii_como_el_del_docente():
    malos = sorted({c for c in DSL if ord(c) > 127})
    assert malos == [], f"caracteres fuera de ASCII (Structurizr Lite los muestra mal según la plataforma): {malos}"


def test_el_dsl_trae_los_niveles_que_pide_el_formato_del_docente():
    for tipo in ("systemContext", "container", "component", "dynamic", "deployment"):
        assert re.search(rf"^\s*{tipo}\s", VISTAS, re.M), f"falta al menos una vista {tipo}"
    assert VISTAS.count("deployment sistema ") >= 2
    assert "!identifiers hierarchical" in DSL


def test_el_cli_oficial_de_structurizr_valida_el_dsl():
    cli = os.environ.get("STRUCTURIZR_CLI") or shutil.which("structurizr.sh") or shutil.which("structurizr")
    if not cli or not shutil.which("java"):
        pytest.skip("sin Structurizr CLI y Java: definir STRUCTURIZR_CLI para validar el .dsl con el analizador oficial")
    r = subprocess.run([cli, "validate", "-workspace", str(DSL_RUTA)], capture_output=True, text=True, timeout=180)
    assert r.returncode == 0, r.stdout + r.stderr


def test_los_svg_exportados_corresponden_al_dsl_actual():
    sys.path.insert(0, str(RAIZ / "scripts"))
    import exportar_diagramas
    assert exportar_diagramas.revisar() == []


# ----------------------------- servicios, bases y despliegue contra docker-compose.yml ---------------------------------
def test_cada_servicio_del_dsl_es_un_servicio_del_compose_con_su_carpeta_y_su_codigo():
    contenedores = {i for i, _ in CONTENEDOR.findall(MODELO)}
    assert set(SERVICIO_DE) <= contenedores
    for ident, servicio in SERVICIO_DE.items():
        assert servicio in SERVICIOS, f"{ident}: no hay servicio «{servicio}» en docker-compose.yml"
        carpeta = SERVICIOS[servicio]["build"]["args"]["SERVICIO"]
        assert (RAIZ / carpeta / "app" / "main.py").exists(), f"{ident}: falta {carpeta}/app/main.py"


def test_los_servicios_de_aplicacion_del_compose_estan_todos_en_el_dsl():
    aplicacion = {n for n, s in SERVICIOS.items() if "build" in s}
    assert aplicacion == set(SERVICIO_DE.values())


def test_las_siete_bases_del_dsl_son_las_de_los_servicios_que_dependen_de_mongo():
    con_mongo = {n for n, s in SERVICIOS.items() if "mongo" in (s.get("depends_on") or {})}
    leen_bd = {}
    for origen, destino, *_ in _relaciones():
        if destino.startswith("sistema.db"):
            leen_bd[destino.split(".")[1]] = SERVICIO_DE[_contenedor(origen)]
    assert set(leen_bd) == set(BASES), "cada base del DSL debe tener quien la use"
    assert set(leen_bd.values()) == con_mongo, (leen_bd, con_mongo)
    assert len(set(leen_bd.values())) == len(BASES), "una base por servicio (nadie comparte base)"


def test_todo_servicio_de_aplicacion_lee_sus_secretos_de_vault_en_el_dsl_y_en_el_compose():
    en_dsl = {SERVICIO_DE[_contenedor(o)] for o, d, *_ in _relaciones() if d == "sistema.secretManager" and _contenedor(o) in SERVICIO_DE}
    en_compose = {n for n, s in SERVICIOS.items() if "build" in s and "VAULT_ADDR" in (s.get("environment") or {})}
    assert en_dsl == en_compose == set(SERVICIO_DE.values())


def test_los_puertos_la_red_interna_y_las_versiones_del_despliegue_son_los_del_compose():
    publican = {n: s["ports"] for n, s in SERVICIOS.items() if s.get("ports")}
    assert publican == {"api-gateway": ["127.0.0.1:8000:8000"], "provider-sandbox": ["127.0.0.1:8300:8300"]}
    for servicio, puerto in (("api-gateway", "127.0.0.1:8000"), ("provider-sandbox", "127.0.0.1:8300")):
        assert re.search(rf'"Contenedor {servicio}" "{re.escape(puerto)}\.', DSL), f"el DSL debe decir que {servicio} publica {puerto}"
    assert COMPOSE["networks"]["interna"]["internal"] is True and "internal: true" in DSL
    assert SERVICIOS["mongo"]["image"] == "mongo:8.0" and "MongoDB 8.0" in DSL
    assert SERVICIOS["vault"]["image"] == "hashicorp/vault:2.0.0" and "Vault 2.0.0" in DSL
    # «sin privilegios y con sistema de archivos de solo lectura» (nodo Docker Compose del DSL)
    for n, s in SERVICIOS.items():
        if "build" in s:
            assert s.get("read_only") is True and s.get("cap_drop") == ["ALL"], n


def test_cada_contenedor_aparece_una_vez_en_cada_entorno_de_despliegue():
    esperados = sorted("proveedor.sandbox" if e == "sandbox" else f"sistema.{e}" for e in ["frontend", *SERVICIO_DE, *BASES, "secretManager"])
    for entorno in ("compose", "procesos"):
        inicio = MODELO.index(f"{entorno} = deploymentEnvironment")
        fin = MODELO.find("= deploymentEnvironment", inicio + 10)       # el siguiente entorno, si lo hay
        bloque = MODELO[inicio:fin if fin != -1 else len(MODELO)]
        instancias = sorted(re.findall(r"containerInstance\s+([\w.]+)", bloque))
        assert instancias == esperados, (entorno, set(instancias) ^ set(esperados))


def test_el_dsl_declara_el_despliegue_en_localhost_como_indico_el_docente():
    assert "localhost" in DSL and "127.0.0.1" in DSL


# ----------------------------- llamadas entre servicios y rutas contra los contratos y el código ----------------------
def test_los_20_pares_de_llamadas_del_dsl_son_exactamente_los_del_contrato_aprobado():
    contrato = {tuple(p) for p in json.loads((RAIZ / "tests" / "contratos" / "pares_de_servicios.json").read_text(encoding="utf-8"))}
    assert len(contrato) == 20
    assert _pares(solo_contenedores=True) == contrato, (_pares(True) ^ contrato)


def test_ninguna_flecha_de_componentes_inventa_una_llamada_que_el_contrato_no_autoriza():
    contrato = {tuple(p) for p in json.loads((RAIZ / "tests" / "contratos" / "pares_de_servicios.json").read_text(encoding="utf-8"))}
    sobran = _pares(solo_contenedores=False) - contrato
    assert sobran == set(), sobran


def test_el_dsl_dice_que_son_tantas_rutas_como_tiene_la_tabla_del_gateway():
    cuantas = {int(n) for n in re.findall(r"(\d+) rutas", DSL)}
    assert cuantas == {len(RUTAS)}, (cuantas, len(RUTAS))
    ultima = max(int(r.id[1:]) for r in RUTAS)
    assert f"S01 a S{ultima:02d}" in DSL


def test_cada_ruta_que_un_escenario_cita_existe_con_ese_verbo_y_esa_ruta():
    norm = lambda p: re.sub(r"\{[^}]*\}", "{}", p)
    por_id = {r.id: r for r in RUTAS}
    citas = re.findall(r'"(GET|POST|PUT|PATCH|DELETE) (/api/\S+) \((S\d\d)\)', VISTAS)
    assert len(citas) >= 10
    for metodo, ruta, ident in citas:
        r = por_id[ident]
        assert (r.metodo, norm(r.patron)) == (metodo, norm(ruta)), (ident, r.metodo, r.patron, metodo, ruta)


# ----------------------------- cada prueba citada por un escenario existe -----------------------------------------------
def _descripciones_dinamicas():
    return re.findall(r'^\s*dynamic\s+\S+\s+"([^"]+)"\s+"([^"]+)"', VISTAS, re.M)


def test_los_escenarios_dinamicos_citan_pruebas_y_evidencia_que_existen():
    dinamicas = _descripciones_dinamicas()
    assert len(dinamicas) >= 15
    faltan = []
    for clave, descripcion in dinamicas:
        archivo = None
        citadas = 0
        for m in re.finditer(r"(test_\w+\.py)|::(\w+)", descripcion):
            if m.group(1):
                archivo = m.group(1)
                citadas += 1
                if not (RAIZ / "tests" / archivo).exists():
                    faltan.append((clave, archivo))
            elif archivo and not re.search(rf"def {m.group(2)}\(", (RAIZ / "tests" / archivo).read_text(encoding="utf-8")):
                faltan.append((clave, f"{archivo}::{m.group(2)}"))
        for ruta in re.findall(r"docs/[\w/.-]+\.\w+", descripcion):
            if not (RAIZ / ruta).exists():
                faltan.append((clave, ruta))
        assert citadas or "docs/evidencia" in descripcion, f"{clave}: el escenario no cita ninguna prueba ni evidencia"
    assert faltan == [], faltan


def test_los_siete_flujos_de_la_pauta_tienen_escenario_dinamico():
    claves = [c for c, _ in _descripciones_dinamicas()]
    for flujo in ("F01", "F02", "F03", "F04", "F05", "F06", "F07"):
        assert any(c.startswith(f"D_{flujo}_") for c in claves), flujo
    # los que la pauta llama «de excepción» tienen su variante de error
    for variante in ("D_F01_Recuperacion", "D_F02_Reintento", "D_F03_Ajeno", "D_F03_Expirada", "D_F04_GraphQL_Parcial", "D_F05_Aviso_Invalido_C3"):
        assert variante in claves, variante
