"""Pagos, boletas, reembolsos y avisos del proveedor (RF2, RF3, RF4, RF8).

Regla central: un pago se aprueba SOLO por un aviso firmado del proveedor o por la confirmación manual de un administrador
(y esta última únicamente para transferencia/depósito). El navegador nunca decide si algo está pagado ni cuánto cuesta.
"""
import json
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

import httpx
import pytest

from ayuda import (aviso, enviar_aviso, esperar, estado_pedido, iniciar_pago, llamar_servicio, pagar_en_proveedor, pedido_ok,
                   pedido_pagado_con_proveedor, pedido_pagado_manual, ventas_del_dia)

pytestmark = pytest.mark.integracion


# ----------------------------- pago manual (transferencia / depósito) -------------------------------------------
def test_flujo_completo_de_transferencia(nuevo_cliente, admin):
    c = nuevo_cliente()
    antes = ventas_del_dia(admin)
    p = pedido_ok(c, items=[{"id": "p02", "cantidad": 1}], medio="Transferencia bancaria")
    pago = iniciar_pago(c, p["id"])
    assert pago["estado"] == "iniciado" and pago["modo"] == "manual" and pago["monto"] == p["total"] == 44990
    assert "$44.990" in pago["instrucciones"] and p["id"] in pago["instrucciones"] and "checkoutUrl" not in pago
    assert pago["datosBancarios"]["titular"] == "Parrilladas El Asador SpA"
    repetido = c.post(f"/api/orders/{p['id']}/payment")                           # repetir no crea otro cobro
    assert repetido.status_code == 200 and repetido.json()["id"] == pago["id"]
    assert estado_pedido(c, p["id"]) == "Pago pendiente"

    r = admin.post(f"/api/admin/orders/{p['id']}/payment-confirmation", json={"referencia": "TRF-0099887"})
    assert r.status_code == 200 and r.json()["pago"]["estado"] == "aprobado"
    esperar(lambda: estado_pedido(c, p["id"]) == "En preparación")
    d = c.get(f"/api/orders/{p['id']}").json()
    assert d["historial"][-1] == {**d["historial"][-1], "estado": "En preparación", "por": "Sistema de pagos"}

    b = esperar(lambda: (lambda x: x.json() if x.status_code == 200 else None)(c.get(f"/api/orders/{p['id']}/receipt")), mensaje="no se emitió la boleta")
    assert b["folio"].startswith("B-") and len(b["folio"]) == 8 and b["pedidoId"] == p["id"] and b["estado"] == "vigente"
    assert b["total"] == 44990 and b["neto"] + b["iva"] == 44990 and b["ivaTasa"] == 19 and (b["neto"], b["iva"]) == (37807, 7183)
    assert b["emisor"]["rut"] == "76.123.456-0" and b["medioPago"] == "Transferencia bancaria" and b["lineas"][0]["nombre"] == "Parrillada familiar"
    assert esperar(lambda: ventas_del_dia(admin)[0] - antes[0] == 44990, mensaje="analítica no recibió la venta")
    assert ventas_del_dia(admin)[1] - antes[1] == 1

    r = admin.post(f"/api/admin/orders/{p['id']}/payment-confirmation", json={"referencia": "TRF-0099887"})   # confirmar dos veces
    assert r.status_code == 409 and r.json()["codigo"] == "PEDIDO_NO_PAGABLE"


def test_confirmacion_manual_exige_referencia_valida_y_rol_administrador(nuevo_cliente, admin, despacho, dueno):
    c = nuevo_cliente()
    p = pedido_ok(c, medio="Depósito bancario")
    url = f"/api/admin/orders/{p['id']}/payment-confirmation"
    for cuerpo in ({}, {"referencia": ""}, {"referencia": "ab"}, {"referencia": "<script>"}, {"referencia": "x" * 61}, {"referencia": "TRF-1", "monto": 1}):
        assert admin.post(url, json=cuerpo).status_code == 422, cuerpo
    for sin_permiso in (c, despacho, dueno):
        assert sin_permiso.post(url, json={"referencia": "TRF-123"}).status_code == 403
    assert estado_pedido(c, p["id"]) == "Pago pendiente"


def test_un_pedido_con_proveedor_no_se_confirma_a_mano(nuevo_cliente, admin):
    c = nuevo_cliente()
    p = pedido_ok(c, medio="Servipag")
    r = admin.post(f"/api/admin/orders/{p['id']}/payment-confirmation", json={"referencia": "TRF-123"})
    assert r.status_code == 409 and r.json()["codigo"] == "MEDIO_NO_MANUAL"
    assert estado_pedido(c, p["id"]) == "Pago pendiente"


# ----------------------------- pago con proveedor (Servipag sandbox) --------------------------------------------
def test_flujo_completo_con_el_proveedor(nuevo_cliente, admin):
    c = nuevo_cliente()
    antes = ventas_del_dia(admin)
    p = pedido_ok(c, items=[{"id": "p05", "cantidad": 2}], comuna="Ñuñoa")
    pago = iniciar_pago(c, p["id"])
    assert pago["modo"] == "proveedor" and pago["checkoutUrl"].startswith("http") and "/checkout/prv_" in pago["checkoutUrl"] and pago["monto"] == 27980
    pagina = httpx.get(pago["checkoutUrl"], timeout=10)
    assert pagina.status_code == 200 and "$27.980" in pagina.text                       # el proveedor cobra lo que fijó el servidor
    assert estado_pedido(c, p["id"]) == "Pago pendiente"                                # hasta que el proveedor avise no hay pago

    pagar_en_proveedor(pago["checkoutUrl"])
    esperar(lambda: c.get(f"/api/orders/{p['id']}/payment").json()["estado"] == "aprobado", mensaje="el aviso firmado no aprobó el pago")
    esperar(lambda: estado_pedido(c, p["id"]) == "En preparación")
    assert esperar(lambda: ventas_del_dia(admin)[0] - antes[0] == 27980)
    assert c.get(f"/api/orders/{p['id']}/receipt").json()["total"] == 27980


def test_pago_rechazado_deja_el_pedido_pendiente_y_se_puede_reintentar(nuevo_cliente):
    c = nuevo_cliente()
    p = pedido_ok(c)
    primero = iniciar_pago(c, p["id"])
    pagar_en_proveedor(primero["checkoutUrl"], aprobar=False)
    esperar(lambda: c.get(f"/api/orders/{p['id']}/payment").json()["estado"] == "rechazado")
    assert estado_pedido(c, p["id"]) == "Pago pendiente"
    segundo = c.post(f"/api/orders/{p['id']}/payment")
    assert segundo.status_code == 201 and segundo.json()["id"] != primero["id"] and segundo.json()["checkoutUrl"] != primero["checkoutUrl"]
    pagar_en_proveedor(segundo.json()["checkoutUrl"])
    esperar(lambda: estado_pedido(c, p["id"]) == "En preparación")


def test_volver_del_proveedor_con_pago_aprobado_en_la_url_no_paga_nada(nuevo_cliente):
    """La URL de retorno es del navegador: lo que importa es el estado que guarda el servidor."""
    c = nuevo_cliente()
    p = pedido_ok(c)
    iniciar_pago(c, p["id"])
    time.sleep(0.5)
    assert c.get(f"/api/orders/{p['id']}?pago=aprobado").json()["estado"] == "Pago pendiente"
    assert c.get(f"/api/orders/{p['id']}/receipt").status_code == 404


def test_un_cliente_no_puede_marcar_su_pedido_como_pagado(nuevo_cliente):
    c = nuevo_cliente()
    p = pedido_ok(c)
    for metodo, ruta, cuerpo in (("PUT", f"/api/orders/{p['id']}", {"estado": "En preparación"}), ("PUT", f"/api/admin/orders/{p['id']}/status", {"estado": "En camino"}),
                                 ("POST", f"/api/admin/orders/{p['id']}/payment-confirmation", {"referencia": "TRF-1"}),
                                 ("POST", f"/api/orders/{p['id']}/payment-confirmed", {"pagoId": "x", "monto": p["total"]}),
                                 ("POST", "/api/webhooks/provider", {"type": "payment.succeeded"})):
        r = c.pedir(metodo, ruta, json=cuerpo)
        assert r.status_code in (400, 403, 404, 405), (ruta, r.status_code, r.text)
    assert estado_pedido(c, p["id"]) == "Pago pendiente"


# ----------------------------- avisos del proveedor: firma, repetición, monto -----------------------------------
def _pedido_con_cobro(c):
    p = pedido_ok(c)
    return p, iniciar_pago(c, p["id"])


def test_aviso_sin_firma_o_con_firma_falsa_se_rechaza(sistema, gw, nuevo_cliente):
    c = nuevo_cliente()
    p, pago = _pedido_con_cobro(c)
    cuerpo, cab = aviso(sistema, "payment.succeeded", pago)
    sin_firma = {k: v for k, v in cab.items() if k != "X-Provider-Signature"}
    assert enviar_aviso(gw, cuerpo, sin_firma).status_code == 400
    falsa = aviso(sistema, "payment.succeeded", pago, secreto="clave-inventada-por-el-atacante")
    r = enviar_aviso(gw, *falsa)
    assert r.status_code == 400 and r.json()["codigo"] == "AVISO_NO_VALIDO" and "firma" not in r.text.lower()   # no se explica por qué falló
    assert estado_pedido(c, p["id"]) == "Pago pendiente" and c.get(f"/api/orders/{p['id']}/payment").json()["estado"] == "iniciado"


def test_aviso_alterado_despues_de_firmar_se_rechaza(sistema, gw, nuevo_cliente):
    c = nuevo_cliente()
    p, pago = _pedido_con_cobro(c)
    cuerpo, cab = aviso(sistema, "payment.failed", pago)
    alterado = cuerpo.replace(b"payment.failed", b"payment.succeeded")
    assert alterado != cuerpo
    assert enviar_aviso(gw, alterado, cab).status_code == 400
    assert estado_pedido(c, p["id"]) == "Pago pendiente"


def test_aviso_antiguo_o_del_futuro_se_rechaza(sistema, gw, nuevo_cliente):
    c = nuevo_cliente()
    p, pago = _pedido_con_cobro(c)
    for desfase in (-3600, -360, 360, 3600):    # con 60 s de margen sobre los 300 s: la demora de la red no los vuelve válidos (el borde exacto se prueba en test_unidad_reglas)
        assert enviar_aviso(gw, *aviso(sistema, "payment.succeeded", pago, t=int(time.time()) + desfase)).status_code == 400, desfase
    assert estado_pedido(c, p["id"]) == "Pago pendiente"


def test_aviso_con_monto_distinto_no_aprueba_el_pago(sistema, gw, nuevo_cliente):
    c = nuevo_cliente()
    p, pago = _pedido_con_cobro(c)
    for monto in (1, pago["monto"] - 1, pago["monto"] + 1):
        r = enviar_aviso(gw, *aviso(sistema, "payment.succeeded", pago, monto=monto))
        assert r.status_code == 409 and r.json()["codigo"] == "MONTO_NO_COINCIDE", monto
    r = enviar_aviso(gw, *aviso(sistema, "payment.succeeded", pago, moneda="USD"))
    assert r.status_code == 409
    assert estado_pedido(c, p["id"]) == "Pago pendiente" and c.get(f"/api/orders/{p['id']}/payment").json()["estado"] == "iniciado"


def test_aviso_de_otro_pago_del_proveedor_no_coincide(sistema, gw, nuevo_cliente):
    c = nuevo_cliente()
    _, pago = _pedido_con_cobro(c)
    r = enviar_aviso(gw, *aviso(sistema, "payment.succeeded", pago, proveedor_id="prv_" + "x" * 20))
    assert r.status_code == 409 and r.json()["codigo"] == "PAGO_NO_COINCIDE"


def test_aviso_de_un_cobro_desconocido_se_ignora(sistema, gw, nuevo_cliente):
    c = nuevo_cliente()
    _, pago = _pedido_con_cobro(c)
    r = enviar_aviso(gw, *aviso(sistema, "payment.succeeded", {**pago, "id": "pay-" + uuid.uuid4().hex[:16]}))
    assert r.status_code == 200 and r.json()["resultado"] == "pago_desconocido"


def test_aviso_con_formato_incorrecto(sistema, gw, nuevo_cliente):
    c = nuevo_cliente()
    _, pago = _pedido_con_cobro(c)
    cuerpo, cab = aviso(sistema, "payment.succeeded", pago, evento_id="evt_valido12345")
    assert enviar_aviso(gw, cuerpo, {**cab, "X-Provider-Event-Id": "no-es-un-evento"}).status_code == 400
    assert enviar_aviso(gw, cuerpo, {**cab, "X-Provider-Signature": "x"}).status_code == 400
    assert enviar_aviso(gw, b"{no es json", cab).status_code in (400,)
    assert enviar_aviso(gw, b"x" * 70000, cab).status_code == 413


def test_aviso_firmado_legitimo_aprueba_una_sola_vez_aunque_se_repita(sistema, gw, nuevo_cliente, admin):
    c = nuevo_cliente()
    antes = ventas_del_dia(admin)
    p, pago = _pedido_con_cobro(c)
    cuerpo, cab = aviso(sistema, "payment.succeeded", pago)
    primero = enviar_aviso(gw, cuerpo, cab)
    assert primero.status_code == 200 and primero.json()["resultado"] == "aprobado"
    repetido = enviar_aviso(gw, cuerpo, cab)                                      # el proveedor entrega «al menos una vez»
    assert repetido.status_code == 200 and repetido.json() == {"ok": True, "duplicado": True}
    otro_evento = enviar_aviso(gw, *aviso(sistema, "payment.succeeded", pago))    # mismo pago, otro id de evento
    assert otro_evento.status_code == 200 and otro_evento.json()["resultado"] == "sin_cambios"
    esperar(lambda: estado_pedido(c, p["id"]) == "En preparación")
    esperar(lambda: ventas_del_dia(admin)[0] - antes[0] == pago["monto"])
    time.sleep(1.5)
    assert ventas_del_dia(admin) == (antes[0] + pago["monto"], antes[1] + 1)       # una sola venta, una sola boleta
    historial = [h["estado"] for h in c.get(f"/api/orders/{p['id']}").json()["historial"]]
    assert historial == ["Pago pendiente", "En preparación"]


def test_dos_avisos_simultaneos_aprueban_solo_uno(sistema, gw, nuevo_cliente):
    from concurrent.futures import ThreadPoolExecutor
    c = nuevo_cliente()
    p, pago = _pedido_con_cobro(c)
    avisos = [aviso(sistema, "payment.succeeded", pago) for _ in range(6)]
    with ThreadPoolExecutor(6) as pool:
        resultados = list(pool.map(lambda a: enviar_aviso(gw, *a).json().get("resultado"), avisos))
    assert resultados.count("aprobado") == 1 and set(resultados) <= {"aprobado", "sin_cambios"}, resultados
    esperar(lambda: estado_pedido(c, p["id"]) == "En preparación")
    assert [h["estado"] for h in c.get(f"/api/orders/{p['id']}").json()["historial"]].count("En preparación") == 1


def test_el_proveedor_que_entrega_cada_aviso_dos_veces_no_duplica_efectos(nuevo_cliente, admin):
    """El sandbox reenvía algunos avisos; aquí comprobamos que el pedido y la venta quedan una sola vez."""
    c = nuevo_cliente()
    antes = ventas_del_dia(admin)
    p, pago = pedido_pagado_con_proveedor(c)
    time.sleep(1.5)
    assert ventas_del_dia(admin) == (antes[0] + pago["monto"], antes[1] + 1)


# ----------------------------- reembolsos y anulación de pedidos pagados ---------------------------------------
def test_anular_un_pedido_pagado_manualmente_genera_reembolso_pendiente(nuevo_cliente, admin):
    c = nuevo_cliente()
    antes = ventas_del_dia(admin)
    p, _ = pedido_pagado_manual(c, admin, medio="Depósito bancario")
    esperar(lambda: ventas_del_dia(admin)[0] - antes[0] == p["total"])
    r = c.post(f"/api/orders/{p['id']}/cancellation", json={"motivo": "Se demora mucho el despacho"})
    assert r.status_code == 200 and r.json()["estado"] == "Anulado" and r.json()["reembolso"] in ("pendiente", "no_aplica")
    esperar(lambda: c.get(f"/api/orders/{p['id']}").json()["reembolso"] == "pendiente", mensaje="el reembolso no quedó pendiente")
    assert esperar(lambda: ventas_del_dia(admin) == antes, mensaje="la venta anulada siguió contando en los reportes")
    pendientes = admin.get("/api/admin/payments?reembolso=pendiente&limit=100").json()
    assert any(x["pedidoId"] == p["id"] for x in pendientes)

    url = f"/api/admin/orders/{p['id']}/refund"
    r = admin.post(url, json={})
    assert r.status_code == 422 and r.json()["codigo"] == "REFERENCIA_REQUERIDA"        # a mano exige comprobante de la devolución
    r = admin.post(url, json={"referencia": "DEV-777"})
    assert r.status_code == 200 and r.json()["reembolso"]["estado"] == "realizado"
    again = admin.post(url, json={"referencia": "DEV-888"})                                   # idempotente
    assert again.status_code == 200 and again.json()["reembolso"]["estado"] == "realizado"
    esperar(lambda: c.get(f"/api/orders/{p['id']}").json()["reembolso"] == "realizado")
    assert c.get(f"/api/orders/{p['id']}/receipt").json()["estado"] == "anulada"


def test_reembolso_de_un_pago_con_proveedor_lo_ejecuta_el_proveedor(nuevo_cliente, admin):
    c = nuevo_cliente()
    p, _ = pedido_pagado_con_proveedor(c)
    assert c.post(f"/api/orders/{p['id']}/cancellation", json={"motivo": "Encontré otra opción"}).status_code == 200
    esperar(lambda: c.get(f"/api/orders/{p['id']}").json()["reembolso"] == "pendiente")
    r = admin.post(f"/api/admin/orders/{p['id']}/refund", json={})
    assert r.status_code == 200 and r.json()["reembolso"]["estado"] == "realizado"
    esperar(lambda: c.get(f"/api/orders/{p['id']}").json()["reembolso"] == "realizado")


def test_reembolso_sin_pago_aprobado_o_sin_permiso(nuevo_cliente, admin, despacho, dueno):
    c = nuevo_cliente()
    p = pedido_ok(c)
    r = admin.post(f"/api/admin/orders/{p['id']}/refund", json={"referencia": "DEV-1"})
    assert r.status_code == 404 and r.json()["codigo"] == "SIN_REEMBOLSO"
    for otro in (c, despacho, dueno):
        assert otro.post(f"/api/admin/orders/{p['id']}/refund", json={"referencia": "DEV-1"}).status_code == 403


def test_pago_que_llega_despues_de_anular_se_reembolsa_solo(sistema, gw, nuevo_cliente, admin):
    c = nuevo_cliente()
    antes = ventas_del_dia(admin)
    p, pago = _pedido_con_cobro(c)
    assert c.post(f"/api/orders/{p['id']}/cancellation", json={"motivo": "Ya no lo necesito"}).status_code == 200
    esperar(lambda: c.get(f"/api/orders/{p['id']}/payment").json()["estado"] == "cancelado")
    # el cliente alcanzó a pagar en el proveedor justo antes de que se cancelara: llega un aviso legítimo y firmado
    r = enviar_aviso(gw, *aviso(sistema, "payment.succeeded", pago))
    assert r.status_code == 200 and r.json()["resultado"] == "tardio"
    assert estado_pedido(c, p["id"]) == "Anulado"
    esperar(lambda: c.get(f"/api/orders/{p['id']}").json()["reembolso"] == "pendiente", mensaje="el pago tardío no quedó para reembolso")
    assert c.get(f"/api/orders/{p['id']}/receipt").status_code == 404                           # nunca hubo venta
    assert ventas_del_dia(admin) == antes
    assert any(x["pedidoId"] == p["id"] for x in admin.get("/api/admin/payments?reembolso=pendiente&limit=100").json())


def test_el_proveedor_no_acepta_pagar_un_cobro_cancelado(nuevo_cliente):
    c = nuevo_cliente()
    p = pedido_ok(c)
    pago = iniciar_pago(c, p["id"])
    c.post(f"/api/orders/{p['id']}/cancellation", json={"motivo": "Ya no lo necesito"})
    esperar(lambda: c.get(f"/api/orders/{p['id']}/payment").json()["estado"] == "cancelado")
    r = httpx.post(pago["checkoutUrl"] + "/pay", follow_redirects=False, timeout=10)
    assert r.status_code == 409


# ----------------------------- listado administrativo de pagos ---------------------------------------------------
def test_listado_de_pagos_por_confirmar_y_filtros(nuevo_cliente, admin, despacho):
    c = nuevo_cliente()
    p = pedido_ok(c, medio="Transferencia bancaria")
    iniciar_pago(c, p["id"])
    r = admin.get("/api/admin/payments?estado=iniciado&modo=manual&limit=100")
    assert r.status_code == 200 and any(x["pedidoId"] == p["id"] for x in r.json()) and int(r.headers["x-total-count"]) >= 1
    assert admin.get("/api/admin/payments?estado=inventado").status_code == 400
    assert admin.get("/api/admin/payments?limit=101").status_code == 400
    assert despacho.get("/api/admin/payments").status_code == 403 and c.get("/api/admin/payments").status_code == 403
    assert json.dumps(r.json()).count("password") == 0


# ----------------------------- la misma confirmación llegando varias veces a la vez ------------------------------
def test_dos_confirmaciones_simultaneas_del_mismo_pago_responden_igual_y_ninguna_es_un_rechazo(sistema, nuevo_cliente):
    """Hallazgo de la ejecución con MongoDB real: el aviso original de payments y su reintento llegan juntos a orders; antes una de las
    dos perdía la escritura y recibía 409, y payments lo tomaba como «el pedido rechaza el pago» y devolvía el dinero.
    Con MongoDB real las lecturas de todas las solicitudes se emiten antes de que la primera escritura termine, así que la carrera
    ocurre sola; con mongomock no se intercalan (el caso determinista está en tests/test_unidad_carreras.py)."""
    c = nuevo_cliente()
    p = pedido_ok(c, medio="Transferencia bancaria")
    ruta, cuerpo, n = f"/internal/orders/{p['id']}/payment-confirmed", {"pagoId": "pay-simultaneo-1", "monto": p["total"]}, 16
    salida = threading.Barrier(n)

    def confirmar(_):
        salida.wait(10)   # todas salen en el mismo instante
        return llamar_servicio(sistema, "orders", "POST", ruta, como="payments", json=cuerpo)

    with ThreadPoolExecutor(n) as pool:
        respuestas = list(pool.map(confirmar, range(n)))
    assert [r.status_code for r in respuestas] == [200] * n, [(r.status_code, r.text) for r in respuestas if r.status_code != 200]
    assert sorted(r.json()["repetido"] for r in respuestas) == [False] + [True] * (n - 1)   # una aplicó el pago; las demás lo reconocieron
    assert estado_pedido(c, p["id"]) == "En preparación"
    assert len([h for h in c.get(f"/api/orders/{p['id']}").json()["historial"] if h["estado"] == "En preparación"]) == 1   # y se anotó una sola vez
