"""Formato de los logs (common/logs.py), probado sin levantar servicios:
  * una línea JSON por evento;
  * el texto de una excepción de una LIBRERÍA nunca se escribe (podría traer una URL de base de datos o un dato personal);
  * toda línea, también la que escribe una librería, lleva el request_id de la solicitud que la provocó;
  * las claves del contexto que parecen secretos se reemplazan por «***».
"""
import io
import json
import logging

from fastapi.testclient import TestClient

from common.app import crear_app
from common.logs import RID, JsonFormatter


def _linea(nombre, msg, args=(), exc_info=None, ctx=None):
    r = logging.LogRecord(nombre, logging.ERROR, __file__, 1, msg, args, exc_info)
    if ctx:
        r.ctx = ctx
    return json.loads(JsonFormatter().format(r))


def test_el_texto_de_una_excepcion_de_una_libreria_no_se_escribe():
    peligro = "mongodb://u_orders:CLAVE-SECRETA@10.0.0.7:27017/asador_orders"
    linea = _linea("strawberry.execution", Exception(peligro))          # strawberry registra el error mismo como «mensaje»
    assert linea["msg"] == "Exception" and "CLAVE-SECRETA" not in json.dumps(linea) and "mongodb" not in json.dumps(linea)


def test_de_una_libreria_solo_se_escribe_la_plantilla_no_los_valores():
    linea = _linea("uvicorn.error", "Solicitud de %s con RUN %s rechazada", ("cliente@correo.cl", "12.345.678-5"))
    assert linea["msg"] == "Solicitud de %s con RUN %s rechazada"
    assert "correo.cl" not in json.dumps(linea) and "12.345.678" not in json.dumps(linea)


def test_una_excepcion_deja_su_tipo_pero_no_su_texto():
    try:
        raise ValueError("RUN 12.345.678-5 no es válido")
    except ValueError:
        import sys
        linea = _linea("orders", "no se pudo crear el pedido", exc_info=sys.exc_info())
    assert linea["error"] == "ValueError" and "12.345.678" not in json.dumps(linea)


def test_los_mensajes_propios_se_escriben_tal_cual_y_con_su_contexto():
    linea = _linea("auth", "login rechazado", ctx={"request_id": "abc-12345678", "status": 401, "ms": 3.2})
    assert linea["msg"] == "login rechazado" and linea["request_id"] == "abc-12345678" and linea["status"] == 401 and linea["nivel"] == "ERROR"


def test_las_claves_del_contexto_que_parecen_secretos_se_enmascaran():
    linea = _linea("auth", "evento", ctx={"password": "x", "token_de_sesion": "y", "correo": "a@b.cl", "run": "1-9", "cookie": "c", "ruta": "/api"})
    assert [linea[k] for k in ("password", "token_de_sesion", "correo", "run", "cookie")] == ["***"] * 5 and linea["ruta"] == "/api"


def test_la_linea_lleva_el_request_id_en_curso_y_el_explicito_manda():
    marca = RID.set("req-en-curso-0001")
    try:
        assert _linea("httpx", "algo")["request_id"] == "req-en-curso-0001"
        assert _linea("orders", "algo", ctx={"request_id": "req-explicito-0002"})["request_id"] == "req-explicito-0002"
    finally:
        RID.reset(marca)
    assert "request_id" not in _linea("orders", "fuera de una solicitud")


def test_en_una_solicitud_real_toda_linea_lleva_su_request_id_y_ninguna_filtra_el_texto_de_la_excepcion():
    app, _ = crear_app("prueba-logs")
    salida = io.StringIO()
    manejador = logging.StreamHandler(salida)
    manejador.setFormatter(JsonFormatter())
    logging.getLogger().addHandler(manejador)

    @app.get("/algo")
    async def algo():
        logging.getLogger("prueba-logs").info("hola desde el endpoint")
        logging.getLogger("strawberry.execution").error(RuntimeError("postgres://usuario:CLAVE-SECRETA@host/bd"))
        return {"ok": True}

    try:
        with TestClient(app) as cliente:
            assert cliente.get("/algo", headers={"X-Request-ID": "req-prueba-0001"}).headers["x-request-id"] == "req-prueba-0001"
            cliente.get("/algo")      # sin identificador propio: el servicio crea uno
    finally:
        logging.getLogger().removeHandler(manejador)
    lineas = [json.loads(l) for l in salida.getvalue().splitlines() if l.strip()]
    propias = [l for l in lineas if l["msg"] == "hola desde el endpoint"]
    ajenas = [l for l in lineas if l["logger"] == "strawberry.execution"]
    assert len(propias) == 2 and len(ajenas) == 2
    assert propias[0]["request_id"] == ajenas[0]["request_id"] == "req-prueba-0001"
    assert propias[1]["request_id"] == ajenas[1]["request_id"] and propias[1]["request_id"] != "req-prueba-0001"
    assert "CLAVE-SECRETA" not in salida.getvalue() and "postgres" not in salida.getvalue()


def test_si_quien_llamo_se_desconecta_se_deja_una_linea_json_y_no_una_traza_ni_un_error_inesperado():
    """Hallazgo de la prueba de caos con Vault real: al reanudar un servicio colgado, el gateway ya había cortado por su tiempo máximo y
    leer el cuerpo lanzaba ClientDisconnect; salía como «error inesperado» y uvicorn imprimía una traza (línea que no es JSON) en el log."""
    import asyncio
    app, _ = crear_app("prueba-desconexion")
    salida = io.StringIO()
    manejador = logging.StreamHandler(salida)
    manejador.setFormatter(JsonFormatter())
    logging.getLogger().addHandler(manejador)

    @app.post("/lento")
    async def lento(request: __import__("fastapi").Request):
        await request.body()
        return {"ok": True}

    enviados = []

    async def receive():
        return {"type": "http.disconnect"}

    async def send(mensaje):
        enviados.append(mensaje)

    alcance = {"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1", "method": "POST", "path": "/lento", "raw_path": b"/lento",
               "query_string": b"", "headers": [(b"x-request-id", b"req-desconexion-01"), (b"content-length", b"10")], "client": ("127.0.0.1", 1),
               "server": ("127.0.0.1", 8000), "scheme": "http", "root_path": ""}
    try:
        asyncio.run(app(alcance, receive, send))      # si la excepción se escapara, asyncio.run la propagaría y la prueba fallaría
    finally:
        logging.getLogger().removeHandler(manejador)
    lineas = [json.loads(l) for l in salida.getvalue().splitlines() if l.strip()]
    assert [l["msg"] for l in lineas if l["logger"] == "prueba-desconexion"] == ["cliente desconectado"]
    assert not [l for l in lineas if l["msg"] == "error inesperado"]
    assert lineas[0]["request_id"] == "req-desconexion-01" and lineas[0]["nivel"] == "WARNING"
