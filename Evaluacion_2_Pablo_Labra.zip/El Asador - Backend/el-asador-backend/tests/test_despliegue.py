"""Configuración de despliegue: las reglas de seguridad del informe (módulo 5) comprobadas leyendo los archivos reales.

No levanta contenedores (este entorno de pruebas no puede bajar imágenes); lo que sí hace es:
  * leer docker-compose.yml, Dockerfile, requirements/*.txt, mongo/init-users.js y .gitignore y exigir sus reglas;
  * si existe el programa `docker`, pedirle a Docker Compose (el analizador oficial) que valide los tres archivos compose.
"""
import importlib.metadata as metadatos
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import pytest
import yaml

from ayuda import RAIZ, cargar

bootstrap = cargar("scripts/bootstrap.py", "bootstrap_script")
COMPOSE_TEXTO = (RAIZ / "docker-compose.yml").read_text(encoding="utf-8")
COMPOSE = yaml.safe_load(COMPOSE_TEXTO)
SERVICIOS = COMPOSE["services"]
ALMACENES = {"vault", "mongo", "vault-seed"}
APLICACION = {n: s for n, s in SERVICIOS.items() if n not in ALMACENES}
PUBLICABLES = {"api-gateway", "provider-sandbox"}


def _entorno(servicio):
    return servicio.get("environment") or {}


def test_solo_el_gateway_y_el_proveedor_simulado_publican_puertos_y_solo_hacia_localhost():
    publican = {n for n, s in SERVICIOS.items() if s.get("ports")}
    assert publican == PUBLICABLES, publican
    for n in publican:
        assert all(re.fullmatch(r"127\.0\.0\.1:\d+:\d+", p) for p in SERVICIOS[n]["ports"]), (n, SERVICIOS[n]["ports"])


def test_mongo_y_vault_y_los_servicios_privados_no_son_alcanzables_desde_fuera_de_docker():
    for n in ALMACENES | (set(APLICACION) - PUBLICABLES):
        assert not SERVICIOS[n].get("ports"), n
        assert set(SERVICIOS[n]["networks"]) == {"interna"}, (n, SERVICIOS[n]["networks"])
    assert COMPOSE["networks"]["interna"]["internal"] is True, "la red interna no debe tener salida a internet"
    assert {n for n, s in SERVICIOS.items() if "publica" in s["networks"]} == PUBLICABLES


def test_el_token_raiz_y_la_clave_de_mongo_solo_los_ven_quienes_los_necesitan():
    for n, s in SERVICIOS.items():
        texto = yaml.safe_dump(_entorno(s))
        if n not in {"vault", "vault-seed"}:
            assert "VAULT_ROOT_TOKEN" not in texto, f"{n} no debe conocer el token raíz de Vault"
        if n != "mongo":
            assert "MONGO_ROOT" not in texto, f"{n} no debe conocer el administrador de MongoDB"
        if n not in {"mongo", "vault-seed"}:
            assert "MONGO_PASS_" not in texto, f"{n} no recibe contraseñas de base de datos: las lee de Vault con su propio token"


def test_cada_servicio_recibe_solo_su_propio_token_de_vault_y_todos_distintos():
    usados = {}
    for n, s in APLICACION.items():
        valor = _entorno(s)["VAULT_TOKEN"]
        variable = re.match(r"\$\{(VAULT_TOKEN_[A-Z_]+):\?", valor).group(1)
        assert variable == "VAULT_TOKEN_" + n.upper().replace("-", "_"), (n, valor)
        usados[variable] = n
    assert len(usados) == len(APLICACION)
    semilla = _entorno(SERVICIOS["vault-seed"])
    assert {k for k in semilla if k.startswith("VAULT_TOKEN_")} == set(usados), "la siembra debe crear exactamente un token por servicio"


def test_las_variables_obligatorias_del_compose_las_genera_bootstrap():
    obligatorias = set(re.findall(r"\$\{([A-Z_]+):\?", COMPOSE_TEXTO))
    assert obligatorias and obligatorias <= set(bootstrap.variables_necesarias()), obligatorias - set(bootstrap.variables_necesarias())


def test_el_log_del_vault_de_desarrollo_se_descarta_porque_imprime_su_token_raiz():
    """Comprobado contra el Vault real (tests/test_infraestructura_real.py): su banner de arranque trae «Root Token» y «Unseal Key»."""
    assert "-dev" in SERVICIOS["vault"]["command"]
    assert SERVICIOS["vault"]["logging"]["driver"] == "${VAULT_LOG_DRIVER:-none}"


def test_cada_servicio_de_aplicacion_va_endurecido():
    for n, s in APLICACION.items():
        assert s["read_only"] is True and s["cap_drop"] == ["ALL"] and "no-new-privileges:true" in s["security_opt"], n
        assert s.get("pids_limit") and s.get("mem_limit"), n
        assert s["restart"] == "unless-stopped" and s["logging"]["options"]["max-size"], n


def test_los_servicios_con_base_esperan_a_la_siembra_y_a_mongo_y_ninguno_corre_antes_de_tener_su_token():
    for n in ("auth", "clients", "inventory", "orders", "payments", "notifications", "analytics"):
        dep = SERVICIOS[n]["depends_on"]
        assert dep["mongo"]["condition"] == "service_healthy" and dep["vault-seed"]["condition"] == "service_completed_successfully", n
    for n, s in APLICACION.items():
        assert s["depends_on"]["vault-seed"]["condition"] == "service_completed_successfully", n


def test_las_imagenes_de_terceros_llevan_version_y_no_latest():
    for n, s in SERVICIOS.items():
        if "image" in s and "build" not in s:
            nombre, _, etiqueta = s["image"].partition(":")
            assert etiqueta and etiqueta != "latest", (n, s["image"])


def test_mongo_arranca_con_autenticacion_y_crea_un_usuario_por_servicio_solo_sobre_su_base():
    assert "--auth" in SERVICIOS["mongo"]["command"]
    js = (RAIZ / "mongo" / "init-users.js").read_text(encoding="utf-8")
    servicios = re.search(r"const servicios = \[(.*?)\];", js, re.S).group(1)
    assert set(re.findall(r'"([a-z]+)"', servicios)) == {"auth", "clients", "inventory", "orders", "payments", "notifications", "analytics"}
    assert 'roles: [{ role: "readWrite", db: nombre }]' in js and 'user: "u_" + servicio' in js
    assert "root" not in js.replace("process.env", "")        # ningún servicio recibe un rol de administrador
    assert 'MONGO_PASS_' in js and "pwd: clave" in js


def test_el_dockerfile_no_corre_como_root_ni_deja_servidor_ni_proxy_headers():
    docker = (RAIZ / "Dockerfile").read_text(encoding="utf-8")
    etapas = re.split(r"^FROM ", docker, flags=re.M)[1:]
    assert len(etapas) == 1
    for etapa in etapas:
        usuarios = re.findall(r"^USER (\S+)", etapa, flags=re.M)
        assert usuarios and usuarios[-1] == "10001", "cada etapa debe terminar con un usuario sin privilegios"
    assert "--no-proxy-headers" in docker and "--no-server-header" in docker and "HEALTHCHECK" in docker
    assert re.search(r"FROM python:\$\{PYTHON_VERSION\}-slim", docker) and "ARG PYTHON_VERSION=3.13" in docker


@pytest.mark.parametrize("archivo", sorted((RAIZ / "requirements").glob("*.txt")), ids=lambda p: p.name)
def test_los_requirements_fijan_versiones_exactas(archivo):
    for linea in archivo.read_text(encoding="utf-8").splitlines():
        if not linea.strip() or linea.startswith("#") or linea.startswith("-r "):
            continue
        assert re.fullmatch(r"[A-Za-z0-9_.-]+==[0-9][A-Za-z0-9_.+!-]*", linea), f"{archivo.name}: «{linea}» no fija una versión exacta"


def test_el_entorno_donde_corren_las_pruebas_tiene_exactamente_las_versiones_fijadas():
    """Los requirements no son una lista de deseos: son lo que se ejecutó. Si esta prueba falla, el entorno difiere de lo documentado."""
    distintos = []
    for archivo in ("base.txt", "auth.txt", "graphql.txt", "tests.txt"):
        for linea in (RAIZ / "requirements" / archivo).read_text(encoding="utf-8").splitlines():
            if "==" not in linea or linea.startswith("#"):
                continue
            nombre, version = linea.strip().split("==")
            try:
                instalada = metadatos.version(nombre)
            except metadatos.PackageNotFoundError:
                distintos.append((nombre, version, None))
                continue
            if instalada != version:
                distintos.append((nombre, version, instalada))
    assert not distintos, distintos


def test_los_secretos_locales_no_se_versionan_y_el_ejemplo_no_trae_ninguno():
    ignorados = (RAIZ / ".gitignore").read_text(encoding="utf-8").splitlines()
    assert ".env" in ignorados and "*.pem" in ignorados
    ejemplo = (RAIZ / ".env.example").read_text(encoding="utf-8")
    assert not re.search(r"[0-9a-f]{32,}", ejemplo), ".env.example no debe contener valores que parezcan secretos"
    for nombre in ("VAULT_ROOT_TOKEN=", "MONGO_ROOT_PASSWORD=", "MONGO_PASS_", "VAULT_TOKEN_"):
        assert not re.search(rf"^{nombre}", ejemplo, re.M), nombre
    assert not (RAIZ / ".env").exists() or ".env" in ignorados


@pytest.mark.skipif(shutil.which("docker") is None, reason="no hay Docker instalado: solo se valida la lectura de los archivos")
@pytest.mark.parametrize("archivos", [("docker-compose.yml",), ("docker-compose.yml", "docker-compose.carga.yml"), ("docker-compose.yml", "docker-compose.tls.yml")],
                         ids=["base", "carga", "tls"])
def test_docker_compose_acepta_los_archivos(archivos):
    """`docker compose config` es el analizador oficial: valida sintaxis, anclas, interpolación y combinación de archivos (no necesita el daemon)."""
    with tempfile.TemporaryDirectory() as tmp:
        env = Path(tmp) / "variables.env"
        env.write_text("".join(f"{n}=valor-de-prueba\n" for n in bootstrap.variables_necesarias()), encoding="utf-8")
        orden = ["docker", "compose", "--env-file", str(env), "--project-directory", str(RAIZ)]
        for a in archivos:
            orden += ["-f", str(RAIZ / a)]
        r = subprocess.run(orden + ["config", "--quiet"], capture_output=True, text=True, timeout=60)
    if r.returncode != 0 and "Cannot connect to the Docker daemon" in r.stderr:
        pytest.skip("Docker Compose necesita el daemon en esta versión")
    assert r.returncode == 0, r.stderr[-1500:]


def test_cada_servicio_solo_importa_paquetes_que_su_requirements_declara():
    """Como la imagen de cada servicio solo instala SU archivo de requirements, un import que falte ahí rompería el contenedor al arrancar.
    En este entorno no se pudo construir con Docker, así que se revisa de forma estática: los imports de cada servicio (y de common/) contra su archivo."""
    import ast
    import sys
    from importlib.metadata import packages_distributions

    distribuciones = packages_distributions()
    por_servicio = {"auth-service": "auth", "clients-service": "base", "inventory-service": "base", "orders-service": "base", "payments-service": "base",
                    "notifications-service": "base", "analytics-service": "base", "provider-sandbox": "base", "api-gateway": "base", "graphql-gateway": "graphql"}
    declarados = {}
    for archivo in (RAIZ / "requirements").glob("*.txt"):
        declarados[archivo.stem] = {re.split(r"[=<>\[]", l.strip())[0].lower().replace("_", "-") for l in archivo.read_text().splitlines()
                                    if l.strip() and not l.startswith(("#", "-"))}
    for servicio, requisitos in por_servicio.items():
        imports = set()
        for fuente in list((RAIZ / servicio).rglob("*.py")) + list((RAIZ / "common").rglob("*.py")):
            for nodo in ast.walk(ast.parse(fuente.read_text(encoding="utf-8"))):
                if isinstance(nodo, ast.Import):
                    imports |= {a.name.split(".")[0] for a in nodo.names}
                elif isinstance(nodo, ast.ImportFrom) and nodo.level == 0 and nodo.module:
                    imports.add(nodo.module.split(".")[0])
        for modulo in sorted(imports - set(sys.stdlib_module_names) - {"common", "app"}):
            paquetes = {d.lower().replace("_", "-") for d in distribuciones.get(modulo, [modulo])}
            assert paquetes & declarados[requisitos], f"{servicio} importa «{modulo}» y requirements/{requisitos}.txt no declara {sorted(paquetes)}"
