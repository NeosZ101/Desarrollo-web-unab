"""El informe y las matrices deben describir la implementación ENTREGADA (pauta de la Evaluación 2).

No levanta servicios: compara los documentos generados con el código y revisa que los ejemplos capturados sean de verdad de cada ruta
y no lleven secretos. Si alguien cambia una ruta, un rol o el esquema GraphQL y no regenera los documentos, estas pruebas fallan.
"""
import importlib.util
import json
import re
import sys

import pytest

from ayuda import RAIZ

sys.path.insert(0, str(RAIZ / "scripts"))


@pytest.fixture(scope="module")
def gen():
    spec = importlib.util.spec_from_file_location("generar_documentos_t", RAIZ / "scripts" / "generar_documentos.py")
    modulo = importlib.util.module_from_spec(spec)
    sys.modules["generar_documentos_t"] = modulo
    spec.loader.exec_module(modulo)
    return modulo


@pytest.fixture(scope="module")
def rutas(gen):
    return gen._rutas().RUTAS


def test_las_matrices_y_el_esquema_graphql_publicados_coinciden_con_el_codigo(gen):
    nuevos = gen.generar()
    desactualizados = [str(r.relative_to(RAIZ)) for r, t in nuevos.items() if not r.exists() or r.read_text(encoding="utf-8") != t]
    assert desactualizados == [], "regenera con: python scripts/generar_documentos.py"


def test_toda_ruta_con_rol_cliente_o_firma_tiene_escrita_su_condicion_de_pertenencia(gen, rutas):
    sin_condicion = [r.id for r in rutas if ("cliente" in r.roles or r.acceso == "firma") and r.id not in gen.CONDICIONES]
    assert sin_condicion == []
    assert set(gen.CONDICIONES) <= {r.id for r in rutas}, "una condición apunta a una ruta que ya no existe"


def test_todas_las_rutas_tienen_ejemplo_capturado_y_es_de_esa_ruta(gen, rutas):
    contratos = {(s, m, gen._norm(p)): c for (s, m, p), c in gen.contratos.todos().items()}
    for r in rutas:
        archivo = gen.EJEMPLOS / f"{r.id}.json"
        assert archivo.exists(), f"falta el ejemplo de {r.id}: python scripts/capturar_ejemplos.py"
        ej = json.loads(archivo.read_text(encoding="utf-8"))
        assert ej["id"] == r.id and ej["peticion"]["metodo"] == r.metodo, r.id
        patron = re.sub(r"\{[^}]+\}", "[^/]+", re.escape(r.patron).replace(r"\{", "{").replace(r"\}", "}"))
        assert re.fullmatch(patron + r"(\?.*)?", ej["peticion"]["ruta"]), (r.id, ej["peticion"]["ruta"])
        c = contratos.get((r.destino, r.metodo, gen._norm(r.ruta_interna)))
        assert ej["respuesta"]["estado"] == (c.estado_ok if c else 200), (r.id, ej["respuesta"]["estado"])


def test_los_ejemplos_no_traen_secretos(gen, rutas):
    for r in rutas:
        texto = (gen.EJEMPLOS / f"{r.id}.json").read_text(encoding="utf-8")
        assert not re.search(r"session_token=(?!«)", texto), r.id
        assert not re.search(r'"(password|clave|passwordHash)": "(?!«secreto»)', texto), r.id
        assert "X-Service-Secret" not in texto and "mongodb://" not in texto and "hvs." not in texto, r.id


def test_el_catalogo_enumera_todos_los_servicios_y_pantallas(gen, rutas):
    texto = (gen.MATRICES / "servicios_y_contratos.md").read_text(encoding="utf-8")
    assert [r.id for r in rutas] == [f"S{n:02d}" for n in range(1, len(rutas) + 1)], "los identificadores S## deben ser consecutivos"
    assert all(f"| {r.id} |" in texto for r in rutas)
    assert all(f"| {p} |" in texto for p in gen._rutas().PAGINAS)


def test_toda_prueba_citada_en_la_evidencia_de_controles_existe_y_todas_las_verificaciones_cumplieron():
    """docs/evidencia/controles.json lo escribe scripts/verificar_controles.py tras ejecutar los casos del módulo 7 contra el sistema."""
    datos = json.loads((RAIZ / "docs" / "evidencia" / "controles.json").read_text(encoding="utf-8"))
    assert datos["cumplidas"] == datos["total"] > 60 and all(f["ok"] for f in datos["filas"])
    for fila in datos["filas"]:
        for cita in re.findall(r"(test_[a-z_]+)::(test_\w+)", fila["prueba"]):
            archivo, nombre = cita
            fuente = (RAIZ / "tests" / f"{archivo}.py").read_text(encoding="utf-8")
            assert f"def {nombre}(" in fuente, f"la evidencia cita {archivo}::{nombre}, que no existe"


def test_la_matriz_de_trazabilidad_esta_al_dia_y_ningun_requisito_queda_sin_prueba():
    """Se calcula con las rutas del gateway y con los JUnit guardados en docs/evidencia/; si faltan pruebas para un requisito, generar() se detiene."""
    spec = importlib.util.spec_from_file_location("generar_trazabilidad_t", RAIZ / "scripts" / "generar_trazabilidad.py")
    modulo = importlib.util.module_from_spec(spec)
    sys.modules["generar_trazabilidad_t"] = modulo
    spec.loader.exec_module(modulo)
    assert modulo.SALIDA.read_text(encoding="utf-8") == modulo.generar(), "regenera con: python scripts/generar_trazabilidad.py"


def test_los_enlaces_relativos_de_la_documentacion_apuntan_a_algo_que_existe():
    rotos = []
    for md in sorted((RAIZ / "docs").rglob("*.md")) + [RAIZ / "README.md", RAIZ / "datos-frontend" / "README.md"]:
        if not md.exists() or md.name == "INFORME.plantilla.md":   # la plantilla escribe sus enlaces desde docs/ (donde queda el informe armado): se revisan en INFORME.md
            continue
        for destino in re.findall(r"\]\(([^)\s]+)\)", md.read_text(encoding="utf-8")):
            if destino.startswith(("http://", "https://", "#", "mailto:")):
                continue
            if not (md.parent / destino.split("#")[0]).exists():
                rotos.append(f"{md.relative_to(RAIZ)} -> {destino}")
    assert rotos == []


def test_el_informe_esta_al_dia_con_su_plantilla_y_con_los_documentos_que_incrusta():
    spec = importlib.util.spec_from_file_location("generar_informe_t", RAIZ / "scripts" / "generar_informe.py")
    modulo = importlib.util.module_from_spec(spec)
    sys.modules["generar_informe_t"] = modulo
    spec.loader.exec_module(modulo)
    assert modulo.SALIDA.read_text(encoding="utf-8") == modulo.generar(), "regenera con: python scripts/generar_informe.py"


def test_toda_prueba_nombrada_en_el_informe_existe():
    """El informe cita pruebas por su nombre como evidencia; si una cita no existe, la afirmación que respalda queda sin evidencia."""
    texto = (RAIZ / "docs" / "INFORME.md").read_text(encoding="utf-8")
    fuentes = "\n".join(f.read_text(encoding="utf-8") for f in (RAIZ / "tests").glob("test_*.py"))
    faltan = sorted(n for n in set(re.findall(r"\b(test_[a-z0-9_]+)\b", texto))
                    if not (RAIZ / "tests" / f"{n}.py").exists() and f"def {n}(" not in fuentes)
    assert faltan == [], f"el informe cita pruebas que no existen: {faltan}"


def test_la_matriz_de_sistemas_del_informe_lista_todos_los_servicios_del_compose():
    import yaml
    servicios = set(yaml.safe_load((RAIZ / "docker-compose.yml").read_text(encoding="utf-8"))["services"])
    texto = (RAIZ / "docs" / "INFORME.md").read_text(encoding="utf-8")
    seccion = texto.split("### 3.1 Matriz de sistemas", 1)[1].split("### 3.2", 1)[0]
    ausentes = sorted(s for s in servicios if f"| `{s}` |" not in seccion)
    assert ausentes == [], f"la matriz de sistemas del informe no lista: {ausentes}"
