"""Pruebas en el mismo proceso (sin levantar servicios) de dos piezas de seguridad que de fuera no se pueden provocar con precisión:

  1. La guardia de los servicios privados (common/seguridad.py): solo un llamador «de confianza» puede afirmar la identidad de un usuario.
     Hoy ninguna ruta admite a la vez un servicio sin confianza y una identidad, así que se prueba con una mini-aplicación armada con la
     MISMA guardia; si mañana alguien agrega una ruta así, la regla ya está protegida.
  2. El enmascarado de errores del GraphQL Gateway: una excepción inesperada de un resolver jamás llega al navegador con su texto
     (podría traer una URL de base de datos, una ruta de archivo o un secreto); los errores de negocio y de permisos sí se muestran.
"""
import asyncio
import importlib

import httpx
import pytest
from fastapi import Depends
from fastapi.testclient import TestClient

from ayuda import cargar_paquete
from common.app import crear_app
from common.cliente_interno import ServicioNoDisponible
from common.seguridad import Guardia, Identidad, Llamada
from common.vault_secrets import SecretUnavailable


# ----------------------------- 1. guardia ---------------------------------------------------------------
class BovedaFalsa:
    """Hace de Vault: entrega el secreto de cada par (llamador->prueba) que se haya registrado y niega el resto."""

    def __init__(self, secretos):
        self.secretos = secretos

    async def avalor(self, ruta, campo="value"):
        try:
            return self.secretos[ruta]
        except KeyError:
            raise SecretUnavailable(f"sin secreto {ruta}", revocado=True)

    async def aesperar(self, ruta):
        await self.avalor(ruta)


SECRETOS = {f"asador/svc/{c}-to-prueba": f"secreto-de-{c}" for c in ("api-gateway", "payments", "clients", "orders")}


@pytest.fixture(scope="module")
def mini():
    app, _ = crear_app("prueba")
    guardia = Guardia("prueba", BovedaFalsa(SECRETOS))

    @app.get("/opcional")
    async def opcional(ll: Llamada = Depends(guardia.dep(("api-gateway", "payments", "orders"), identidad="opcional"))):
        return {"servicio": ll.servicio, "usuario": ll.identidad.user_id if ll.identidad else None, "roles": list(ll.identidad.roles) if ll.identidad else []}

    @app.get("/requerida")
    async def requerida(ll: Llamada = Depends(guardia.dep(("api-gateway", "payments"), identidad="requerida"))):
        return {"usuario": ll.identidad.user_id}

    @app.get("/solo-admin")
    async def solo_admin(ll: Llamada = Depends(guardia.dep(("api-gateway", "payments"), identidad="requerida", roles=("administrador",)))):
        return {"usuario": ll.identidad.user_id}

    @app.get("/sistema")
    async def sistema_a_sistema(ll: Llamada = Depends(guardia.dep(("payments",)))):
        return {"servicio": ll.servicio, "usuario": ll.identidad.user_id if ll.identidad else None}

    with TestClient(app) as cliente:
        yield cliente


def _h(servicio, rol=None, usuario="u-1"):
    h = {"X-Service-Name": servicio, "X-Service-Secret": SECRETOS[f"asador/svc/{servicio}-to-prueba"], "X-Request-ID": "unidad-" + servicio}
    if rol:
        h.update({"X-Authenticated-User": usuario, "X-Authenticated-Username": "x@x.cl", "X-Authenticated-Roles": rol})
    return h


def test_un_servicio_de_confianza_puede_afirmar_la_identidad_de_un_usuario(mini):
    r = mini.get("/opcional", headers=_h("api-gateway", "administrador", "u-admin"))
    assert r.json() == {"servicio": "api-gateway", "usuario": "u-admin", "roles": ["administrador"]}
    assert mini.get("/solo-admin", headers=_h("api-gateway", "administrador")).status_code == 200


def test_un_servicio_sin_confianza_no_puede_afirmar_identidades_aunque_su_secreto_sea_valido(mini):
    # payments está permitido en la ruta y su secreto es real, pero NO es quien autentica usuarios: la identidad que dice traer se ignora
    r = mini.get("/opcional", headers=_h("payments", "administrador", "u-admin"))
    assert r.status_code == 200 and r.json() == {"servicio": "payments", "usuario": None, "roles": []}
    r = mini.get("/requerida", headers=_h("payments", "administrador"))
    assert r.status_code == 401 and r.json()["codigo"] == "NO_AUTENTICADO"
    r = mini.get("/solo-admin", headers=_h("payments", "administrador"))
    assert r.status_code == 401
    # una llamada de sistema a sistema jamás trae usuario, venga o no con cabeceras de identidad
    assert mini.get("/sistema", headers=_h("payments", "administrador")).json() == {"servicio": "payments", "usuario": None}


def test_el_rol_se_exige_en_la_guardia_y_una_identidad_rota_cuenta_como_ausente(mini):
    for rol in ("cliente", "despacho", "dueno"):
        r = mini.get("/solo-admin", headers=_h("api-gateway", rol))
        assert r.status_code == 403 and r.json()["codigo"] == "ROL_NO_AUTORIZADO", rol
    for rol in ("superusuario", "ADMINISTRADOR", ""):
        assert mini.get("/solo-admin", headers=_h("api-gateway", rol)).status_code == 401, rol
    assert mini.get("/solo-admin", headers=_h("api-gateway", "administrador", "../../etc/passwd")).status_code == 401


def test_la_guardia_exige_nombre_y_secreto_del_par_correcto(mini):
    assert mini.get("/sistema").status_code == 403
    h = _h("payments")
    assert mini.get("/sistema", headers={**h, "X-Service-Secret": "otro"}).json()["codigo"] == "SECRETO_INVALIDO"
    assert mini.get("/sistema", headers={**h, "X-Service-Secret": SECRETOS["asador/svc/api-gateway-to-prueba"]}).json()["codigo"] == "SECRETO_INVALIDO"
    assert mini.get("/sistema", headers=_h("api-gateway")).json()["codigo"] == "LLAMADOR_NO_PERMITIDO"      # secreto válido, pero no es llamador de esta ruta


# ----------------------------- 2. enmascarado de errores de GraphQL -------------------------------------
@pytest.fixture(scope="module")
def gql():
    cargar_paquete("graphql-gateway/app", "gql_app")
    return importlib.import_module("gql_app.schema")


class InternoFalso:
    def __init__(self, respuesta=None, error=None):
        self.respuesta, self.error = respuesta, error

    async def llamar(self, destino, metodo, ruta, **kw):
        if self.error:
            raise self.error
        return self.respuesta


def _ejecutar(gql, consulta, interno, rol="cliente"):
    ident = Identidad("u-1", "x@x.cl", (rol,), "c-0001" if rol == "cliente" else None)

    async def correr():
        return await gql.schema.execute(consulta, context_value=gql.Contexto(Llamada("api-gateway", "unidad-gql-1", ident), interno))

    return asyncio.run(correr())


def test_una_excepcion_inesperada_se_ve_como_error_interno_sin_su_texto(gql):
    secreto = "mongodb://u_orders:CLAVE-SECRETA@10.0.0.7:27017/asador_orders"
    for error in (RuntimeError(secreto), KeyError(secreto), ValueError(secreto)):
        res = _ejecutar(gql, "{ misPedidos(limit: 1) { total } }", InternoFalso(error=error))
        assert [e.message for e in res.errors] == ["Error interno"], res.errors
        assert "CLAVE-SECRETA" not in str(res.errors) and "mongodb" not in str(res.errors)
        assert res.errors[0].extensions in (None, {}) or "codigo" not in res.errors[0].extensions


def test_un_dato_de_origen_con_forma_inesperada_tambien_se_enmascara(gql):
    rota = httpx.Response(200, json=[{"id": "A-1", "forma": "inesperada"}], headers={"x-total-count": "1"})     # a «pedido» le faltan campos
    res = _ejecutar(gql, "{ misPedidos(limit: 1) { total items { id } } }", InternoFalso(rota))
    assert [e.message for e in res.errors] == ["Error interno"], res.errors


def test_los_errores_de_negocio_y_de_permisos_si_se_muestran(gql):
    no_encontrado = httpx.Response(404, json={"codigo": "PEDIDO_NO_ENCONTRADO", "detail": "Pedido no encontrado"})
    res = _ejecutar(gql, "{ misPedidos(limit: 1) { total } }", InternoFalso(no_encontrado))
    assert res.errors[0].message == "Pedido no encontrado" and res.errors[0].extensions["codigo"] == "PEDIDO_NO_ENCONTRADO"
    caido = _ejecutar(gql, "{ misPedidos(limit: 1) { total } }", InternoFalso(error=ServicioNoDisponible("orders", "timeout")))
    assert caido.errors[0].extensions["codigo"] == "SERVICIO_NO_DISPONIBLE" and "Error interno" not in str(caido.errors)
    prohibido = _ejecutar(gql, "{ pedidosAdmin { total } }", InternoFalso(), rol="cliente")
    assert prohibido.errors[0].extensions["codigo"] == "PROHIBIDO"


def test_los_errores_de_la_propia_consulta_no_se_confunden_con_fallas_internas(gql):
    res = _ejecutar(gql, "{ misPedidos( }", InternoFalso())
    assert res.errors and "Error interno" not in str(res.errors)
    res = _ejecutar(gql, "{ noExiste }", InternoFalso())
    assert res.errors and "Error interno" not in str(res.errors)



class Captura:
    """Recoge lo que el GraphQL Gateway escribe en su log mientras se ejecuta una consulta."""

    def __enter__(self):
        import logging
        self.registros = []
        capturar = self.registros

        class Manejador(logging.Handler):
            def emit(self, registro):
                capturar.append(registro)

        self.manejador, self.log = Manejador(), logging.getLogger("graphql-gateway")
        self.nivel = self.log.level
        self.log.setLevel(logging.DEBUG)
        self.log.addHandler(self.manejador)
        return self.registros

    def __exit__(self, *a):
        self.log.removeHandler(self.manejador)
        self.log.setLevel(self.nivel)


def test_un_error_inesperado_deja_en_el_log_el_campo_y_el_tipo_pero_nunca_el_texto(gql):
    secreto = "mongodb://u_orders:CLAVE-SECRETA@10.0.0.7:27017/asador_orders"
    with Captura() as registros:
        _ejecutar(gql, "{ misPedidos(limit: 1) { total } }", InternoFalso(error=RuntimeError(secreto)))
    assert len(registros) == 1 and registros[0].levelname == "ERROR"
    assert registros[0].ctx == {"campo": "misPedidos", "tipo": "RuntimeError"}
    assert "CLAVE-SECRETA" not in str(registros[0].ctx) and "CLAVE-SECRETA" not in registros[0].getMessage()


def test_los_errores_previstos_o_de_la_consulta_no_se_registran_como_inesperados(gql):
    with Captura() as registros:
        _ejecutar(gql, "{ misPedidos(limit: 1) { total } }", InternoFalso(error=ServicioNoDisponible("orders", "timeout")))
        _ejecutar(gql, "{ pedidosAdmin { total } }", InternoFalso(), rol="cliente")
        _ejecutar(gql, "{ misPedidos( }", InternoFalso())
    assert registros == []


def test_un_valor_que_no_cabe_en_su_tipo_tambien_se_enmascara_y_se_registra(gql):
    """El valor se rechaza al serializarlo y su texto nombra el valor y el tipo: no debe llegar al navegador."""
    enorme = httpx.Response(200, json=[], headers={"x-total-count": "3000000000"})
    with Captura() as registros:
        res = _ejecutar(gql, "{ misPedidos(limit: 1) { total } }", InternoFalso(enorme))
    assert [e.message for e in res.errors] == ["Error interno"] and "3000000000" not in str(res.errors)
    assert len(registros) == 1 and registros[0].ctx["campo"] == "misPedidos.total"


def test_un_error_con_ruta_pero_sin_excepcion_asociada_tambien_se_enmascara(gql):
    """Se muestra solo lo permitido (negocio, permisos, la propia consulta); lo demás se oculta aunque no traiga excepción asociada."""
    from graphql import GraphQLError
    sin_excepcion = GraphQLError("detalle interno del valor 3000000000", path=["misPedidos", "total"])
    assert sin_excepcion.original_error is None and gql._enmascarar(sin_excepcion) is True
    con_codigo = GraphQLError("No tiene permisos", path=["pedidosAdmin"], extensions={"codigo": "PROHIBIDO"})
    de_la_consulta = GraphQLError("Syntax Error: Expected Name", path=None)
    assert gql._enmascarar(con_codigo) is False and gql._enmascarar(de_la_consulta) is False
