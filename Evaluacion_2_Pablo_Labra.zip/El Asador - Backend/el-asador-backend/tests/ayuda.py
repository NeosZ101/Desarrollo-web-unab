"""Utilidades compartidas por las pruebas: un «navegador» de pruebas, datos únicos y llamadas como atacante.

Todo se hace por HTTP contra el sistema real. Las pruebas nunca importan el código de los servicios
(salvo las reglas puras, que se cargan por ruta para probarlas sin red).
"""
import hashlib
import hmac
import importlib.util
import json
import random
import re
import sys
import time
import uuid
from pathlib import Path

import httpx

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))

REGION = "Región Metropolitana de Santiago"


def cargar(ruta, nombre):
    """Carga un módulo de reglas puras por su ruta (las carpetas de servicio se llaman todas «app»)."""
    spec = importlib.util.spec_from_file_location(nombre, RAIZ / ruta)
    modulo = importlib.util.module_from_spec(spec)
    sys.modules[nombre] = modulo
    spec.loader.exec_module(modulo)
    return modulo


def cargar_paquete(carpeta, nombre):
    """Carga la carpeta «app» de un servicio como paquete (sus módulos usan importaciones relativas) para probarla en el mismo proceso."""
    ruta = RAIZ / carpeta
    spec = importlib.util.spec_from_file_location(nombre, ruta / "__init__.py", submodule_search_locations=[str(ruta)])
    modulo = importlib.util.module_from_spec(spec)
    sys.modules[nombre] = modulo
    spec.loader.exec_module(modulo)
    return modulo


reglas_clientes = cargar("clients-service/app/reglas.py", "reglas_clientes")

# Lo que vieron los clientes de prueba y lo que escribieron: al final se comprueba que ningún secreto viajó al navegador
# y que ningún dato sensible quedó en los logs.
TRAFICO = []              # (metodo, ruta, status, texto de la respuesta, cabeceras)
CLAVES_USADAS = set()     # contraseñas escritas por las pruebas
TOKENS_DE_SESION = set()  # valores de la cookie de sesión recibidos
DATOS_PERSONALES = set()  # RUN y correos de los clientes creados por las pruebas


def run_valido():
    n = random.randint(30_000_000, 99_999_999)
    return f"{n}-{reglas_clientes.digito_verificador(n)}"


def datos_registro(**cambios):
    run = cambios.pop("run", None) or run_valido()
    comuna = cambios.get("comuna", "Ñuñoa")
    base = {"run": run, "nombre": "Cliente De Prueba", "telefono": "+56 9 1234 5678", "direccion": "Calle Falsa 123", "comuna": comuna,
            "correo": f"prueba{run.split('-')[0]}@correo.cl", "nacimiento": "1990-01-01", "sexo": "Otro", "region": REGION,
            "provincia": "Cordillera" if comuna == "Puente Alto" else "Santiago", "clave": "clave-segura-123"}
    base.update(cambios)
    return base


class Api:
    """Un «navegador»: conserva la cookie de sesión y manda el Origin del propio sitio (como lo haría la web)."""

    def __init__(self, base, origen=None, cabeceras=None, registrar=True, ip=None):
        """`ip`: dirección de origen local (127.x.x.x). El gateway limita por IP de la conexión, así cada prueba de límites tiene la suya."""
        self.base = base.rstrip("/")
        self.registrar = registrar
        transporte = httpx.HTTPTransport(local_address=ip) if ip else None
        self.c = httpx.Client(base_url=self.base, timeout=30, headers={"Origin": origen or self.base, **(cabeceras or {})}, transport=transporte)
        self.usuario = None
        self.client_id = None
        self.datos = None

    def pedir(self, metodo, ruta, **kw):
        cuerpo = kw.get("json")
        if isinstance(cuerpo, dict):   # toda contraseña que una prueba escribe se anota: al final se busca en los logs
            CLAVES_USADAS.update(v for k, v in cuerpo.items() if k in ("password", "clave") and isinstance(v, str))
        r = self.c.request(metodo, ruta, **kw)
        if self.registrar:
            TRAFICO.append((metodo, ruta, r.status_code, r.text, dict(r.headers)))
        return r

    def get(self, ruta, **kw):
        return self.pedir("GET", ruta, **kw)

    def post(self, ruta, **kw):
        return self.pedir("POST", ruta, **kw)

    def put(self, ruta, **kw):
        return self.pedir("PUT", ruta, **kw)

    def delete(self, ruta, **kw):
        return self.pedir("DELETE", ruta, **kw)

    def login(self, correo, clave):
        CLAVES_USADAS.add(clave)
        r = self.post("/api/auth/login", json={"username": correo, "password": clave})
        if r.status_code == 200:
            self.usuario = r.json()["usuario"]
            self.client_id = self.usuario.get("client_id")
            token = self.c.cookies.get("session_token")
            if token:
                TOKENS_DE_SESION.add(token)
        return r

    @property
    def token(self):
        return self.c.cookies.get("session_token")

    def gql(self, consulta, variables=None, **kw):
        return self.post("/api/graphql", json={"query": consulta, "variables": variables or {}}, **kw)

    def cerrar(self):
        self.c.close()


def cliente_nuevo(gw, **cambios):
    """Registra un cliente por la web, inicia sesión y lo devuelve (`.datos` guarda lo que escribió)."""
    d = datos_registro(**cambios)
    api = Api(gw)
    r = api.post("/api/clients/register", json=d)
    assert r.status_code == 201, r.text
    entrada = api.login(d["correo"], d["clave"])
    assert entrada.status_code == 200, entrada.text
    api.datos = d
    DATOS_PERSONALES.update({d["run"], d["run"].replace("-", ""), d["correo"]})
    return api


def esperar(condicion, segundos=20, pausa=0.25, mensaje="la condición no se cumplió a tiempo"):
    """Reintenta hasta que `condicion()` devuelva algo verdadero. Sirve para efectos asíncronos (webhooks, reintentos)."""
    limite = time.time() + segundos
    ultimo = None
    while time.time() < limite:
        try:
            ultimo = condicion()
        except (AssertionError, httpx.HTTPError, KeyError, IndexError):
            ultimo = None
        if ultimo:
            return ultimo
        time.sleep(pausa)
    raise AssertionError(f"{mensaje} (último valor: {ultimo!r})")


def sin_id(d):
    """Cuerpo de error sin el identificador de correlación, para comparar respuestas entre sí."""
    return {k: v for k, v in d.items() if k != "request_id"}


# ----------------------------- pedidos y pagos -----------------------------------------------------------------
def crear_pedido(api, items=None, comuna="Ñuñoa", medio="Servipag", llave=True, **extra):
    cuerpo = {"items": items if items is not None else [{"id": "p07", "cantidad": 1}], "comuna": comuna, "medioPago": medio, **extra}
    cabeceras = {"Idempotency-Key": uuid.uuid4().hex} if llave is True else ({"Idempotency-Key": llave} if llave else {})
    return api.post("/api/orders", json=cuerpo, headers=cabeceras)


def pedido_ok(api, **kw):
    r = crear_pedido(api, **kw)
    assert r.status_code in (200, 201), r.text
    return r.json()


def iniciar_pago(api, pedido_id):
    r = api.post(f"/api/orders/{pedido_id}/payment")
    assert r.status_code in (200, 201), r.text
    return r.json()


def estado_pedido(api, pedido_id):
    r = api.get(f"/api/orders/{pedido_id}")
    assert r.status_code == 200, r.text
    return r.json()["estado"]


def id_proveedor(checkout_url):
    return checkout_url.rstrip("/").split("/")[-1]


def pagar_en_proveedor(checkout_url, aprobar=True):
    """Hace lo que haría el cliente en la página del proveedor. El proveedor responde con un aviso firmado al gateway."""
    r = httpx.post(checkout_url.rstrip("/") + ("/pay" if aprobar else "/reject"), follow_redirects=False, timeout=10)
    assert r.status_code == 303, r.text
    return r


def pedido_pagado_con_proveedor(api, **kw):
    """Crea un pedido con Servipag y lo paga en el proveedor. Devuelve (pedido, pago) cuando el pedido ya está en preparación."""
    p = pedido_ok(api, **kw)
    pago = iniciar_pago(api, p["id"])
    pagar_en_proveedor(pago["checkoutUrl"])
    esperar(lambda: estado_pedido(api, p["id"]) == "En preparación", mensaje=f"el pedido {p['id']} no pasó a «En preparación»")
    return p, pago


def pedido_pagado_manual(api, admin, medio="Transferencia bancaria", referencia="TRF-100200", **kw):
    p = pedido_ok(api, medio=medio, **kw)
    iniciar_pago(api, p["id"])
    r = admin.post(f"/api/admin/orders/{p['id']}/payment-confirmation", json={"referencia": referencia})
    assert r.status_code == 200, r.text
    esperar(lambda: estado_pedido(api, p["id"]) == "En preparación", mensaje="el pago manual no movió el pedido")
    return p, r.json()["pago"]


# ----------------------------- avisos del proveedor (webhook) --------------------------------------------------
def firmar(secreto, t, cuerpo):
    return hmac.new(secreto.encode(), f"{t}.".encode() + cuerpo, hashlib.sha256).hexdigest()


def aviso(sistema, tipo, pago, *, monto=None, proveedor_id=None, t=None, secreto=None, evento_id=None, moneda="CLP"):
    """Construye un aviso como lo enviaría el proveedor. Devuelve (cuerpo, cabeceras)."""
    t = int(time.time()) if t is None else t
    evento_id = evento_id or "evt_" + uuid.uuid4().hex[:16]
    evento = {"id": evento_id, "type": tipo, "created": t,
              "data": {"payment_id": proveedor_id or id_proveedor(pago["checkoutUrl"]), "reference": pago["id"],
                       "amount": pago["monto"] if monto is None else monto, "currency": moneda}}
    cuerpo = json.dumps(evento, separators=(",", ":")).encode()
    secreto = secreto or sistema.secreto("provider/webhook-secret")
    cabeceras = {"Content-Type": "application/json", "X-Provider-Signature": f"t={t},v1={firmar(secreto, t, cuerpo)}", "X-Provider-Event-Id": evento_id}
    return cuerpo, cabeceras


def enviar_aviso(gw, cuerpo, cabeceras):
    return httpx.post(f"{gw}/api/webhooks/provider", content=cuerpo, headers=cabeceras, timeout=15)


# ----------------------------- llamadas directas a un servicio privado (como un atacante dentro de la red) --------
def llamar_servicio(sistema, destino, metodo, ruta, *, como, secreto=None, identidad=None, sin_credencial=False, **kw):
    """Llama a un servicio privado saltándose el gateway. `como` es el nombre de servicio que se declara."""
    h = {"X-Request-ID": "prueba-" + uuid.uuid4().hex[:10]}
    if not sin_credencial:
        h["X-Service-Name"] = como
        h["X-Service-Secret"] = secreto if secreto is not None else sistema.secreto(f"svc/{como}-to-{destino}")
    if identidad:
        h.update({"X-Authenticated-User": identidad["user"], "X-Authenticated-Username": identidad.get("username", "x@x.cl"),
                  "X-Authenticated-Roles": identidad["roles"]})
        if identidad.get("client"):
            h["X-Authenticated-Client"] = identidad["client"]
    h.update(kw.pop("headers", {}))
    return httpx.request(metodo, sistema.urls[destino] + ruta, headers=h, timeout=15, **kw)


def lineas_de_log(sistema, servicio):
    """Líneas JSON del log de un servicio (el archivo lo escribe el proceso real)."""
    ruta = sistema.logdir / f"{servicio}.log"
    salida = []
    for linea in ruta.read_text(encoding="utf-8", errors="ignore").splitlines():
        try:
            salida.append(json.loads(linea))
        except ValueError:
            continue
    return salida


def consulta_del_frontend(constante):
    """Texto EXACTO de una consulta GraphQL que envían las pantallas de la C2 (datos-frontend/consultas-graphql.json; no se reescribe aquí)."""
    consultas = json.loads((RAIZ / "datos-frontend" / "consultas-graphql.json").read_text(encoding="utf-8"))
    return consultas[constante]


def llamadas_registradas(sistema, servicio, request_id):
    """Líneas de «solicitud» que un servicio registró para un identificador de correlación (prueba de qué servicios tocó una consulta)."""
    return [l for l in lineas_de_log(sistema, servicio) if l.get("request_id") == request_id and l.get("msg") == "solicitud"]


def hoy_santiago():
    from zoneinfo import ZoneInfo
    from datetime import datetime
    return datetime.now(ZoneInfo("America/Santiago")).strftime("%Y-%m-%d")


def sumar_dias(fecha, dias):
    from datetime import datetime, timedelta
    return (datetime.strptime(fecha, "%Y-%m-%d") + timedelta(days=dias)).strftime("%Y-%m-%d")


def ventas_del_dia(api, fecha=None):
    """(ventas, pedidos) que informa el reporte GraphQL para un día."""
    fecha = fecha or hoy_santiago()
    r = api.gql("query($d:String!,$h:String!){ reporteVentas(desde:$d, hasta:$h){ totales{ ventas pedidos } } }", {"d": fecha, "h": fecha})
    assert r.status_code == 200 and "errors" not in r.json(), r.text
    t = r.json()["data"]["reporteVentas"]["totales"]
    return t["ventas"], t["pedidos"]


def buscar(texto, patron):
    return re.search(patron, texto)
