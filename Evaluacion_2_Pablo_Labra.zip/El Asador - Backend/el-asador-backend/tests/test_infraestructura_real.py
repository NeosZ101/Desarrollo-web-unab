"""Pruebas que solo tienen sentido contra los servidores REALES (ASADOR_REAL=1): MongoDB con autenticación y HashiCorp Vault.

  * cada servicio entra a MongoDB con SU usuario: no puede leer ni escribir en la base de otro, ni administrar el servidor;
    sin credenciales o con una clave equivocada no se entra;
  * las contraseñas se guardan con argon2id (hash adaptativo con sal) y ninguna colección de ninguna base guarda un texto plano
    ni el token de sesión tal cual;
  * los logs de la infraestructura no traen secretos de la aplicación. La ÚNICA excepción conocida es el banner del servidor de
    desarrollo de Vault, que imprime su token raíz: por eso docker-compose.yml descarta el log de ese contenedor.

Por defecto no se ejecutan (la base simulada no tiene usuarios ni permisos): corren con  ASADOR_REAL=1 ASADOR_BIN=<carpeta con vault y mongod>.
"""
import json
import re

import pytest
from pymongo import MongoClient
from pymongo.errors import OperationFailure

from ayuda import CLAVES_USADAS, Api, cliente_nuevo
from stack import REAL, SERVICIOS_BD

pytestmark = [pytest.mark.integracion, pytest.mark.skipif(not REAL, reason="necesita MongoDB y Vault reales (ASADOR_REAL=1)")]


def _conexion(stack, servicio, clave=None):
    return MongoClient(f"mongodb://127.0.0.1:{stack.mongo_puerto}", username=f"u_{servicio}", password=clave or stack.clave_bd[servicio],
                       authSource=f"asador_{servicio}", serverSelectionTimeoutMS=3000)


def _administrador(stack):
    usuario, clave = stack.mongo_root
    return MongoClient(f"mongodb://127.0.0.1:{stack.mongo_puerto}", username=usuario, password=clave, authSource="admin", serverSelectionTimeoutMS=3000)


# ----------------------------- MongoDB: un usuario por servicio, solo sobre su base --------------------------------------------------
@pytest.mark.parametrize("servicio", SERVICIOS_BD)
def test_cada_servicio_solo_entra_a_su_propia_base_de_datos(aislado, servicio):
    cliente = _conexion(aislado, servicio)
    propia = cliente[f"asador_{servicio}"]
    propia["_prueba_de_aislamiento"].insert_one({"_id": "x"})
    assert propia["_prueba_de_aislamiento"].find_one({"_id": "x"}) == {"_id": "x"}
    propia["_prueba_de_aislamiento"].drop()
    for otro in SERVICIOS_BD:
        if otro == servicio:
            continue
        with pytest.raises(OperationFailure) as e:
            cliente[f"asador_{otro}"].list_collection_names()
        assert e.value.code == 13, (servicio, otro)                                      # Unauthorized
        with pytest.raises(OperationFailure):
            cliente[f"asador_{otro}"]["pedidos"].insert_one({"_id": "intruso"})
    assert {d["name"] for d in cliente.list_databases()} == {f"asador_{servicio}"}      # ni siquiera ve que existen las demás bases
    with pytest.raises(OperationFailure):                                                # y no administra el servidor
        propia.command("createUser", "u_intruso", pwd="una-clave-de-prueba-1", roles=["readWrite"])
    with pytest.raises(OperationFailure) as e:
        cliente.admin.command("serverStatus")                                            # ni consulta el estado interno del servidor
    assert e.value.code == 13
    cliente.close()


def test_sin_credenciales_o_con_clave_equivocada_mongodb_no_deja_entrar(aislado):
    anonimo = MongoClient(f"mongodb://127.0.0.1:{aislado.mongo_puerto}", serverSelectionTimeoutMS=3000)
    with pytest.raises(OperationFailure) as e:
        anonimo["asador_orders"].list_collection_names()
    assert e.value.code == 13
    with pytest.raises(OperationFailure):
        anonimo.admin.command("listDatabases")
    anonimo.close()
    equivocada = _conexion(aislado, "orders", clave="clave-que-no-es")
    with pytest.raises(OperationFailure) as e:
        equivocada["asador_orders"].list_collection_names()
    assert e.value.code == 18                                                            # AuthenticationFailed
    equivocada.close()


def test_el_usuario_de_un_servicio_no_sirve_con_la_base_de_otro_como_origen_de_autenticacion(aislado):
    """El usuario u_orders vive en asador_orders: intentar autenticarse contra otra base falla."""
    ajeno = MongoClient(f"mongodb://127.0.0.1:{aislado.mongo_puerto}", username="u_orders", password=aislado.clave_bd["orders"],
                        authSource="asador_payments", serverSelectionTimeoutMS=3000)
    with pytest.raises(OperationFailure):
        ajeno["asador_orders"].list_collection_names()
    ajeno.close()


# ----------------------------- contraseñas y sesiones guardadas con hash -----------------------------------------------------------
def _documentos(stack):
    """Todos los documentos de todas las bases de la aplicación, leídos con el administrador de MongoDB (que ningún servicio conoce)."""
    admin = _administrador(stack)
    for servicio in SERVICIOS_BD:
        base = admin[f"asador_{servicio}"]
        for coleccion in base.list_collection_names():
            for doc in base[coleccion].find({}):
                yield servicio, coleccion, doc
    admin.close()


def test_las_contrasenas_se_guardan_con_argon2id_y_ninguna_coleccion_guarda_texto_plano(aislado):
    web = cliente_nuevo(aislado.urls["api-gateway"])
    clave = web.datos["clave"]
    token = web.token
    assert token and clave
    otras = Api(aislado.urls["api-gateway"])
    assert otras.login("admin@elasador.cl", "admin123").status_code == 200               # una cuenta sembrada: su clave también está como hash
    usuarios = [d for s, c, d in _documentos(aislado) if (s, c) == ("auth", "usuarios")]
    assert len(usuarios) >= 5
    for u in usuarios:
        assert re.fullmatch(r"\$argon2id\$v=19\$m=\d+,t=\d+,p=\d+\$[A-Za-z0-9+/]+\$[A-Za-z0-9+/]+", u["passwordHash"]), u["username"]
    assert len({u["passwordHash"] for u in usuarios}) == len(usuarios), "dos cuentas no pueden compartir hash (la sal es única)"
    secretos_de_clientes = {clave, "admin123", "dueno123", "despacho123", "cliente123"} | {c for c in CLAVES_USADAS if len(c) >= 8}
    for servicio, coleccion, doc in _documentos(aislado):
        texto = json.dumps(doc, default=str, ensure_ascii=False)
        for c in secretos_de_clientes:
            assert c not in texto, f"asador_{servicio}.{coleccion} guarda una contraseña en texto plano"
        assert token not in texto, f"asador_{servicio}.{coleccion} guarda el token de sesión tal cual (solo su resumen)"


def test_las_sesiones_se_guardan_por_resumen_del_token_no_por_el_token(aislado):
    web = cliente_nuevo(aislado.urls["api-gateway"])
    sesiones = [d for s, c, d in _documentos(aislado) if (s, c) == ("auth", "sesiones")]
    assert sesiones and all(re.fullmatch(r"[0-9a-f]{64}", str(s["_id"])) for s in sesiones), "el identificador de sesión debe ser un SHA-256 del token"
    assert web.token not in {str(s["_id"]) for s in sesiones}
    assert all(s["expira"] > 0 for s in sesiones)                                        # toda sesión caduca


# ----------------------------- logs de la infraestructura ----------------------------------------------------------------------------
def test_los_logs_de_vault_y_mongodb_no_traen_secretos_de_la_aplicacion(aislado):
    infra = aislado.logdir_infra
    assert (infra / "vault.log").exists() and (infra / "mongo.log").exists()
    aplicacion = set(aislado.secretos_conocidos) | set(aislado.tokens.values()) | set(aislado.clave_bd.values()) | {aislado.mongo_root[1]}
    aplicacion = {v for v in aplicacion if len(v) >= 12}
    assert len(aplicacion) >= 30
    for archivo in ("vault.log", "mongo.log"):
        texto = (infra / archivo).read_text(encoding="utf-8", errors="ignore")
        assert [n for n, v in enumerate(sorted(aplicacion)) if v in texto] == [], f"{archivo} deja ver un secreto de la aplicación"
        assert aislado.root_token not in texto.replace(_banner_del_token_raiz(texto), "")


def _banner_del_token_raiz(texto):
    """La línea «Root Token: ...» del servidor de DESARROLLO de Vault (lo único que se permite; el compose descarta ese log)."""
    return "\n".join(linea for linea in texto.splitlines() if linea.startswith("Root Token:"))


def test_el_servidor_de_desarrollo_de_vault_imprime_su_token_raiz_y_por_eso_el_compose_descarta_su_log(aislado):
    """Hallazgo de la ejecución real, no una suposición: queda como prueba para que el motivo del `logging: none` del compose no se olvide."""
    texto = (aislado.logdir_infra / "vault.log").read_text(encoding="utf-8", errors="ignore")
    assert f"Root Token: {aislado.root_token}" in texto
    assert "Unseal Key:" in texto


# ----------------------------- el reporte de ventas lee solo lo que necesita (evidencia del ADR-004) -----------------------------------
def _claves(obj, nombre):
    """Todos los valores de la clave `nombre` en un plan de ejecución (el plan de una agregación anida sus etapas)."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k == nombre:
                yield v
            yield from _claves(v, nombre)
    elif isinstance(obj, list):
        for x in obj:
            yield from _claves(x, nombre)


def test_el_reporte_de_ventas_usa_el_indice_de_fecha_y_solo_lee_las_ventas_del_periodo(aislado):
    ventas = _conexion(aislado, "analytics")["asador_analytics"]["ventas"]
    docs = [{"_id": f"B-9{i:05d}", "estado": "vigente", "fechaLocal": f"2026-{1 + i % 6:02d}-{1 + i % 28:02d}", "total": 1000, "medio": "x", "lineas": []}
            for i in range(1200)]
    ventas.insert_many(docs)
    try:
        enero = {"$gte": "2026-01-01", "$lte": "2026-01-31"}
        en_el_periodo = sum(1 for d in docs if enero["$gte"] <= d["fechaLocal"] <= enero["$lte"])
        plan = ventas.database.command("explain", {"aggregate": "ventas", "cursor": {}, "pipeline": [
            {"$match": {"estado": "vigente", "fechaLocal": enero}}, {"$group": {"_id": "$fechaLocal", "ventas": {"$sum": "$total"}}}]},
            verbosity="executionStats")
        etapas = set(_claves(plan, "stage"))
        assert "IXSCAN" in etapas and "COLLSCAN" not in etapas, etapas                   # el índice (estado, fechaLocal) existe y se usa
        assert max(_claves(plan, "totalDocsExamined")) == en_el_periodo < len(docs)      # y no se revisa nada fuera del período pedido
    finally:
        ventas.delete_many({"_id": {"$in": [d["_id"] for d in docs]}})
