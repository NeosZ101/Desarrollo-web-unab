"""Límites de solicitudes y bloqueo de cuentas (sistema «estricto»: pocos intentos por minuto y cookie «Secure»).

El gateway cuenta por la IP de la CONEXIÓN. Como todas las pruebas salen de esta máquina, cada una usa su propia dirección
local (127.x.x.x): así los contadores no se mezclan y el orden de las pruebas da lo mismo.
Límites del sistema estricto: login 8/min por IP, registro 3, formularios 3, GraphQL 5 por USUARIO, general 150/min por IP;
la cuenta se bloquea tras 3 claves incorrectas.
"""
import re
import uuid

import pytest

from ayuda import Api, DATOS_PERSONALES, datos_registro, llamadas_registradas, sin_id

pytestmark = pytest.mark.estricto

_siguiente = iter(range(1, 250))


def ip_nueva():
    """Una dirección de origen que ninguna otra prueba ha usado."""
    return f"127.0.7.{next(_siguiente)}"


@pytest.fixture(scope="module")
def gw(sistema_estricto):
    return sistema_estricto.urls["api-gateway"]


def _credenciales(usuario):
    return {"username": usuario, "password": "clave-equivocada-1"}


def _con_cookie(api, respuesta):
    """La cookie de sesión es «Secure»: un navegador solo la manda por HTTPS. Aquí se reenvía a mano para poder seguir probando por HTTP."""
    token = re.search(r"session_token=([^;]+)", respuesta.headers["set-cookie"]).group(1)
    api.c.headers["Cookie"] = f"session_token={token}"
    return token


def _cliente_con_sesion(gw, ip):
    api = Api(gw, ip=ip)
    d = datos_registro()
    DATOS_PERSONALES.update({d["run"], d["run"].replace("-", ""), d["correo"]})
    r = api.post("/api/clients/register", json=d)
    assert r.status_code == 201, r.text
    entrada = api.login(d["correo"], d["clave"])
    assert entrada.status_code == 200, entrada.text
    _con_cookie(api, entrada)
    api.datos = d
    return api


# ----------------------------- cookie de sesión ----------------------------------------------------
def test_la_cookie_de_sesion_va_con_secure_httponly_y_samesite(gw):
    api = Api(gw, ip=ip_nueva())
    r = api.login("admin@elasador.cl", "admin123")
    assert r.status_code == 200
    cookie = r.headers["set-cookie"].lower()
    assert "httponly" in cookie and "secure" in cookie and "samesite=lax" in cookie and "path=/" in cookie
    assert "session_token" not in r.text, "el token no debe viajar en el cuerpo de la respuesta"
    assert r.headers["strict-transport-security"].startswith("max-age=")


# ----------------------------- login ---------------------------------------------------------------
def test_el_login_se_limita_por_ip_y_otra_ip_no_se_ve_afectada(gw):
    api = Api(gw, ip=ip_nueva())
    estados = [api.post("/api/auth/login", json=_credenciales("noexiste@correo.cl")).status_code for _ in range(8)]
    assert estados == [401] * 8
    r = api.post("/api/auth/login", json=_credenciales("noexiste@correo.cl"))
    assert r.status_code == 429 and r.json()["codigo"] == "DEMASIADAS_SOLICITUDES" and r.headers["retry-after"] == "60"
    # ni siquiera la clave correcta pasa desde esa IP mientras dure el límite
    assert api.post("/api/auth/login", json={"username": "admin@elasador.cl", "password": "admin123"}).status_code == 429
    # pero otra persona (otra IP) entra sin problema: el límite no tumba el sitio para todos
    otra = Api(gw, ip=ip_nueva())
    assert otra.login("admin@elasador.cl", "admin123").status_code == 200


def test_el_429_se_decide_en_el_gateway_sin_llegar_al_servicio_de_autenticacion(sistema_estricto, gw):
    api = Api(gw, ip=ip_nueva())
    for _ in range(8):
        api.post("/api/auth/login", json=_credenciales("noexiste@correo.cl"))
    r = api.post("/api/auth/login", json=_credenciales("noexiste@correo.cl"))
    assert r.status_code == 429
    rid = r.json()["request_id"]
    assert llamadas_registradas(sistema_estricto, "auth", rid) == [], "una solicitud limitada no debe consumir al servicio de autenticación"
    assert [l for l in llamadas_registradas(sistema_estricto, "api-gateway", rid) if l["status"] == 429]


def test_x_forwarded_for_no_sirve_para_saltarse_el_limite(gw):
    api = Api(gw, ip=ip_nueva())
    for i in range(8):
        api.post("/api/auth/login", json=_credenciales("noexiste@correo.cl"), headers={"X-Forwarded-For": f"10.0.0.{i}", "X-Real-IP": f"10.1.0.{i}"})
    r = api.post("/api/auth/login", json=_credenciales("noexiste@correo.cl"), headers={"X-Forwarded-For": "203.0.113.77"})
    assert r.status_code == 429, "el gateway no debe creerle a una cabecera que escribe el propio cliente"


# ----------------------------- bloqueo de cuentas ---------------------------------------------------
def test_la_cuenta_se_bloquea_tras_claves_incorrectas_sin_revelar_que_esta_bloqueada(gw):
    victima = _cliente_con_sesion(gw, ip_nueva())
    correo, clave = victima.datos["correo"], victima.datos["clave"]
    atacante = Api(gw, ip=ip_nueva())
    erradas = [atacante.post("/api/auth/login", json={"username": correo, "password": f"intento-{i}-equivocado"}) for i in range(3)]
    assert [r.status_code for r in erradas] == [401, 401, 401]
    bloqueada = atacante.post("/api/auth/login", json={"username": correo, "password": clave})     # la clave CORRECTA, pero la cuenta ya está bloqueada
    inexistente = atacante.post("/api/auth/login", json=_credenciales(f"nadie{uuid.uuid4().hex[:6]}@correo.cl"))
    assert bloqueada.status_code == 401
    # misma respuesta que una clave mala o un usuario inexistente: quien ataca no aprende si la cuenta existe o está bloqueada
    assert sin_id(bloqueada.json()) == sin_id(erradas[0].json()) == sin_id(inexistente.json())
    assert "set-cookie" not in bloqueada.headers
    # el bloqueo es de ESA cuenta: otras cuentas siguen entrando desde la misma IP
    assert Api(gw, ip=ip_nueva()).login("despacho@elasador.cl", "despacho123").status_code == 200
    # y la sesión que la víctima ya tenía abierta sigue funcionando (el bloqueo impide NUEVOS accesos, no tumba lo ya iniciado)
    assert victima.get("/api/clients/me").status_code == 200


def test_el_bloqueo_se_aplica_aunque_el_atacante_cambie_de_ip(gw):
    victima = _cliente_con_sesion(gw, ip_nueva())
    correo, clave = victima.datos["correo"], victima.datos["clave"]
    for _ in range(3):
        assert Api(gw, ip=ip_nueva()).post("/api/auth/login", json={"username": correo, "password": "mala-mala-mala"}).status_code == 401
    assert Api(gw, ip=ip_nueva()).post("/api/auth/login", json={"username": correo, "password": clave}).status_code == 401


# ----------------------------- registro y formularios ----------------------------------------------
def test_el_registro_y_los_formularios_tienen_limites_propios(gw):
    ip = ip_nueva()
    api = Api(gw, ip=ip)
    for _ in range(3):
        d = datos_registro()
        DATOS_PERSONALES.update({d["run"], d["run"].replace("-", ""), d["correo"]})
        assert api.post("/api/clients/register", json=d).status_code == 201
    d = datos_registro()
    DATOS_PERSONALES.update({d["run"], d["run"].replace("-", ""), d["correo"]})
    cuarto = api.post("/api/clients/register", json=d)
    assert cuarto.status_code == 429 and cuarto.json()["codigo"] == "DEMASIADAS_SOLICITUDES"
    # agotar el registro no agota otros grupos: el catálogo y el formulario de contacto siguen disponibles desde la misma IP
    assert api.get("/api/products?limit=3").status_code == 200
    contacto = {"nombre": "Persona Contacto", "correo": f"contacto{uuid.uuid4().hex[:8]}@correo.cl", "asunto": "Sugerencia", "mensaje": "Mensaje de prueba de límites de tasa."}
    DATOS_PERSONALES.add(contacto["correo"])
    for _ in range(3):
        assert api.post("/api/contact-messages", json=contacto).status_code == 201
    assert api.post("/api/contact-messages", json=contacto).status_code == 429


# ----------------------------- GraphQL: por usuario ---------------------------------------------------
def test_graphql_se_limita_por_usuario_y_no_por_ip(gw):
    ip = ip_nueva()
    ana = _cliente_con_sesion(gw, ip)
    beto = Api(gw, ip=ip)
    d = datos_registro()
    DATOS_PERSONALES.update({d["run"], d["run"].replace("-", ""), d["correo"]})
    assert beto.post("/api/clients/register", json=d).status_code == 201
    _con_cookie(beto, beto.login(d["correo"], d["clave"]))
    consulta = "{ misPedidos(limit: 1) { total } }"
    assert [ana.gql(consulta).status_code for _ in range(5)] == [200] * 5
    sexta = ana.gql(consulta)
    assert sexta.status_code == 429 and sexta.json()["codigo"] == "DEMASIADAS_SOLICITUDES"
    # otra persona desde la MISMA IP tiene su propio cupo...
    assert beto.gql(consulta).status_code == 200
    # ...y la misma persona desde OTRA IP sigue limitada (el límite es de la cuenta, no de la dirección)
    desde_otra = Api(gw, ip=ip_nueva())
    desde_otra.c.headers["Cookie"] = ana.c.headers["Cookie"]
    assert desde_otra.gql(consulta).status_code == 429
    # los límites de GraphQL no impiden usar la versión REST
    assert ana.get("/api/orders").status_code == 200


# ----------------------------- límite general ----------------------------------------------------------
def test_el_limite_general_corta_a_quien_inunda_y_no_a_los_demas(gw):
    api = Api(gw, ip=ip_nueva(), registrar=False)
    primero_429 = None
    for n in range(1, 200):
        r = api.get("/api/delivery-zones")
        if r.status_code == 429:
            primero_429 = n
            break
    assert primero_429 is not None and primero_429 <= 151, f"el límite general no cortó (primer 429 en la solicitud {primero_429})"
    assert r.headers["retry-after"] == "60"
    # quien inunda también queda sin acceso al resto de rutas...
    assert api.get("/api/products").status_code == 429
    # ...pero una persona normal desde otra IP sigue navegando
    assert Api(gw, ip=ip_nueva()).get("/api/products?limit=3").status_code == 200
