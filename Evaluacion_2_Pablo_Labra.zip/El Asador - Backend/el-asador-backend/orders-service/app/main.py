"""Orders (privado): creación y ciclo de vida de los pedidos. Es la AUTORIDAD del estado oficial del pedido.

Qué decide orders:
  * Precios y totales: los calcula aquí con datos de inventory; lo que envíe el navegador se ignora.
  * Cambios de estado: una máquina de estados con actor autorizado por transición (ver reglas.py).
    "Pago pendiente -> En preparación" solo la puede pedir el servicio `payments`, nunca un usuario.
  * Anulación: no borra; deja el motivo, quién y cuándo, y el historial completo.
  * Zonas y costo de despacho, y la cotización de eventos (servicios al cliente).
Lo que NO decide: si un pago es válido (payments) ni la existencia de un correo (clients/notifications).
"""
import asyncio
import json
import os
import re
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Annotated, Literal

from fastapi import Depends, Header, Query, Response
from fastapi import Path as ParametroRuta
from pydantic import BaseModel, ConfigDict, Field, field_validator
from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError

from common import auditoria, plazos
from common.app import crear_app
from common.cliente_interno import ClienteInterno, ServicioNoDisponible, cuerpo
from common.db import abrir_db
from common.errores import ErrorNegocio
from common.migraciones import migrar
from common.seguridad import Guardia
from common.tiempo import TZ, fecha_local, iso
from common.vault_secrets import VaultSecrets

from .reglas import (ACTIVOS, ANTERIOR_DE, ANULABLES, ESTADOS, ETIQUETA_ROL, costo_despacho, cotizar_evento,
                     totales, transicion_permitida, validar_anulacion)

SEMILLA = os.environ.get("SEED_DEMO_DATA", "false").lower() == "true"
MAX_PENDIENTES = int(os.environ.get("MAX_PEDIDOS_PENDIENTES", "5"))
INTENTOS_DE_CONFIRMACION = 3   # veces que se relee el pedido si otra solicitud lo cambia mientras se confirma su pago
BUZON_RESTAURANT = os.environ.get("CONTACT_INBOX", "contacto@elasador.cl")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9.-]{1,190}\.[A-Za-z]{2,24}$")
vault = VaultSecrets()
guardia = Guardia("orders", vault)
GW, GWQL = ("api-gateway",), ("api-gateway", "graphql-gateway")
ID = Annotated[str, ParametroRuta(pattern=r"^A-\d{3,9}$")]
db = None
interno = None

# Lectura: la pueden pedir el API Gateway y el GraphQL Gateway. Escritura: SOLO el API Gateway (el GraphQL Gateway es de solo lectura).
CLIENTE = Depends(guardia.dep(GWQL, identidad="requerida", roles=("cliente",)))
CLIENTE_ESCRIBE = Depends(guardia.dep(GW, identidad="requerida", roles=("cliente",)))
CUALQUIERA = Depends(guardia.dep(GWQL, identidad="requerida", roles=("cliente", "administrador", "despacho")))
DESPACHO = Depends(guardia.dep(GWQL, identidad="requerida", roles=("administrador", "despacho")))
DESPACHO_ESCRIBE = Depends(guardia.dep(GW, identidad="requerida", roles=("administrador", "despacho")))


async def _indices(d):
    await d.pedidos.create_index([("clienteId", 1), ("fecha", -1)])
    await d.pedidos.create_index([("estado", 1), ("fecha", 1)])
    await d.pedidos.create_index([("clienteId", 1), ("claveIdempotencia", 1)], unique=True,
                                 partialFilterExpression={"claveIdempotencia": {"$type": "string"}})
    await d.contadores.update_one({"_id": "pedidos"}, {"$setOnInsert": {"seq": 1000}}, upsert=True)
    await d.contadores.update_one({"_id": "cotizaciones"}, {"$setOnInsert": {"seq": 1000}}, upsert=True)


MIGRACIONES = [(1, "índices y contadores", _indices)]


def _fecha_semilla(h):
    """Los pedidos de ejemplo se fechan hacia atrás desde 'ahora': nunca quedan en el futuro."""
    return iso(datetime.now(TZ) - timedelta(days=h["dias"], hours=h["horas"], minutes=h["min"]))


async def sembrar(d):
    base = Path(__file__).parent / "seed"
    n = 0
    cfg = json.loads((base / "config.json").read_text(encoding="utf-8"))
    for c in cfg["config"]:
        if not await d.config.find_one({"_id": c["_id"]}):
            await d.config.insert_one(c)
            n += 1
    for z in cfg["zonas"]:
        if not await d.zonas.find_one({"_id": z["nombre"]}):
            await d.zonas.insert_one({"_id": z["nombre"], "km": z["km"]})
            n += 1
    mayor = 1000
    for p in json.loads((base / "pedidos.json").read_text(encoding="utf-8")):
        mayor = max(mayor, int(p["id"].split("-")[1]))
        if await d.pedidos.find_one({"_id": p["id"]}):
            continue
        fecha = _fecha_semilla(p["hace"])
        historial = [{"estado": e, "fecha": fecha, "por": "Sistema (datos de prueba)"} for e in p["recorrido"]]
        doc = {k: v for k, v in p.items() if k not in ("id", "hace", "recorrido")}
        await d.pedidos.insert_one({**doc, "_id": p["id"], "fecha": fecha, "origen": "ejemplo", "historial": historial,
                                    "reembolso": "no_aplica", "creadoEn": fecha})
        n += 1
    await d.contadores.update_one({"_id": "pedidos"}, {"$max": {"seq": mayor}}, upsert=True)
    return n


@asynccontextmanager
async def lifespan(app):
    global db, interno
    await vault.aesperar("asador/db/orders")
    await guardia.precalentar()
    cliente, db = await abrir_db("orders", vault)
    urls = {k: os.environ[v] for k, v in (("inventory", "INVENTORY_URL"), ("clients", "CLIENTS_URL"), ("payments", "PAYMENTS_URL"),
                                          ("notifications", "NOTIFICATIONS_URL"))}
    interno = ClienteInterno("orders", vault, urls, timeout=plazos.upstream("servicio"),
                             pausa_circuito=float(os.environ.get("CIRCUITO_PAUSA", "5")))
    await interno.precalentar()
    await migrar(db, MIGRACIONES)
    if SEMILLA:
        log.info("datos de prueba cargados", extra={"ctx": {"documentos_nuevos": await sembrar(db)}})
    app.state.chequeos.append(lambda: db.command("ping"))
    tarea = asyncio.create_task(_reintentos())
    log.info("Orders listo")
    yield
    tarea.cancel()
    await interno.cerrar()
    cliente.close()


app, log = crear_app("orders", lifespan)


# ----------------------------- modelos ------------------------------------------
class ItemIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str = Field(pattern=r"^[a-z0-9]{2,12}$")
    cantidad: int = Field(ge=1, le=20)


class PedidoIn(BaseModel):
    """Lo ÚNICO que aporta el navegador: qué quiere, cuánto y adónde. Nada de precios, totales ni estados."""
    model_config = ConfigDict(extra="forbid")
    items: list[ItemIn] = Field(min_length=1, max_length=30)
    comuna: str = Field(min_length=3, max_length=40)
    indicaciones: str = Field(default="", max_length=200)
    medioPago: Literal["Servipag", "Transferencia bancaria", "Depósito bancario"] = "Servipag"
    confirmaMayorEdad: bool = False


class AnulacionIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    motivo: Literal["Me equivoqué al armar el pedido", "Ya no lo necesito", "Se demora mucho el despacho", "Encontré otra opción", "Otro motivo"]
    detalle: str = Field(default="", max_length=200)


class EstadoIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    estado: Literal["En camino", "Entregado"]


class CotizacionIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    nombre: str = Field(min_length=3, max_length=80)
    correo: str = Field(min_length=5, max_length=254)
    fecha: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    personas: int = Field(ge=1, le=100000)
    menu: Literal["clasico", "parrillero", "premium"]
    bebidas: bool = False
    ensaladas: bool = False
    parrillero: bool = False
    comuna: str | None = Field(default=None, max_length=40)

    @field_validator("correo")
    @classmethod
    def _c(cls, v):
        v = v.strip().lower()
        if not EMAIL_RE.fullmatch(v):
            raise ValueError("El correo no tiene un formato válido")
        return v

    @field_validator("nombre")
    @classmethod
    def _n(cls, v):
        return " ".join(v.split())


def pedido_dto(d, personal=False):
    out = {"id": d["_id"], "fecha": d["fecha"], "origen": d.get("origen", "web"), "cliente": d["cliente"],
           "lineas": [{"itemId": l.get("itemId"), "nombre": l["nombre"], "cantidad": l["cantidad"], "precio": l["precio"]} for l in d["lineas"]],
           "subtotal": d["subtotal"], "despacho": d["despacho"], "total": d["total"], "pago": d["medioPago"], "estado": d["estado"],
           "reembolso": d.get("reembolso", "no_aplica"),
           "historial": [{"estado": h["estado"], "fecha": h["fecha"], "por": h["por"]} for h in d.get("historial", [])]}
    a = d.get("anulacion")
    if a:
        out.update({"motivoAnulacion": a["motivo"], "anuladoPor": a["por"], "fechaAnulacion": a["fecha"]})
    if personal:
        out["clienteId"] = d["clienteId"]
    return out


def _es_personal(ident):
    return ident.tiene("administrador", "despacho")


def _rol_actor(ident):
    return "administrador" if ident.tiene("administrador") else "despacho" if ident.tiene("despacho") else "cliente"


def _prohibido():
    return ErrorNegocio(403, "PROHIBIDO", "No tiene permisos para esta operación")


async def _pedido_para(id, ident):
    """Un cliente solo ve SUS pedidos. Pedido ajeno y pedido inexistente dan la MISMA respuesta (403): no se revela cuáles existen."""
    d = await db.pedidos.find_one({"_id": id})
    if _es_personal(ident):
        if not d:
            raise ErrorNegocio(404, "PEDIDO_NO_ENCONTRADO", "Pedido no encontrado")
        return d
    if not d or not ident.client_id or d["clienteId"] != ident.client_id:
        raise _prohibido()
    return d


async def _llamar(destino, metodo, ruta, ll, **kw):
    try:
        return await interno.llamar(destino, metodo, ruta, request_id=ll.request_id, **kw)
    except ServicioNoDisponible as e:
        log.warning("dependencia no disponible", extra={"ctx": {"destino": e.destino, "motivo": e.motivo, "request_id": ll.request_id}})
        raise ErrorNegocio(503, "SERVICIO_NO_DISPONIBLE", "El servicio no está disponible en este momento. Intenta nuevamente en unos minutos.",
                           headers={"Retry-After": "10"})


async def _config_despacho():
    return await db.config.find_one({"_id": "despacho"})


# ----------------------------- zonas de despacho y eventos (anónimo) --------------
@app.get("/delivery-zones")
async def zonas(ll=Depends(guardia.dep(GW, identidad="opcional"))):
    cfg = await _config_despacho()
    comunas = [{"nombre": z["_id"], "km": z["km"], "costo": costo_despacho(z["km"], cfg)} async for z in db.zonas.find({}).sort("km", 1)]
    return {"reglas": {"kmDespachoGratis": cfg["kmGratis"], "despachoBase": cfg["base"], "despachoPorKm": cfg["porKm"]}, "comunas": comunas}


async def _precios_extras(cfg, ll):
    r = await _llamar("inventory", "POST", "/internal/pricing/resolve", ll,
                      json={"items": [{"id": cfg["extras"]["bebida"], "cantidad": 1}, {"id": cfg["extras"]["ensalada"], "cantidad": 1}]})
    if r.status_code != 200:
        raise ErrorNegocio(503, "SERVICIO_NO_DISPONIBLE", "El servicio no está disponible en este momento.")
    precios = {l["id"]: l for l in r.json()["lineas"]}
    return precios[cfg["extras"]["bebida"]], precios[cfg["extras"]["ensalada"]]


@app.get("/event-config")
async def config_evento(ll=Depends(guardia.dep(GW, identidad="opcional"))):
    cfg = await db.config.find_one({"_id": "evento"})
    bebida, ensalada = await _precios_extras(cfg, ll)
    return {"minPersonas": cfg["minPersonas"], "maxPersonas": cfg["maxPersonas"], "precioParrillero": cfg["precioParrillero"], "menus": cfg["menus"],
            "extras": {"bebida": {"nombre": bebida["nombre"], "precio": bebida["precio"]}, "ensalada": {"nombre": ensalada["nombre"], "precio": ensalada["precio"]}}}


@app.post("/event-quotes", status_code=201)
async def solicitar_cotizacion(datos: CotizacionIn, ll=Depends(guardia.dep(GW))):
    if datos.fecha < fecha_local():
        raise ErrorNegocio(422, "FECHA_PASADA", "Elige una fecha desde hoy en adelante.")
    cfg = await db.config.find_one({"_id": "evento"})
    despacho = 0
    if datos.comuna:
        z = await db.zonas.find_one({"_id": datos.comuna})
        if not z:
            raise ErrorNegocio(422, "COMUNA_SIN_COBERTURA", "No despachamos a esa comuna")
        despacho = costo_despacho(z["km"], await _config_despacho())
    bebida, ensalada = await _precios_extras(cfg, ll)
    try:
        detalle, estimado = cotizar_evento(cfg, datos.personas, datos.menu, datos.bebidas, datos.ensaladas, datos.parrillero,
                                           bebida["precio"], ensalada["precio"], despacho, datos.comuna)
    except ValueError as e:
        raise ErrorNegocio(422, "COTIZACION_INVALIDA", str(e))
    seq = (await db.contadores.find_one_and_update({"_id": "cotizaciones"}, {"$inc": {"seq": 1}}, upsert=True, return_document=ReturnDocument.AFTER))["seq"]
    folio = f"COT-{seq:05d}"
    await db.cotizaciones_evento.insert_one({"_id": folio, **datos.model_dump(), "detalle": detalle, "estimado": estimado, "creadoEn": iso()})
    for para, asunto, texto, clave in (
            (datos.correo, f"Solicitud {folio} recibida - El Asador",
             f"Hola {datos.nombre.split()[0]}, recibimos tu solicitud {folio}. Estimamos ${estimado:,} para {datos.personas} personas. "
             "Te enviaremos la cotización formal en un máximo de 24 horas.".replace(",", "."), f"cotizacion:{folio}:cliente"),
            (BUZON_RESTAURANT, f"[Evento] {folio} - {datos.personas} personas el {datos.fecha}",
             f"Cliente: {datos.nombre} <{datos.correo}>\nMenú: {datos.menu}\nEstimado: ${estimado}", f"cotizacion:{folio}:local")):
        try:  # mejor esfuerzo: la solicitud ya quedó registrada
            await interno.llamar("notifications", "POST", "/internal/email/send", request_id=ll.request_id,
                                 json={"tipo": "cotizacion", "para": para, "asunto": asunto, "texto": texto, "clave": clave})
        except ServicioNoDisponible:
            log.warning("no se pudo enviar el aviso de cotización", extra={"ctx": {"folio": folio}})
    return {"folio": folio, "estimado": estimado, "detalle": detalle, "correo": datos.correo, "personas": datos.personas}


# ----------------------------- crear pedido (cliente) -----------------------------
@app.post("/orders", status_code=201)
async def crear(datos: PedidoIn, response: Response, idem: str | None = Header(default=None, alias="Idempotency-Key"), ll=CLIENTE_ESCRIBE):
    cid = ll.identidad.client_id
    if not cid:
        raise ErrorNegocio(403, "CUENTA_DE_CLIENTE_REQUERIDA", "Para pagar necesitas una cuenta de cliente")
    if idem is not None and not re.fullmatch(r"[A-Za-z0-9_-]{8,64}", idem):
        raise ErrorNegocio(400, "IDEMPOTENCY_KEY_INVALIDA", "Idempotency-Key inválida")
    if idem:
        previo = await db.pedidos.find_one({"clienteId": cid, "claveIdempotencia": idem})
        if previo:  # el mismo intento repetido (doble clic, reintento de red) devuelve el mismo pedido
            response.status_code = 200
            return pedido_dto(previo)
    if await db.pedidos.count_documents({"clienteId": cid, "estado": "Pago pendiente"}) >= MAX_PENDIENTES:
        raise ErrorNegocio(409, "DEMASIADOS_PEDIDOS_PENDIENTES", "Tienes varios pedidos esperando pago. Paga o anula alguno antes de crear otro.")

    # 1) perfil de entrega: lo entrega `clients` (autoridad), no el navegador
    r = await _llamar("clients", "GET", f"/internal/clients/{cid}/delivery-profile", ll, identidad=ll.identidad)
    if r.status_code == 409:
        raise ErrorNegocio(409, "CLIENTE_INACTIVO", "Tu cuenta está inactiva. Escríbenos desde Contacto.")
    if r.status_code != 200:
        raise _prohibido()
    perfil = r.json()

    # 2) precios y disponibilidad vigentes: los entrega `inventory`
    acumulado = {}
    for it in datos.items:
        acumulado[it.id] = acumulado.get(it.id, 0) + it.cantidad
    if any(c > 20 for c in acumulado.values()):
        raise ErrorNegocio(422, "CANTIDAD_EXCEDIDA", "Máximo 20 unidades por producto")
    r = await _llamar("inventory", "POST", "/internal/pricing/resolve", ll,
                      json={"items": [{"id": i, "cantidad": c} for i, c in acumulado.items()]})
    if r.status_code != 200:
        raise ErrorNegocio(422, "ITEMS_INVALIDOS", cuerpo(r).get("detail", "Los productos del pedido no son válidos"))
    res = r.json()
    if res["noEncontrados"]:
        raise ErrorNegocio(422, "ITEM_INEXISTENTE", "Algún producto del pedido ya no existe en la carta", {"items": res["noEncontrados"]})
    if res["noDisponibles"]:
        raise ErrorNegocio(409, "ITEM_NO_DISPONIBLE", "Algún producto del pedido está agotado por hoy", {"items": res["noDisponibles"]})

    # 3) venta de alcohol: mayoría de edad según el perfil Y confirmación explícita
    if any(l["alcohol"] for l in res["lineas"]):
        if not perfil["mayorDeEdad"]:
            raise ErrorNegocio(422, "MENOR_DE_EDAD", "La venta de alcohol es solo para mayores de 18 años. Revisa la fecha de nacimiento de tu perfil.")
        if not datos.confirmaMayorEdad:
            raise ErrorNegocio(422, "CONFIRMAR_MAYORIA_EDAD", "Confirma que eres mayor de 18 años para comprar alcohol")

    # 4) despacho según la comuna (km de la zona), totales calculados aquí
    zona = await db.zonas.find_one({"_id": datos.comuna})
    if not zona:
        raise ErrorNegocio(422, "COMUNA_SIN_COBERTURA", "No despachamos a esa comuna")
    despacho = costo_despacho(zona["km"], await _config_despacho())
    lineas = [{"itemId": l["id"], "nombre": l["nombre"], "cantidad": l["cantidad"], "precio": l["precio"]} for l in res["lineas"]]
    subtotal, total = totales(lineas, despacho)

    seq = (await db.contadores.find_one_and_update({"_id": "pedidos"}, {"$inc": {"seq": 1}}, upsert=True, return_document=ReturnDocument.AFTER))["seq"]
    ahora = iso()
    doc = {"_id": f"A-{seq}", "clienteId": cid, "fecha": ahora, "origen": "web",
           "cliente": {"nombre": perfil["nombre"], "correo": perfil["correo"], "telefono": perfil["telefono"],
                       "direccion": perfil["direccion"], "comuna": datos.comuna, "indicaciones": datos.indicaciones.strip()},
           "lineas": lineas, "subtotal": subtotal, "despacho": despacho, "total": total, "medioPago": datos.medioPago,
           "estado": "Pago pendiente", "reembolso": "no_aplica", "historial": [{"estado": "Pago pendiente", "fecha": ahora, "por": "Cliente"}],
           "creadoEn": ahora}
    if idem:
        doc["claveIdempotencia"] = idem
    try:
        await db.pedidos.insert_one(doc)
    except DuplicateKeyError:  # carrera con el mismo Idempotency-Key
        response.status_code = 200
        return pedido_dto(await db.pedidos.find_one({"clienteId": cid, "claveIdempotencia": idem}))
    await auditoria.registrar(db, ll, "pedido.crear", f"pedido:{doc['_id']}", {"total": total, "lineas": len(lineas)})
    return pedido_dto(doc)


# ----------------------------- consultar -------------------------------------------
@app.get("/orders")
async def mis_pedidos(response: Response, limit: int = Query(default=20, ge=1, le=50), offset: int = Query(default=0, ge=0, le=10000), ll=CLIENTE):
    """Siempre acotado al cliente de la sesión: no existe parámetro para pedir los de otro."""
    if not ll.identidad.client_id:
        raise _prohibido()
    filtro = {"clienteId": ll.identidad.client_id}
    response.headers["X-Total-Count"] = str(await db.pedidos.count_documents(filtro))
    cur = db.pedidos.find(filtro).sort("fecha", -1).skip(offset).limit(limit)
    return [pedido_dto(d) async for d in cur]


@app.get("/admin/orders")
async def pedidos_personal(response: Response, estado: str = Query(default="activos", max_length=20), limit: int = Query(default=100, ge=1, le=200),
                           offset: int = Query(default=0, ge=0, le=10000), ll=DESPACHO):
    if estado not in ("activos", "todos") and estado not in ESTADOS:
        raise ErrorNegocio(400, "FILTRO_INVALIDO", "Estado desconocido")
    filtro = {} if estado == "todos" else {"estado": {"$in": list(ACTIVOS)}} if estado == "activos" else {"estado": estado}
    # RF13: las órdenes en preparación salen en el orden en que llegaron (más antigua primero)
    orden = 1 if estado == "activos" or estado in ACTIVOS else -1
    response.headers["X-Total-Count"] = str(await db.pedidos.count_documents(filtro))
    cur = db.pedidos.find(filtro).sort("fecha", orden).skip(offset).limit(limit)
    return [pedido_dto(d, personal=True) async for d in cur]


@app.get("/admin/orders/summary")
async def resumen(ll=Depends(guardia.dep(("graphql-gateway",), identidad="requerida", roles=("administrador", "despacho")))):
    filas = await db.pedidos.aggregate([{"$group": {"_id": "$estado", "n": {"$sum": 1}}}]).to_list(20)
    por_estado = {e: 0 for e in ESTADOS}
    por_estado.update({f["_id"]: f["n"] for f in filas})
    return {"porEstado": por_estado}


@app.get("/orders/{id}")
async def obtener(id: ID, ll=CUALQUIERA):
    d = await _pedido_para(id, ll.identidad)
    return pedido_dto(d, personal=_es_personal(ll.identidad))


# ----------------------------- anulación (cliente dueño o administrador) -----------
# Orders manda sobre el ESTADO: anula primero (una sola escritura atómica) y después avisa a payments.
# Si payments no responde, queda la marca `pagoPorCancelar` y un reintento periódico lo completa;
# un pago que llegue tarde se reembolsa solo (payments lo detecta). Así no existen estados a medias.
RESULTADO_PAGO = {"reembolso_pendiente": "pendiente", "reembolso_realizado": "realizado", "sin_pago": "no_aplica", "pago_cancelado": "no_aplica"}


async def _cancelar_pago(id, motivo, request_id):
    try:
        r = await interno.llamar("payments", "POST", f"/internal/orders/{id}/payment-cancel", request_id=request_id, json={"motivo": motivo})
    except ServicioNoDisponible as e:
        log.warning("payments no disponible: la cancelación del pago queda para reintento",
                    extra={"ctx": {"pedido": id, "motivo": e.motivo, "request_id": request_id}})
        return False
    if r.status_code != 200:
        log.error("payments rechazó la cancelación del pago", extra={"ctx": {"pedido": id, "status": r.status_code, "request_id": request_id}})
        return False
    nuevo = RESULTADO_PAGO.get(r.json().get("resultado"))
    if nuevo:
        await db.pedidos.update_one({"_id": id, "reembolso": {"$ne": "realizado"}}, {"$set": {"reembolso": nuevo}})
    await db.pedidos.update_one({"_id": id}, {"$set": {"pagoPorCancelar": False}})
    return True


async def _reintentos():
    """Cada REINTENTO_SEGUNDOS completa las cancelaciones de pago que no pudieron avisarse a payments."""
    espera = float(os.environ.get("REINTENTO_SEGUNDOS", "10"))
    while True:
        await asyncio.sleep(espera)
        try:
            async for d in db.pedidos.find({"estado": "Anulado", "pagoPorCancelar": True}).limit(20):
                await _cancelar_pago(d["_id"], d["anulacion"]["motivo"], "reintento-" + uuid.uuid4().hex[:12])
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("falló el ciclo de reintentos")


@app.post("/orders/{id}/cancellation")
async def anular(id: ID, datos: AnulacionIn, ll=Depends(guardia.dep(GW, identidad="requerida", roles=("cliente", "administrador")))):
    d = await _pedido_para(id, ll.identidad)
    if d["estado"] not in ANULABLES:
        raise ErrorNegocio(409, "NO_SE_PUEDE_ANULAR",
                           f"El pedido {id} ya está «{d['estado']}» y no se puede anular. Escríbenos desde Contacto si necesitas ayuda.")
    try:
        motivo = validar_anulacion(datos.motivo, datos.detalle)
    except ValueError as e:
        raise ErrorNegocio(422, "MOTIVO_INVALIDO", str(e))
    actor = _rol_actor(ll.identidad)
    ahora = iso()
    anulacion = {"motivo": motivo, "por": ETIQUETA_ROL[actor], "rol": actor, "actor": ll.identidad.user_id, "fecha": ahora}
    # "En preparación" solo se alcanza con un pago confirmado: se prevé reembolso; payments confirma el resultado real.
    reembolso = "pendiente" if d["estado"] == "En preparación" else "no_aplica"
    res = await db.pedidos.update_one(
        {"_id": id, "estado": d["estado"]},
        {"$set": {"estado": "Anulado", "anulacion": anulacion, "reembolso": reembolso, "pagoPorCancelar": True, "actualizadoEn": ahora},
         "$push": {"historial": {"estado": "Anulado", "fecha": ahora, "por": ETIQUETA_ROL[actor]}}})
    if res.matched_count == 0:  # otro proceso cambió el estado entre la lectura y la escritura
        raise ErrorNegocio(409, "CONFLICTO_DE_ESTADO", "El pedido cambió de estado mientras lo anulabas. Revisa su estado e inténtalo de nuevo.")
    await auditoria.registrar(db, ll, "pedido.anular", f"pedido:{id}", {"desde": d["estado"], "reembolsoPrevisto": reembolso})
    await _cancelar_pago(id, motivo, ll.request_id)
    return pedido_dto(await db.pedidos.find_one({"_id": id}), personal=_es_personal(ll.identidad))


# ----------------------------- avance de despacho (personal) -----------------------
@app.put("/admin/orders/{id}/status")
async def avanzar(id: ID, datos: EstadoIn, ll=DESPACHO_ESCRIBE):
    d = await db.pedidos.find_one({"_id": id})
    if not d:
        raise ErrorNegocio(404, "PEDIDO_NO_ENCONTRADO", "Pedido no encontrado")
    actor = _rol_actor(ll.identidad)
    desde = ANTERIOR_DE[datos.estado]
    if d["estado"] != desde or not transicion_permitida(desde, datos.estado, actor):
        raise ErrorNegocio(409, "TRANSICION_NO_PERMITIDA", f"El pedido está «{d['estado']}»: no puede pasar a «{datos.estado}».")
    ahora = iso()
    res = await db.pedidos.update_one({"_id": id, "estado": desde},
                                      {"$set": {"estado": datos.estado, "actualizadoEn": ahora},
                                       "$push": {"historial": {"estado": datos.estado, "fecha": ahora, "por": ETIQUETA_ROL[actor]}}})
    if res.matched_count == 0:
        raise ErrorNegocio(409, "CONFLICTO_DE_ESTADO", "El pedido cambió de estado. Actualiza la lista e inténtalo de nuevo.")
    await auditoria.registrar(db, ll, "pedido.estado", f"pedido:{id}", {"desde": desde, "hasta": datos.estado})
    return pedido_dto(await db.pedidos.find_one({"_id": id}), personal=True)


# ----------------------------- contratos internos para payments --------------------
@app.get("/internal/orders/{id}/payable")
async def por_pagar(id: ID, ll=Depends(guardia.dep(("payments",)))):
    """payments pregunta cuánto cobrar: el monto sale de AQUÍ, no de lo que diga el navegador."""
    d = await db.pedidos.find_one({"_id": id})
    if not d:
        raise ErrorNegocio(404, "PEDIDO_NO_ENCONTRADO", "Pedido no encontrado")
    return {"id": id, "clienteId": d["clienteId"], "estado": d["estado"], "total": d["total"], "medioPago": d["medioPago"],
            "cliente": {"nombre": d["cliente"]["nombre"], "correo": d["cliente"]["correo"]}, "comuna": d["cliente"]["comuna"],
            "lineas": [{"itemId": l.get("itemId"), "nombre": l["nombre"], "cantidad": l["cantidad"], "precio": l["precio"]} for l in d["lineas"]],
            "subtotal": d["subtotal"], "despacho": d["despacho"]}


class PagoConfirmado(BaseModel):
    model_config = ConfigDict(extra="forbid")
    pagoId: str = Field(min_length=3, max_length=60)
    monto: int = Field(ge=0)
    ventaId: str | None = Field(default=None, max_length=40)


@app.post("/internal/orders/{id}/payment-confirmed")
async def pago_confirmado(id: ID, datos: PagoConfirmado, ll=Depends(guardia.dep(("payments",)))):
    """ÚNICA vía hacia «En preparación». Idempotente: repetir la misma confirmación no cambia nada, tampoco si dos llegan a la vez.

    Leer y escribir son dos pasos: si otra solicitud cambia el pedido en medio (típico: el aviso original de payments y su reintento
    llegando juntos cuando orders vuelve de una pausa), esta escritura no encuentra el estado que leyó. Eso NO es un rechazo del pago:
    se vuelve a leer y se decide con el estado que quedó (la misma confirmación ya aplicada responde igual que la primera vez).
    Responder 409 aquí hacía que payments devolviera el dinero de un pedido que sí avanzó."""
    for _ in range(INTENTOS_DE_CONFIRMACION):
        d = await db.pedidos.find_one({"_id": id})
        if not d:
            raise ErrorNegocio(404, "PEDIDO_NO_ENCONTRADO", "Pedido no encontrado")
        if d.get("pagoId") == datos.pagoId and d["estado"] in ("En preparación", "En camino", "Entregado"):
            return {"estado": d["estado"], "repetido": True}   # misma confirmación repetida: no cambia nada
        if d["estado"] == "Anulado":
            # el dinero llegó después de anular: el pedido queda con reembolso pendiente y payments lo gestiona
            await db.pedidos.update_one({"_id": id, "reembolso": "no_aplica"}, {"$set": {"reembolso": "pendiente", "actualizadoEn": iso()}})
            raise ErrorNegocio(409, "PEDIDO_ANULADO", "El pedido fue anulado antes de confirmarse el pago")
        if datos.monto != d["total"]:
            raise ErrorNegocio(409, "MONTO_NO_COINCIDE", "El monto pagado no coincide con el total del pedido")
        if not transicion_permitida(d["estado"], "En preparación", "payments"):
            raise ErrorNegocio(409, "TRANSICION_NO_PERMITIDA", f"El pedido está «{d['estado']}»")
        ahora = iso()
        res = await db.pedidos.update_one({"_id": id, "estado": "Pago pendiente"},
                                          {"$set": {"estado": "En preparación", "pagoId": datos.pagoId, "ventaId": datos.ventaId, "pagadoEn": ahora, "actualizadoEn": ahora},
                                           "$push": {"historial": {"estado": "En preparación", "fecha": ahora, "por": "Sistema de pagos"}}})
        if res.matched_count == 1:
            await auditoria.registrar(db, ll, "pedido.pago_confirmado", f"pedido:{id}", {"pagoId": datos.pagoId})
            return {"estado": "En preparación", "repetido": False}
    # el pedido sigue cambiando bajo los pies de esta solicitud: payments no lo toma como rechazo, reintenta
    raise ErrorNegocio(409, "CONFLICTO_DE_ESTADO", "El pedido cambió de estado")


@app.post("/internal/orders/{id}/refund-done")
async def reembolso_realizado(id: ID, ll=Depends(guardia.dep(("payments",)))):
    r = await db.pedidos.update_one({"_id": id, "estado": "Anulado", "reembolso": "pendiente"}, {"$set": {"reembolso": "realizado", "actualizadoEn": iso()}})
    return {"actualizado": r.modified_count == 1}
