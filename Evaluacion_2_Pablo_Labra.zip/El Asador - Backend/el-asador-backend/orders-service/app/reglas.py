"""Reglas puras de orders: ciclo de vida del pedido, despacho, totales y cotización de eventos.

Se mantienen sin red ni base de datos para poder probarlas (y mutarlas) de forma aislada.
"""
import math

ESTADOS = ("Pago pendiente", "En preparación", "En camino", "Entregado", "Anulado")
ACTIVOS = ("Pago pendiente", "En preparación", "En camino")
ANULABLES = ("Pago pendiente", "En preparación")

# (estado actual, estado nuevo) -> quién puede ejecutar la transición.
# "payments" es una identidad de SERVICIO: el pago solo lo confirma el sistema de pagos, nunca el navegador.
TRANSICIONES = {
    ("Pago pendiente", "En preparación"): {"payments"},
    ("En preparación", "En camino"): {"despacho", "administrador"},
    ("En camino", "Entregado"): {"despacho", "administrador"},
    ("Pago pendiente", "Anulado"): {"cliente", "administrador"},
    ("En preparación", "Anulado"): {"cliente", "administrador"},
}
# Estado requerido para avanzar al estado pedido por el personal de despacho.
ANTERIOR_DE = {"En camino": "En preparación", "Entregado": "En camino"}

MOTIVOS_ANULACION = ("Me equivoqué al armar el pedido", "Ya no lo necesito", "Se demora mucho el despacho",
                     "Encontré otra opción", "Otro motivo")
MEDIOS_PAGO = ("Servipag", "Transferencia bancaria", "Depósito bancario")
ETIQUETA_ROL = {"cliente": "Cliente", "administrador": "Administrador", "dueno": "Dueño", "despacho": "Encargado de despacho"}


def transicion_permitida(desde, hasta, actor):
    return actor in TRANSICIONES.get((desde, hasta), set())


def costo_despacho(km, cfg):
    """Gratis hasta kmGratis; después, costo base + valor por cada km adicional (redondeado hacia arriba)."""
    if km <= cfg["kmGratis"]:
        return 0
    return cfg["base"] + math.ceil(km - cfg["kmGratis"]) * cfg["porKm"]


def totales(lineas, despacho):
    subtotal = sum(l["precio"] * l["cantidad"] for l in lineas)
    return subtotal, subtotal + despacho


def validar_anulacion(motivo, detalle):
    if motivo not in MOTIVOS_ANULACION:
        raise ValueError("Motivo de anulación desconocido")
    if motivo == "Otro motivo" and len((detalle or "").strip()) < 3:
        raise ValueError("Cuéntanos cuál es el motivo para poder anular la compra.")
    return f"{motivo}: {detalle.strip()}" if (detalle or "").strip() else motivo


def cotizar_evento(cfg, personas, menu_id, bebidas, ensaladas, parrillero, precio_bebida, precio_ensalada, despacho, comuna):
    """Estimación de un evento. Misma regla que el cotizador de la página Servicios, pero calculada en el servidor."""
    menu = next((m for m in cfg["menus"] if m["id"] == menu_id), None)
    if menu is None:
        raise ValueError("Menú desconocido")
    if personas < cfg["minPersonas"]:
        raise ValueError(f"Para eventos atendemos desde {cfg['minPersonas']} personas")
    if personas > cfg["maxPersonas"]:
        raise ValueError(f"Para más de {cfg['maxPersonas']} personas escríbenos desde Contacto y lo coordinamos")
    detalle = [(f"{menu['nombre']} × {personas}", menu["precioPersona"] * personas)]
    cada_cuatro = math.ceil(personas / 4)  # una bebida y una ensalada cada 4 personas
    if bebidas:
        detalle.append((f"Bebida 1,5 L × {cada_cuatro}", precio_bebida * cada_cuatro))
    if ensaladas:
        detalle.append((f"Ensalada chilena × {cada_cuatro}", precio_ensalada * cada_cuatro))
    if parrillero:
        detalle.append(("Parrillero en el lugar (hasta 5 horas)", cfg["precioParrillero"]))
    if comuna:
        detalle.append((f"Despacho a {comuna}", despacho))
    return [{"texto": t, "valor": v} for t, v in detalle], sum(v for _, v in detalle)
