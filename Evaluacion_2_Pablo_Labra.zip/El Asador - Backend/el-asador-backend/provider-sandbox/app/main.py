"""Proveedor de pagos SIMULADO (sandbox). Representa a un tercero externo (tipo Servipag / Webpay).

Qué hace, igual que un proveedor real:
  * API con API key:  crear pago, consultar, cancelar y reembolsar (POST/GET /v1/...).
  * Página de pago ("checkout") donde el cliente decide Pagar o Rechazar. No se procesa dinero real.
  * Avisos (webhooks) firmados con HMAC-SHA256 hacia El Asador, con reintentos si el destino falla.
    La firma cubre «timestamp.cuerpo», así un aviso alterado o repetido fuera de plazo se puede detectar.

La API key y la clave de firma viven en Vault (asador/provider/api-key y asador/provider/webhook-secret).
El estado se guarda en memoria: es un simulador, no un sistema de registro.
"""
import asyncio
import hashlib
import hmac
import html
import json
import os
import secrets
import time
from contextlib import asynccontextmanager
from typing import Literal
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

import httpx
from fastapi import Depends, Header
from fastapi.responses import HTMLResponse, RedirectResponse
from pydantic import BaseModel, ConfigDict, Field

from common.app import crear_app
from common.errores import ErrorNegocio
from common.vault_secrets import SecretUnavailable, VaultSecrets

vault = VaultSecrets()
PUBLICA = (os.environ.get("PROVIDER_PUBLIC_URL") or os.environ.get("PROVIDER_URL") or "http://localhost:8300").rstrip("/")
GATEWAY = (os.environ.get("GATEWAY_URL") or "http://localhost:8000").rstrip("/")
NOTIFY_URL = os.environ.get("NOTIFY_URL") or GATEWAY + "/api/webhooks/provider"
RETORNO_PERMITIDO = tuple(p.strip().rstrip("/") for p in (os.environ.get("RETURN_URL_PREFIXES") or GATEWAY).split(",") if p.strip())
DUPLICAR = os.environ.get("WEBHOOK_DUPLICAR", "false").lower() == "true"   # reenvía cada aviso (entrega "al menos una vez")
REINTENTOS = int(os.environ.get("WEBHOOK_REINTENTOS", "6"))
PAUSA_BASE = float(os.environ.get("WEBHOOK_PAUSA", "0.5"))
PID_RE = r"^prv_[A-Za-z0-9_-]{10,40}$"

PAGOS = {}        # id -> pago
POR_REFERENCIA = {}
REEMBOLSOS = {}   # id de pago -> reembolso
TAREAS = set()
http = None
log = None


@asynccontextmanager
async def lifespan(app):
    global http
    await vault.aesperar("asador/provider/api-key")
    await vault.aesperar("asador/provider/webhook-secret")
    http = httpx.AsyncClient(timeout=httpx.Timeout(5.0, connect=2.0))
    log.info("Proveedor sandbox listo", extra={"ctx": {"notify_url": NOTIFY_URL}})
    yield
    for t in list(TAREAS):
        t.cancel()
    await http.aclose()


app, log = crear_app("provider-sandbox", lifespan)


async def api_key(authorization: str = Header(default="")):
    if not authorization.startswith("Bearer "):
        raise ErrorNegocio(401, "NO_AUTENTICADO", "API key requerida")
    try:
        esperada = await vault.avalor("asador/provider/api-key")
    except SecretUnavailable:
        raise ErrorNegocio(503, "SIN_CREDENCIALES", "Servicio no disponible")
    if not hmac.compare_digest(authorization[7:].encode(), esperada.encode()):
        log.warning("API key inválida")
        raise ErrorNegocio(401, "API_KEY_INVALIDA", "API key inválida")


def firmar(secreto: str, t: int, cuerpo: bytes) -> str:
    return hmac.new(secreto.encode(), f"{t}.".encode() + cuerpo, hashlib.sha256).hexdigest()


def vista(p):
    return {"id": p["id"], "status": p["status"], "reference": p["reference"], "amount": p["amount"], "currency": "CLP",
            "checkout_url": f"{PUBLICA}/checkout/{p['id']}", "created": p["created"]}


# ----------------------------- avisos firmados (webhooks) ---------------------------
async def _enviar_aviso(cuerpo: bytes, evento_id: str):
    for intento in range(REINTENTOS):
        try:
            secreto = await vault.avalor("asador/provider/webhook-secret")
            t = int(time.time())
            r = await http.post(NOTIFY_URL, content=cuerpo, headers={
                "Content-Type": "application/json", "X-Provider-Signature": f"t={t},v1={firmar(secreto, t, cuerpo)}",
                "X-Provider-Event-Id": evento_id})
            if r.status_code < 300:
                return
            if r.status_code < 500 and r.status_code != 429:
                log.warning("el destino rechazó el aviso", extra={"ctx": {"evento": evento_id, "status": r.status_code}})
                return
        except (httpx.HTTPError, SecretUnavailable) as e:
            log.warning("no se pudo entregar el aviso", extra={"ctx": {"evento": evento_id, "tipo": type(e).__name__, "intento": intento + 1}})
        await asyncio.sleep(min(PAUSA_BASE * (2 ** intento), 8))
    log.error("aviso sin entregar tras los reintentos", extra={"ctx": {"evento": evento_id}})


def _avisar(tipo: str, pago: dict):
    evento = {"id": "evt_" + secrets.token_hex(8), "type": tipo, "created": int(time.time()),
              "data": {"payment_id": pago["id"], "reference": pago["reference"], "amount": pago["amount"], "currency": "CLP"}}
    cuerpo = json.dumps(evento, separators=(",", ":")).encode()

    async def enviar():
        for _ in range(2 if DUPLICAR else 1):
            await _enviar_aviso(cuerpo, evento["id"])

    t = asyncio.create_task(enviar())
    TAREAS.add(t)
    t.add_done_callback(TAREAS.discard)


# ----------------------------- API del proveedor (con API key) ----------------------
class PagoIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    reference: str = Field(pattern=r"^[A-Za-z0-9_-]{6,60}$")
    amount: int = Field(ge=1, le=10_000_000)
    currency: Literal["CLP"] = "CLP"
    description: str = Field(default="", max_length=100)
    return_url: str = Field(max_length=300)


def _retorno_valido(url: str) -> bool:
    return any(url == p or url.startswith(p + "/") for p in RETORNO_PERMITIDO)


@app.post("/v1/payments", status_code=201, dependencies=[Depends(api_key)])
async def crear_pago(datos: PagoIn):
    if not _retorno_valido(datos.return_url):
        raise ErrorNegocio(422, "RETURN_URL_NO_PERMITIDA", "return_url no está en la lista de destinos permitidos")
    previo = POR_REFERENCIA.get(datos.reference)
    if previo:   # crear dos veces con la misma referencia devuelve el mismo pago
        return vista(PAGOS[previo])
    pid = "prv_" + secrets.token_urlsafe(14)
    PAGOS[pid] = {"id": pid, "status": "pending", "reference": datos.reference, "amount": datos.amount, "description": datos.description,
                  "return_url": datos.return_url, "created": int(time.time())}
    POR_REFERENCIA[datos.reference] = pid
    return vista(PAGOS[pid])


@app.get("/v1/payments/{pid}", dependencies=[Depends(api_key)])
async def consultar_pago(pid: str):
    p = PAGOS.get(pid)
    if not p:
        raise ErrorNegocio(404, "PAGO_NO_ENCONTRADO", "Pago no encontrado")
    return vista(p)


@app.post("/v1/payments/{pid}/cancel", dependencies=[Depends(api_key)])
async def cancelar_pago(pid: str):
    p = PAGOS.get(pid)
    if not p:
        raise ErrorNegocio(404, "PAGO_NO_ENCONTRADO", "Pago no encontrado")
    if p["status"] == "succeeded":
        raise ErrorNegocio(409, "PAGO_YA_APROBADO", "El pago ya fue aprobado; corresponde un reembolso")
    if p["status"] == "pending":
        p["status"] = "cancelled"
    return vista(p)


class ReembolsoIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    payment_id: str = Field(pattern=PID_RE)
    amount: int = Field(ge=1, le=10_000_000)


@app.post("/v1/refunds", status_code=201, dependencies=[Depends(api_key)])
async def reembolsar(datos: ReembolsoIn):
    p = PAGOS.get(datos.payment_id)
    if not p:
        raise ErrorNegocio(404, "PAGO_NO_ENCONTRADO", "Pago no encontrado")
    previo = REEMBOLSOS.get(p["id"])
    if previo:   # un pago se reembolsa una sola vez: repetir devuelve el mismo reembolso
        return previo
    if p["status"] != "succeeded":
        raise ErrorNegocio(409, "PAGO_NO_APROBADO", "Solo se reembolsan pagos aprobados")
    if datos.amount != p["amount"]:
        raise ErrorNegocio(422, "MONTO_INVALIDO", "Solo se admiten reembolsos por el total del pago")
    r = {"id": "rfd_" + secrets.token_urlsafe(10), "payment_id": p["id"], "amount": p["amount"], "status": "succeeded", "created": int(time.time())}
    REEMBOLSOS[p["id"]] = r
    return r


# ----------------------------- página de pago (la ve el cliente) --------------------
CSP = "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'"
ESTILO = """
:root{color-scheme:light dark;--bg:#f3f1ee;--card:#fff;--tx:#1d1d1f;--mut:#6b6b70;--ac:#0b6b53;--bd:#dcd8d2}
@media (prefers-color-scheme:dark){:root{--bg:#161616;--card:#222;--tx:#f2f2f2;--mut:#a3a3a8;--ac:#38b28f;--bd:#3a3a3a}}
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:var(--bg);color:var(--tx);
font:16px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;padding:16px}
main{width:100%;max-width:420px;background:var(--card);border:1px solid var(--bd);border-radius:14px;padding:24px}
.tag{display:inline-block;font-size:12px;letter-spacing:.04em;text-transform:uppercase;color:var(--mut);margin-bottom:8px}
h1{font-size:20px;margin:0 0 4px}.monto{font-size:34px;font-weight:700;margin:12px 0 4px}.mut{color:var(--mut);font-size:14px}
form{display:inline}button{font:inherit;font-weight:600;border-radius:10px;padding:12px 16px;border:1px solid var(--ac);cursor:pointer;width:100%;margin-top:12px}
.pagar{background:var(--ac);color:#fff}.rechazar{background:transparent;color:var(--ac)}
.aviso{margin-top:16px;padding:10px 12px;border-radius:10px;background:rgba(0,0,0,.06);font-size:13px;color:var(--mut)}
"""


def _pagina(contenido: str, status=200):
    cuerpo = (f"<!doctype html><html lang='es'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
              f"<title>Pago seguro (sandbox)</title><style>{ESTILO}</style></head><body><main>{contenido}</main></body></html>")
    return HTMLResponse(cuerpo, status_code=status, headers={"Content-Security-Policy": CSP, "X-Content-Type-Options": "nosniff",
                                                              "Referrer-Policy": "no-referrer"})


def _clp(n: int) -> str:
    return "$" + f"{n:,}".replace(",", ".")


@app.get("/checkout/{pid}")
async def checkout(pid: str):
    p = PAGOS.get(pid) if len(pid) < 60 else None
    if not p:
        return _pagina("<h1>Pago no encontrado</h1><p class='mut'>El enlace no es válido o ya no está disponible.</p>", 404)
    if p["status"] != "pending":
        etiqueta = {"succeeded": "Este pago ya fue aprobado.", "failed": "Este pago fue rechazado.", "cancelled": "Este pago fue cancelado."}[p["status"]]
        return _pagina(f"<span class='tag'>Pago seguro · sandbox</span><h1>{html.escape(etiqueta)}</h1>"
                       f"<p class='mut'>Referencia {html.escape(p['reference'])}</p>")
    e = html.escape
    return _pagina(
        f"<span class='tag'>Pago seguro · sandbox</span><h1>Parrilladas El Asador</h1>"
        f"<p class='mut'>{e(p['description'] or 'Pedido')} · ref. {e(p['reference'])}</p>"
        f"<div class='monto'>{_clp(p['amount'])}</div><p class='mut'>Pesos chilenos (CLP)</p>"
        f"<form method='post' action='/checkout/{e(pid)}/pay'><button class='pagar' type='submit'>Pagar {_clp(p['amount'])}</button></form>"
        f"<form method='post' action='/checkout/{e(pid)}/reject'><button class='rechazar' type='submit'>Rechazar el pago</button></form>"
        f"<div class='aviso'>Simulador de pagos para pruebas: no se usa dinero ni datos de tarjetas reales.</div>")


def _volver(p, estado: str):
    partes = urlparse(p["return_url"])
    consulta = dict(parse_qsl(partes.query)) | {"pago": estado}
    return RedirectResponse(urlunparse(partes._replace(query=urlencode(consulta))), status_code=303)


@app.post("/checkout/{pid}/pay")
async def pagar(pid: str):
    p = PAGOS.get(pid) if len(pid) < 60 else None
    if not p:
        return _pagina("<h1>Pago no encontrado</h1>", 404)
    if p["status"] == "pending":
        p["status"] = "succeeded"
        _avisar("payment.succeeded", p)
        return _volver(p, "aprobado")
    if p["status"] == "succeeded":   # doble clic o recarga: no se vuelve a avisar
        return _volver(p, "aprobado")
    return _pagina("<h1>Este pago ya no está disponible</h1>", 409)


@app.post("/checkout/{pid}/reject")
async def rechazar(pid: str):
    p = PAGOS.get(pid) if len(pid) < 60 else None
    if not p:
        return _pagina("<h1>Pago no encontrado</h1>", 404)
    if p["status"] == "pending":
        p["status"] = "failed"
        _avisar("payment.failed", p)
        return _volver(p, "rechazado")
    if p["status"] == "failed":
        return _volver(p, "rechazado")
    return _pagina("<h1>Este pago ya no está disponible</h1>", 409)
