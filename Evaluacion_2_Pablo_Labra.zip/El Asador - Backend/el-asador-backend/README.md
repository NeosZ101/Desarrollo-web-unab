# El Asador · backend (Evaluación 2)

Caso 20 · Parrilladas «El Asador» · Desarrollo Web y Móvil, Universidad Andrés Bello · Pablo Labra (NeosZ101), equipo de una sola persona.

Backend de microservicios (FastAPI + MongoDB + HashiCorp Vault + GraphQL) construido con las pantallas y los datos de la Entrega C2 (la Evaluación 2 se entrega con datos del frontend, no con el frontend integrado: ver `datos-frontend/`). **El informe de arquitectura está en [`docs/INFORME.md`](docs/INFORME.md)**; este archivo explica cómo levantar el sistema, probarlo y qué se verificó y qué no.

## Qué hay aquí

| Carpeta | Contenido |
|---|---|
| `api-gateway/` | Única puerta pública: tabla de 38 rutas, sesión, rol, origen, límites |
| `auth-service/` `clients-service/` `inventory-service/` `orders-service/` `payments-service/` `notifications-service/` `analytics-service/` | Servicios privados (cada uno con su base y su usuario de MongoDB) |
| `graphql-gateway/` | Consultas agregadas de solo lectura |
| `provider-sandbox/` | Proveedor de pagos simulado (tercero externo) |
| `common/` | Código compartido: secretos (Vault), cliente interno, errores, logs, plazos |
| `datos-frontend/` | Datos de las pantallas de la C2 que usan las pruebas: consultas GraphQL (ver [`datos-frontend/README.md`](datos-frontend/README.md)) |
| `scripts/` | Arranque, siembra de secretos, pruebas de humo y de carga, generadores de documentos |
| `tests/` | Pruebas automáticas, de mutación y harness que levanta el sistema |
| `docs/` | Informe, ADR, matrices, diagramas (modelo Structurizr `docs/diagramas/El-Asador.dsl` y Mermaid, ambos editables), ejemplos JSON y evidencia |

## Requisitos

- **Con Docker (recomendado para la entrega):** Docker con Compose v2 y Python 3 (solo para los scripts de ayuda; se probaron con Python 3.13; usan la biblioteca estándar, salvo `smoke_test.py`, que necesita `httpx`).
- **Sin Docker:** Python 3.13 y `pip install -r requirements/tests.txt`. Opcionalmente los binarios de HashiCorp Vault y de MongoDB para ejecutar con servidores reales.

## Levantar con Docker

```bash
python scripts/bootstrap.py        # crea .env con los secretos generados al azar (permisos 600; está en .gitignore)
docker compose up -d --build       # Vault, siembra de secretos, MongoDB, 9 servicios y el proveedor simulado
python scripts/smoke_test.py       # recorre el sistema como una persona (cliente y administrador); código 0 solo si TODO pasó
```

La prueba de humo inicia sesión varias veces y el límite por omisión es de 5 inicios de sesión por minuto: si se repite, hay que esperar un minuto o el segundo intento recibirá `429`. Su resultado guardado está en [`docs/evidencia/humo.txt`](docs/evidencia/humo.txt).

La API queda en <http://localhost:8000> (usar siempre `localhost`, sin mezclarlo con `127.0.0.1`: la cookie de sesión es del sitio). La página de pago del proveedor simulado queda en <http://localhost:8300>.

**Todo se ejecuta en localhost**: no hace falta publicar el sistema en ningún servidor.

Detener: `docker compose down` (conserva los datos) o `docker compose down -v` (borra también la base de datos). Para rotar un secreto de servicio a servicio (por ejemplo `svc/orders-to-clients`) se vuelve a ejecutar la tarea de siembra con `--rotar`: `docker compose run --rm vault-seed python /seed/seed_vault.py --rotar svc/orders-to-clients` (este comando no se ejecutó con Docker; el procedimiento y su plan ante una filtración están en [ADR-003](docs/adr/ADR-003-secretos-en-vault.md)). Los servicios recogen el valor nuevo en menos de 60 s.

Solo el gateway (`127.0.0.1:8000`) y la página de pago (`127.0.0.1:8300`) publican puertos, y solo hacia el propio equipo; Vault, MongoDB y los servicios privados están en una red interna sin salida.

### Cuentas de demostración

Se crean cuando `SEED_DEMO_DATA=true` (valor por defecto del compose, para la revisión). **En cualquier uso que no sea una demostración se debe poner `SEED_DEMO_DATA=false`**: estas claves son públicas.

| Rol | Usuario | Clave |
|---|---|---|
| Administrador | `admin@elasador.cl` | `admin123` |
| Dueño | `dueno@elasador.cl` | `dueno123` |
| Despacho | `despacho@elasador.cl` | `despacho123` |
| Cliente | `andrea.molina@correo.cl` | `cliente123` |

Otros clientes de ejemplo: `felipe.araya`, `catalina.vega` y `tomas.nunez` (`@correo.cl`, misma clave del cliente).

## Levantar sin Docker

```bash
pip install -r requirements/tests.txt
python scripts/demo_local.py                              # Vault y MongoDB simulados en memoria
python scripts/demo_local.py --real --bin /ruta/a/bins    # Vault y MongoDB reales (carpeta con los binarios vault y mongod)
python scripts/smoke_test.py --base http://127.0.0.1:8000 --proveedor http://127.0.0.1:8300
```

Cada servicio corre en su propio proceso, con su propio token de Vault y su propia base; al terminar (Ctrl+C) se borra todo.

## Pruebas

```bash
python -m pytest tests -q                                  # suite completa con Vault y MongoDB simulados
ASADOR_REAL=1 ASADOR_BIN=/ruta/a/bins python -m pytest tests -q   # la misma suite con servidores reales (agrega pruebas de permisos de MongoDB y de argon2id)
python tests/mutaciones.py                                 # introduce defectos a propósito y exige que alguna prueba falle (lento)
python scripts/verificar_controles.py                      # ejecuta los 6 casos de validación del módulo 7 y escribe docs/evidencia/controles.md
python scripts/load_test.py --ventas 3150                  # prueba de carga de la analítica (ver docs/evidencia/carga.md)
```

Los documentos que describen el sistema se **generan** y hay pruebas que fallan si quedan desactualizados:

```bash
python scripts/generar_documentos.py     # matrices, esquema GraphQL (desde el código)
python scripts/capturar_ejemplos.py      # un ejemplo real de cada uno de los 38 servicios (docs/ejemplos/)
python scripts/generar_trazabilidad.py   # requisito | pantalla | servicio | prueba | resultado | evidencia
python scripts/generar_informe.py        # docs/INFORME.md
python scripts/exportar_diagramas.py --cli <structurizr.sh>   # vistas del modelo C4 a SVG (docs/diagramas/render/); ver docs/diagramas/README.md
```

## Qué se verificó y qué no

Las cifras exactas (pruebas que pasaron en cada modo, mutaciones detectadas, verificaciones de controles) se generan desde los resultados guardados: [`docs/INFORME.md`](docs/INFORME.md), sección 10.3.

**Verificado ejecutándolo:**
- El sistema completo como procesos separados, con Vault y MongoDB **simulados** y con HashiCorp Vault y MongoDB **reales** (sin Docker): suite de pruebas automáticas, casos de validación de seguridad, caos (servicios y Vault caídos) y pruebas de carga.
- Los flujos principales por HTTP con los datos del frontend (prueba de humo, 29 de 29: `docs/evidencia/humo.txt`).

**NO verificado:**
- **Docker:** el compose principal se ejecutó en Docker Desktop para Windows el 7 y el 8 de noviembre de 2026: se construyeron las imágenes, los 12 contenedores quedaron `healthy` y `python scripts/smoke_test.py` dio 29 de 29 (`docs/evidencia/docker_humo.txt` y `docs/evidencia/docker_2026-11-08/`, esta última con la versión final y las capturas de los casos C1–C6). En el primer intento apareció un defecto de Vault, corregido con `SKIP_SETCAP`. La suite de pruebas y las mediciones de carga no se repitieron dentro de contenedores.
- La variante con HTTPS (`docker-compose.tls.yml`, Caddy) y el modo `--modo externo` de la prueba de carga (`docker-compose.carga.yml`).
- Envío real de correo (SMTP) y validación de correos por DNS MX: el proveedor por omisión es un adaptador de prueba (`EMAIL_PROVIDER=sandbox`).
- Usabilidad (RNF10, RNF11) y validación de HTML (RNF16).
- Rendimiento fuera del equipo de pruebas (2 CPU, ~8 GB, generador de carga en el mismo equipo): ver las limitaciones en `docs/evidencia/carga.md`.

Vault corre en **modo desarrollo** (memoria, sellado automático): sirve para demostrar el modelo de secretos, no para producción.

## Desviaciones y supuestos

- Los requisitos siguen la estructura del caso de referencia de la asignatura, adaptados a «El Asador» (detalle en la portada del informe).
- RNF3 (Oracle, .NET/J2EE) se reemplaza por FastAPI y MongoDB, las restricciones del curso. RNF4 (procedimientos almacenados) se reemplaza por reintentos y una bandeja de salida.
