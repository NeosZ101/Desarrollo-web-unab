"""Inventory (privado): catálogo y disponibilidad. Es la AUTORIDAD de productos, promociones y precios.

Decisión de negocio: el caso pide "administrar la disponibilidad de cada producto" (RF7), no cantidades de
stock; la comida se prepara al momento. Por eso inventory NO reserva ni descuenta unidades: orders consulta
la disponibilidad al crear el pedido y el precio vigente queda copiado (snapshot) en el pedido.
"""
import json
import os
import re
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

from fastapi import Depends, Query, Response
from pydantic import BaseModel, ConfigDict, Field, field_validator
from pymongo import ReturnDocument

from common import auditoria
from common.app import crear_app
from common.db import abrir_db
from common.errores import ErrorNegocio
from common.migraciones import migrar
from common.seguridad import Guardia
from common.tiempo import iso
from common.vault_secrets import VaultSecrets

from .reglas import CATEGORIAS, incluye_promo, precio_promo, validar_imagen

SEMILLA = os.environ.get("SEED_DEMO_DATA", "false").lower() == "true"
vault = VaultSecrets()
guardia = Guardia("inventory", vault)
GW = ("api-gateway",)
PERSONAL_CATALOGO = ("administrador", "dueno")
db = None


async def _indices(d):
    await d.productos.create_index([("categoria", 1), ("eliminado", 1)])
    await d.promos.create_index("activa")


MIGRACIONES = [(1, "índices de catálogo", _indices)]


async def sembrar(d):
    base = Path(__file__).parent / "seed"
    n = 0
    for p in json.loads((base / "productos.json").read_text(encoding="utf-8")):
        if not await d.productos.find_one({"_id": p["id"]}):
            doc = {**p, "_id": p.pop("id"), "alcohol": p.get("alcohol", False), "eliminado": False, "creadoEn": iso(), "actualizadoEn": iso()}
            doc.pop("id", None)
            await d.productos.insert_one(doc)
            n += 1
    for p in json.loads((base / "promos.json").read_text(encoding="utf-8")):
        if not await d.promos.find_one({"_id": p["id"]}):
            await d.promos.insert_one({**{k: v for k, v in p.items() if k != "id"}, "_id": p["id"], "activa": True})
            n += 1
    await d.contadores.update_one({"_id": "productos"}, {"$max": {"seq": 13}}, upsert=True)
    return n


@asynccontextmanager
async def lifespan(app):
    global db
    await vault.aesperar("asador/db/inventory")
    await guardia.precalentar()
    cliente, db = await abrir_db("inventory", vault)
    await migrar(db, MIGRACIONES)
    if SEMILLA:
        log.info("datos de prueba cargados", extra={"ctx": {"documentos_nuevos": await sembrar(db)}})
    app.state.chequeos.append(lambda: db.command("ping"))
    log.info("Inventory listo")
    yield
    cliente.close()


app, log = crear_app("inventory", lifespan)


# ----------------------------- modelos ------------------------------------------
class ProductoIn(BaseModel):
    """Representación editable de un producto (PUT la reemplaza completa; POST la crea)."""
    model_config = ConfigDict(extra="forbid")
    nombre: str = Field(min_length=3, max_length=60)
    categoria: Literal["parrilladas", "parrilla", "acompanamientos", "bebidas"]
    precio: int = Field(ge=500, le=200000)
    descripcion: str = Field(min_length=10, max_length=160)
    imagen: str
    personas: int | None = Field(default=None, ge=1, le=20)
    incluye: list[str] = Field(default_factory=list, max_length=12)
    disponible: bool = True
    alcohol: bool = False

    @field_validator("imagen")
    @classmethod
    def _img(cls, v):
        return validar_imagen(v)

    @field_validator("incluye")
    @classmethod
    def _inc(cls, v):
        if any(not (1 <= len(x.strip()) <= 80) for x in v):
            raise ValueError("Cada elemento de 'incluye' debe tener entre 1 y 80 caracteres")
        return [x.strip() for x in v]

    @field_validator("nombre", "descripcion")
    @classmethod
    def _txt(cls, v):
        return v.strip()


class DisponibilidadIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    disponible: bool


class ItemPedido(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str = Field(pattern=r"^[a-z0-9]{2,12}$")
    cantidad: int = Field(ge=1, le=20)


class ResolverIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    items: list[ItemPedido] = Field(min_length=1, max_length=30)


def publico(d):
    """DTO público de un producto: solo campos del catálogo, nunca campos internos (eliminado, auditoría)."""
    out = {"id": d["_id"], "categoria": d["categoria"], "nombre": d["nombre"], "precio": d["precio"], "disponible": d["disponible"],
           "imagen": d["imagen"], "descripcion": d["descripcion"], "incluye": d.get("incluye", []), "alcohol": d.get("alcohol", False)}
    if d.get("personas"):
        out["personas"] = d["personas"]
    return out


async def _productos_por_id(ids):
    return {d["_id"]: d async for d in db.productos.find({"_id": {"$in": list(ids)}})}


def _promo_dto(p, prods):
    activos = {k: v for k, v in prods.items() if not v.get("eliminado")}
    comps = p["componentes"]
    normal, final = precio_promo(comps, {k: v["precio"] for k, v in prods.items()}, p["descuento"])
    return {"id": p["_id"], "nombre": p["nombre"], "descripcion": p["descripcion"], "vigencia": p["vigencia"],
            "descuento": p["descuento"], "imagen": p["imagen"], "componentes": comps, "precioNormal": normal, "precio": final,
            "disponible": all(c["id"] in activos and activos[c["id"]]["disponible"] for c in comps),
            "incluye": incluye_promo(comps, {k: v["nombre"] for k, v in prods.items()}),
            "alcohol": any(prods[c["id"]].get("alcohol") for c in comps)}


# ----------------------------- catálogo público (vía gateway) -------------------
@app.get("/products")
async def listar(response: Response, categoria: str = Query(default="todas", max_length=20), available: bool | None = None,
                 q: str = Query(default="", max_length=60), limit: int = Query(default=100, ge=1, le=200),
                 offset: int = Query(default=0, ge=0, le=10000), ll=Depends(guardia.dep(GW, identidad="opcional"))):
    if categoria != "todas" and categoria not in CATEGORIAS:
        raise ErrorNegocio(400, "FILTRO_INVALIDO", "Categoría desconocida")
    filtro = {"eliminado": False}
    if categoria != "todas":
        filtro["categoria"] = categoria
    if available is not None:
        filtro["disponible"] = available
    if q.strip():
        t = re.escape(q.strip())
        filtro["$or"] = [{"nombre": {"$regex": t, "$options": "i"}}, {"descripcion": {"$regex": t, "$options": "i"}}]
    total = await db.productos.count_documents(filtro)
    cur = db.productos.find(filtro).sort("_id", 1).skip(offset).limit(limit)
    response.headers["X-Total-Count"] = str(total)
    return [publico(d) async for d in cur]


@app.get("/promos")
async def promociones(ll=Depends(guardia.dep(GW, identidad="opcional"))):
    prods = await _productos_por_id({c["id"] for p in await db.promos.find({"activa": True}).to_list(50) for c in p["componentes"]})
    return [_promo_dto(p, prods) async for p in db.promos.find({"activa": True}).sort("_id", 1)]


# ----------------------------- mantenedor (administrador y dueño) ---------------
STAFF = Depends(guardia.dep(GW, identidad="requerida", roles=PERSONAL_CATALOGO))


async def _siguiente_id():
    doc = await db.contadores.find_one_and_update({"_id": "productos"}, {"$inc": {"seq": 1}}, upsert=True, return_document=ReturnDocument.AFTER)
    return f"p{doc['seq']:02d}"


@app.post("/products", status_code=201)
async def crear(datos: ProductoIn, ll=STAFF):
    doc = {**datos.model_dump(), "_id": await _siguiente_id(), "eliminado": False, "creadoEn": iso(), "actualizadoEn": iso()}
    if not doc["incluye"]:
        doc["incluye"] = [doc["nombre"]]
    await db.productos.insert_one(doc)
    await auditoria.registrar(db, ll, "producto.crear", f"producto:{doc['_id']}", {"precio": doc["precio"]})
    return publico(doc)


async def _vigente_o_404(id):
    d = await db.productos.find_one({"_id": id, "eliminado": False})
    if not d:
        raise ErrorNegocio(404, "PRODUCTO_NO_ENCONTRADO", "Producto no encontrado")
    return d


@app.put("/products/{id}")
async def reemplazar(id: str, datos: ProductoIn, ll=STAFF):
    anterior = await _vigente_o_404(id)
    cambios = {**datos.model_dump(), "actualizadoEn": iso()}
    if not cambios["incluye"]:
        cambios["incluye"] = [cambios["nombre"]]
    await db.productos.update_one({"_id": id}, {"$set": cambios})
    await auditoria.registrar(db, ll, "producto.modificar", f"producto:{id}", {"precio_antes": anterior["precio"], "precio_despues": datos.precio})
    return publico({**anterior, **cambios})


@app.put("/products/{id}/availability")
async def disponibilidad(id: str, datos: DisponibilidadIn, ll=STAFF):
    anterior = await _vigente_o_404(id)
    await db.productos.update_one({"_id": id}, {"$set": {"disponible": datos.disponible, "actualizadoEn": iso()}})
    await auditoria.registrar(db, ll, "producto.disponibilidad", f"producto:{id}", {"antes": anterior["disponible"], "despues": datos.disponible})
    return publico({**anterior, "disponible": datos.disponible})


@app.delete("/products/{id}")
async def retirar(id: str, ll=STAFF):
    """DELETE = retirar de la carta (baja lógica). Los pedidos antiguos conservan su copia del nombre y el precio."""
    await _vigente_o_404(id)
    en_promo = await db.promos.find_one({"activa": True, "componentes.id": id})
    if en_promo:
        raise ErrorNegocio(409, "PRODUCTO_EN_PROMO", f"No se puede retirar: forma parte de la promo «{en_promo['nombre']}». Márcalo como agotado.")
    await db.productos.update_one({"_id": id}, {"$set": {"eliminado": True, "disponible": False, "actualizadoEn": iso()}})
    await auditoria.registrar(db, ll, "producto.retirar", f"producto:{id}")
    return {"id": id, "retirado": True}


# ----------------------------- contratos internos --------------------------------
@app.post("/internal/pricing/resolve")
async def resolver(datos: ResolverIn, ll=Depends(guardia.dep(("orders",)))):
    """orders envía ids y cantidades; inventory responde con precios y disponibilidad VIGENTES (nunca los del navegador)."""
    ids, vistos = [], set()
    for it in datos.items:
        if it.id in vistos:
            raise ErrorNegocio(422, "ITEM_REPETIDO", "Un producto aparece más de una vez; suma las cantidades en una sola línea")
        vistos.add(it.id)
        ids.append(it.id)
    promos = {p["_id"]: p async for p in db.promos.find({"_id": {"$in": ids}, "activa": True})}
    comps = {c["id"] for p in promos.values() for c in p["componentes"]}
    prods = await _productos_por_id(set(ids) | comps)
    lineas, faltan, agotados = [], [], []
    for it in datos.items:
        if it.id in promos:
            dto = _promo_dto(promos[it.id], prods)
            nombre, precio, disp, alc, tipo = f"{dto['nombre']} (promo)", dto["precio"], dto["disponible"], dto["alcohol"], "promo"
        elif it.id in prods and not prods[it.id].get("eliminado"):
            d = prods[it.id]
            nombre, precio, disp, alc, tipo = d["nombre"], d["precio"], d["disponible"], d.get("alcohol", False), "producto"
        else:
            faltan.append(it.id)
            continue
        if not disp:
            agotados.append(it.id)
        lineas.append({"id": it.id, "tipo": tipo, "nombre": nombre, "precio": precio, "cantidad": it.cantidad, "disponible": disp, "alcohol": alc})
    return {"lineas": lineas, "noEncontrados": faltan, "noDisponibles": agotados}


@app.get("/internal/items")
async def items_por_id(ids: str = Query(min_length=1, max_length=600), ll=Depends(guardia.dep(("graphql-gateway", "orders")))):
    """Datos PÚBLICOS de productos y promos por id (para agregaciones). Incluye productos retirados, marcados como tales."""
    lista = [i for i in ids.split(",") if re.fullmatch(r"[a-z0-9]{2,12}", i)][:100]
    promos = {p["_id"]: p async for p in db.promos.find({"_id": {"$in": lista}})}
    comps = {c["id"] for p in promos.values() for c in p["componentes"]}
    prods = await _productos_por_id(set(lista) | comps)
    out = {}
    for i in lista:
        if i in promos:
            dto = _promo_dto(promos[i], prods)
            out[i] = {"id": i, "tipo": "promo", "nombre": dto["nombre"], "descripcion": dto["descripcion"], "imagen": dto["imagen"],
                      "categoria": "promociones", "disponible": dto["disponible"], "retirado": False}
        elif i in prods:
            d = prods[i]
            out[i] = {"id": i, "tipo": "producto", "nombre": d["nombre"], "descripcion": d["descripcion"], "imagen": d["imagen"],
                      "categoria": d["categoria"], "disponible": d["disponible"] and not d.get("eliminado"), "retirado": bool(d.get("eliminado"))}
    return out


@app.get("/internal/summary")
async def resumen(ll=Depends(guardia.dep(("graphql-gateway",)))):
    """Conteos para el panel de operación (sin datos personales)."""
    agotados = [{"id": d["_id"], "nombre": d["nombre"]} async for d in db.productos.find({"eliminado": False, "disponible": False}).sort("_id", 1)]
    return {"productosActivos": await db.productos.count_documents({"eliminado": False}), "agotados": agotados}
