"""Reglas puras de inventory: catálogo, precios de promociones y validación de productos."""
import re

CATEGORIAS = ("parrilladas", "parrilla", "acompanamientos", "bebidas")
IMAGEN_RE = re.compile(r"^img/[a-z0-9-]{1,40}\.svg$")  # solo rutas locales del sitio: sin '..', sin URLs externas


def precio_promo(componentes, precios, descuento):
    """(precio normal, precio con descuento). Aritmética entera: sin errores de redondeo flotante.

    Igual que la regla del frontend: descuento sobre la suma de los productos, redondeado a la decena.
    """
    normal = sum(precios[c["id"]] * c["cantidad"] for c in componentes)
    con_descuento = (normal * (100 - descuento) + 500) // 1000 * 10
    return normal, con_descuento


def incluye_promo(componentes, nombres):
    return [f"{c['cantidad']} × {nombres[c['id']]}" for c in componentes]


def validar_imagen(valor):
    if not IMAGEN_RE.fullmatch(valor):
        raise ValueError("La imagen debe ser una ruta local con la forma img/nombre.svg")
    return valor
