"""Clients (privado): registro, perfil y acceso autorizado a los datos de clientes.

Es la AUTORIDAD de los datos personales del cliente (RUN, dirección, teléfono, correo...). La contraseña NO se
guarda aquí: la custodia `auth` (argon2id). El registro es una pequeña saga:
    validar -> comprobar que el correo existe (notifications) -> crear perfil -> crear credencial (auth)
y si la credencial falla se deshace el perfil, para no dejar clientes a medias.
"""
import json
import os
import re
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

from fastapi import Depends, Query, Response
from pydantic import BaseModel, ConfigDict, Field, field_validator
from pymongo.errors import DuplicateKeyError

from common import auditoria, plazos
from common.app import crear_app
from common.cliente_interno import ClienteInterno, ServicioNoDisponible, cuerpo
from common.db import abrir_db
from common.errores import ErrorNegocio
from common.migraciones import migrar
from common.seguridad import Guardia
from common.tiempo import iso
from common.vault_secrets import VaultSecrets

from .reglas import (es_mayor_de_edad, formatear_run, normalizar_run, validar_nacimiento, validar_telefono, validar_ubicacion)

SEMILLA = os.environ.get("SEED_DEMO_DATA", "false").lower() == "true"
vault = VaultSecrets()
guardia = Guardia("clients", vault)
GW = ("api-gateway",)
ADMIN = Depends(guardia.dep(GW, identidad="requerida", roles=("administrador",)))
db = None
interno = None


async def _indices(d):
    await d.clientes.create_index("run", unique=True)
    await d.clientes.create_index("correo", unique=True)
    await d.clientes.create_index("nombre")


MIGRACIONES = [(1, "índices únicos de RUN y correo", _indices)]


async def sembrar(d):
    n = 0
    for c in json.loads((Path(__file__).parent / "seed" / "clientes.json").read_text(encoding="utf-8")):
        if not await d.clientes.find_one({"_id": c["id"]}):
            doc = {**{k: v for k, v in c.items() if k != "id"}, "_id": c["id"], "run": normalizar_run(c["run"]), "estado": "activo",
                   "creadoEn": iso(), "actualizadoEn": iso()}
            await d.clientes.insert_one(doc)
            n += 1
    return n


@asynccontextmanager
async def lifespan(app):
    global db, interno
    await vault.aesperar("asador/db/clients")
    await guardia.precalentar()
    cliente, db = await abrir_db("clients", vault)
    interno = ClienteInterno("clients", vault, {"auth": os.environ["AUTH_URL"], "notifications": os.environ["NOTIFICATIONS_URL"]},
                             timeout=plazos.upstream("servicio"))
    await interno.precalentar()
    await migrar(db, MIGRACIONES)
    if SEMILLA:
        log.info("datos de prueba cargados", extra={"ctx": {"clientes_nuevos": await sembrar(db)}})
    app.state.chequeos.append(lambda: db.command("ping"))
    log.info("Clients listo")
    yield
    await interno.cerrar()
    cliente.close()


app, log = crear_app("clients", lifespan)


# ----------------------------- modelos ------------------------------------------
class DatosBase(BaseModel):
    model_config = ConfigDict(extra="forbid")
    nombre: str = Field(min_length=3, max_length=120)
    telefono: str
    direccion: str = Field(min_length=5, max_length=120)
    comuna: str = Field(min_length=3, max_length=40)

    @field_validator("nombre", "direccion")
    @classmethod
    def _t(cls, v):
        return " ".join(v.split())

    @field_validator("telefono")
    @classmethod
    def _tel(cls, v):
        return validar_telefono(v)


class RegistroWeb(DatosBase):
    run: str
    correo: str = Field(min_length=5, max_length=254)
    nacimiento: str
    sexo: Literal["Femenino", "Masculino", "Otro", "Prefiero no decirlo"]
    region: str
    provincia: str
    clave: str = Field(min_length=8, max_length=128)

    @field_validator("run")
    @classmethod
    def _run(cls, v):
        return normalizar_run(v)

    @field_validator("nacimiento")
    @classmethod
    def _nac(cls, v):
        return validar_nacimiento(v)

    @field_validator("correo")
    @classmethod
    def _correo(cls, v):
        return v.strip().lower()


class ClienteLocal(DatosBase):
    """RF6: alta hecha por el administrador en el local (sin clave: el cliente puede activar su acceso web después)."""
    run: str
    correo: str = Field(min_length=5, max_length=254)
    nacimiento: str | None = None
    sexo: Literal["Femenino", "Masculino", "Otro", "Prefiero no decirlo"] | None = None
    region: str | None = None
    provincia: str | None = None

    @field_validator("run")
    @classmethod
    def _run(cls, v):
        return normalizar_run(v)

    @field_validator("nacimiento")
    @classmethod
    def _nac(cls, v):
        return validar_nacimiento(v) if v else v

    @field_validator("correo")
    @classmethod
    def _correo(cls, v):
        return v.strip().lower()


class ClienteReemplazo(DatosBase):
    """PUT del administrador: representación editable. El RUN y el correo no cambian (son la identidad de la cuenta)."""
    nacimiento: str | None = None
    sexo: Literal["Femenino", "Masculino", "Otro", "Prefiero no decirlo"] | None = None
    region: str | None = None
    provincia: str | None = None

    @field_validator("nacimiento")
    @classmethod
    def _nac(cls, v):
        return validar_nacimiento(v) if v else v


def dto(d):
    """Vista completa del cliente: solo para su dueño y para el administrador. Nunca incluye la clave."""
    return {"id": d["_id"], "run": formatear_run(d["run"]), "nombre": d["nombre"], "correo": d["correo"], "telefono": d["telefono"],
            "region": d.get("region"), "provincia": d.get("provincia"), "comuna": d["comuna"], "direccion": d["direccion"],
            "nacimiento": d.get("nacimiento"), "sexo": d.get("sexo"), "origen": d["origen"], "estado": d["estado"],
            "tieneAcceso": bool(d.get("authUserId"))}


def _ubicacion(d):
    try:
        validar_ubicacion(d.region, d.provincia, d.comuna)
    except ValueError as e:
        raise ErrorNegocio(422, "UBICACION_INVALIDA", str(e))


async def _validar_correo_existente(correo, ll):
    try:
        r = await interno.llamar("notifications", "POST", "/internal/email/validate", request_id=ll.request_id, json={"correo": correo})
    except ServicioNoDisponible:
        raise ErrorNegocio(503, "VALIDACION_CORREO_NO_DISPONIBLE", "No pudimos validar tu correo en este momento. Intenta nuevamente en unos minutos.")
    if r.status_code != 200:
        raise ErrorNegocio(503, "VALIDACION_CORREO_NO_DISPONIBLE", "No pudimos validar tu correo en este momento. Intenta nuevamente en unos minutos.")
    res = r.json()
    if not res["valido"]:
        raise ErrorNegocio(422, "CORREO_NO_EXISTE", res.get("motivo") or "El correo no existe o no está activo")


async def _crear_credencial(datos_cliente, client_id, ll):
    try:
        r = await interno.llamar("auth", "POST", "/internal/credentials", request_id=ll.request_id,
                                 json={"username": datos_cliente["correo"], "password": datos_cliente["clave"],
                                       "nombre": datos_cliente["nombre"], "clientId": client_id})
    except ServicioNoDisponible:
        raise ErrorNegocio(503, "SERVICIO_NO_DISPONIBLE", "No pudimos crear tu cuenta en este momento. Intenta nuevamente en unos minutos.")
    if r.status_code in (200, 201):   # 200: la credencial ya existía por un intento anterior con la misma clave
        return r.json()["user_id"]
    c = cuerpo(r)
    if r.status_code == 422 and c.get("codigo") == "CLAVE_DEBIL":
        raise ErrorNegocio(422, "CLAVE_DEBIL", c.get("detail", "La contraseña no cumple la política"))
    if r.status_code == 409:
        raise ErrorNegocio(409, "CUENTA_NO_DISPONIBLE", "No pudimos crear la cuenta con esos datos. Si ya tienes una, usa «Acceder».")
    raise ErrorNegocio(503, "SERVICIO_NO_DISPONIBLE", "No pudimos crear tu cuenta en este momento. Intenta nuevamente en unos minutos.")


async def _bienvenida(client_id, nombre, correo, ll):
    try:  # mejor esfuerzo: si el correo no sale, la cuenta igual queda creada
        await interno.llamar("notifications", "POST", "/internal/email/send", request_id=ll.request_id, json={
            "tipo": "bienvenida", "para": correo, "asunto": "Bienvenido/a a El Asador", "clave": f"bienvenida:{client_id}",
            "texto": f"Hola {nombre.split()[0]}, tu cuenta en El Asador está lista. Ya puedes armar tu pedido y pagar en línea."})
    except ServicioNoDisponible:
        log.warning("no se pudo enviar la bienvenida", extra={"ctx": {"client_id": client_id}})


# ----------------------------- registro web (anónimo) ----------------------------
@app.post("/clients/register", status_code=201)
async def registrar(datos: RegistroWeb, ll=Depends(guardia.dep(GW))):
    _ubicacion(datos)
    previos = await db.clientes.find({"$or": [{"run": datos.run}, {"correo": datos.correo}]}).to_list(5)
    reclamable = None
    if previos:
        # Un cliente dado de alta en el local (sin acceso web) puede activar su cuenta si RUN y correo coinciden.
        if len(previos) == 1 and previos[0]["run"] == datos.run and previos[0]["correo"] == datos.correo \
                and not previos[0].get("authUserId") and previos[0]["estado"] == "activo":
            reclamable = previos[0]
        else:
            raise ErrorNegocio(409, "CUENTA_NO_DISPONIBLE", "No pudimos crear la cuenta con esos datos. Si ya tienes una, usa «Acceder».")
    if not reclamable:
        await _validar_correo_existente(datos.correo, ll)

    campos = {"nombre": datos.nombre, "telefono": datos.telefono, "region": datos.region, "provincia": datos.provincia,
              "comuna": datos.comuna, "direccion": datos.direccion, "nacimiento": datos.nacimiento, "sexo": datos.sexo}
    if reclamable:
        client_id = reclamable["_id"]
        user_id = await _crear_credencial(datos.model_dump(), client_id, ll)
        await db.clientes.update_one({"_id": client_id}, {"$set": {**campos, "authUserId": user_id, "actualizadoEn": iso()}})
        doc = {**reclamable, **campos, "authUserId": user_id}
    else:
        client_id = "c-" + uuid.uuid4().hex[:10]
        doc = {"_id": client_id, "run": datos.run, "correo": datos.correo, **campos, "origen": "Web", "estado": "activo",
               "authUserId": None, "creadoEn": iso(), "actualizadoEn": iso()}
        try:
            await db.clientes.insert_one(doc)
        except DuplicateKeyError:
            raise ErrorNegocio(409, "CUENTA_NO_DISPONIBLE", "No pudimos crear la cuenta con esos datos. Si ya tienes una, usa «Acceder».")
        try:
            doc["authUserId"] = await _crear_credencial(datos.model_dump(), client_id, ll)
        except ErrorNegocio as e:
            if e.codigo != "SERVICIO_NO_DISPONIBLE":
                await db.clientes.delete_one({"_id": client_id})  # rechazo definitivo (clave débil, correo ya usado): no queda un perfil sin credencial
            # Si Auth no respondió no sabemos si alcanzó a crear la cuenta: el perfil se conserva y repetir el registro con el mismo
            # RUN y correo lo completa (Auth devuelve la misma credencial si es la misma clave).
            raise
        await db.clientes.update_one({"_id": client_id}, {"$set": {"authUserId": doc["authUserId"]}})
    await auditoria.registrar(db, ll, "cliente.registro_web", f"cliente:{client_id}", {"reclamo_alta_local": bool(reclamable)})
    await _bienvenida(client_id, datos.nombre, datos.correo, ll)
    return dto(doc)


# ----------------------------- perfil propio -------------------------------------
@app.get("/clients/me")
async def mi_perfil(ll=Depends(guardia.dep(GW, identidad="requerida", roles=("cliente",)))):
    d = await db.clientes.find_one({"_id": ll.identidad.client_id}) if ll.identidad.client_id else None
    if not d:
        raise ErrorNegocio(404, "CLIENTE_NO_ENCONTRADO", "No encontramos tu perfil de cliente")
    return dto(d)


# ----------------------------- mantenedor del administrador (CU3) ----------------
@app.get("/clients")
async def listar(response: Response, q: str = Query(default="", max_length=60), limit: int = Query(default=50, ge=1, le=100),
                 offset: int = Query(default=0, ge=0, le=100000), ll=ADMIN):
    filtro = {}
    if q.strip():
        t = re.escape(q.strip())
        solo_run = re.sub(r"[.\-\s]", "", q.strip()).upper()
        filtro["$or"] = [{"nombre": {"$regex": t, "$options": "i"}}, {"correo": {"$regex": t, "$options": "i"}}]
        if re.fullmatch(r"[0-9K]{3,9}", solo_run):
            filtro["$or"].append({"run": {"$regex": "^" + solo_run}})
    response.headers["X-Total-Count"] = str(await db.clientes.count_documents(filtro))
    cur = db.clientes.find(filtro).sort("nombre", 1).skip(offset).limit(limit)
    await auditoria.registrar(db, ll, "cliente.consultar_lista", "clientes", {"filtro": bool(q.strip())})
    return [dto(d) async for d in cur]


@app.post("/clients", status_code=201)
async def crear_local(datos: ClienteLocal, ll=ADMIN):
    if datos.region or datos.provincia:
        _ubicacion(datos)
    else:
        try:
            validar_ubicacion(None, None, datos.comuna)
        except ValueError as e:
            raise ErrorNegocio(422, "UBICACION_INVALIDA", str(e))
    if await db.clientes.find_one({"$or": [{"run": datos.run}, {"correo": datos.correo}]}):
        raise ErrorNegocio(409, "CLIENTE_EXISTE", "Ya existe un cliente con ese RUN o correo.")
    await _validar_correo_existente(datos.correo, ll)
    doc = {"_id": "c-" + uuid.uuid4().hex[:10], "run": datos.run, "correo": datos.correo, "nombre": datos.nombre, "telefono": datos.telefono,
           "region": datos.region, "provincia": datos.provincia, "comuna": datos.comuna, "direccion": datos.direccion,
           "nacimiento": datos.nacimiento, "sexo": datos.sexo, "origen": "Local", "estado": "activo", "authUserId": None,
           "creadoEn": iso(), "actualizadoEn": iso()}
    try:
        await db.clientes.insert_one(doc)
    except DuplicateKeyError:
        raise ErrorNegocio(409, "CLIENTE_EXISTE", "Ya existe un cliente con ese RUN o correo.")
    await auditoria.registrar(db, ll, "cliente.crear_local", f"cliente:{doc['_id']}")
    return dto(doc)


async def _cliente_o_404(id):
    d = await db.clientes.find_one({"_id": id})
    if not d:
        raise ErrorNegocio(404, "CLIENTE_NO_ENCONTRADO", "Cliente no encontrado")
    return d


@app.put("/clients/{id}")
async def reemplazar(id: str, datos: ClienteReemplazo, ll=ADMIN):
    anterior = await _cliente_o_404(id)
    if datos.region or datos.provincia:
        _ubicacion(datos)
    else:
        try:
            validar_ubicacion(None, None, datos.comuna)
        except ValueError as e:
            raise ErrorNegocio(422, "UBICACION_INVALIDA", str(e))
    cambios = {"nombre": datos.nombre, "telefono": datos.telefono, "region": datos.region, "provincia": datos.provincia,
               "comuna": datos.comuna, "direccion": datos.direccion, "nacimiento": datos.nacimiento, "sexo": datos.sexo, "actualizadoEn": iso()}
    await db.clientes.update_one({"_id": id}, {"$set": cambios})
    await auditoria.registrar(db, ll, "cliente.modificar", f"cliente:{id}", {"campos": sorted(k for k in cambios if k != "actualizadoEn")})
    return dto({**anterior, **cambios})


@app.delete("/clients/{id}")
async def desactivar(id: str, ll=ADMIN):
    """DELETE = baja lógica. Se conserva el perfil porque los pedidos y boletas emitidos deben poder respaldarse (ver docs, retención)."""
    d = await _cliente_o_404(id)
    if d.get("authUserId"):
        try:
            r = await interno.llamar("auth", "PUT", f"/internal/credentials/{d['authUserId']}/estado", request_id=ll.request_id, json={"activo": False})
        except ServicioNoDisponible:
            raise ErrorNegocio(503, "SERVICIO_NO_DISPONIBLE", "No se pudo desactivar el acceso del cliente ahora. Intenta nuevamente.")
        if r.status_code != 200:
            raise ErrorNegocio(503, "SERVICIO_NO_DISPONIBLE", "No se pudo desactivar el acceso del cliente ahora. Intenta nuevamente.")
    await db.clientes.update_one({"_id": id}, {"$set": {"estado": "inactivo", "actualizadoEn": iso()}})
    await auditoria.registrar(db, ll, "cliente.desactivar", f"cliente:{id}")
    return {"id": id, "estado": "inactivo"}


# ----------------------------- contrato interno para orders -----------------------
@app.get("/internal/clients/{id}/delivery-profile")
async def perfil_de_entrega(id: str, ll=Depends(guardia.dep(("orders",), identidad="requerida", roles=("cliente",)))):
    """Datos mínimos para despachar un pedido. Solo el propio cliente (identidad verificada) puede pedir los suyos."""
    if ll.identidad.client_id != id:
        raise ErrorNegocio(403, "PROHIBIDO", "No tiene permisos para esta operación")
    d = await _cliente_o_404(id)
    if d["estado"] != "activo":
        raise ErrorNegocio(409, "CLIENTE_INACTIVO", "La cuenta del cliente está inactiva")
    return {"id": id, "nombre": d["nombre"], "correo": d["correo"], "telefono": d["telefono"], "direccion": d["direccion"],
            "comuna": d["comuna"], "mayorDeEdad": es_mayor_de_edad(d.get("nacimiento"))}
