"""Reglas puras de clients: RUN chileno, teléfono, ubicación y mayoría de edad."""
import re
from datetime import date

# Región > provincia > comuna (misma estructura que usa el formulario de registro).
UBICACIONES = {
    "Región Metropolitana de Santiago": {
        "Santiago": ["Santiago", "Providencia", "Ñuñoa", "Las Condes", "La Reina", "Macul", "San Miguel", "La Florida", "Maipú"],
        "Cordillera": ["Puente Alto"],
    }
}
SEXOS = ("Femenino", "Masculino", "Otro", "Prefiero no decirlo")
TELEFONO_RE = re.compile(r"^\+?[0-9][0-9 ]{7,15}$")


def digito_verificador(cuerpo):
    """Módulo 11 del RUN chileno."""
    suma, factor = 0, 2
    for d in reversed(str(cuerpo)):
        suma += int(d) * factor
        factor = 2 if factor == 7 else factor + 1
    resto = 11 - suma % 11
    return "0" if resto == 11 else "K" if resto == 10 else str(resto)


def normalizar_run(texto):
    """'12.345.678-5' -> '123456785'. Lanza ValueError si el formato o el dígito verificador no son válidos."""
    limpio = re.sub(r"[.\-\s]", "", (texto or "")).upper()
    if not re.fullmatch(r"[0-9]{7,8}[0-9K]", limpio):
        raise ValueError("El RUN no tiene un formato válido (ejemplo: 12.345.678-5)")
    cuerpo, dv = limpio[:-1], limpio[-1]
    if digito_verificador(cuerpo) != dv:
        raise ValueError("El dígito verificador del RUN no es correcto")
    return limpio


def formatear_run(normalizado):
    cuerpo, dv = normalizado[:-1], normalizado[-1]
    return f"{int(cuerpo):,}".replace(",", ".") + "-" + dv


def validar_telefono(texto):
    t = (texto or "").strip()
    if not TELEFONO_RE.fullmatch(t):
        raise ValueError("El teléfono debe tener entre 8 y 16 dígitos (ejemplo: +56 9 1234 5678)")
    return t


def validar_ubicacion(region, provincia, comuna):
    if region is None and provincia is None:
        if not any(comuna in cs for provs in UBICACIONES.values() for cs in provs.values()):
            raise ValueError("Solo despachamos en la Región Metropolitana: la comuna no tiene cobertura")
        return
    if region not in UBICACIONES or provincia not in UBICACIONES[region] or comuna not in UBICACIONES[region][provincia]:
        raise ValueError("La región, provincia y comuna no son coherentes entre sí")


def edad(nacimiento, hoy=None):
    hoy = hoy or date.today()
    n = date.fromisoformat(nacimiento)
    return hoy.year - n.year - ((hoy.month, hoy.day) < (n.month, n.day))


def validar_nacimiento(texto, hoy=None):
    try:
        e = edad(texto, hoy)
    except ValueError:
        raise ValueError("La fecha de nacimiento no es válida (AAAA-MM-DD)")
    if e < 0 or e > 120:
        raise ValueError("La fecha de nacimiento no es plausible")
    return texto


def es_mayor_de_edad(nacimiento, hoy=None):
    return bool(nacimiento) and edad(nacimiento, hoy) >= 18
