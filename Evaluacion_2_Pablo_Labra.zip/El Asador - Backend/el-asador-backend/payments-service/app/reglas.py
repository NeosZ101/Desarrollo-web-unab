"""Reglas puras de payments: firma de avisos, IVA de la boleta e instrucciones de pago manual.

Sin red ni base de datos, para probarlas (y mutarlas) de forma aislada.
"""
import hashlib
import hmac

TOLERANCIA_SEGUNDOS = 300       # un aviso firmado hace más de 5 minutos (o del futuro) se rechaza
MEDIOS_MANUALES = ("Transferencia bancaria", "Depósito bancario")
IVA_TASA = 19

# Datos públicos del negocio para transferir o depositar. Son datos de EJEMPLO (no son secretos ni reales).
DATOS_BANCARIOS = {"banco": "Banco de ejemplo", "tipoCuenta": "Cuenta corriente", "numero": "000-00000-00",
                   "titular": "Parrilladas El Asador SpA", "rut": "76.123.456-0", "correo": "pagos@elasador.cl"}


def clp(n):
    return "$" + f"{int(n):,}".replace(",", ".")


def desglose_iva(total, tasa=IVA_TASA):
    """Los precios de la carta ya incluyen IVA: neto = total / 1,19 (redondeado) e IVA = total - neto."""
    divisor = 100 + tasa
    neto = (total * 100 + divisor // 2) // divisor
    return neto, total - neto


def firmar(secreto, t, cuerpo):
    return hmac.new(secreto.encode(), f"{t}.".encode() + cuerpo, hashlib.sha256).hexdigest()


def verificar_firma(secreto, cabecera, cuerpo, ahora, tolerancia=TOLERANCIA_SEGUNDOS):
    """Cabecera «t=<unix>,v1=<hex>». Devuelve (ok, motivo). El motivo es solo para el log, no para quien llama."""
    if not cabecera:
        return False, "firma_ausente"
    partes = {}
    for trozo in cabecera.split(","):
        k, _, v = trozo.strip().partition("=")
        partes.setdefault(k, []).append(v)
    try:
        t = int(partes["t"][0])
    except (KeyError, ValueError, IndexError):
        return False, "formato_invalido"
    candidatas = partes.get("v1", [])
    if not candidatas:
        return False, "formato_invalido"
    if abs(ahora - t) > tolerancia:
        return False, "fuera_de_ventana"
    esperada = firmar(secreto, t, cuerpo)
    if not any(hmac.compare_digest(c.encode(), esperada.encode()) for c in candidatas):
        return False, "firma_incorrecta"
    return True, "ok"


def instrucciones_manual(medio, monto, pedido_id):
    d = DATOS_BANCARIOS
    verbo = "Transfiere" if medio == "Transferencia bancaria" else "Deposita"
    return (f"{verbo} {clp(monto)} a {d['titular']} (RUT {d['rut']}), {d['banco']}, {d['tipoCuenta']} N° {d['numero']}. "
            f"Indica el pedido {pedido_id} y envía el comprobante a {d['correo']}. Confirmaremos tu pago dentro del día hábil.")


def texto_boleta(v):
    filas = "\n".join(f"  {l['cantidad']} x {l['nombre']}: {clp(l['precio'] * l['cantidad'])}" for l in v["lineas"])
    return (f"Boleta electrónica {v['_id']} (comprobante de ejemplo)\nPedido {v['pedidoId']} · {v['fecha'][:10]}\n\n{filas}\n"
            f"  Despacho: {clp(v['despacho'])}\n\nNeto: {clp(v['neto'])}\nIVA ({IVA_TASA}%): {clp(v['iva'])}\nTotal: {clp(v['total'])}\n"
            f"Medio de pago: {v['medio']}\n\nGracias por preferir Parrilladas El Asador.")
