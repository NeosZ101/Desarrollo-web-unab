"""Payments (privado): pagos, ventas, boletas y reembolsos. Es la AUTORIDAD del dinero.

Reglas que garantiza este servicio:
  * El monto a cobrar sale de `orders` (nunca del navegador) y se compara con lo que informa el proveedor.
  * Un pago se aprueba SOLO por (a) un aviso firmado del proveedor (HMAC + ventana de tiempo + idempotencia)
    o (b) la confirmación manual de un administrador, solo para transferencia/depósito. Jamás por el navegador.
  * Con el pago aprobado, payments le pide a `orders` pasar a «En preparación»; recién entonces nace la venta y su boleta.
  * Los efectos hacia otros servicios (orders, analytics, correo) se reintentan solos hasta confirmarse
    (marcas en cada documento + un ciclo periódico), así una caída momentánea no deja datos a medias.
  * Un pago que llega después de anular el pedido se reembolsa (queda "pendiente" para el administrador).
"""
import asyncio
import os
import re
import time
import uuid
from contextlib import asynccontextmanager
from datetime import timedelta
from typing import Annotated

import httpx
from fastapi import Depends, Path, Query, Request, Response
from pydantic import BaseModel, ConfigDict, Field, ValidationError
from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError

from common import auditoria, plazos
from common.app import crear_app
from common.cliente_interno import ClienteInterno, ServicioNoDisponible, cuerpo
from common.db import abrir_db
from common.errores import ErrorNegocio
from common.migraciones import migrar
from common.seguridad import Guardia
from common.tiempo import ahora, fecha_local, iso
from common.vault_secrets import SecretUnavailable, VaultSecrets

from .reglas import DATOS_BANCARIOS, IVA_TASA, MEDIOS_MANUALES, desglose_iva, instrucciones_manual, texto_boleta, verificar_firma

vault = VaultSecrets()
guardia = Guardia("payments", vault)
GW = ("api-gateway",)
PROVIDER_URL = os.environ.get("PROVIDER_URL", "http://provider-sandbox:8300").rstrip("/")
VOLVER_A = (os.environ.get("PUBLIC_BASE_URL") or os.environ.get("GATEWAY_URL") or "http://localhost:8000").rstrip("/")
CONCILIAR_DESPUES = float(os.environ.get("CONCILIAR_DESPUES_SEGUNDOS", "120"))
PEDIDO_RE = re.compile(r"^A-\d{3,9}$")
# Respuestas de orders que significan «no» de verdad (el pago no puede quedar en ese pedido y se devuelve). Lo demás NO es un rechazo.
RECHAZOS_DE_PEDIDOS = frozenset({"PEDIDO_ANULADO", "MONTO_NO_COINCIDE", "TRANSICION_NO_PERMITIDA", "PEDIDO_NO_ENCONTRADO"})
EMISOR ={"razonSocial": "Parrilladas El Asador SpA", "rut": "76.123.456-0", "giro": "Restaurante y venta de comida preparada"}
db = None
interno = None
http = None
ID = Annotated[str, Path(pattern=r"^A-\d{3,9}$")]

CLIENTE = Depends(guardia.dep(GW, identidad="requerida", roles=("cliente",)))
CLIENTE_O_ADMIN = Depends(guardia.dep(GW, identidad="requerida", roles=("cliente", "administrador")))
ADMIN = Depends(guardia.dep(GW, identidad="requerida", roles=("administrador",)))


async def _indices(d):
    await d.pagos.create_index([("pedidoId", 1), ("creadoEn", -1)])
    # a lo más UN pago "iniciado" por pedido: dos clics seguidos no generan dos cobros
    await d.pagos.create_index("pedidoId", unique=True, partialFilterExpression={"estado": "iniciado"}, name="un_pago_iniciado_por_pedido")
    await d.pagos.create_index("proveedorPagoId", unique=True, partialFilterExpression={"proveedorPagoId": {"$type": "string"}})
    await d.pagos.create_index([("estado", 1), ("creadoEn", -1)])
    await d.ventas.create_index("pagoId", unique=True)
    await d.ventas.create_index("pedidoId", unique=True)
    await d.ventas.create_index("fechaLocal")
    await d.contadores.update_one({"_id": "ventas"}, {"$setOnInsert": {"seq": 0}}, upsert=True)


MIGRACIONES = [(1, "índices de pagos y ventas, contador de folios", _indices)]


@asynccontextmanager
async def lifespan(app):
    global db, interno, http
    await vault.aesperar("asador/db/payments")
    await guardia.precalentar()
    for ruta in ("asador/provider/api-key", "asador/provider/webhook-secret"):
        await vault.aesperar(ruta)
    cliente, db = await abrir_db("payments", vault)
    urls = {k: os.environ[v] for k, v in (("orders", "ORDERS_URL"), ("notifications", "NOTIFICATIONS_URL"), ("analytics", "ANALYTICS_URL"))}
    interno = ClienteInterno("payments", vault, urls, timeout=plazos.upstream("servicio"),
                             pausa_circuito=float(os.environ.get("CIRCUITO_PAUSA", "5")))
    await interno.precalentar()
    http = httpx.AsyncClient(timeout=httpx.Timeout(plazos.proveedor(), connect=2.0))
    await migrar(db, MIGRACIONES)
    app.state.chequeos.append(lambda: db.command("ping"))
    tarea = asyncio.create_task(_ciclos())
    log.info("Payments listo")
    yield
    tarea.cancel()
    await interno.cerrar()
    await http.aclose()
    cliente.close()


app, log = crear_app("payments", lifespan)


# ----------------------------- proveedor de pagos (externo) -------------------------
class ProveedorNoDisponible(Exception):
    pass


async def _proveedor(metodo, ruta, cuerpo_json=None):
    try:
        clave = await vault.avalor("asador/provider/api-key")
    except SecretUnavailable:
        raise ProveedorNoDisponible("sin_credencial")
    try:
        r = await http.request(metodo, PROVIDER_URL + ruta, json=cuerpo_json, headers={"Authorization": f"Bearer {clave}"})
    except httpx.HTTPError:
        raise ProveedorNoDisponible("conexion")
    if r.status_code >= 500:
        raise ProveedorNoDisponible(f"http_{r.status_code}")
    return r


# ----------------------------- modelos y vistas ------------------------------------
class ConfirmacionManual(BaseModel):
    model_config = ConfigDict(extra="forbid")
    referencia: str = Field(pattern=r"^[A-Za-z0-9 ._/#-]{3,60}$")


class ReembolsoIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    referencia: str | None = Field(default=None, pattern=r"^[A-Za-z0-9 ._/#-]{3,60}$")


class MotivoIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    motivo: str = Field(min_length=1, max_length=300)


class DatosEvento(BaseModel):
    model_config = ConfigDict(extra="ignore")   # un proveedor externo puede agregar campos
    payment_id: str = Field(max_length=60)
    reference: str = Field(max_length=60)
    amount: int
    currency: str = Field(default="CLP", max_length=3)


class EventoProveedor(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(pattern=r"^evt_[A-Za-z0-9]{8,40}$")
    type: str = Field(max_length=40)
    created: int
    data: DatosEvento


def pago_dto(d):
    out = {"id": d["_id"], "pedidoId": d["pedidoId"], "estado": d["estado"], "medio": d["medio"], "modo": d["modo"], "monto": d["monto"],
           "creadoEn": d["creadoEn"], "aprobadoEn": d.get("aprobadoEn")}
    if d["estado"] == "iniciado":
        if d["modo"] == "proveedor":
            out["checkoutUrl"] = d.get("checkoutUrl")
        else:
            out["instrucciones"] = instrucciones_manual(d["medio"], d["monto"], d["pedidoId"])
            out["datosBancarios"] = DATOS_BANCARIOS
    r = d.get("reembolso")
    out["reembolso"] = {"estado": r["estado"], "solicitadoEn": r["solicitadoEn"], "realizadoEn": r.get("realizadoEn")} if r else None
    return out


def boleta_dto(v):
    return {"folio": v["_id"], "fecha": v["fecha"], "pedidoId": v["pedidoId"], "estado": v["estado"], "emisor": EMISOR, "cliente": v["cliente"],
            "lineas": v["lineas"], "subtotal": v["subtotal"], "despacho": v["despacho"], "neto": v["neto"], "iva": v["iva"], "ivaTasa": IVA_TASA,
            "total": v["total"], "medioPago": v["medio"]}


def _prohibido():
    return ErrorNegocio(403, "PROHIBIDO", "No tiene permisos para esta operación")


def _no_disponible(detalle="El servicio no está disponible en este momento. Intenta nuevamente en unos minutos."):
    return ErrorNegocio(503, "SERVICIO_NO_DISPONIBLE", detalle, headers={"Retry-After": "10"})


async def _pedido_de(id, ll):
    """Datos del pedido según `orders` (autoridad). El cliente solo opera sobre SU pedido: ajeno e inexistente dan el mismo 403."""
    try:
        r = await interno.llamar("orders", "GET", f"/internal/orders/{id}/payable", request_id=ll.request_id)
    except ServicioNoDisponible as e:
        log.warning("orders no disponible", extra={"ctx": {"motivo": e.motivo, "request_id": ll.request_id}})
        raise _no_disponible()
    staff = ll.identidad.tiene("administrador")
    if r.status_code == 404:
        raise ErrorNegocio(404, "PEDIDO_NO_ENCONTRADO", "Pedido no encontrado") if staff else _prohibido()
    if r.status_code != 200:
        raise _no_disponible()
    p = r.json()
    if not staff and p["clienteId"] != ll.identidad.client_id:
        raise _prohibido()
    return p


# ----------------------------- iniciar y consultar el pago (cliente) ----------------
@app.post("/orders/{id}/payment", status_code=201)
async def iniciar_pago(response: Response, id: ID, ll=CLIENTE):
    p = await _pedido_de(id, ll)
    if p["estado"] != "Pago pendiente":
        raise ErrorNegocio(409, "PEDIDO_NO_PAGABLE", f"El pedido {id} está «{p['estado']}»: no admite un pago nuevo.")
    previo = await db.pagos.find_one({"pedidoId": id, "estado": "iniciado"})
    if previo:
        if previo["modo"] == "proveedor" and not previo.get("proveedorPagoId"):
            raise ErrorNegocio(409, "PAGO_EN_PROCESO", "Estamos preparando tu pago. Intenta de nuevo en unos segundos.", headers={"Retry-After": "2"})
        response.status_code = 200   # repetir la solicitud devuelve el mismo cobro, no crea otro
        return pago_dto(previo)
    modo = "manual" if p["medioPago"] in MEDIOS_MANUALES else "proveedor"
    pid = "pay-" + uuid.uuid4().hex[:16]
    ahora = iso()
    doc = {"_id": pid, "pedidoId": id, "clienteId": p["clienteId"], "monto": p["total"], "medio": p["medioPago"], "modo": modo, "estado": "iniciado",
           "creadoEn": ahora, "actualizadoEn": ahora, "pedidoNotificado": False, "ventaId": None, "ventaLease": None, "reembolso": None}
    try:
        await db.pagos.insert_one(doc)
    except DuplicateKeyError:   # carrera: otra solicitud creó el cobro un instante antes
        raise ErrorNegocio(409, "PAGO_EN_PROCESO", "Estamos preparando tu pago. Intenta de nuevo en unos segundos.", headers={"Retry-After": "2"})
    if modo == "proveedor":
        try:
            r = await _proveedor("POST", "/v1/payments", {"reference": pid, "amount": doc["monto"], "currency": "CLP",
                                                          "description": f"Pedido {id}", "return_url": f"{VOLVER_A}/pedidos.html?pedido={id}"})
            if r.status_code not in (200, 201):
                raise ProveedorNoDisponible(f"http_{r.status_code}")
            prov = r.json()
        except ProveedorNoDisponible as e:
            await db.pagos.update_one({"_id": pid, "estado": "iniciado"}, {"$set": {"estado": "cancelado", "cierre": "proveedor_no_disponible", "actualizadoEn": iso()}})
            log.warning("proveedor de pagos no disponible", extra={"ctx": {"motivo": str(e), "request_id": ll.request_id}})
            raise ErrorNegocio(503, "PROVEEDOR_PAGO_NO_DISPONIBLE",
                               "El medio de pago no está disponible en este momento. Tu pedido quedó guardado: intenta pagar nuevamente en unos minutos.",
                               headers={"Retry-After": "10"})
        doc["proveedorPagoId"], doc["checkoutUrl"] = prov["id"], prov["checkout_url"]
        await db.pagos.update_one({"_id": pid}, {"$set": {"proveedorPagoId": prov["id"], "checkoutUrl": prov["checkout_url"]}})
    await auditoria.registrar(db, ll, "pago.iniciar", f"pago:{pid}", {"pedido": id, "monto": doc["monto"], "modo": modo})
    return pago_dto(doc)


@app.get("/orders/{id}/payment")
async def estado_pago(id: ID, ll=CLIENTE_O_ADMIN):
    await _pedido_de(id, ll)
    d = await db.pagos.find({"pedidoId": id}).sort("creadoEn", -1).limit(1).to_list(1)
    if not d:
        raise ErrorNegocio(404, "SIN_PAGO", "Este pedido todavía no tiene un pago iniciado")
    return pago_dto(d[0])


@app.get("/orders/{id}/receipt")
async def boleta(id: ID, ll=CLIENTE_O_ADMIN):
    await _pedido_de(id, ll)
    v = await db.ventas.find_one({"pedidoId": id})
    if not v:
        raise ErrorNegocio(404, "SIN_BOLETA", "Este pedido todavía no tiene boleta: se emite cuando el pago está confirmado.")
    return boleta_dto(v)


# ----------------------------- aprobación del pago ---------------------------------
async def aprobar(pid, *, origen, request_id, ll=None, referencia=None, actor=None):
    """ÚNICA función que marca un pago como aprobado. Es atómica: de dos aprobaciones simultáneas, solo una gana."""
    ahora = iso()
    pago = await db.pagos.find_one_and_update(
        {"_id": pid, "estado": "iniciado"},
        {"$set": {"estado": "aprobado", "aprobadoEn": ahora, "actualizadoEn": ahora, "origenAprobacion": origen, "referencia": referencia, "confirmadoPor": actor}},
        return_document=ReturnDocument.AFTER)
    resultado = "aprobado"
    if pago is None:
        previo = await db.pagos.find_one({"_id": pid})
        if previo and previo["estado"] == "cancelado" and previo.get("cierre") == "pedido_anulado":
            # el cliente alcanzó a pagar en el proveedor y el pedido ya estaba anulado: el dinero llegó, hay que devolverlo
            pago = await db.pagos.find_one_and_update(
                {"_id": pid, "estado": "cancelado"},
                {"$set": {"estado": "aprobado", "aprobadoEn": ahora, "actualizadoEn": ahora, "origenAprobacion": origen, "tardio": True, "pedidoNotificado": False}},
                return_document=ReturnDocument.AFTER)
            resultado = "tardio"
        if pago is None:
            return "sin_cambios"
    await auditoria.registrar(db, ll, "pago.aprobar", f"pago:{pid}", {"origen": origen, "tardio": resultado == "tardio"})
    await _notificar_pedido(pago, request_id)
    return resultado


def _reembolso_auto(motivo):
    return {"estado": "pendiente", "motivo": motivo, "solicitadoEn": iso(), "automatico": True}


async def _notificar_pedido(pago, request_id):
    """Le avisa a orders que el pago está confirmado. Devuelve True si quedó resuelto (bien o con reembolso)."""
    if pago.get("pedidoNotificado") is not False:
        return True
    try:
        r = await interno.llamar("orders", "POST", f"/internal/orders/{pago['pedidoId']}/payment-confirmed", request_id=request_id,
                                 json={"pagoId": pago["_id"], "monto": pago["monto"]})
    except ServicioNoDisponible as e:
        log.warning("orders no disponible: la confirmación queda para reintento", extra={"ctx": {"pago": pago["_id"], "motivo": e.motivo}})
        return False
    if r.status_code == 200:
        await db.pagos.update_one({"_id": pago["_id"]}, {"$set": {"pedidoNotificado": True}})
        return await _registrar_venta({**pago, "pedidoNotificado": True}, request_id)
    codigo = cuerpo(r).get("codigo")
    if codigo not in RECHAZOS_DE_PEDIDOS:
        # Esto NO es un «no» de orders (p. ej. CONFLICTO_DE_ESTADO: perdió una carrera con otra solicitud). Devolver el dinero sin estar
        # seguros reembolsaría un pedido que sí se cobró y avanzó: se deja para el siguiente ciclo, que recibirá la respuesta definitiva.
        log.warning("orders respondió algo que no es un rechazo del pago: la confirmación queda para reintento",
                    extra={"ctx": {"pago": pago["_id"], "codigo": codigo, "status": r.status_code}})
        if codigo != "CONFLICTO_DE_ESTADO":   # lo esperable se resuelve solo; lo inesperado se deja a la vista del administrador
            await db.pagos.update_one({"_id": pago["_id"]}, {"$set": {"alerta": f"pedidos_respondio_{codigo or r.status_code}"}})
        return False
    anulado = r.status_code == 409 and codigo == "PEDIDO_ANULADO"
    motivo = "Pago recibido después de anular el pedido" if anulado else f"El pedido no pudo confirmarse ({codigo or r.status_code})"
    log.error("orders no aceptó la confirmación del pago: se reembolsará", extra={"ctx": {"pago": pago["_id"], "codigo": codigo, "status": r.status_code}})
    await db.pagos.update_one({"_id": pago["_id"], "reembolso": None},
                              {"$set": {"reembolso": _reembolso_auto(motivo), "alerta": None if anulado else codigo}})
    await db.pagos.update_one({"_id": pago["_id"]}, {"$set": {"pedidoNotificado": "anulado" if anulado else "rechazado"}})
    return True


# ----------------------------- ventas y boletas -------------------------------------
async def _registrar_venta(pago, request_id):
    if pago.get("ventaId") or pago.get("reembolso"):
        return True   # ya existe, o el pago se está devolviendo: no es una venta
    previa = await db.ventas.find_one({"pagoId": pago["_id"]})
    if previa:
        await db.pagos.update_one({"_id": pago["_id"]}, {"$set": {"ventaId": previa["_id"]}})
        return True
    ahora_s = time.time()
    tomado = await db.pagos.find_one_and_update(   # un solo proceso emite el folio de este pago (la numeración no tiene saltos)
        {"_id": pago["_id"], "ventaId": None, "$or": [{"ventaLease": None}, {"ventaLease": {"$lt": ahora_s}}]},
        {"$set": {"ventaLease": ahora_s + 30}})
    if not tomado:
        return False
    try:
        r = await interno.llamar("orders", "GET", f"/internal/orders/{pago['pedidoId']}/payable", request_id=request_id)
    except ServicioNoDisponible:
        await db.pagos.update_one({"_id": pago["_id"]}, {"$set": {"ventaLease": None}})
        return False
    if r.status_code != 200:
        await db.pagos.update_one({"_id": pago["_id"]}, {"$set": {"ventaLease": None}})
        return False
    p = r.json()
    seq = (await db.contadores.find_one_and_update({"_id": "ventas"}, {"$inc": {"seq": 1}}, upsert=True, return_document=ReturnDocument.AFTER))["seq"]
    folio = f"B-{seq:06d}"
    neto, iva = desglose_iva(pago["monto"])
    venta = {"_id": folio, "pagoId": pago["_id"], "pedidoId": pago["pedidoId"], "clienteId": pago["clienteId"], "fecha": iso(), "fechaLocal": fecha_local(),
             "cliente": p["cliente"], "comuna": p.get("comuna"), "lineas": p["lineas"], "subtotal": p["subtotal"], "despacho": p["despacho"],
             "total": pago["monto"], "neto": neto, "iva": iva, "medio": pago["medio"], "estado": "vigente",
             "analyticsEnviado": False, "boletaEnviada": False, "analyticsReversoEnviado": None}
    await db.ventas.insert_one(venta)
    await db.pagos.update_one({"_id": pago["_id"]}, {"$set": {"ventaId": folio, "ventaLease": None}})
    actual = await db.pagos.find_one({"_id": pago["_id"]})
    if actual and actual.get("reembolso"):   # se anuló justo mientras se emitía: la venta nace anulada
        await _anular_venta(pago["_id"], request_id)
        return True
    await _entregar_venta(venta, request_id)
    return True


async def _publicar_venta(v, request_id):
    lineas = [{"itemId": l.get("itemId"), "nombre": l["nombre"], "cantidad": l["cantidad"], "subtotal": l["precio"] * l["cantidad"]} for l in v["lineas"]]
    try:
        r = await interno.llamar("analytics", "POST", "/internal/events/sale-registered", request_id=request_id, json={
            "eventoId": f"venta:{v['_id']}", "ventaId": v["_id"], "pedidoId": v["pedidoId"], "fecha": v["fecha"], "fechaLocal": v["fechaLocal"],
            "total": v["total"], "neto": v["neto"], "iva": v["iva"], "medio": v["medio"], "comuna": v.get("comuna"), "lineas": lineas})
    except ServicioNoDisponible:
        return False
    return r.status_code in (200, 201)


async def _enviar_boleta(v, request_id):
    """True/'destinatario_invalido' cierran el asunto; False deja la boleta para reintento."""
    try:
        r = await interno.llamar("notifications", "POST", "/internal/email/send", request_id=request_id, json={
            "tipo": "boleta", "para": v["cliente"]["correo"], "asunto": f"Boleta {v['_id']} - El Asador", "texto": texto_boleta(v), "clave": f"boleta:{v['_id']}"})
    except ServicioNoDisponible:
        return False
    if r.status_code == 200:
        return True
    if r.status_code == 422:
        return "destinatario_invalido"
    return False


async def _entregar_venta(v, request_id):
    if not v.get("analyticsEnviado") and await _publicar_venta(v, request_id):
        await db.ventas.update_one({"_id": v["_id"]}, {"$set": {"analyticsEnviado": True}})
    if not v.get("boletaEnviada"):
        res = await _enviar_boleta(v, request_id)
        if res:
            await db.ventas.update_one({"_id": v["_id"]}, {"$set": {"boletaEnviada": res}})


async def _entregar_reverso(v, request_id):
    try:
        r = await interno.llamar("analytics", "POST", "/internal/events/sale-reversed", request_id=request_id,
                                 json={"eventoId": f"reverso:{v['_id']}", "ventaId": v["_id"]})
    except ServicioNoDisponible:
        return False
    if r.status_code in (200, 201):
        await db.ventas.update_one({"_id": v["_id"]}, {"$set": {"analyticsReversoEnviado": True}})
        return True
    return False


async def _anular_venta(pago_id, request_id):
    """La venta de un pedido anulado deja de contarse en los reportes (queda el registro, marcado anulada)."""
    v = await db.ventas.find_one_and_update({"pagoId": pago_id, "estado": "vigente"},
                                            {"$set": {"estado": "anulada", "anuladaEn": iso(), "analyticsReversoEnviado": False}},
                                            return_document=ReturnDocument.AFTER)
    if v:
        await _entregar_reverso(v, request_id)


# ----------------------------- avisos del proveedor (webhook) ----------------------
@app.post("/webhooks/provider")
async def aviso_proveedor(request: Request, ll=Depends(guardia.dep(GW))):
    """Entrada pública (a través del gateway) protegida por la FIRMA del aviso, no por sesión de usuario."""
    crudo = await request.body()
    if len(crudo) > 65536:
        raise ErrorNegocio(413, "CUERPO_DEMASIADO_GRANDE", "Aviso demasiado grande")
    try:
        secreto = await vault.avalor("asador/provider/webhook-secret")
    except SecretUnavailable:   # 503: el proveedor reintenta más tarde
        raise ErrorNegocio(503, "SECRETOS_NO_DISPONIBLES", "Servicio temporalmente no disponible")
    ok, motivo = verificar_firma(secreto, request.headers.get("x-provider-signature", ""), crudo, int(time.time()))
    if not ok:
        log.warning("aviso del proveedor rechazado", extra={"ctx": {"motivo": motivo, "request_id": ll.request_id}})
        raise ErrorNegocio(400, "AVISO_NO_VALIDO", "Aviso no válido")
    try:
        ev = EventoProveedor.model_validate_json(crudo)
    except ValidationError:
        raise ErrorNegocio(400, "AVISO_NO_VALIDO", "Aviso no válido")
    try:
        await db.eventos_proveedor.insert_one({"_id": ev.id, "tipo": ev.type, "pago": ev.data.reference, "recibidoEn": iso(), "procesado": False})
    except DuplicateKeyError:
        previo = await db.eventos_proveedor.find_one({"_id": ev.id})
        if previo and previo.get("procesado"):
            return {"ok": True, "duplicado": True}   # el mismo aviso otra vez: no se repite ningún efecto
    resultado = await _procesar_evento(ev, ll)
    await db.eventos_proveedor.update_one({"_id": ev.id}, {"$set": {"procesado": True, "resultado": resultado}})
    return {"ok": True, "resultado": resultado}


async def _procesar_evento(ev, ll):
    pago = await db.pagos.find_one({"_id": ev.data.reference})
    if not pago or pago["modo"] != "proveedor":
        log.warning("aviso de un pago desconocido", extra={"ctx": {"evento": ev.id, "request_id": ll.request_id}})
        return "pago_desconocido"
    if pago.get("proveedorPagoId") != ev.data.payment_id:
        raise ErrorNegocio(409, "PAGO_NO_COINCIDE", "El aviso no corresponde al pago registrado")
    if ev.data.amount != pago["monto"] or ev.data.currency != "CLP":
        await db.pagos.update_one({"_id": pago["_id"]}, {"$set": {"alerta": "monto_no_coincide"}})
        log.error("el monto del aviso no coincide con el cobrado", extra={"ctx": {"pago": pago["_id"], "evento": ev.id, "request_id": ll.request_id}})
        await auditoria.registrar(db, ll, "pago.monto_no_coincide", f"pago:{pago['_id']}", {"evento": ev.id})
        raise ErrorNegocio(409, "MONTO_NO_COINCIDE", "El monto informado no coincide con el cobro")
    if ev.type == "payment.succeeded":
        return await aprobar(pago["_id"], origen="proveedor", request_id=ll.request_id, ll=ll)
    if ev.type == "payment.failed":
        r = await db.pagos.update_one({"_id": pago["_id"], "estado": "iniciado"}, {"$set": {"estado": "rechazado", "actualizadoEn": iso()}})
        return "rechazado" if r.modified_count else "sin_cambios"
    return "ignorado"


# ----------------------------- confirmación manual (administrador) -----------------
@app.post("/admin/orders/{id}/payment-confirmation")
async def confirmar_manual(datos: ConfirmacionManual, id: ID, ll=ADMIN):
    """Solo transferencia/depósito: el administrador comprueba el abono y lo confirma. El pago con proveedor NO se confirma a mano."""
    p = await _pedido_de(id, ll)
    if p["medioPago"] not in MEDIOS_MANUALES:
        raise ErrorNegocio(409, "MEDIO_NO_MANUAL", "Este pedido se paga con el proveedor en línea: su confirmación llega sola, no se confirma a mano.")
    if p["estado"] != "Pago pendiente":
        raise ErrorNegocio(409, "PEDIDO_NO_PAGABLE", f"El pedido {id} está «{p['estado']}»: no hay un pago pendiente que confirmar.")
    pago = await db.pagos.find_one({"pedidoId": id, "estado": "iniciado"})
    if not pago:
        pid = "pay-" + uuid.uuid4().hex[:16]
        ahora = iso()
        pago = {"_id": pid, "pedidoId": id, "clienteId": p["clienteId"], "monto": p["total"], "medio": p["medioPago"], "modo": "manual", "estado": "iniciado",
                "creadoEn": ahora, "actualizadoEn": ahora, "pedidoNotificado": False, "ventaId": None, "ventaLease": None, "reembolso": None}
        try:
            await db.pagos.insert_one(pago)
        except DuplicateKeyError:
            pago = await db.pagos.find_one({"pedidoId": id, "estado": "iniciado"})
    res = await aprobar(pago["_id"], origen="manual", request_id=ll.request_id, ll=ll, referencia=datos.referencia, actor=ll.identidad.user_id)
    return {"resultado": res, "pago": pago_dto(await db.pagos.find_one({"_id": pago["_id"]}))}


# ----------------------------- cancelación y reembolso -----------------------------
async def _marcar_reembolso(p, motivo, request_id):
    r = p.get("reembolso")
    if r:   # ya estaba: repetir la cancelación no cambia nada
        return "reembolso_realizado" if r["estado"] == "realizado" else "reembolso_pendiente"
    await db.pagos.update_one({"_id": p["_id"], "reembolso": None},
                              {"$set": {"reembolso": {"estado": "pendiente", "motivo": motivo[:300], "solicitadoEn": iso(), "automatico": False}}})
    await db.pagos.update_one({"_id": p["_id"], "pedidoNotificado": False}, {"$set": {"pedidoNotificado": "anulado"}})
    await _anular_venta(p["_id"], request_id)
    return "reembolso_pendiente"


@app.post("/internal/orders/{id}/payment-cancel")
async def cancelar_pago_de_pedido(datos: MotivoIn, id: ID, ll=Depends(guardia.dep(("orders",)))):
    """orders anuló el pedido: se cancela el cobro pendiente, o se registra el reembolso del pago ya aprobado. Es idempotente."""
    resultado = "sin_pago"
    for p in await db.pagos.find({"pedidoId": id}).sort("creadoEn", -1).to_list(20):
        if p["estado"] == "iniciado":
            cas = await db.pagos.update_one({"_id": p["_id"], "estado": "iniciado"},
                                            {"$set": {"estado": "cancelado", "cierre": "pedido_anulado", "actualizadoEn": iso()}})
            if cas.modified_count:
                if p["modo"] == "proveedor" and p.get("proveedorPagoId"):
                    try:
                        await _proveedor("POST", f"/v1/payments/{p['proveedorPagoId']}/cancel")
                    except ProveedorNoDisponible:
                        log.warning("no se pudo cancelar en el proveedor", extra={"ctx": {"pago": p["_id"]}})   # si igual pagan, se reembolsa solo
                resultado = "pago_cancelado"
                continue
            p = await db.pagos.find_one({"_id": p["_id"]})   # lo aprobaron en este mismo instante: se trata como aprobado
        if p["estado"] == "aprobado":
            resultado = await _marcar_reembolso(p, datos.motivo, ll.request_id)
    await auditoria.registrar(db, ll, "pago.cancelar_por_anulacion", f"pedido:{id}", {"resultado": resultado})
    return {"resultado": resultado}


@app.post("/admin/orders/{id}/refund")
async def reembolsar(datos: ReembolsoIn, id: ID, ll=ADMIN):
    pago = await db.pagos.find_one({"pedidoId": id, "estado": "aprobado", "reembolso.estado": {"$in": ["pendiente", "realizado"]}})
    if not pago:
        raise ErrorNegocio(404, "SIN_REEMBOLSO", "El pedido no tiene un reembolso por realizar")
    if pago["reembolso"]["estado"] == "realizado":
        return pago_dto(pago)   # idempotente
    if pago["modo"] == "proveedor":
        try:
            r = await _proveedor("POST", "/v1/refunds", {"payment_id": pago["proveedorPagoId"], "amount": pago["monto"]})
        except ProveedorNoDisponible:
            raise ErrorNegocio(503, "PROVEEDOR_PAGO_NO_DISPONIBLE", "El proveedor de pagos no está disponible. Intenta el reembolso nuevamente en unos minutos.",
                               headers={"Retry-After": "10"})
        if r.status_code not in (200, 201):
            raise ErrorNegocio(502, "PROVEEDOR_RECHAZO", "El proveedor de pagos no aceptó el reembolso")
        referencia = r.json()["id"]
    else:
        if not datos.referencia:
            raise ErrorNegocio(422, "REFERENCIA_REQUERIDA", "Indica la referencia de la devolución (número de comprobante)")
        referencia = datos.referencia
    ahora = iso()
    nuevo = await db.pagos.find_one_and_update(
        {"_id": pago["_id"], "reembolso.estado": "pendiente"},
        {"$set": {"reembolso.estado": "realizado", "reembolso.realizadoEn": ahora, "reembolso.referencia": referencia,
                  "reembolso.ejecutadoPor": ll.identidad.user_id, "reembolsoNotificado": False, "actualizadoEn": ahora}},
        return_document=ReturnDocument.AFTER)
    if nuevo is None:   # otro administrador lo hizo en el mismo instante
        nuevo = await db.pagos.find_one({"_id": pago["_id"]})
        return pago_dto(nuevo)
    await auditoria.registrar(db, ll, "reembolso.realizar", f"pago:{pago['_id']}", {"pedido": id, "modo": pago["modo"]})
    await _avisar_reembolso(nuevo, ll.request_id)
    return pago_dto(await db.pagos.find_one({"_id": pago["_id"]}))


async def _avisar_reembolso(pago, request_id):
    try:
        r = await interno.llamar("orders", "POST", f"/internal/orders/{pago['pedidoId']}/refund-done", request_id=request_id)
    except ServicioNoDisponible:
        return False
    if r.status_code != 200:
        return False
    await db.pagos.update_one({"_id": pago["_id"]}, {"$set": {"reembolsoNotificado": True}})
    try:   # mejor esfuerzo: el aviso al cliente no condiciona el reembolso
        q = await interno.llamar("orders", "GET", f"/internal/orders/{pago['pedidoId']}/payable", request_id=request_id)
        if q.status_code == 200:
            c = q.json()["cliente"]
            await interno.llamar("notifications", "POST", "/internal/email/send", request_id=request_id, json={
                "tipo": "boleta", "para": c["correo"], "asunto": f"Reembolso del pedido {pago['pedidoId']} - El Asador",
                "texto": f"Hola {c['nombre'].split()[0]}, registramos el reembolso de tu pedido {pago['pedidoId']} por "
                         f"${pago['monto']:,}.".replace(",", ".") + " Puede tardar algunos días en verse en tu cuenta.",
                "clave": f"reembolso:{pago['_id']}"})
    except ServicioNoDisponible:
        pass
    return True


# ----------------------------- consultas administrativas e internas ----------------
@app.get("/admin/payments")
async def listar_pagos(response: Response, estado: str | None = Query(default=None, pattern="^(iniciado|aprobado|rechazado|cancelado)$"),
                       reembolso: str | None = Query(default=None, pattern="^(pendiente|realizado)$"),
                       modo: str | None = Query(default=None, pattern="^(proveedor|manual)$"),
                       limit: int = Query(default=50, ge=1, le=100), offset: int = Query(default=0, ge=0, le=10000), ll=ADMIN):
    filtro = {}
    if estado:
        filtro["estado"] = estado
    if reembolso:
        filtro["reembolso.estado"] = reembolso
    if modo:
        filtro["modo"] = modo
    response.headers["X-Total-Count"] = str(await db.pagos.count_documents(filtro))
    cur = db.pagos.find(filtro).sort("creadoEn", -1).skip(offset).limit(limit)
    return [pago_dto(d) async for d in cur]


@app.get("/internal/payments/by-orders")
async def pagos_de_pedidos(ids: str = Query(max_length=900), ll=Depends(guardia.dep(("graphql-gateway",), identidad="requerida",
                                                                                      roles=("cliente", "administrador", "despacho", "dueno")))):
    """Estado de pago y boleta de varios pedidos a la vez (lo usa el GraphQL gateway). Un cliente solo ve los suyos."""
    lista = [i for i in ids.split(",") if i]
    if not lista or len(lista) > 50 or any(not PEDIDO_RE.fullmatch(i) for i in lista):
        raise ErrorNegocio(400, "FILTRO_INVALIDO", "Lista de pedidos inválida")
    filtro = {"pedidoId": {"$in": lista}}
    if not ll.identidad.es_personal:
        filtro["clienteId"] = ll.identidad.client_id
    ultimos = {}
    async for d in db.pagos.find(filtro).sort("creadoEn", 1):
        ultimos[d["pedidoId"]] = d   # el más reciente de cada pedido
    boletas = {v["pedidoId"]: v async for v in db.ventas.find(filtro)}
    return [{"pedidoId": pid, "pago": pago_dto(d), "boleta": ({"folio": boletas[pid]["_id"], "total": boletas[pid]["total"], "estado": boletas[pid]["estado"]}
                                                              if pid in boletas else None)} for pid, d in ultimos.items()]


@app.get("/internal/summary")
async def resumen(ll=Depends(guardia.dep(("graphql-gateway",), identidad="requerida", roles=("administrador", "dueno", "despacho")))):
    filas = await db.pagos.aggregate([{"$group": {"_id": "$estado", "n": {"$sum": 1}}}]).to_list(20)
    por_estado = {"iniciado": 0, "aprobado": 0, "rechazado": 0, "cancelado": 0}
    por_estado.update({f["_id"]: f["n"] for f in filas})
    return {"porEstado": por_estado,
            "reembolsosPendientes": await db.pagos.count_documents({"reembolso.estado": "pendiente"}),
            "pagosManualesPorConfirmar": await db.pagos.count_documents({"estado": "iniciado", "modo": "manual"})}


# ----------------------------- ciclo de reintentos y conciliación -------------------
async def _ciclo():
    rid = "ciclo-" + uuid.uuid4().hex[:12]
    async for p in db.pagos.find({"estado": "aprobado", "pedidoNotificado": False}).limit(20):
        await _notificar_pedido(p, rid)
    async for p in db.pagos.find({"estado": "aprobado", "pedidoNotificado": True, "ventaId": None}).limit(20):
        await _registrar_venta(p, rid)
    async for v in db.ventas.find({"estado": "vigente", "$or": [{"analyticsEnviado": False}, {"boletaEnviada": False}]}).limit(20):
        await _entregar_venta(v, rid)
    async for v in db.ventas.find({"estado": "anulada", "analyticsReversoEnviado": False}).limit(20):
        await _entregar_reverso(v, rid)
    async for p in db.pagos.find({"reembolso.estado": "realizado", "reembolsoNotificado": False}).limit(20):
        await _avisar_reembolso(p, rid)
    # conciliación: si un aviso del proveedor se perdió, se pregunta directamente al proveedor por los cobros "iniciados" antiguos
    limite = iso(ahora() - timedelta(seconds=CONCILIAR_DESPUES))
    async for p in db.pagos.find({"estado": "iniciado", "modo": "proveedor", "creadoEn": {"$lt": limite}}).limit(10):
        if p.get("proveedorPagoId"):
            await _conciliar(p, rid)


async def _conciliar(p, rid):
    try:
        r = await _proveedor("GET", f"/v1/payments/{p['proveedorPagoId']}")
    except ProveedorNoDisponible:
        return
    if r.status_code != 200:
        return
    prov = r.json()
    if prov.get("amount") != p["monto"]:
        await db.pagos.update_one({"_id": p["_id"]}, {"$set": {"alerta": "monto_no_coincide"}})
        return
    if prov.get("status") == "succeeded":
        await aprobar(p["_id"], origen="conciliacion", request_id=rid)
    elif prov.get("status") == "failed":
        await db.pagos.update_one({"_id": p["_id"], "estado": "iniciado"}, {"$set": {"estado": "rechazado", "actualizadoEn": iso()}})
    elif prov.get("status") == "cancelled":
        await db.pagos.update_one({"_id": p["_id"], "estado": "iniciado"}, {"$set": {"estado": "cancelado", "cierre": "proveedor_cancelo", "actualizadoEn": iso()}})


async def _ciclos():
    espera = float(os.environ.get("REINTENTO_SEGUNDOS", "5"))
    while True:
        await asyncio.sleep(espera)
        try:
            await _ciclo()
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("falló el ciclo de reintentos")
