# Datos del frontend

La Evaluación 2 se entrega con **datos del frontend**, no con el frontend integrado. Esta carpeta guarda lo que las pruebas toman de las pantallas de la C2 (repositorio `NeosZ101/el-asador-frontend`):

- `consultas-graphql.json`: texto exacto de las tres consultas GraphQL que envían las pantallas «Mis pedidos» (`CONSULTA_PEDIDOS`, de `pedidos.js`) y el panel interno (`CONSULTA_VENTAS` y `CONSULTA_DESPACHO`, de `admin.js`). Las pruebas las leen de aquí y no las reescriben.

Las páginas HTML, el CSS y el resto del JavaScript no forman parte de esta entrega.
