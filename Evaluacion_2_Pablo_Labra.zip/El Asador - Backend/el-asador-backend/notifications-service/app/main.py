"""Notifications (privado): mensajería. Valida la existencia de correos, envía correos y recibe el formulario de contacto.

Es un servicio propio que usa un proveedor de correo EXTERNO a través de un adaptador (ver proveedores.py).
Es la autoridad de la bandeja de salida (lo enviado) y de los mensajes de contacto.
"""
import hashlib
import os
import uuid
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import Depends
from pydantic import BaseModel, ConfigDict, Field, field_validator
from pymongo.errors import DuplicateKeyError

from common.app import crear_app
from common.db import abrir_db
from common.errores import ErrorNegocio
from common.migraciones import migrar
from common.seguridad import Guardia
from common.tiempo import iso
from common.vault_secrets import VaultSecrets

from .proveedores import MxCorreo, ProveedorNoDisponible, SandboxCorreo, SmtpCorreo, normalizar, validar_sintaxis_y_dominio

vault = VaultSecrets()
guardia = Guardia("notifications", vault)
GW = ("api-gateway",)
BUZON_RESTAURANT = os.environ.get("CONTACT_INBOX", "contacto@elasador.cl")
db = None
proveedor = None


def crear_proveedor():
    modo = os.environ.get("EMAIL_PROVIDER", "sandbox")
    if modo == "smtp":
        return SmtpCorreo(vault)
    if os.environ.get("EMAIL_VALIDATION", "sandbox") == "mx":
        return MxCorreo()
    return SandboxCorreo(caido=os.environ.get("SANDBOX_EMAIL_CAIDO", "false").lower() == "true")


async def _indices(d):
    await d.bandeja.create_index("clave", unique=True, partialFilterExpression={"clave": {"$type": "string"}})
    await d.bandeja.create_index("creadoEn")
    await d.mensajes_contacto.create_index("creadoEn")


MIGRACIONES = [(1, "índices de bandeja y contacto", _indices)]


@asynccontextmanager
async def lifespan(app):
    global db, proveedor
    await vault.aesperar("asador/db/notifications")
    await guardia.precalentar()
    cliente, db = await abrir_db("notifications", vault)
    await migrar(db, MIGRACIONES)
    proveedor = crear_proveedor()
    app.state.chequeos.append(lambda: db.command("ping"))
    log.info("Notifications listo", extra={"ctx": {"proveedor": proveedor.nombre}})
    yield
    cliente.close()


app, log = crear_app("notifications", lifespan)

ASUNTOS = ("Consulta sobre un pedido", "Reclamo", "Sugerencia", "Evento o pedido especial", "Otro")


class CorreoIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    correo: str = Field(min_length=5, max_length=254)


class EnvioIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    tipo: Literal["bienvenida", "boleta", "cotizacion", "contacto", "autorespuesta"]
    para: str = Field(min_length=5, max_length=254)
    asunto: str = Field(min_length=3, max_length=150)
    texto: str = Field(min_length=1, max_length=8000)
    clave: str | None = Field(default=None, min_length=8, max_length=120)  # idempotencia: misma clave = un solo envío


class ContactoIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    nombre: str = Field(min_length=3, max_length=80)
    correo: str = Field(min_length=5, max_length=254)
    asunto: Literal["Consulta sobre un pedido", "Reclamo", "Sugerencia", "Evento o pedido especial", "Otro"]
    mensaje: str = Field(min_length=10, max_length=2000)

    @field_validator("nombre", "mensaje")
    @classmethod
    def _t(cls, v):
        return v.strip()


def _enmascarar(correo):
    local, dominio = correo.split("@", 1)
    return f"{local[:1]}***@{dominio}"


async def _enviar_y_guardar(tipo, para, asunto, texto, clave=None):
    """Envía por el proveedor y deja constancia. Con la misma clave no se envía dos veces lo ya enviado."""
    para = normalizar(para)
    ok, motivo = validar_sintaxis_y_dominio(para)
    if not ok:
        raise ErrorNegocio(422, "DESTINATARIO_INVALIDO", motivo)
    previo = await db.bandeja.find_one({"clave": clave}) if clave else None
    if previo and previo["estado"] == "enviado":
        return {"id": previo["_id"], "estado": "enviado", "repetido": True}
    doc = previo or {"_id": uuid.uuid4().hex, "tipo": tipo, "para": para, "asunto": asunto, "texto": texto, "estado": "pendiente",
                     "intentos": 0, "proveedor": proveedor.nombre, "creadoEn": iso()}
    if clave and not previo:
        doc["clave"] = clave
    if not previo:
        try:
            await db.bandeja.insert_one(doc)
        except DuplicateKeyError:  # otra solicitud con la misma clave ganó la carrera
            previo = await db.bandeja.find_one({"clave": clave})
            return {"id": previo["_id"], "estado": previo["estado"], "repetido": True}
    try:
        await proveedor.enviar(para, asunto, texto)
        estado, error = "enviado", None
    except ProveedorNoDisponible:
        estado, error = "pendiente", "proveedor_no_disponible"
    await db.bandeja.update_one({"_id": doc["_id"]}, {"$set": {"estado": estado, "errorTipo": error, "enviadoEn": iso() if estado == "enviado" else None},
                                                      "$inc": {"intentos": 1}})
    return {"id": doc["_id"], "estado": estado, "repetido": False}


@app.post("/internal/email/validate")
async def validar_correo(datos: CorreoIn, ll=Depends(guardia.dep(("clients",)))):
    """RF11: comprueba con el proveedor que el correo existe y está activo."""
    correo = normalizar(datos.correo)
    try:
        valido, motivo = await proveedor.validar(correo)
    except ProveedorNoDisponible:
        raise ErrorNegocio(503, "PROVEEDOR_CORREO_NO_DISPONIBLE", "No pudimos validar el correo en este momento. Intenta nuevamente en unos minutos.")
    return {"valido": valido, "motivo": motivo}


@app.post("/internal/email/send")
async def enviar_correo(datos: EnvioIn, ll=Depends(guardia.dep(("clients", "payments", "orders")))):
    r = await _enviar_y_guardar(datos.tipo, datos.para, datos.asunto, datos.texto, datos.clave)
    return r


@app.post("/contact-messages", status_code=201)
async def contacto(datos: ContactoIn, ll=Depends(guardia.dep(GW))):
    """P04: guarda el mensaje, avisa al restaurante y responde al remitente (una respuesta por hora y dirección)."""
    correo = normalizar(datos.correo)
    ok, motivo = validar_sintaxis_y_dominio(correo)
    if not ok:
        raise ErrorNegocio(422, "CORREO_INVALIDO", motivo)
    mid = uuid.uuid4().hex
    await db.mensajes_contacto.insert_one({"_id": mid, "nombre": datos.nombre, "correo": correo, "asunto": datos.asunto,
                                           "mensaje": datos.mensaje, "creadoEn": iso()})
    try:   # el mensaje ya quedó guardado: si el buzón del restaurante está mal configurado no se le echa la culpa a quien escribió
        await _enviar_y_guardar("contacto", BUZON_RESTAURANT, f"[Contacto web] {datos.asunto}",
                                f"De: {datos.nombre} <{correo}>\n\n{datos.mensaje}", clave=f"contacto:{mid}")
    except ErrorNegocio:
        log.error("CONTACT_INBOX no es un correo válido: el aviso al restaurante no salió", extra={"ctx": {"mensaje_id": mid}})
    hora = iso()[:13]
    huella = hashlib.sha256(correo.encode()).hexdigest()[:16]
    await _enviar_y_guardar("autorespuesta", correo, "Recibimos tu mensaje - El Asador",
                            f"Hola {datos.nombre.split()[0]}, recibimos tu consulta sobre «{datos.asunto}». "
                            "Te responderemos durante el día (martes a domingo, de 12:00 a 23:00 h).", clave=f"autorespuesta:{huella}:{hora}")
    return {"id": mid}


@app.get("/outbox")
async def bandeja(limit: int = 20, ll=Depends(guardia.dep(GW, identidad="requerida", roles=("administrador",)))):
    """Vista de administración de lo enviado (destinatario enmascarado). Sirve para comprobar boletas y avisos."""
    limit = max(1, min(limit, 100))
    cur = db.bandeja.find({}).sort("creadoEn", -1).limit(limit)
    return [{"id": d["_id"], "tipo": d["tipo"], "para": _enmascarar(d["para"]), "asunto": d["asunto"], "estado": d["estado"],
             "intentos": d["intentos"], "creadoEn": d["creadoEn"]} async for d in cur]
