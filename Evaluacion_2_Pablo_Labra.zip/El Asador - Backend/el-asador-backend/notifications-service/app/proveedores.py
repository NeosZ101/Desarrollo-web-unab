"""Adaptadores del proveedor de mensajería (correo).

El servicio `notifications` es propio; el proveedor de correo es EXTERNO. Se separan con una interfaz
mínima (validar existencia, enviar) para poder cambiar de proveedor sin tocar el resto del sistema.

  * SandboxCorreo (por defecto): entorno de prueba determinista. No sale a Internet: guarda lo "enviado"
    en la bandeja de salida. Respeta el contrato (validar/enviar, errores, idempotencia).
  * MxCorreo: comprueba que el dominio del correo existe y recibe correo (registro MX/A) con DNS real.
  * SmtpCorreo: envío real por SMTP con credenciales de Vault (STARTTLS).
"""
import asyncio
import os
import re
import smtplib
import ssl
from email.message import EmailMessage

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9.-]{1,190}\.[A-Za-z]{2,24}$")
DOMINIOS_SIN_CORREO = {"example.com", "example.org", "example.net", "localhost", "invalid", "test"}
SUFIJOS_RESERVADOS = (".invalid", ".test", ".example", ".localhost")
DESECHABLES = {"mailinator.com", "10minutemail.com", "guerrillamail.com", "tempmail.com", "yopmail.com"}
BUZONES_FALSOS = ("noexiste", "no-existe", "rebota", "bounce")  # convención del sandbox para simular direcciones inexistentes


class ProveedorNoDisponible(Exception):
    """El proveedor externo no respondió o falló: el llamador decide si reintenta."""


def normalizar(correo):
    return (correo or "").strip().lower()


def validar_sintaxis_y_dominio(correo):
    """Comprobaciones locales comunes a todos los proveedores. Devuelve (valido, motivo)."""
    if not EMAIL_RE.fullmatch(correo):
        return False, "El correo no tiene un formato válido"
    local, dominio = correo.rsplit("@", 1)
    if dominio in DOMINIOS_SIN_CORREO or dominio.endswith(SUFIJOS_RESERVADOS):
        return False, "El dominio del correo no recibe mensajes"
    if dominio in DESECHABLES:
        return False, "No se aceptan correos temporales o desechables"
    return True, None


class SandboxCorreo:
    nombre = "sandbox"

    def __init__(self, caido=False):
        self.caido = caido

    async def validar(self, correo):
        if self.caido:
            raise ProveedorNoDisponible("sandbox caído (simulado)")
        ok, motivo = validar_sintaxis_y_dominio(correo)
        if not ok:
            return False, motivo
        if correo.split("@")[0].startswith(BUZONES_FALSOS):
            return False, "El buzón no existe o no está activo"
        return True, None

    async def enviar(self, para, asunto, texto):
        if self.caido:
            raise ProveedorNoDisponible("sandbox caído (simulado)")
        return "sandbox"


class MxCorreo:
    """Validación con DNS real: el dominio debe tener registro MX (o A). No prueba el buzón, solo el dominio."""
    nombre = "mx"

    def __init__(self, enviar=None):
        self._enviar = enviar or SandboxCorreo()

    async def validar(self, correo):
        ok, motivo = validar_sintaxis_y_dominio(correo)
        if not ok:
            return False, motivo
        import dns.exception
        import dns.resolver
        dominio = correo.rsplit("@", 1)[1]

        def consulta():
            r = dns.resolver.Resolver()
            r.lifetime = 3.0
            for tipo in ("MX", "A"):
                try:
                    if len(r.resolve(dominio, tipo)) > 0:
                        return True
                except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
                    continue
            return False

        try:
            existe = await asyncio.get_running_loop().run_in_executor(None, consulta)
        except (dns.exception.Timeout, dns.resolver.NoNameservers, OSError):
            raise ProveedorNoDisponible("DNS no disponible")
        return (True, None) if existe else (False, "El dominio del correo no existe o no recibe mensajes")

    async def enviar(self, para, asunto, texto):
        return await self._enviar.enviar(para, asunto, texto)


class SmtpCorreo:
    nombre = "smtp"

    def __init__(self, vault, validador=None):
        self.vault = vault
        self._validador = validador or MxCorreo()

    async def validar(self, correo):
        return await self._validador.validar(correo)

    async def enviar(self, para, asunto, texto):
        cred = await self.vault.aget("asador/email/smtp")
        puerto = int(os.environ.get("SMTP_PORT", "587"))
        remitente = os.environ.get("SMTP_FROM", "no-responder@elasador.cl")

        def envio():
            msg = EmailMessage()
            msg["From"], msg["To"], msg["Subject"] = remitente, para, asunto
            msg.set_content(texto)
            with smtplib.SMTP(cred["host"], puerto, timeout=10) as s:
                s.starttls(context=ssl.create_default_context())
                s.login(cred["user"], cred["password"])
                s.send_message(msg)

        try:
            await asyncio.get_running_loop().run_in_executor(None, envio)
        except (smtplib.SMTPException, OSError):
            raise ProveedorNoDisponible("SMTP no disponible")
        return "smtp"
