workspace "El Asador" "Backend seguro de Parrilladas El Asador (Caso 20, Evaluacion 2). Modelo C4, escenarios y despliegue de lo que se entrega." {

    !identifiers hierarchical

    // Modelo C4 en el formato Structurizr DSL de la asignatura: C1 y C2, componentes C3, escenarios dinamicos y despliegue.
    // Cada elemento corresponde a codigo entregado (carpetas del repositorio y docker-compose.yml); tests/test_diagrama_dsl.py lo comprueba.
    // Se abre con Structurizr Lite o se valida con: structurizr.sh validate -workspace docs/diagramas/El-Asador.dsl

    model {
        visitante = person "Visitante" "Persona que mira la carta y las promociones y pide una cotizacion de evento sin iniciar sesion."
        cliente = person "Cliente" "Persona registrada: arma pedidos, paga en linea, ve su boleta y puede anular."
        personal = person "Personal interno" "Administrador, despacho y dueno: cada rol opera solo lo que su permiso autoriza."

        proveedor = softwareSystem "Proveedor de pagos" "Tercero externo que cobra y avisa el resultado con un aviso firmado. En esta entrega lo reemplaza un proveedor simulado." {
            tags "SistemaExterno"

            sandbox = container "provider-sandbox" "Proveedor simulado: API con clave, pagina de pago y avisos firmados (HMAC)." "FastAPI" {
                tags "Simulado"
            }
        }

        correo = softwareSystem "Proveedor de correo" "Entrega las boletas y los avisos por correo. En esta entrega solo existe un adaptador de prueba: no sale correo real." {
            tags "SistemaExterno"
        }

        sistema = softwareSystem "El Asador" "Pedidos con despacho, pago en linea, boleta digital, panel interno y reportes de ventas." {
            tags "SistemaEvaluado"

            frontend = container "Frontend responsivo" "Las 8 paginas de la C2 para visitantes, clientes y personal. No forman parte de esta entrega: el backend se prueba con sus datos." "HTML5, CSS, JavaScript, Bootstrap 5" {
                tags "Frontend"
            }

            apiGateway = container "API Gateway" "Unica puerta publica: tabla explicita de 38 rutas, sesion, rol, origen, limites de solicitudes y plazos." "FastAPI (api-gateway)" {
                tags "Gateway"

                // C3 - Componentes internos del API Gateway.
                entrada = component "Adaptador HTTP" "Recibe las solicitudes y agrega cabeceras de seguridad y numero de correlacion." "FastAPI" {
                    tags "EntradaC3"
                }
                limitador = component "Limitador de solicitudes" "Cuenta solicitudes por grupo (general, login, registro, formularios, graphql, webhook) y rechaza el exceso con 429." "Modulo de seguridad" {
                    tags "ControlC3"
                }
                verificadorOrigen = component "Verificador de origen" "Rechaza las operaciones de escritura que no vienen del propio sitio." "Modulo de seguridad" {
                    tags "ControlC3"
                }
                tablaRutas = component "Tabla de rutas" "Lista explicita S01 a S38: verbo, destino, acceso, roles, cabeceras y parametros permitidos. Lo que no esta aqui no se reenvia." "Configuracion" {
                    tags "AplicacionC3"
                }
                filtroSesion = component "Filtro de sesion y rol" "Convierte la cookie en una identidad verificada por Auth en cada solicitud y exige el rol de la ruta." "Modulo de seguridad" {
                    tags "ControlC3"
                }
                despachador = component "Despachador de rutas" "Reenvia al destino con identidad verificada y solo los parametros permitidos; guarda en cache la carta anonima unos segundos." "Modulo de enrutamiento" {
                    tags "AplicacionC3"
                }
                clienteInterno = component "Cliente interno" "Llama a los servicios con el secreto de su par, plazo maximo y cortacircuitos." "Adaptador de integracion" {
                    tags "IntegracionC3"
                }
                traductorErrores = component "Traductor de errores" "Convierte las fallas en respuestas JSON uniformes sin detalles internos." "Modulo de errores" {
                    tags "ErrorC3"
                }
            }

            authService = container "Auth Service" "Credenciales con argon2id, sesiones opacas, usuarios del personal y credenciales de clientes." "FastAPI (auth)" {
                tags "Seguridad"

                // C3 - Componentes internos del Auth Service.
                identityApi = component "API de identidad" "login, introspect y logout; mantenedor de usuarios (administrador); credenciales de clientes (solo clients)." "FastAPI" {
                    tags "EntradaC3"
                }
                guardiaAuth = component "Guardia entre servicios" "Acepta solo llamadores autorizados con el secreto de su par y exige el rol de la operacion." "Modulo de seguridad" {
                    tags "ControlC3"
                }
                politicaAcceso = component "Politica de acceso" "Bloquea la cuenta tras intentos fallidos y responde igual si el usuario no existe." "Reglas de acceso" {
                    tags "ControlC3"
                }
                verificadorClaves = component "Verificador de credenciales" "Compara y renueva el hash argon2id sin exponer la clave." "Servicio de validacion" {
                    tags "ControlC3"
                }
                gestorSesiones = component "Gestor de sesiones" "Emite tokens opacos, guarda solo su huella SHA-256, controla la vigencia y revoca." "Servicio de identidad" {
                    tags "AplicacionC3"
                }
                repositorioIdentidades = component "Repositorio de identidades" "Lee y escribe usuarios y sesiones." "Acceso a datos" {
                    tags "PersistenciaC3"
                }
            }

            secretManager = container "Administrador de secretos" "HashiCorp Vault: un token y una politica de solo lectura por servicio; secretos por par de servicios." "Vault 2.0.0 (modo desarrollo)" {
                tags "Seguridad"
            }

            inventory = container "inventory" "Productos, promociones, precios y disponibilidad; entrega precios vigentes a orders." "FastAPI (inventory)" {
                tags "Privado"
            }

            orders = container "orders" "Pedidos, estados, despacho y cotizacion de eventos. Es la autoridad del estado del pedido." "FastAPI (orders)" {
                tags "Privado"

                // C3 - Componentes internos de orders.
                ordersApi = component "API de pedidos" "Recibe las solicitudes del gateway, de GraphQL y de payments." "FastAPI" {
                    tags "EntradaC3"
                }
                guardiaOrders = component "Guardia entre servicios" "Verifica quien llama, en nombre de quien y con que rol." "Modulo de seguridad" {
                    tags "ControlC3"
                }
                politicaPedidos = component "Politica de acceso a pedidos" "Un cliente solo ve sus pedidos: ajeno e inexistente dan la misma respuesta 403." "Reglas de autorizacion" {
                    tags "ControlC3"
                }
                idempotencia = component "Control de idempotencia" "Detecta la clave Idempotency-Key repetida y devuelve el pedido ya creado." "Regla de negocio" {
                    tags "ControlC3"
                }
                reglasPedido = component "Reglas del pedido" "Ciclo de vida y transiciones, totales, costo de despacho por comuna y cotizacion de eventos." "Reglas puras" {
                    tags "AplicacionC3"
                }
                flujoPedidos = component "Servicio de pedidos" "Crea, anula y avanza pedidos coordinando reglas y dependencias." "Servicio de aplicacion" {
                    tags "AplicacionC3"
                }
                adaptadorClientes = component "Adaptador de clientes" "Pide el perfil de entrega a clients." "Adaptador privado" {
                    tags "IntegracionC3"
                }
                adaptadorInventario = component "Adaptador de inventario" "Resuelve precios y disponibilidad vigentes." "Adaptador privado" {
                    tags "IntegracionC3"
                }
                adaptadorPagos = component "Adaptador de pagos" "Cancela el pago de un pedido anulado y reintenta si payments no responde." "Adaptador privado" {
                    tags "IntegracionC3"
                }
                repositorioPedidos = component "Repositorio de pedidos" "Persiste pedidos, zonas de despacho y claves de operacion." "Acceso a datos" {
                    tags "PersistenciaC3"
                }
            }

            clients = container "clients" "Perfiles y datos personales de los clientes; el registro se completa como saga con Auth." "FastAPI (clients)" {
                tags "Privado"
            }

            payments = container "payments" "Pagos, ventas, boletas y reembolsos. Es la autoridad del dinero." "FastAPI (payments)" {
                tags "Privado"

                // C3 - Componentes internos de payments.
                paymentsApi = component "API de pagos" "Inicia y consulta pagos, boletas, reembolsos y recibe el aviso del proveedor." "FastAPI" {
                    tags "EntradaC3"
                }
                guardiaPayments = component "Guardia entre servicios" "Verifica quien llama, en nombre de quien y con que rol." "Modulo de seguridad" {
                    tags "ControlC3"
                }
                verificadorFirma = component "Verificador de firma" "Comprueba la firma HMAC del aviso y su ventana de tiempo antes de leerlo." "Modulo de seguridad" {
                    tags "ControlC3"
                }
                registroEventos = component "Registro de avisos" "Guarda el identificador de cada aviso: repetirlo no repite ningun efecto." "Regla de negocio" {
                    tags "ControlC3"
                }
                aprobacion = component "Aprobacion de pagos" "Unica funcion que aprueba un pago, de forma atomica." "Servicio de aplicacion" {
                    tags "AplicacionC3"
                }
                ventasBoletas = component "Ventas y boletas" "Registra la venta, emite la boleta y publica el hecho a analytics y notifications." "Servicio de aplicacion" {
                    tags "AplicacionC3"
                }
                conciliador = component "Ciclo de reintentos y conciliacion" "Completa lo pendiente y pregunta al proveedor por los cobros sin aviso." "Proceso periodico" {
                    tags "AplicacionC3"
                }
                adaptadorProveedor = component "Adaptador del proveedor" "Crea cobros y consulta su estado con la clave del proveedor y un plazo maximo." "Adaptador de integracion" {
                    tags "IntegracionC3"
                }
                adaptadorPedidos = component "Adaptador de pedidos" "Consulta el pedido pagable y le avisa que el pago se confirmo." "Adaptador privado" {
                    tags "IntegracionC3"
                }
                repositorioPagos = component "Repositorio de pagos" "Persiste pagos, ventas, boletas y avisos recibidos." "Acceso a datos" {
                    tags "PersistenciaC3"
                }
            }

            notifications = container "notifications" "Valida correos, guarda la bandeja de salida y los mensajes de contacto." "FastAPI (notifications)" {
                tags "Privado"
            }

            analytics = container "analytics" "Modelo de lectura de ventas: reportes por periodo, idempotente y sin datos personales." "FastAPI (analytics)" {
                tags "Privado" "Analitica"
            }

            graphqlGateway = container "GraphQL Gateway" "Consultas de solo lectura que combinan orders, payments, inventory y analytics." "FastAPI + Strawberry (graphql-gateway)" {
                tags "Gateway"

                // C3 - Componentes internos del GraphQL Gateway.
                graphqlEndpoint = component "Endpoint GraphQL" "Recibe POST /graphql solo desde el API Gateway y con identidad verificada." "FastAPI" {
                    tags "EntradaC3"
                }
                validadorConsultas = component "Validador de consultas" "Esquema cerrado, sin introspeccion, y limites de profundidad, alias, tamano y costo." "Validacion GraphQL" {
                    tags "ControlC3"
                }
                permisosCampos = component "Permisos por campo" "Comprueba el rol para cada campo antes de resolverlo." "Modulo de autorizacion" {
                    tags "ControlC3"
                }
                resolvers = component "Resolvers" "misPedidos, pedidosAdmin, panelAdmin y reporteVentas." "Resolvers GraphQL" {
                    tags "AplicacionC3"
                }
                cargadores = component "Cargadores por lote" "Una sola llamada por tipo de dato (productos y pagos) en vez de una por pedido." "Batching" {
                    tags "AplicacionC3"
                }
                conectores = component "Conectores de servicios" "Llaman a orders, payments, inventory y analytics por sus contratos internos." "Adaptadores de integracion" {
                    tags "IntegracionC3"
                }
                compositorRespuestas = component "Compositor de respuestas" "Oculta el texto de los errores inesperados e informa los datos que faltaron sin pasarlos por completos." "Modulo de resultados" {
                    tags "ErrorC3"
                }
            }

            dbIdentity = container "Datos de identidad" "Base auth: usuarios y sesiones." "MongoDB (base y usuario propios)" {
                tags "BaseDatos"
            }
            dbClients = container "Datos de clientes" "Base clients: perfiles de clientes." "MongoDB (base y usuario propios)" {
                tags "BaseDatos"
            }
            dbInventory = container "Datos de inventario" "Base inventory: productos, promociones y precios." "MongoDB (base y usuario propios)" {
                tags "BaseDatos"
            }
            dbOrders = container "Datos de pedidos" "Base orders: pedidos, zonas de despacho y cotizaciones." "MongoDB (base y usuario propios)" {
                tags "BaseDatos"
            }
            dbPayments = container "Datos de pagos" "Base payments: pagos, ventas, boletas y avisos recibidos." "MongoDB (base y usuario propios)" {
                tags "BaseDatos"
            }
            dbNotifications = container "Datos de notificaciones" "Base notifications: bandeja de salida y mensajes de contacto." "MongoDB (base y usuario propios)" {
                tags "BaseDatos"
            }
            dbAnalytics = container "Datos de analitica" "Base analytics: ventas para reportes." "MongoDB (base y usuario propios)" {
                tags "BaseDatos"
            }
        }

        // Relaciones de contexto (C1).
        visitante -> sistema "Mira la carta y cotiza eventos"
        cliente -> sistema "Arma pedidos, paga y ve su boleta"
        personal -> sistema "Administra carta, clientes, despacho, pagos y reportes segun su rol"
        sistema -> proveedor "Crea cobros y los concilia" "HTTPS/JSON"
        proveedor -> sistema "Avisa el resultado del pago con un aviso firmado" "HTTPS/JSON"
        sistema -> correo "Envia la boleta y los avisos (adaptador de prueba)" "SMTP"
        cliente -> proveedor "Paga en la pagina del proveedor" "Navegador web"
        cliente -> proveedor.sandbox "Paga en la pagina del proveedor simulado" "Navegador web"

        // Relaciones entre las personas y el frontend; y entre contenedores.
        visitante -> sistema.frontend "Consulta la carta, las promociones y cotiza" "Navegador web"
        cliente -> sistema.frontend "Registra su cuenta, arma pedidos, paga y consulta" "Navegador web"
        personal -> sistema.frontend "Opera el panel interno segun su rol" "Navegador web"
        sistema.frontend -> sistema.apiGateway "Envia las solicitudes de las paginas (cookie de sesion HttpOnly)" "HTTP/JSON"
                sistema.apiGateway -> sistema.frontend "Devuelve respuestas y errores controlados" "HTTP" "Respuesta"
        sistema.apiGateway -> sistema.authService "Inicia sesion, valida la sesion y administra usuarios" "HTTP/JSON"
        sistema.apiGateway -> sistema.clients "Enruta registro y datos de clientes" "HTTP/JSON"
        sistema.apiGateway -> sistema.inventory "Enruta carta, promociones y mantenedor de productos" "HTTP/JSON"
        sistema.apiGateway -> sistema.orders "Enruta pedidos, despacho y cotizaciones" "HTTP/JSON"
        sistema.apiGateway -> sistema.payments "Enruta pagos, boletas, reembolsos y el aviso del proveedor" "HTTP/JSON"
        sistema.apiGateway -> sistema.notifications "Enruta contacto y bandeja de salida" "HTTP/JSON"
        sistema.apiGateway -> sistema.graphqlGateway "Enruta consultas GraphQL" "HTTP/GraphQL"
        proveedor.sandbox -> sistema.apiGateway "Avisa el resultado del pago (aviso firmado)" "HTTP/JSON"
        sistema.clients -> sistema.authService "Crea, activa y borra las credenciales del cliente" "HTTP/JSON"
        sistema.clients -> sistema.notifications "Valida el correo y envia los mensajes del registro" "HTTP/JSON"
        sistema.orders -> sistema.clients "Pide el perfil de entrega del cliente" "HTTP/JSON"
        sistema.orders -> sistema.inventory "Resuelve precios y disponibilidad vigentes" "HTTP/JSON"
        sistema.orders -> sistema.payments "Cancela el pago de un pedido anulado" "HTTP/JSON"
        sistema.orders -> sistema.notifications "Avisa los cambios del pedido" "HTTP/JSON"
        sistema.payments -> sistema.orders "Consulta el pedido pagable y confirma pagos y reembolsos" "HTTP/JSON"
        sistema.payments -> sistema.analytics "Publica las ventas y sus anulaciones" "HTTP/JSON"
        sistema.payments -> sistema.notifications "Envia la boleta y los avisos de pago" "HTTP/JSON"
        sistema.payments -> proveedor.sandbox "Crea cobros y los concilia" "HTTP/JSON"
        sistema.notifications -> correo "Entrega los correos (adaptador de prueba)" "SMTP"
        sistema.graphqlGateway -> sistema.orders "Lee pedidos y su resumen" "HTTP/JSON"
        sistema.graphqlGateway -> sistema.payments "Lee pagos, boletas y su resumen" "HTTP/JSON"
        sistema.graphqlGateway -> sistema.inventory "Lee productos y su resumen" "HTTP/JSON"
        sistema.graphqlGateway -> sistema.analytics "Lee el reporte de ventas" "HTTP/JSON"

        // Cada servicio lee solo su propia base (usuario propio de MongoDB).
        sistema.authService -> sistema.dbIdentity "Lee y escribe usuarios y sesiones" "Acceso a datos"
        sistema.clients -> sistema.dbClients "Lee y escribe perfiles de clientes" "Acceso a datos"
        sistema.inventory -> sistema.dbInventory "Lee y escribe productos y promociones" "Acceso a datos"
        sistema.orders -> sistema.dbOrders "Lee y escribe pedidos" "Acceso a datos"
        sistema.payments -> sistema.dbPayments "Lee y escribe pagos, ventas y boletas" "Acceso a datos"
        sistema.notifications -> sistema.dbNotifications "Lee y escribe la bandeja de salida" "Acceso a datos"
        sistema.analytics -> sistema.dbAnalytics "Lee y escribe ventas" "Acceso a datos"

        // Secretos: cada consumidor lee solo los suyos, con su propio token (ver docs/matrices/inventario_de_secretos.md).
        sistema.apiGateway -> sistema.secretManager "Lee los secretos de sus pares y de la sesion" "HTTP/JSON, token propio"
        sistema.authService -> sistema.secretManager "Lee su secreto y la credencial de su base" "HTTP/JSON, token propio"
        sistema.clients -> sistema.secretManager "Lee sus secretos y la credencial de su base" "HTTP/JSON, token propio"
        sistema.inventory -> sistema.secretManager "Lee sus secretos y la credencial de su base" "HTTP/JSON, token propio"
        sistema.orders -> sistema.secretManager "Lee sus secretos y la credencial de su base" "HTTP/JSON, token propio"
        sistema.payments -> sistema.secretManager "Lee sus secretos, la clave del proveedor y la credencial de su base" "HTTP/JSON, token propio"
        sistema.notifications -> sistema.secretManager "Lee sus secretos y la credencial de su base" "HTTP/JSON, token propio"
        sistema.analytics -> sistema.secretManager "Lee sus secretos y la credencial de su base" "HTTP/JSON, token propio"
        sistema.graphqlGateway -> sistema.secretManager "Lee los secretos de sus pares" "HTTP/JSON, token propio"
        proveedor.sandbox -> sistema.secretManager "Lee su clave y el secreto de firma" "HTTP/JSON, token propio"

        // Componentes C3 - API Gateway.
        sistema.frontend -> sistema.apiGateway.entrada "Invoca las funciones del backend" "HTTP/JSON"
        proveedor.sandbox -> sistema.apiGateway.entrada "Avisa el resultado del pago (aviso firmado)" "HTTP/JSON"
        sistema.apiGateway.entrada -> sistema.apiGateway.limitador "Cuenta la solicitud por origen"
        sistema.apiGateway.limitador -> sistema.apiGateway.verificadorOrigen "Deja pasar si no excede el limite"
        sistema.apiGateway.verificadorOrigen -> sistema.apiGateway.tablaRutas "Busca la ruta y valida sus parametros"
        sistema.apiGateway.tablaRutas -> sistema.apiGateway.filtroSesion "Pide el control de acceso de la ruta"
        sistema.apiGateway.filtroSesion -> sistema.authService "Valida la sesion" "HTTP/JSON"
        sistema.apiGateway.filtroSesion -> sistema.apiGateway.despachador "Permite una ruta publica o una solicitud autorizada"
        sistema.apiGateway.despachador -> sistema.apiGateway.clienteInterno "Reenvia al destino de la tabla"
        sistema.apiGateway.clienteInterno -> sistema.inventory "Llama a inventory" "HTTP/JSON"
        sistema.apiGateway.clienteInterno -> sistema.orders "Llama a orders" "HTTP/JSON"
        sistema.apiGateway.clienteInterno -> sistema.clients "Llama a clients" "HTTP/JSON"
        sistema.apiGateway.clienteInterno -> sistema.payments "Llama a payments" "HTTP/JSON"
        sistema.apiGateway.clienteInterno -> sistema.notifications "Llama a notifications" "HTTP/JSON"
        sistema.apiGateway.clienteInterno -> sistema.graphqlGateway "Llama al GraphQL Gateway" "HTTP/GraphQL"
        sistema.apiGateway.clienteInterno -> sistema.secretManager "Lee el secreto de cada par" "HTTP/JSON, token propio"
        sistema.apiGateway.clienteInterno -> sistema.apiGateway.traductorErrores "Reporta fallas de comunicacion"
                sistema.apiGateway.traductorErrores -> sistema.apiGateway.entrada "Entrega el error controlado" "" "Respuesta"
                sistema.apiGateway.despachador -> sistema.apiGateway.entrada "Entrega la respuesta del destino" "" "Respuesta"

        // Componentes C3 - GraphQL Gateway.
        sistema.apiGateway -> sistema.graphqlGateway.graphqlEndpoint "Remite las operaciones GraphQL con la identidad verificada" "HTTP/GraphQL"
        sistema.graphqlGateway.graphqlEndpoint -> sistema.graphqlGateway.validadorConsultas "Verifica sintaxis, esquema y limites"
        sistema.graphqlGateway.validadorConsultas -> sistema.graphqlGateway.permisosCampos "Entrega la consulta valida"
        sistema.graphqlGateway.permisosCampos -> sistema.graphqlGateway.resolvers "Autoriza los campos"
        sistema.graphqlGateway.resolvers -> sistema.graphqlGateway.cargadores "Pide productos y pagos por lote"
        sistema.graphqlGateway.resolvers -> sistema.graphqlGateway.conectores "Pide pedidos, resumenes y reportes"
        sistema.graphqlGateway.cargadores -> sistema.graphqlGateway.conectores "Hace una sola llamada por tipo de dato"
        sistema.graphqlGateway.conectores -> sistema.orders "Lee pedidos" "HTTP/JSON"
        sistema.graphqlGateway.conectores -> sistema.payments "Lee pagos y boletas" "HTTP/JSON"
        sistema.graphqlGateway.conectores -> sistema.inventory "Lee productos" "HTTP/JSON"
        sistema.graphqlGateway.conectores -> sistema.analytics "Lee el reporte de ventas" "HTTP/JSON"
        sistema.graphqlGateway.conectores -> sistema.secretManager "Lee el secreto de cada par" "HTTP/JSON, token propio"
        sistema.graphqlGateway.resolvers -> sistema.graphqlGateway.compositorRespuestas "Envia datos y errores"
                sistema.graphqlGateway.compositorRespuestas -> sistema.graphqlGateway.graphqlEndpoint "Entrega la respuesta" "" "Respuesta"
                sistema.graphqlGateway.validadorConsultas -> sistema.graphqlGateway.graphqlEndpoint "Reporta el rechazo de una consulta invalida" "" "Respuesta"
                sistema.graphqlGateway.graphqlEndpoint -> sistema.apiGateway "Responde el resultado o el error GraphQL" "HTTP/GraphQL" "Respuesta"

        // Componentes C3 - Auth Service.
        sistema.apiGateway -> sistema.authService.identityApi "Valida identidad y sesiones" "HTTP/JSON"
        sistema.clients -> sistema.authService.identityApi "Administra las credenciales del cliente" "HTTP/JSON"
        sistema.authService.identityApi -> sistema.authService.guardiaAuth "Verifica quien llama y con que rol"
        sistema.authService.guardiaAuth -> sistema.secretManager "Lee el secreto del par llamador-destino" "HTTP/JSON, token propio"
        sistema.authService.guardiaAuth -> sistema.authService.politicaAcceso "Pasa el inicio de sesion autorizado"
        sistema.authService.guardiaAuth -> sistema.authService.gestorSesiones "Pasa la validacion y el cierre de sesion"
        sistema.authService.politicaAcceso -> sistema.authService.verificadorClaves "Pide verificar la clave"
        sistema.authService.politicaAcceso -> sistema.authService.gestorSesiones "Pide emitir la sesion"
        sistema.authService.verificadorClaves -> sistema.authService.repositorioIdentidades "Lee el hash del usuario"
        sistema.authService.gestorSesiones -> sistema.authService.repositorioIdentidades "Guarda, lee y revoca sesiones"
        sistema.authService.repositorioIdentidades -> sistema.dbIdentity "Lee y escribe usuarios y sesiones" "Acceso a datos"

        // Componentes C3 - orders.
        sistema.apiGateway -> sistema.orders.ordersApi "Enruta las operaciones de pedidos" "HTTP/JSON"
        sistema.graphqlGateway -> sistema.orders.ordersApi "Lee los pedidos permitidos" "HTTP/JSON"
        sistema.payments -> sistema.orders.ordersApi "Consulta el pedido pagable y confirma pagos" "HTTP/JSON"
        sistema.orders.ordersApi -> sistema.orders.guardiaOrders "Comprueba el llamador, la identidad y el rol"
        sistema.orders.guardiaOrders -> sistema.orders.politicaPedidos "Pasa la solicitud autorizada"
        sistema.orders.politicaPedidos -> sistema.orders.flujoPedidos "Encamina las lecturas y las operaciones sobre un pedido propio"
        sistema.orders.politicaPedidos -> sistema.orders.idempotencia "Encamina la creacion de pedidos"
        sistema.orders.idempotencia -> sistema.orders.repositorioPedidos "Busca el pedido previo por clave"
        sistema.orders.idempotencia -> sistema.orders.flujoPedidos "Ejecuta solo la creacion admisible"
        sistema.orders.flujoPedidos -> sistema.orders.reglasPedido "Aplica ciclo de vida, totales y despacho"
        sistema.orders.flujoPedidos -> sistema.orders.adaptadorClientes "Pide el perfil de entrega"
        sistema.orders.flujoPedidos -> sistema.orders.adaptadorInventario "Pide precios y disponibilidad"
        sistema.orders.flujoPedidos -> sistema.orders.adaptadorPagos "Cancela el pago de un pedido anulado"
        sistema.orders.flujoPedidos -> sistema.orders.repositorioPedidos "Persiste el pedido y sus cambios de estado"
        sistema.orders.adaptadorClientes -> sistema.clients "Invoca el contrato de clients" "HTTP/JSON"
        sistema.orders.adaptadorInventario -> sistema.inventory "Invoca el contrato de inventory" "HTTP/JSON"
        sistema.orders.adaptadorPagos -> sistema.payments "Invoca el contrato de payments" "HTTP/JSON"
        sistema.orders.repositorioPedidos -> sistema.dbOrders "Lee y escribe pedidos y claves" "Acceso a datos"
                sistema.dbOrders -> sistema.orders.repositorioPedidos "Devuelve el pedido o el resultado previo" "Acceso a datos" "Respuesta"
                sistema.orders.repositorioPedidos -> sistema.orders.idempotencia "Devuelve el resultado de la operacion ya registrada" "" "Respuesta"
                sistema.orders.idempotencia -> sistema.orders.ordersApi "Devuelve el resultado existente sin crear otro pedido" "" "Respuesta"
                sistema.orders.ordersApi -> sistema.apiGateway "Devuelve la respuesta controlada" "HTTP/JSON" "Respuesta"

        // Componentes C3 - payments.
        sistema.apiGateway -> sistema.payments.paymentsApi "Enruta los pagos y el aviso del proveedor" "HTTP/JSON"
        sistema.graphqlGateway -> sistema.payments.paymentsApi "Lee pagos, boletas y resumen" "HTTP/JSON"
        sistema.orders -> sistema.payments.paymentsApi "Cancela el pago de un pedido anulado" "HTTP/JSON"
        sistema.payments.paymentsApi -> sistema.payments.guardiaPayments "Comprueba el llamador, la identidad y el rol"
        sistema.payments.guardiaPayments -> sistema.payments.verificadorFirma "Entrega el aviso del proveedor sin interpretarlo"
        sistema.payments.guardiaPayments -> sistema.payments.adaptadorPedidos "Autoriza iniciar el pago de un pedido propio"
        sistema.payments.guardiaPayments -> sistema.payments.aprobacion "Autoriza la confirmacion manual del administrador"
        sistema.payments.verificadorFirma -> sistema.secretManager "Lee el secreto de firma" "HTTP/JSON, token propio"
        sistema.payments.verificadorFirma -> sistema.payments.registroEventos "Entrega el aviso con firma y fecha validas"
                sistema.payments.verificadorFirma -> sistema.payments.paymentsApi "Rechaza el aviso con firma o fecha invalidas" "" "Respuesta"
        sistema.payments.registroEventos -> sistema.payments.aprobacion "Procesa solo un aviso nuevo"
                sistema.payments.registroEventos -> sistema.payments.paymentsApi "Responde que el aviso ya se habia procesado" "" "Respuesta"
        sistema.payments.adaptadorPedidos -> sistema.orders "Invoca el contrato de orders" "HTTP/JSON"
        sistema.payments.adaptadorPedidos -> sistema.payments.adaptadorProveedor "Pasa el monto que informa orders"
        sistema.payments.adaptadorProveedor -> proveedor.sandbox "Crea y consulta cobros" "HTTP/JSON"
        sistema.payments.aprobacion -> sistema.payments.adaptadorPedidos "Avisa al pedido que el pago se confirmo"
        sistema.payments.aprobacion -> sistema.payments.ventasBoletas "Registra la venta del pago aprobado"
        sistema.payments.ventasBoletas -> sistema.analytics "Publica la venta" "HTTP/JSON"
        sistema.payments.ventasBoletas -> sistema.notifications "Envia la boleta" "HTTP/JSON"
        sistema.payments.conciliador -> sistema.payments.adaptadorProveedor "Pregunta por los cobros sin aviso"
        sistema.payments.conciliador -> sistema.payments.aprobacion "Aprueba los cobros que el proveedor confirma"
        sistema.payments.conciliador -> sistema.payments.ventasBoletas "Completa ventas y entregas pendientes"
        sistema.payments.registroEventos -> sistema.payments.repositorioPagos "Guarda el identificador del aviso"
        sistema.payments.aprobacion -> sistema.payments.repositorioPagos "Cambia el estado del pago"
        sistema.payments.ventasBoletas -> sistema.payments.repositorioPagos "Guarda la venta y la boleta"
        sistema.payments.repositorioPagos -> sistema.dbPayments "Lee y escribe pagos, ventas y avisos" "Acceso a datos"
                sistema.payments.paymentsApi -> sistema.apiGateway "Devuelve la respuesta controlada" "HTTP/JSON" "Respuesta"

        // Respuestas explicitas que se siguen en los escenarios dinamicos (son relaciones de comunicacion, no resultados de pruebas).
        sistema.frontend -> visitante "Presenta resultados de consulta" "Interfaz web" "Respuesta"
        sistema.frontend -> cliente "Presenta resultados y errores de las operaciones" "Interfaz web" "Respuesta"
        sistema.frontend -> personal "Presenta los paneles y los reportes" "Interfaz web" "Respuesta"
        sistema.authService -> sistema.apiGateway "Responde las comprobaciones de identidad" "HTTP/JSON" "Respuesta"
        sistema.inventory -> sistema.apiGateway "Responde consultas de la carta" "HTTP/JSON" "Respuesta"
        sistema.orders -> sistema.apiGateway "Responde operaciones y consultas de pedidos" "HTTP/JSON" "Respuesta"
        sistema.payments -> sistema.apiGateway "Responde operaciones de pago y el aviso del proveedor" "HTTP/JSON" "Respuesta"
        sistema.graphqlGateway -> sistema.apiGateway "Devuelve el resultado agregado o el error" "HTTP/GraphQL" "Respuesta"
        sistema.apiGateway -> proveedor.sandbox "Responde el aviso del proveedor" "HTTP/JSON" "Respuesta"
        proveedor.sandbox -> sistema.payments "Devuelve el cobro creado o consultado" "HTTP/JSON" "Respuesta"
        sistema.clients -> sistema.orders "Responde el perfil de entrega" "HTTP/JSON" "Respuesta"
        sistema.inventory -> sistema.orders "Responde precios y disponibilidad" "HTTP/JSON" "Respuesta"
        sistema.orders -> sistema.graphqlGateway "Devuelve los datos autorizados de pedidos" "HTTP/JSON" "Respuesta"
        sistema.payments -> sistema.graphqlGateway "Devuelve pagos y boletas" "HTTP/JSON" "Respuesta"
        sistema.inventory -> sistema.graphqlGateway "Devuelve productos" "HTTP/JSON" "Respuesta"
        sistema.analytics -> sistema.graphqlGateway "Devuelve el reporte de ventas" "HTTP/JSON" "Respuesta"
        sistema.dbInventory -> sistema.inventory "Devuelve resultados de consulta" "Acceso a datos" "Respuesta"
        sistema.dbOrders -> sistema.orders "Devuelve el estado de pedidos y operaciones" "Acceso a datos" "Respuesta"
        sistema.dbPayments -> sistema.payments "Devuelve pagos y avisos" "Acceso a datos" "Respuesta"
        sistema.dbAnalytics -> sistema.analytics "Devuelve las ventas agregadas" "Acceso a datos" "Respuesta"

        // Despliegue 1: lo que describe docker-compose.yml (todo en localhost). Se ejecuto con Docker Desktop el 2026-11-07 y el 2026-11-08 (docs/evidencia/docker_humo.txt y docs/evidencia/docker_2026-11-08/).
        compose = deploymentEnvironment "Docker_Compose_Local" {
            deploymentNode "Equipo del evaluador" "Computador con Docker; todo corre en localhost." "Computador" {
                tags "ZonaLocal"

                deploymentNode "Navegador web" "Ejecuta las paginas; se abre http://localhost:8000." "Navegador" {
                    containerInstance sistema.frontend
                }

                deploymentNode "Docker Compose" "docker compose up: una imagen por servicio, sin privilegios, con sistema de archivos de solo lectura." "Docker Compose" {
                    deploymentNode "Zona de entrada" "Los dos unicos contenedores con puerto publicado, y solo hacia 127.0.0.1. Pertenecen a la red publica y a la interna." "Red publica" {
                        tags "ZonaPublica"

                        deploymentNode "Contenedor api-gateway" "127.0.0.1:8000. Unico acceso al sistema." "Contenedor" {
                            containerInstance sistema.apiGateway
                        }
                        deploymentNode "Contenedor provider-sandbox" "127.0.0.1:8300. Pagina de pago del proveedor simulado." "Contenedor" {
                            containerInstance proveedor.sandbox
                        }
                    }

                    deploymentNode "Zona de servicios privados" "Red interna (internal: true): sin salida a Internet y sin puertos publicados." "Red interna" {
                        tags "ZonaPrivada"

                        deploymentNode "Contenedores de servicios" "Un contenedor por servicio; se hablan por HTTP con secretos por par." "Contenedores" {
                            containerInstance sistema.authService
                            containerInstance sistema.clients
                            containerInstance sistema.inventory
                            containerInstance sistema.orders
                            containerInstance sistema.payments
                            containerInstance sistema.notifications
                            containerInstance sistema.analytics
                            containerInstance sistema.graphqlGateway
                        }
                        deploymentNode "Contenedor mongo" "MongoDB 8.0: una base y un usuario por servicio." "Servicio de datos" {
                            containerInstance sistema.dbIdentity
                            containerInstance sistema.dbClients
                            containerInstance sistema.dbInventory
                            containerInstance sistema.dbOrders
                            containerInstance sistema.dbPayments
                            containerInstance sistema.dbNotifications
                            containerInstance sistema.dbAnalytics
                        }
                        deploymentNode "Contenedor vault" "Vault 2.0.0 en modo desarrollo (memoria); no es una configuracion de produccion." "Servicio protegido" {
                            containerInstance sistema.secretManager
                        }
                        deploymentNode "Tarea vault-seed" "Corre una vez al iniciar: genera los secretos, las politicas y un token por servicio." "Tarea de arranque" {
                            infrastructureNode "Siembra de secretos" "scripts/seed_vault.py: no deja valores en el repositorio." "Python"
                        }
                    }
                }
            }
        }

        // Despliegue 2: la variante que si se ejecuto en el desarrollo (sin Docker): scripts/demo_local.py y la suite de pruebas.
        procesos = deploymentEnvironment "Procesos_Locales" {
            deploymentNode "Equipo de desarrollo" "Estacion local usada para pruebas y demostracion." "Estacion de trabajo" {
                tags "ZonaLocal"

                deploymentNode "Navegador local" "Frontend de la C2 ejecutado en el navegador (cliente externo; su integracion se valida en la Evaluacion 3)." "Navegador" {
                    containerInstance sistema.frontend
                }
                deploymentNode "Proceso de entrada" "API Gateway en el puerto 8000; el proveedor simulado en el 8300." "Procesos locales" {
                    containerInstance sistema.apiGateway
                    containerInstance proveedor.sandbox
                }
                deploymentNode "Procesos privados" "Un proceso de Python por servicio, con su propio token de Vault y su propia base." "Procesos locales" {
                    containerInstance sistema.authService
                    containerInstance sistema.clients
                    containerInstance sistema.inventory
                    containerInstance sistema.orders
                    containerInstance sistema.payments
                    containerInstance sistema.notifications
                    containerInstance sistema.analytics
                    containerInstance sistema.graphqlGateway
                }
                deploymentNode "Persistencia y secretos locales" "Vault y MongoDB reales (binarios) o simulados en memoria; datos ficticios." "Servicios locales" {
                    containerInstance sistema.dbIdentity
                    containerInstance sistema.dbClients
                    containerInstance sistema.dbInventory
                    containerInstance sistema.dbOrders
                    containerInstance sistema.dbPayments
                    containerInstance sistema.dbNotifications
                    containerInstance sistema.dbAnalytics
                    containerInstance sistema.secretManager
                }
            }
        }
    }

    views {
        systemContext sistema "C1_Contexto" "Contexto: personas y sistemas externos de El Asador." {
            title "C1 - Contexto de El Asador"
            include *
            autoLayout lr
        }

        container sistema "C2_Contenedores" "Aplicaciones, servicios privados y bases de datos (sin las lecturas de secretos, que estan en C2_Secretos)." {
            title "C2 - Contenedores de El Asador"
            include *
            exclude "* -> sistema.secretManager"
            exclude "relationship.tag==Respuesta"
            autoLayout lr
        }

        container sistema "C2_Secretos" "Quien lee secretos del administrador y para que (referencias simbolicas; ningun valor)." {
            title "C2 - Secretos: consumidores del administrador de secretos"
            include sistema.secretManager sistema.apiGateway sistema.authService sistema.clients sistema.inventory sistema.orders sistema.payments sistema.notifications sistema.analytics sistema.graphqlGateway proveedor.sandbox
            autoLayout lr
        }

        // Vistas adicionales: recortes del mismo modelo, no otros sistemas.
        container sistema "C2_Catalogo" "Recorrido estructural de la consulta de la carta." {
            title "C2 - Recorte: consulta de la carta"
            include visitante sistema.frontend sistema.apiGateway sistema.inventory sistema.dbInventory
            exclude "relationship.tag==Respuesta"
            autoLayout lr
        }

        container sistema "C2_Pedidos" "Recorrido estructural del registro de pedidos." {
            title "C2 - Recorte: registro de pedidos"
            include cliente sistema.frontend sistema.apiGateway sistema.authService sistema.orders sistema.clients sistema.inventory sistema.dbOrders sistema.dbClients sistema.dbInventory
            exclude "relationship.tag==Respuesta"
            autoLayout lr
        }

        container sistema "C2_Pagos" "Recorrido estructural del pago, la boleta y la venta." {
            title "C2 - Recorte: pago, boleta y venta"
            include cliente proveedor sistema.apiGateway sistema.orders sistema.payments sistema.analytics sistema.notifications correo sistema.dbPayments sistema.dbAnalytics sistema.dbNotifications
            exclude "relationship.tag==Respuesta"
            autoLayout lr
        }

        component sistema.apiGateway "C3_API_Gateway" "Componentes internos del punto de entrada HTTP." {
            title "C3 - API Gateway"
            include *
            exclude "relationship.tag==Respuesta"
            autoLayout lr
        }

        component sistema.graphqlGateway "C3_GraphQL" "Validacion, autorizacion y agregacion de datos." {
            title "C3 - GraphQL Gateway"
            include *
            exclude "relationship.tag==Respuesta"
            autoLayout lr
        }

        component sistema.authService "C3_Auth_Service" "Identidad, sesiones, credenciales y secretos." {
            title "C3 - Auth Service"
            include *
            exclude "relationship.tag==Respuesta"
            autoLayout lr
        }

        component sistema.orders "C3_Orders" "Autorizacion, idempotencia, reglas y persistencia de pedidos." {
            title "C3 - orders"
            include *
            exclude "relationship.tag==Respuesta"
            autoLayout lr
        }

        component sistema.payments "C3_Payments" "Verificacion del aviso, aprobacion unica, ventas y conciliacion." {
            title "C3 - payments"
            include *
            exclude "relationship.tag==Respuesta"
            autoLayout lr
        }

        // ================================================
        // ESCENARIOS DINAMICOS: cada uno cita la prueba ejecutable que lo verifica (ver docs/matrices/trazabilidad.md)
        // ================================================

        dynamic sistema "D_F01_Exito" "Consulta de la carta (S04) desde el navegador hasta inventory y de vuelta. Prueba: test_resiliencia.py::test_el_catalogo_en_cache_sigue_visible_unos_segundos_sin_inventario; recorrido por HTTP: docs/evidencia/humo.txt." {
            title "F01 - Consulta de la carta: exito"
            1: visitante -> sistema.frontend "Abre la carta"
            2: sistema.frontend -> sistema.apiGateway "GET /api/products (S04)" "HTTP/JSON"
            3: sistema.apiGateway -> sistema.inventory "Consulta los productos (la carta anonima se guarda en cache unos segundos)" "HTTP/JSON"
            4: sistema.inventory -> sistema.dbInventory "Busca los productos" "Acceso a datos"
            5: sistema.dbInventory -> sistema.inventory "Devuelve los registros" "Acceso a datos"
            6: sistema.inventory -> sistema.apiGateway "Responde solo los campos permitidos del catalogo" "HTTP/JSON"
            7: sistema.apiGateway -> sistema.frontend "Devuelve el listado" "HTTP"
            8: sistema.frontend -> visitante "Presenta la carta"
            autoLayout lr
        }

        dynamic sistema "D_F01_Recuperacion" "Inventory no responde: error controlado y nueva consulta al volver. Pruebas: test_resiliencia.py::test_el_cortacircuitos_deja_de_esperar_y_se_recupera_solo y ::test_con_inventario_colgado_no_se_crean_pedidos_a_medias_y_lo_demas_sigue." {
            title "F01 - Falla controlada y recuperacion"
            1: visitante -> sistema.frontend "Abre la carta con un filtro que no esta en cache"
            2: sistema.frontend -> sistema.apiGateway "GET /api/products (S04)" "HTTP/JSON"
            3: sistema.apiGateway -> sistema.inventory "Consulta la carta; inventory no responde" "HTTP/JSON"
            4: sistema.apiGateway -> sistema.frontend "Plazo agotado o circuito abierto: error controlado 503/504, sin detalles internos" "HTTP"
            5: sistema.frontend -> visitante "Muestra que el servicio no esta disponible, sin datos inventados"
            6: visitante -> sistema.frontend "Reintenta cuando inventory vuelve"
            7: sistema.frontend -> sistema.apiGateway "GET /api/products (S04)" "HTTP/JSON"
            8: sistema.apiGateway -> sistema.inventory "Consulta la carta recuperada" "HTTP/JSON"
            9: sistema.inventory -> sistema.dbInventory "Busca los productos" "Acceso a datos"
            10: sistema.dbInventory -> sistema.inventory "Devuelve los registros" "Acceso a datos"
            11: sistema.inventory -> sistema.apiGateway "Responde el listado" "HTTP/JSON"
            12: sistema.apiGateway -> sistema.frontend "Devuelve el listado" "HTTP"
            13: sistema.frontend -> visitante "Presenta la carta"
            autoLayout lr
        }

        dynamic sistema "D_F02_Exito" "Registro de un pedido (S21): identidad, perfil y precios que entregan sus autoridades, persistencia y respuesta. Prueba: test_negocio_pedidos.py::test_idempotency_key_evita_duplicar_el_pedido (primer envio)." {
            title "F02 - Registro de pedido: exito"
            1: cliente -> sistema.frontend "Confirma el pedido"
            2: sistema.frontend -> sistema.apiGateway "POST /api/orders (S21) con Idempotency-Key" "HTTP/JSON"
            3: sistema.apiGateway -> sistema.authService "Introspecta la sesion" "HTTP/JSON"
            4: sistema.authService -> sistema.apiGateway "Confirma la identidad y el rol" "HTTP/JSON"
            5: sistema.apiGateway -> sistema.orders "Reenvia con la identidad verificada" "HTTP/JSON"
            6: sistema.orders -> sistema.clients "Pide el perfil de entrega (autoridad de los datos del cliente)" "HTTP/JSON"
            7: sistema.clients -> sistema.orders "Responde el perfil" "HTTP/JSON"
            8: sistema.orders -> sistema.inventory "Resuelve precios y disponibilidad vigentes (no confia en los del navegador)" "HTTP/JSON"
            9: sistema.inventory -> sistema.orders "Responde precios y disponibilidad" "HTTP/JSON"
            10: sistema.orders -> sistema.dbOrders "Persiste el pedido en Pago pendiente y la clave" "Acceso a datos"
            11: sistema.dbOrders -> sistema.orders "Confirma la escritura" "Acceso a datos"
            12: sistema.orders -> sistema.apiGateway "Devuelve el identificador y el estado (201)" "HTTP/JSON"
            13: sistema.apiGateway -> sistema.frontend "Responde la operacion" "HTTP"
            14: sistema.frontend -> cliente "Muestra el pedido creado"
            autoLayout lr
        }

        dynamic sistema "D_F02_Reintento" "Segunda ejecucion con la misma Idempotency-Key: devuelve el pedido existente. Prueba: test_negocio_pedidos.py::test_idempotency_key_evita_duplicar_el_pedido." {
            title "F02 - Reintento de pedido: sin duplicacion"
            1: cliente -> sistema.frontend "Reintenta el mismo pedido tras una respuesta incierta"
            2: sistema.frontend -> sistema.apiGateway "POST /api/orders (S21) con la misma clave" "HTTP/JSON"
            3: sistema.apiGateway -> sistema.orders "Reenvia la solicitud repetida" "HTTP/JSON"
            4: sistema.orders -> sistema.dbOrders "Busca el pedido por cliente y clave" "Acceso a datos"
            5: sistema.dbOrders -> sistema.orders "Devuelve el pedido ya registrado" "Acceso a datos"
            6: sistema.orders -> sistema.apiGateway "Reutiliza el resultado (200): no crea un segundo pedido" "HTTP/JSON"
            7: sistema.apiGateway -> sistema.frontend "Devuelve el identificador previo" "HTTP"
            8: sistema.frontend -> cliente "Muestra el pedido existente"
            autoLayout lr
        }

        dynamic sistema.orders "D_F02_Idempotencia_C3" "Detalle de una solicitud repetida dentro de orders. Prueba: test_negocio_pedidos.py::test_idempotency_key_evita_duplicar_el_pedido." {
            title "F02 - Idempotencia: componentes internos"
            1: sistema.apiGateway -> sistema.orders.ordersApi "Entrega el POST repetido y la clave" "HTTP/JSON"
            2: sistema.orders.ordersApi -> sistema.orders.guardiaOrders "Verifica llamador, identidad y rol"
            3: sistema.orders.guardiaOrders -> sistema.orders.politicaPedidos "Permite la escritura autorizada"
            4: sistema.orders.politicaPedidos -> sistema.orders.idempotencia "Encamina la creacion"
            5: sistema.orders.idempotencia -> sistema.orders.repositorioPedidos "Busca el pedido de esa clave"
            6: sistema.orders.repositorioPedidos -> sistema.dbOrders "Consulta la operacion ya persistida" "Acceso a datos"
            7: sistema.dbOrders -> sistema.orders.repositorioPedidos "Devuelve el pedido" "Acceso a datos"
            8: sistema.orders.repositorioPedidos -> sistema.orders.idempotencia "Entrega el resultado existente"
            9: sistema.orders.idempotencia -> sistema.orders.ordersApi "Retorna el resultado sin ejecutar el servicio de pedidos"
            10: sistema.orders.ordersApi -> sistema.apiGateway "Devuelve el mismo pedido, sin duplicar" "HTTP/JSON"
            autoLayout lr
        }

        dynamic sistema "D_F03_Propio" "Lectura autorizada de un pedido propio (S23). Evidencia: docs/evidencia/controles.md (control 8: el dueno lee su pedido; control 1: otro cliente recibe 403 por el mismo recurso) y docs/evidencia/humo.txt; prueba: test_seguridad_acceso.py::test_el_personal_si_ve_cualquier_pedido_y_los_datos_de_despacho. El navegador muestra los pedidos por GraphQL (D_F04_GraphQL_Exito): S23 no se llama desde el navegador." {
            title "F03 - Consulta protegida: pedido propio"
            1: cliente -> sistema.frontend "Abre uno de sus pedidos"
            2: sistema.frontend -> sistema.apiGateway "GET /api/orders/{pedido} (S23)" "HTTP/JSON"
            3: sistema.apiGateway -> sistema.authService "Comprueba la sesion" "HTTP/JSON"
            4: sistema.authService -> sistema.apiGateway "Sesion valida con identidad y rol" "HTTP/JSON"
            5: sistema.apiGateway -> sistema.orders "Pide el pedido con el contexto del usuario" "HTTP/JSON"
            6: sistema.orders -> sistema.dbOrders "Busca el pedido por identificador" "Acceso a datos"
            7: sistema.dbOrders -> sistema.orders "Devuelve el pedido" "Acceso a datos"
            8: sistema.orders -> sistema.apiGateway "Responde solo porque el titular es el cliente de la sesion" "HTTP/JSON"
            9: sistema.apiGateway -> sistema.frontend "Devuelve el pedido" "HTTP"
            10: sistema.frontend -> cliente "Muestra el identificador y el estado"
            autoLayout lr
        }

        dynamic sistema "D_F03_Ajeno" "Prueba negativa de autorizacion por pertenencia del recurso. Pruebas: test_seguridad_acceso.py::test_un_cliente_no_opera_sobre_pedidos_ajenos y ::test_el_pedido_ajeno_sigue_intacto_tras_los_intentos; evidencia: docs/evidencia/controles.md (control 1)." {
            title "F03 - Consulta protegida: pedido ajeno"
            1: cliente -> sistema.frontend "Intenta abrir el pedido de otro cliente"
            2: sistema.frontend -> sistema.apiGateway "GET /api/orders/{pedidoAjeno} (S23)" "HTTP/JSON"
            3: sistema.apiGateway -> sistema.authService "Comprueba la sesion" "HTTP/JSON"
            4: sistema.authService -> sistema.apiGateway "Sesion valida (no implica acceso al pedido)" "HTTP/JSON"
            5: sistema.apiGateway -> sistema.orders "Consulta el recurso con la identidad" "HTTP/JSON"
            6: sistema.orders -> sistema.dbOrders "Busca el pedido por identificador" "Acceso a datos"
            7: sistema.dbOrders -> sistema.orders "Devuelve el pedido, que no es del solicitante" "Acceso a datos"
            8: sistema.orders -> sistema.apiGateway "Rechaza con 403 PROHIBIDO, igual que un pedido inexistente" "HTTP/JSON"
            9: sistema.apiGateway -> sistema.frontend "Entrega el error conforme al contrato" "HTTP"
            10: sistema.frontend -> cliente "Muestra el rechazo sin datos ajenos"
            autoLayout lr
        }

        dynamic sistema "D_F03_Expirada" "El gateway rechaza la solicitud antes de llegar a orders si la sesion esta cerrada, revocada o vencida. Pruebas: test_seguridad_acceso.py::test_cerrar_sesion_la_revoca_en_el_servidor, test_sesion_vence.py::test_la_sesion_vence_y_el_servidor_rechaza_el_token_que_alguien_conserve y ::test_el_rechazo_por_sesion_vencida_no_llega_al_servicio_de_pedidos." {
            title "F03 - Sesion cerrada o vencida: rechazo temprano"
            1: cliente -> sistema.frontend "Intenta consultar un pedido con la sesion cerrada o vencida"
            2: sistema.frontend -> sistema.apiGateway "GET /api/orders/{pedido} (S23)" "HTTP/JSON"
            3: sistema.apiGateway -> sistema.authService "Verifica la sesion" "HTTP/JSON"
            4: sistema.authService -> sistema.apiGateway "Identidad no valida: active=false" "HTTP/JSON"
            5: sistema.apiGateway -> sistema.frontend "Responde 401 SESION_NO_VALIDA y borra la cookie; orders no se entera" "HTTP"
            6: sistema.frontend -> cliente "Pide ingresar de nuevo sin mostrar el pedido"
            autoLayout lr
        }

        dynamic sistema "D_F04_GraphQL_Exito" "Mis pedidos: la consulta combina orders, payments e inventory (S38). Prueba: test_graphql.py::test_mis_pedidos_une_pedido_pago_y_boleta_en_una_sola_consulta; recorrido por HTTP: docs/evidencia/humo.txt." {
            title "F04 - GraphQL: agregacion exitosa"
            1: cliente -> sistema.frontend "Abre Mis pedidos"
            2: sistema.frontend -> sistema.apiGateway "POST /api/graphql (S38) con la consulta misPedidos" "HTTP/JSON"
            3: sistema.apiGateway -> sistema.authService "Comprueba la sesion" "HTTP/JSON"
            4: sistema.authService -> sistema.apiGateway "Sesion valida con identidad y rol" "HTTP/JSON"
            5: sistema.apiGateway -> sistema.graphqlGateway "Entrega la consulta con la identidad verificada" "HTTP/GraphQL"
            6: sistema.graphqlGateway -> sistema.orders "Lee los pedidos del cliente" "HTTP/JSON"
            7: sistema.orders -> sistema.graphqlGateway "Devuelve los pedidos permitidos" "HTTP/JSON"
            8: sistema.graphqlGateway -> sistema.payments "Lee pagos y boletas de todos los pedidos en una llamada" "HTTP/JSON"
            8: sistema.graphqlGateway -> sistema.inventory "Lee los productos de todas las lineas en una llamada" "HTTP/JSON"
            9: sistema.payments -> sistema.graphqlGateway "Devuelve pagos y boletas" "HTTP/JSON"
            9: sistema.inventory -> sistema.graphqlGateway "Devuelve los productos" "HTTP/JSON"
            10: sistema.graphqlGateway -> sistema.apiGateway "Compone la respuesta agregada" "HTTP/GraphQL"
            11: sistema.apiGateway -> sistema.frontend "Entrega el resultado autorizado" "HTTP"
            12: sistema.frontend -> cliente "Muestra pedidos con su pago y su boleta"
            autoLayout lr
        }

        dynamic sistema "D_F04_GraphQL_Parcial" "Payments no responde: el dato faltante se informa y no se presenta como completo. Pruebas: test_resiliencia.py::test_con_pagos_colgado_mis_pedidos_se_ven_sin_el_dato_del_pago y ::test_con_analitica_colgada_el_reporte_falla_solo_en_su_campo." {
            title "F04 - GraphQL: dependencia fallida"
            1: cliente -> sistema.frontend "Abre Mis pedidos"
            2: sistema.frontend -> sistema.apiGateway "POST /api/graphql (S38)" "HTTP/JSON"
            3: sistema.apiGateway -> sistema.graphqlGateway "Remite la consulta permitida" "HTTP/GraphQL"
            4: sistema.graphqlGateway -> sistema.orders "Lee los pedidos del cliente" "HTTP/JSON"
            5: sistema.orders -> sistema.graphqlGateway "Devuelve los pedidos" "HTTP/JSON"
            6: sistema.graphqlGateway -> sistema.payments "Lee los pagos; payments no responde" "HTTP/JSON"
            7: sistema.graphqlGateway -> sistema.apiGateway "Entrega los pedidos con el pago en nulo y el aviso PAGOS_NO_DISPONIBLES" "HTTP/GraphQL"
            8: sistema.apiGateway -> sistema.frontend "Transmite el resultado identificado como incompleto" "HTTP"
            9: sistema.frontend -> cliente "Muestra los pedidos sin el dato del pago"
            autoLayout lr
        }

        dynamic sistema.graphqlGateway "D_F04_GraphQL_Limite_C3" "Rechazo antes de ejecutar resolvers o llamar a servicios privados. Pruebas: test_graphql.py::test_profundidad_maxima, ::test_campos_repetidos_que_harian_trabajo_cuadratico_se_rechazan y ::test_costo_maximo_con_la_consulta_real_de_la_pantalla." {
            title "F04 - GraphQL: consulta que excede el limite"
            1: sistema.apiGateway -> sistema.graphqlGateway.graphqlEndpoint "Envia una consulta que supera el limite" "HTTP/GraphQL"
            2: sistema.graphqlGateway.graphqlEndpoint -> sistema.graphqlGateway.validadorConsultas "Calcula profundidad, alias, tamano y costo"
            3: sistema.graphqlGateway.validadorConsultas -> sistema.graphqlGateway.graphqlEndpoint "Rechaza la consulta excesiva"
            4: sistema.graphqlGateway.graphqlEndpoint -> sistema.apiGateway "Devuelve el error sin llamar a ningun resolver" "HTTP/GraphQL"
            autoLayout lr
        }

        dynamic sistema "D_F05_Pago_Inicio" "Inicio del pago (S29): el monto lo entrega orders, no el navegador. Pruebas: test_negocio_pagos.py y recorrido del cliente por HTTP en docs/evidencia/humo.txt." {
            title "F05 - Pago: inicio del cobro"
            1: cliente -> sistema.frontend "Elige pagar un pedido en Pago pendiente"
            2: sistema.frontend -> sistema.apiGateway "POST /api/orders/{pedido}/payment (S29)" "HTTP/JSON"
            3: sistema.apiGateway -> sistema.authService "Comprueba la sesion" "HTTP/JSON"
            4: sistema.authService -> sistema.apiGateway "Sesion valida con identidad y rol" "HTTP/JSON"
            5: sistema.apiGateway -> sistema.payments "Reenvia con la identidad verificada" "HTTP/JSON"
            6: sistema.payments -> sistema.orders "Pide el pedido pagable: el monto y el estado vienen de orders" "HTTP/JSON"
            7: sistema.orders -> sistema.payments "Responde monto, estado y titular" "HTTP/JSON"
            8: sistema.payments -> sistema.dbPayments "Guarda el cobro iniciado (un solo cobro abierto por pedido)" "Acceso a datos"
            9: sistema.dbPayments -> sistema.payments "Confirma la escritura" "Acceso a datos"
            10: sistema.payments -> proveedor.sandbox "Crea el cobro con la clave del proveedor y un plazo maximo" "HTTP/JSON"
            11: proveedor.sandbox -> sistema.payments "Devuelve el cobro y la direccion de pago" "HTTP/JSON"
            12: sistema.payments -> sistema.apiGateway "Devuelve el cobro" "HTTP/JSON"
            13: sistema.apiGateway -> sistema.frontend "Responde la operacion" "HTTP"
            14: sistema.frontend -> cliente "Lleva al cliente a la pagina de pago"
            15: cliente -> proveedor.sandbox "Paga en la pagina del proveedor" "Navegador web"
            autoLayout lr
        }

        dynamic sistema "D_F05_Aviso_Firmado" "El proveedor avisa el pago (S35): se verifica la firma, se aprueba una sola vez, el pedido avanza y se registra la venta. Prueba: test_negocio_pagos.py::test_aviso_firmado_legitimo_aprueba_una_sola_vez_aunque_se_repita." {
            title "F05 - Pago: aviso firmado del proveedor"
            1: proveedor.sandbox -> sistema.apiGateway "POST /api/webhooks/provider (S35) con firma HMAC" "HTTP/JSON"
            2: sistema.apiGateway -> sistema.payments "Reenvia el cuerpo crudo y la firma (sin sesion de usuario)" "HTTP/JSON"
            3: sistema.payments -> sistema.secretManager "Lee el secreto de firma" "HTTP/JSON, token propio"
            4: sistema.payments -> sistema.dbPayments "Registra el aviso por su identificador y aprueba el pago de forma atomica" "Acceso a datos"
            5: sistema.dbPayments -> sistema.payments "Confirma la escritura" "Acceso a datos"
            6: sistema.payments -> sistema.orders "Confirma el pago: el pedido pasa a En preparacion" "HTTP/JSON"
            7: sistema.orders -> sistema.dbOrders "Cambia el estado" "Acceso a datos"
            8: sistema.dbOrders -> sistema.orders "Confirma la escritura" "Acceso a datos"
            9: sistema.orders -> sistema.payments "Responde la confirmacion" "HTTP/JSON"
            10: sistema.payments -> sistema.analytics "Publica la venta (tambien por el ciclo de reintentos)" "HTTP/JSON"
            11: sistema.payments -> sistema.notifications "Envia la boleta (tambien por el ciclo de reintentos)" "HTTP/JSON"
            12: sistema.notifications -> correo "Entrega el correo (adaptador de prueba)" "SMTP"
            13: sistema.payments -> sistema.apiGateway "Responde 200 al aviso" "HTTP/JSON"
            14: sistema.apiGateway -> proveedor.sandbox "Responde 200 al aviso" "HTTP/JSON"
            autoLayout lr
        }

        dynamic sistema.payments "D_F05_Aviso_Invalido_C3" "Un aviso con firma falsa o fecha fuera de la ventana se rechaza antes de leerlo y sin ningun efecto. Pruebas: test_negocio_pagos.py::test_aviso_sin_firma_o_con_firma_falsa_se_rechaza, ::test_aviso_alterado_despues_de_firmar_se_rechaza y ::test_aviso_antiguo_o_del_futuro_se_rechaza." {
            title "F05 - Pago: aviso con firma invalida"
            1: sistema.apiGateway -> sistema.payments.paymentsApi "Entrega el aviso sin sesion de usuario" "HTTP/JSON"
            2: sistema.payments.paymentsApi -> sistema.payments.guardiaPayments "Comprueba que llama el gateway"
            3: sistema.payments.guardiaPayments -> sistema.payments.verificadorFirma "Entrega el cuerpo crudo sin interpretarlo"
            4: sistema.payments.verificadorFirma -> sistema.secretManager "Lee el secreto de firma" "HTTP/JSON, token propio"
            5: sistema.payments.verificadorFirma -> sistema.payments.paymentsApi "Rechaza: firma falsa o fecha fuera de la ventana"
            6: sistema.payments.paymentsApi -> sistema.apiGateway "Responde 400 AVISO_NO_VALIDO; no cambia ningun pago" "HTTP/JSON"
            autoLayout lr
        }

        dynamic sistema.payments "D_F05_Aviso_Repetido_C3" "El mismo aviso otra vez: se reconoce por su identificador y no repite ningun efecto. Pruebas: test_negocio_pagos.py::test_aviso_firmado_legitimo_aprueba_una_sola_vez_aunque_se_repita y ::test_el_proveedor_que_entrega_cada_aviso_dos_veces_no_duplica_efectos." {
            title "F05 - Pago: aviso repetido"
            1: sistema.apiGateway -> sistema.payments.paymentsApi "Entrega el aviso repetido" "HTTP/JSON"
            2: sistema.payments.paymentsApi -> sistema.payments.guardiaPayments "Comprueba que llama el gateway"
            3: sistema.payments.guardiaPayments -> sistema.payments.verificadorFirma "Entrega el cuerpo crudo sin interpretarlo"
            4: sistema.payments.verificadorFirma -> sistema.payments.registroEventos "Entrega el aviso con firma y fecha validas"
            5: sistema.payments.registroEventos -> sistema.payments.repositorioPagos "Busca el identificador del aviso"
            6: sistema.payments.repositorioPagos -> sistema.dbPayments "Consulta los avisos ya procesados" "Acceso a datos"
            7: sistema.payments.registroEventos -> sistema.payments.paymentsApi "Responde que ya estaba procesado, sin repetir efectos"
            8: sistema.payments.paymentsApi -> sistema.apiGateway "Responde 200 duplicado" "HTTP/JSON"
            autoLayout lr
        }

        dynamic sistema "D_F06_Anulacion" "Anulacion de un pedido (S24): se anula primero y el pago se cancela despues; si payments no responde, orders reintenta. Prueba: test_resiliencia.py::test_anular_con_pagos_colgado_anula_al_instante_y_el_reembolso_se_registra_al_volver (ADR-008)." {
            title "F06 - Anulacion con cancelacion del pago"
            1: cliente -> sistema.frontend "Anula su pedido con un motivo"
            2: sistema.frontend -> sistema.apiGateway "POST /api/orders/{pedido}/cancellation (S24)" "HTTP/JSON"
            3: sistema.apiGateway -> sistema.authService "Comprueba la sesion" "HTTP/JSON"
            4: sistema.authService -> sistema.apiGateway "Sesion valida con identidad y rol" "HTTP/JSON"
            5: sistema.apiGateway -> sistema.orders "Reenvia con la identidad verificada" "HTTP/JSON"
            6: sistema.orders -> sistema.dbOrders "Marca el pedido Anulado, conserva el historial y deja el pago por cancelar" "Acceso a datos"
            7: sistema.dbOrders -> sistema.orders "Confirma la escritura" "Acceso a datos"
            8: sistema.orders -> sistema.payments "Pide cancelar el pago (reembolso si ya estaba pagado)" "HTTP/JSON"
            9: sistema.payments -> sistema.orders "Responde el resultado; si no responde, orders reintenta despues" "HTTP/JSON"
            10: sistema.orders -> sistema.apiGateway "Devuelve el pedido anulado" "HTTP/JSON"
            11: sistema.apiGateway -> sistema.frontend "Responde la operacion" "HTTP"
            12: sistema.frontend -> cliente "Muestra el pedido anulado"
            autoLayout lr
        }

        dynamic sistema "D_F07_Reporte_Ventas" "Reporte de ventas por periodo para el dueno y el administrador, via GraphQL (S38). Pruebas: test_graphql.py::test_el_reporte_de_ventas_de_la_pantalla_funciona_para_administrador_y_dueno y test_analitica.py; carga: docs/evidencia/carga.md." {
            title "F07 - Reporte de ventas"
            1: personal -> sistema.frontend "Abre Ventas con un rango de fechas"
            2: sistema.frontend -> sistema.apiGateway "POST /api/graphql (S38) con reporteVentas" "HTTP/JSON"
            3: sistema.apiGateway -> sistema.authService "Comprueba la sesion" "HTTP/JSON"
            4: sistema.authService -> sistema.apiGateway "Sesion valida con identidad y rol" "HTTP/JSON"
            5: sistema.apiGateway -> sistema.graphqlGateway "Entrega la consulta con la identidad verificada" "HTTP/GraphQL"
            6: sistema.graphqlGateway -> sistema.analytics "Lee el reporte del periodo (solo administrador o dueno)" "HTTP/JSON"
            7: sistema.analytics -> sistema.dbAnalytics "Agrega las ventas por dia, medio de pago y producto" "Acceso a datos"
            8: sistema.dbAnalytics -> sistema.analytics "Devuelve los totales, sin datos personales" "Acceso a datos"
            9: sistema.analytics -> sistema.graphqlGateway "Devuelve el reporte" "HTTP/JSON"
            10: sistema.graphqlGateway -> sistema.apiGateway "Entrega el reporte" "HTTP/GraphQL"
            11: sistema.apiGateway -> sistema.frontend "Responde el reporte autorizado" "HTTP"
            12: sistema.frontend -> personal "Presenta el reporte"
            autoLayout lr
        }

        // VISTAS DE DESPLIEGUE.
        deployment sistema compose "DEP_Compose_Local" "Contenedores, redes y puertos de docker-compose.yml (todo en localhost)." {
            title "Despliegue - Docker Compose en localhost (segun docker-compose.yml; ejecutado con Docker Desktop, 2026-11-07 y 2026-11-08)"
            include *
            autoLayout lr
        }

        deployment sistema procesos "DEP_Procesos_Locales" "La variante ejecutada en el desarrollo: un proceso por servicio en un solo equipo." {
            title "Despliegue - Procesos locales (variante ejecutada)"
            include *
            autoLayout lr
        }

        styles {
            element "Deployment Node" {
                background #E9EFF5
                color #213F56
                stroke #8FA5B7
            }
            element "Infrastructure Node" {
                shape roundedbox
                background #EDF0F3
                color #334454
            }
            element "ZonaLocal" {
                background #F0F3F6
                color #243F56
            }
            element "ZonaPublica" {
                background #DCEAF7
                color #173B5D
            }
            element "ZonaPrivada" {
                background #E5EEE8
                color #20513D
            }
            element "Person" {
                shape person
                background #56718A
                color #FFFFFF
            }
            element "Software System" {
                shape roundedbox
                background #0C527A
                color #FFFFFF
            }
            element "SistemaEvaluado" {
                background #173B5D
                color #FFFFFF
            }
            element "SistemaExterno" {
                background #F1EDE7
                color #544633
                stroke #A89D8A
            }
            element "Simulado" {
                background #F1EDE7
                color #544633
                stroke #A89D8A
            }
            element "Container" {
                shape roundedbox
                background #E3ECF5
                color #173B5D
            }
            element "Frontend" {
                shape webbrowser
                background #CDE5F7
                color #153E5B
            }
            element "Gateway" {
                background #2B6289
                color #FFFFFF
            }
            element "Seguridad" {
                background #3F6171
                color #FFFFFF
            }
            element "Privado" {
                background #D5E8EF
                color #173B5D
            }
            element "BaseDatos" {
                shape cylinder
                background #E5EAF0
                color #243F56
            }
            element "Analitica" {
                background #E7E0F2
                color #453166
            }
            element "Component" {
                shape roundedbox
                background #EDF3F7
                color #173B5D
            }
            element "EntradaC3" {
                background #D3E9F7
                color #153F62
            }
            element "ControlC3" {
                background #DBE4EC
                color #213F56
            }
            element "AplicacionC3" {
                background #D7E9DE
                color #20533E
            }
            element "IntegracionC3" {
                background #E9E2F2
                color #4A3666
            }
            element "PersistenciaC3" {
                background #E9EBEE
                color #334454
            }
            element "ErrorC3" {
                background #F2E6DB
                color #70462C
            }
            relationship "Relationship" {
                color #60758A
                thickness 2
            }
            relationship "Respuesta" {
                dashed true
            }
        }
    }
}
