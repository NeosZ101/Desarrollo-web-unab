# Diagramas de El Asador

Hay tres piezas, todas describen el código entregado:

| Conjunto | Formato | Para qué sirve |
|---|---|---|
| **`El-Asador.dsl`** (modelo C4) | Structurizr DSL: texto editable, el formato de los modelos C4 de la asignatura | C1 contexto, C2 contenedores, C3 componentes, 17 escenarios dinámicos (flujos F01–F07, con su variante de error) y 2 vistas de despliegue. Es la fuente: se edita este archivo y se exportan las imágenes. |
| `render/*.svg` + `render/INDICE.md` | SVG vectorial (se amplía sin perder nitidez) | Las 30 vistas del modelo ya dibujadas, para leerlas sin instalar nada. `INDICE.md` dice qué muestra cada una. |
| `01-…09-*.mmd` | Mermaid (texto editable) | Diagramas UML y de secuencia complementarios (dominio, estados del pedido, fronteras de confianza, etc.). Se incrustan en `docs/INFORME.md`. |

## Despliegue: todo en localhost

La entrega se ejecuta en **localhost** (no hace falta hosting). Las dos vistas de despliegue lo muestran:

* `DEP_Compose_Local`: lo que describe `docker-compose.yml` (api-gateway en `127.0.0.1:8000` y provider-sandbox en `127.0.0.1:8300`, el resto en una red interna sin salida). Se ejecutó con Docker Desktop el 7 y el 8 de noviembre de 2026 (ver `docs/evidencia/docker_humo.txt` y `docs/evidencia/docker_2026-11-08/`).
* `DEP_Procesos_Locales`: la variante que sí se ejecutó (`scripts/demo_local.py` y la suite de pruebas), con un proceso por servicio.

## Cómo abrir el modelo

1. **Sin instalar nada:** abrir `render/INDICE.md` y los SVG.
2. **Editarlo:** pegar `El-Asador.dsl` en <https://structurizr.com/dsl> o abrirlo con Structurizr Lite (`structurizr/lite` en Docker, apuntando a esta carpeta y con `STRUCTURIZR_WORKSPACE_FILENAME=El-Asador`). Structurizr Lite no se ejecutó aquí; sí se validó con el analizador oficial (abajo).
3. **Validar y exportar con el CLI oficial** (Java 21 y [Structurizr CLI](https://github.com/structurizr/cli)):

```bash
structurizr.sh validate -workspace docs/diagramas/El-Asador.dsl
python scripts/exportar_diagramas.py --cli /ruta/a/structurizr.sh    # regenera render/*.svg, MANIFEST.json e INDICE.md (necesita Graphviz)
```

## Cómo se sabe que el modelo dice lo mismo que el código

`tests/test_diagrama_dsl.py` (no levanta servicios) compara el `.dsl` con las fuentes de verdad:

* los servicios, las bases, los puertos publicados, la red `internal: true` y las versiones de imagen contra `docker-compose.yml`;
* las llamadas entre servicios contra `tests/contratos/pares_de_servicios.json` (20 pares) y la cantidad de rutas contra `api-gateway/app/rutas.py` (38);
* que cada prueba que un escenario cita existe de verdad;
* que los SVG exportados salen del `.dsl` actual (`render/MANIFEST.json` guarda su SHA-256);
* y, si se define `STRUCTURIZR_CLI`, que el CLI oficial lo valida.

Cambiar el `.dsl` sin volver a exportar, o cambiar el código sin actualizar el `.dsl`, hace fallar esa prueba.
