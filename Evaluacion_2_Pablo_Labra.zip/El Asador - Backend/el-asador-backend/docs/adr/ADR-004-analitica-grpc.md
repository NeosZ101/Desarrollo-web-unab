# ADR-004 · Analítica en un servicio separado con HTTP/JSON; gRPC no se implementa

**Estado:** aceptada · **Módulos:** M9

## Contexto
La analítica del caso es el **reporte de ventas** (RF9): total por día, por medio de pago y productos más vendidos, para el dueño y el administrador. Hay dos flujos:

1. **Ingesta:** `payments` avisa a `analytics` cada vez que una venta se registra o se revierte (un evento de unos 490 bytes de promedio, entre 312 y 680 en la prueba).
2. **Consulta:** el panel interno pide el reporte de un período de hasta 92 días a través del GraphQL Gateway (respuesta de 3 KB para 30 días y de 8 KB para 92).

**Volumen proyectado.** El volumen es un **supuesto de diseño**, no un dato del cliente: de **18 a 35 pedidos al día**. El 18 es la base de la historia de ejemplo del reporte del frontend de la C2 (`analytics-service/app/main.py`, `historia_de_ejemplo`: de 0 a 32 pedidos al día según el día de la semana) y el 35 es la cota alta que se usó para probar: **3.150 ventas en los últimos 90 días**. Eso es una venta cada 40 minutos en una jornada de 24 horas, o una cada 20 minutos si el local vende 12 horas. Los usuarios del reporte son pocos (administrador y dueño): se proyectan hasta 4 consultas simultáneas en el peor momento, que es la concurrencia que cubren los objetivos de más abajo.

Estas necesidades no piden transmisión en tiempo real: el panel interno consulta al abrir la pantalla o al cambiar el período, sin sondeo periódico (los únicos reintentos con espera del frontend están en «Mis pedidos», al volver del pago) y un retraso de segundos en el reporte es aceptable (tabla 9.1 del informe).

## Alternativas
| Alternativa | A favor | En contra |
|---|---|---|
| **A. HTTP/JSON entre servicios (elegida)** | El resto del sistema ya habla así (cortacircuitos, plazos, secretos por par, logs con identificador de solicitud, pruebas de contrato); se puede depurar con `curl`; sin dependencias nuevas | Mensajes más grandes que en un formato binario (no se midió cuánto) |
| B. gRPC (protobuf sobre HTTP/2) entre `payments`→`analytics` y `graphql-gateway`→`analytics` | Esquema tipado y mensajes compactos; transmisión de flujos | Segundo protocolo que operar: otro puerto y otro servidor en `analytics`, código generado, un cliente con sus propios plazos/reintentos/cortacircuitos y una segunda forma de pasar el secreto del par y la identidad; el navegador no puede hablar gRPC sin un proxy adicional (gRPC-web) |
| C. Transmisión al navegador (SSE o WebSocket) para ver ventas en vivo | Panel que se actualiza solo | Ningún requisito lo pide; agrega conexiones largas al gateway y revalidar la sesión durante la conexión |
| D. Reporte precalculado por día | Consulta de costo constante | Más estado que mantener consistente con anulaciones tardías; no hizo falta según la medición |

## Decisión
- **Analítica en su propio servicio** (`analytics`, base propia, usuario propio de MongoDB), alcanzado solo por `payments` (escribe eventos) y por `graphql-gateway` (lee reportes). Cada par tiene su secreto en Vault.
- **HTTP/JSON, sin gRPC ni transmisión.** La decisión se apoya en los requisitos y en la carga proyectada de arriba, **no en una comparación medida con gRPC: no se implementó una variante gRPC, así que no se afirma nada sobre cuánto más rápida o más liviana sería.** Lo que sí se midió es que la implementación actual cumple los objetivos con el volumen proyectado (ver más abajo), es decir, la latencia o el tamaño de los mensajes no son el problema que gRPC resolvería.
- **Consulta bajo demanda con agregación en MongoDB** sobre el modelo de lectura `ventas` (índice `(estado, fechaLocal)`), más una tabla `historico` de totales diarios para los días de ejemplo anteriores al sistema.
- **Ingesta idempotente y tolerante al orden:** cada evento tiene identificador; repetirlo no cambia el reporte y una anulación que llega antes que el registro deja la venta anulada (ADR-008). Si `analytics` no responde, el pago no se bloquea: la reconciliación reintenta.
- **Privacidad:** el evento lleva el folio y el número de pedido, los montos, el medio de pago, la comuna de despacho y las líneas de producto; no lleva nombre, RUN, correo ni dirección, y el reporte devuelve solo agregados. Lo ven solo el administrador y el dueño (el servicio lo vuelve a comprobar).

## Objetivos antes de medir
Se fijaron **antes** de ejecutar la prueba y están en `scripts/load_test.py` (`OBJETIVOS`); el informe compara cada uno con el peor valor medido:

| Objetivo | Tope |
|---|---|
| Ingesta de una venta, con hasta 16 emisores simultáneos | p95 ≤ 100 ms |
| Reporte de 30 días de punta a punta (navegador→gateway→auth→GraphQL→analytics), con hasta 4 usuarios simultáneos | p95 ≤ 1.000 ms |
| Reporte de 92 días (el máximo permitido) de punta a punta, con hasta 4 usuarios simultáneos | p95 ≤ 2.000 ms |
| Sin errores en ningún caso, con hasta 4 clientes simultáneos | 0 errores |

## Resultados medidos
Medición real con **MongoDB v8.0.23 y HashiCorp Vault reales**, sin Docker, en un equipo de 2 CPU y 7,8 GB, con el generador de carga **en el mismo equipo** (compite por CPU); datos sintéticos con semilla fija; 15 s por caso más 1 s de calentamiento; concurrencias 1, 4, 16 y 64. El entorno completo, cada caso con su rendimiento, p50/p95/p99, errores y CPU y memoria de cada proceso están en [`carga.md`](../evidencia/carga.md) (volumen proyectado) y [`carga_x10.md`](../evidencia/carga_x10.md) (diez veces el volumen).

**Orden de la medición.** Los reportes se miden primero, con exactamente las ventas declaradas; después la ingesta agrega ventas y al final los reportes se repiten con la base crecida (cada caso registra cuántas ventas había al empezar). *La primera versión de la prueba medía los reportes después de la ingesta, con una base unas 8 veces mayor que la declarada; se corrigió y se repitió todo.*

**Con el volumen proyectado (3.150 ventas, 15 s por caso):**

| Medición | Resultado |
|---|---|
| Ingesta, 1 / 4 / 16 emisores | p95 3,6 / 12,4 / 45,2 ms; 331,6 / 451,7 / 549,5 ventas por segundo; 0 errores |
| Reporte de 30 días de punta a punta, 1 / 4 / 16 usuarios | p95 59,6 / 142,6 / 585,5 ms; 0 errores |
| Reporte de 92 días de punta a punta, 1 / 4 / 16 usuarios | p95 116,3 / 216,1 / 881,9 ms; 0 errores |
| Reentrega del mismo evento 3.049 veces en paralelo | los totales no cambiaron; 0 errores |
| Reporte de 92 días de punta a punta con la base crecida a 28.567 ventas, 1 / 4 usuarios | p95 395,4 / 1.307,6 ms; 0 errores |
| Objetivos | **los 4 se cumplen** (peor caso: 216,1 ms frente a 2.000 ms en el reporte de 92 días) |

**Con diez veces el volumen (31.500 ventas, 10 s por caso):**

| Medición | Resultado |
|---|---|
| Ingesta, 1 / 4 / 16 emisores | p95 3,5 / 13,3 / 45,2 ms; 345,6 / 431,5 / 536,5 ventas por segundo; 0 errores |
| Reporte de 30 días de punta a punta, 1 / 4 / 16 usuarios | p95 163,4 / 500,6 / 1.838,2 ms; 0 errores |
| Reporte de 92 días de punta a punta, 1 / 4 usuarios | p95 470,5 / 1.201,6 ms; 0 errores |
| Reporte de 92 días de punta a punta, **16 usuarios simultáneos** | **las 870 solicitudes fallaron** con `SERVICIO_NO_DISPONIBLE` (fallan rápido, no esperan); el sistema volvió a responder bien 5,0 s después de terminar la carga |
| Reportes con la base crecida a 45.875 ventas, 4 usuarios | 30 días: p95 590,9 ms; 92 días: **p95 1.752,9 ms** (el margen frente al plazo de 2 s es estrecho) |
| Objetivos | **los 4 se cumplen** (peor caso: 1.201,6 ms frente a 2.000 ms) |

**Recursos.** Durante los casos de reporte `mongod` usó en promedio entre 68 % y 180 % de un núcleo (hasta 195 % con 10× el volumen; el equipo tiene 2 núcleos), mientras que ninguno de los procesos de Python (`analytics`, `graphql-gateway`, `api-gateway`, `auth`) superó el 70 % de un núcleo en esos casos (en los de ingesta, `analytics` llegó a 98 % de un núcleo: es un solo proceso). La memoria máxima de `analytics` fue de 123 a 126 MB, la de `graphql-gateway` 100 MB y la del API Gateway 87 MB; la de `mongod` varió entre ejecuciones (526 y 993 MB) y no se investigó la causa. Tamaño de los mensajes: evento de 489 a 494 bytes en promedio (312–680) y respuesta del reporte de 3 KB (30 días) y 7,6 a 7,8 KB (92 días).

**Lo que estas cifras NO muestran.** Todos los datos de la prueba están dentro de los últimos 90 días, así que cada reporte de 92 días recorre *todas* las ventas de la base; con un historial más largo recorrería solo las del período pedido (el plan de ejecución usa el índice `(estado, fechaLocal)`: `test_el_reporte_de_ventas_usa_el_indice_de_fecha_y_solo_lee_las_ventas_del_periodo`, con MongoDB real). No se midió Docker, ni red real entre contenedores, ni un MongoDB en otra máquina; el generador de carga compite por CPU con los servicios; los datos son sintéticos.

## Consecuencias
- **Cumple lo proyectado:** con 3.150 ventas el sistema cumple los cuatro objetivos medidos y el costo de gRPC (segundo protocolo, código generado, gRPC-web para el navegador) no se justifica por lo medido.
- **Cuello de botella medido:** el costo de un reporte lo pone MongoDB, no los servicios de Python: durante los casos de reporte `mongod` usó en promedio entre 68 % y 195 % de un núcleo (el equipo tiene 2) mientras que ningún proceso de Python superó el 70 % en esos casos. Cada reporte hace tres agregaciones seguidas sobre las mismas ventas. No se perfiló qué parte del trabajo de MongoDB pesa más.
- **Comportamiento al saturarse:** con el volumen proyectado no hubo errores ni con 16 usuarios simultáneos. A diez veces ese volumen, 16 reportes de 92 días a la vez superan el plazo de 2 s de las llamadas a `analytics`, el cortacircuitos se abre y el usuario recibe `SERVICIO_NO_DISPONIBLE` de inmediato en vez de esperar sin límite (diseño de ADR-010); el sistema volvió a responder bien 5,0 s después de terminar la carga. Con las 4 consultas simultáneas proyectadas como máximo se cumplen los objetivos incluso a 10×, pero el margen del reporte de 92 días se reduce (1,75 s de p95 frente al plazo de 2 s con unas 46.000 ventas en el período).
- **Defecto encontrado por la medición:** a diez veces el volumen el reporte de 92 días superaba los 2.147 millones de pesos y el tipo `Int` de GraphQL (32 bits) lo rechazaba como «Error interno»; se corrigió con el tipo `Monto`.
- **Si el volumen real fuera de ese orden** (unos 350 pedidos al día o más), lo primero que se agota es el margen del reporte de 92 días. Las mejoras, ordenadas por costo, son: (1) calcular las tres agregaciones en una sola pasada (`$facet`), (2) guardar totales diarios precalculados en `historico` al llegar cada evento, (3) caché de corta duración del reporte. **Ninguna está implementada ni medida**: son opciones, no resultados.
- **Cuándo se reconsideraría gRPC:** si la ingesta pasara a miles de eventos por segundo entre servicios propios, o si apareciera un consumidor interno que necesite transmisión de flujos. Nunca hacia el navegador. Si el panel necesitara ventas en vivo, la opción prevista es SSE o WebSocket detrás del API Gateway, que revalida la sesión.

## Dónde está implementado y probado
- Implementación: `analytics-service/app/main.py` (eventos `sale-registered` y `sale-reversed`, reporte `GET /internal/reports/sales`), `payments-service/app/main.py` (emisión y reconciliación), `graphql-gateway/app/schema.py` (`reporteVentas`).
- Pruebas: `tests/test_analitica.py` (idempotencia, orden de llegada, agrupaciones, período de 92 días, totales mayores a 2.147 millones, privacidad), `tests/test_graphql.py`, `tests/test_resiliencia.py` (`test_con_analitica_colgada_el_pago_avanza_y_la_venta_se_cuenta_una_vez_al_volver`, `test_con_analitica_colgada_el_reporte_falla_solo_en_su_campo`).
- Medición: `scripts/load_test.py` → `docs/evidencia/carga.md` y `carga_x10.md`.
