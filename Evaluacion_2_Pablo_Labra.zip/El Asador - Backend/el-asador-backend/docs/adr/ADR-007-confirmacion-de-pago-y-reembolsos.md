# ADR-007 · El pago solo se confirma por aviso firmado del proveedor o por el administrador

**Estado:** aceptada · **Módulos:** M7, M10

## Contexto
El caso exige que la orden se prepare «una vez que se ha confirmado el pago». La pauta pide demostrar que **no** se puede confirmar un pago alterando datos del frontend.

## Decisión
- **Única vía hacia «En preparación»:** `orders` expone `payment-confirmed` solo al servicio `payments` (secreto del par `payments→orders`). El navegador no tiene ruta hacia él (no figura en la tabla del gateway).
- `payments` aprueba un cobro solo por (a) un **aviso del proveedor** con firma HMAC-SHA256 válida sobre el cuerpo exacto, dentro de una ventana de 300 s, con el mismo monto y moneda que fijó `orders`; (b) la **conciliación** periódica, que le pregunta directamente al proveedor por cobros «iniciados» antiguos; o (c) la **confirmación manual** del administrador, solo para transferencia o depósito, con referencia.
- Volver de la página del proveedor con `?pago=aprobado` no cambia nada: el estado sale únicamente del servidor.
- Los avisos son idempotentes (`eventos_proveedor` guarda el identificador de evento) y dos avisos simultáneos aprueban una sola vez.
- **Reembolsos:** si se anula un pedido «En preparación» queda un reembolso `pendiente` (el administrador lo registra, o lo ejecuta el proveedor en pagos con proveedor). Si un pago se aprueba **después** de anular el pedido, `payments` lo reembolsa automáticamente.

## Hallazgo de las pruebas (carrera entre confirmaciones)
Con MongoDB real (donde las operaciones sí se intercalan) una prueba falló de forma intermitente: dos confirmaciones simultáneas del mismo pago llegaban a `orders`; la que perdía la carrera recibía `409 CONFLICTO_DE_ESTADO` y `payments` lo trataba como rechazo definitivo: **devolvía el dinero y no emitía la boleta** de un pedido que sí avanzó. Se corrigió en dos lugares:
1. `orders` reconoce una confirmación repetida (mismo `pagoId` y pedido ya avanzado) y responde 200 `repetido: true`; la actualización es condicional por estado y reintenta la lectura hasta 3 veces.
2. `payments` solo reembolsa ante un conjunto cerrado de rechazos definitivos (`PEDIDO_ANULADO`, `MONTO_NO_COINCIDE`, `TRANSICION_NO_PERMITIDA`, `PEDIDO_NO_ENCONTRADO`); cualquier otra respuesta se reintenta.
Las pruebas `tests/test_unidad_carreras.py` y `test_negocio_pagos.py::test_dos_confirmaciones_simultaneas…` y las mutaciones M53–M55 protegen la corrección.

## Consecuencias
- La confianza se concentra en la clave de firma del proveedor (referencia propia en Vault, distinta de la clave de API).
- La conciliación cubre la pérdida de avisos a cambio de una consulta periódica al proveedor.

## Dónde está probado
`tests/test_negocio_pagos.py` (firma, alteración, antigüedad, monto, repetición, concurrencia, pago tras anulación), `tests/test_unidad_carreras.py`, `scripts/verificar_controles.py` (caso 6).
