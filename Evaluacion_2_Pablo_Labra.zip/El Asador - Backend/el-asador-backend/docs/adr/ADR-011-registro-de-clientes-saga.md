# ADR-011 · Registro de clientes como saga idempotente entre clients y auth

**Estado:** aceptada · **Módulos:** M3

## Contexto
Registrar un cliente crea dos cosas en dos servicios con bases distintas: el **perfil** (RUN, nombre, dirección…, en `clients`) y la **credencial** (usuario y contraseña, en `auth`). No hay transacción entre ambas (ADR-005). Además el caso (RF5, RF6, RF11) exige comprobar que el correo existe y permite el alta en el local por el administrador, cuyo cliente luego puede activar su cuenta web.

## Decisión
1. `clients` valida la ubicación (región, provincia, comuna) y que el RUN y el correo no estén en uso. Si el cliente fue dado de alta en el local (sin acceso web) y RUN y correo coinciden, **reclama** ese perfil en vez de duplicarlo.
2. Si no es un reclamo, comprueba que el correo existe (servicio de mensajería) y **inserta el perfil** (índices únicos de RUN y correo evitan duplicados en una carrera).
3. Pide a `auth` crear la credencial con rol fijo «cliente» (el navegador no elige el rol). Si `auth` rechaza de forma definitiva (clave débil, usuario ya existente) el perfil recién creado se **elimina**. Si `auth` no responde, el perfil se **conserva**: repetir el registro con el mismo RUN, correo y clave lo completa porque `auth` devuelve la misma credencial para la misma clave (idempotente).
4. Responde **genérico** si la cuenta ya existe («No pudimos crear la cuenta con esos datos…») para no revelar qué RUN o correos están registrados.
5. Envía el correo de bienvenida por la bandeja de salida (si falla, no deshace el registro).

## Consecuencias
- Nunca queda un perfil sin posibilidad de completarse ni una credencial sin perfil.
- La eliminación de un cliente es **baja lógica** (estado «inactivo»): los pedidos y boletas ya emitidos deben poder respaldarse. La credencial se desactiva en `auth`.

## Dónde está probado
`tests/test_resiliencia.py::test_con_auth_colgado…` (registro con auth colgado y recuperación), `tests/test_negocio_administracion.py` (reclamo de alta local, bajas, validación de correo), `tests/test_seguridad_acceso.py` (rol fijo, respuestas que no revelan existencia).
