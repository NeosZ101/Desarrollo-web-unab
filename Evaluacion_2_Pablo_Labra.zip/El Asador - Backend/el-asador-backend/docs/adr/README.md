# Decisiones de arquitectura (ADR)

Cada ADR dice el contexto, las alternativas, la decisión, las consecuencias y **dónde está implementada y probada** (las referencias apuntan a archivos de este repositorio).

| ADR | Decisión | Módulo |
|---|---|---|
| [001](ADR-001-gateway-tabla-de-rutas.md) | El gateway deja pasar solo lo que figura en una tabla de rutas y la autorización se comprueba en dos capas | M5, M6 |
| [002](ADR-002-sesion-opaca-en-cookie.md) | Sesión opaca en cookie HttpOnly, revisada en el servidor en cada solicitud (no JWT en el navegador) | M7 |
| [003](ADR-003-secretos-en-vault.md) | Un secreto por par llamador→destino, tokens de Vault por servicio y plan ante filtración o caída de Vault | M6, M7 |
| [004](ADR-004-analitica-grpc.md) | Servicio de analítica separado; gRPC no se implementa (carga proyectada y medida) | M9 |
| [005](ADR-005-base-de-datos-por-servicio.md) | MongoDB con una base y un usuario por servicio; migraciones versionadas | M8, M10 |
| [006](ADR-006-pedido-precio-y-idempotencia.md) | El servidor fija precios y total; creación de pedidos idempotente | M10 |
| [007](ADR-007-confirmacion-de-pago-y-reembolsos.md) | El pago solo se confirma por aviso firmado del proveedor o por el administrador; carrera de confirmaciones y reembolsos | M7, M10 |
| [008](ADR-008-anulacion-primero-y-reconciliacion.md) | Anular primero y reintentar: consistencia eventual entre pedidos, pagos y analítica | M3, M10 |
| [009](ADR-009-graphql-solo-lectura.md) | GraphQL Gateway de solo lectura con autorización por campo, DataLoader y límites de costo | M8 |
| [010](ADR-010-resiliencia-y-plazos.md) | Plazos jerárquicos, cortacircuitos y comportamiento con Vault o servicios caídos | M3, M6 |
| [011](ADR-011-registro-de-clientes-saga.md) | Registro de clientes como saga idempotente entre clients y auth | M3 |
| [012](ADR-012-pila-tecnologica.md) | FastAPI + MongoDB + Docker Compose frente a las restricciones del caso (RNF3) | M10 |
