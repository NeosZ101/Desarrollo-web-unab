# ADR-009 · GraphQL Gateway de solo lectura con autorización por campo

**Estado:** aceptada · **Módulos:** M8

## Contexto
Las pantallas «Mis pedidos», «Despacho» y «Reporte de ventas» necesitan datos de varios servicios (pedido, pago, boleta, descripción pública del producto, ventas). Pedirlos con varias llamadas REST desde el navegador exigiría exponer más rutas y haría N+1 llamadas.

## Decisión
- Un **GraphQL Gateway privado** (`graphql-gateway`), alcanzado solo por el API Gateway (`POST /api/graphql`, S38). Su esquema tiene **solo `Query`** (4 operaciones: `misPedidos`, `pedidosAdmin`, `panelAdmin`, `reporteVentas`); no hay mutaciones ni suscripciones. Las reglas transaccionales siguen en los servicios; este servicio no escribe en ninguna base ni tiene acceso a ellas.
- **Identidad verificada y propagada.** El gateway afirma la identidad (que sale de la sesión) y el GraphQL Gateway la reenvía a cada servicio, que aplica la pertenencia: `misPedidos` no tiene argumento para elegir cliente.
- **Autorización por campo** (clase de permiso con roles por campo): `Pedido.cliente` (datos personales) solo para el cliente dueño, el administrador y el despacho; el dueño del negocio no ve datos personales; `panelAdmin.pagos` solo administrador. Un alias o un fragmento no evitan el permiso.
- **Límites:** introspección desactivada, profundidad máxima 6, 10 alias, 1200 tokens, costo estimado máximo 1500 (se rechaza **antes** de ejecutar), `limit` entre 1 y 50 con paginación, plazo máximo de 5 s por consulta (`common/plazos.py`, ADR-010) y errores inesperados enmascarados y registrados (campo y tipo, nunca el texto).
- **Anti N+1:** un `DataLoader` por solicitud agrupa las lecturas de pagos e ítems; con 5 pedidos el gateway hace una llamada a `payments` y una a `inventory`.
- **Errores parciales:** si `inventory` no responde, la consulta devuelve el pedido sin el detalle del producto en lugar de fallar completa.

## Consecuencias
- El navegador sigue hablando solo con el API Gateway; el GraphQL Gateway tiene solo permisos de lectura sobre `orders`, `payments`, `inventory` y `analytics` (secretos distintos por par).
- Cada pantalla nueva con agregación exige una consulta dentro del límite de costo; la consulta de cada pantalla se lee de su JavaScript real en las pruebas.

## Dónde está probado
`tests/test_graphql.py` (agregación, pertenencia, permisos por campo y rol, límites, introspección, N+1), `tests/test_unidad_guardia_graphql.py`, `tests/test_seguridad_acceso.py::test_el_graphql_gateway_es_de_solo_lectura_aunque_tenga_su_secreto`, `scripts/verificar_controles.py` (módulo 8).
