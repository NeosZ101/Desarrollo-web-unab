# ADR-008 · Anular primero y reintentar: consistencia eventual entre pedidos, pagos y analítica

**Estado:** aceptada · **Módulos:** M3, M10

## Contexto
No hay transacciones distribuidas entre bases (ADR-005). Anular un pedido, cancelar su cobro, emitir la boleta y alimentar la analítica tocan servicios distintos; cualquiera puede estar caído en ese instante.

## Decisión
- **Anular primero.** `orders` marca el pedido «Anulado» con una actualización condicional por estado (si otro proceso cambió el estado responde 409), registra `pagoPorCancelar` y recién entonces le pide a `payments` cancelar el cobro. Si `payments` no responde, la anulación **no se pierde**: un ciclo periódico reintenta. Para el usuario el pedido ya está anulado y sin posibilidad de pagarse.
- **Efectos laterales idempotentes.** `payments` registra la venta y su folio con un contrato de «exactamente una vez» (arrendamiento `ventaLease` de 30 s sobre el pago), y entrega boleta, evento de analítica y reverso en pasos marcados (`boletaEnviada`, `analyticsEnviado`, `analyticsReversoEnviado`) que un ciclo (`_ciclos`, cada `REINTENTO_SEGUNDOS`) completa si falló alguno. `notifications` usa clave de idempotencia por correo y reintenta con una bandeja de salida (outbox visible para el administrador).
- **Analítica tolerante.** `analytics` es idempotente por evento (la clave es el folio) y tolera desorden: una anulación que llega antes del registro deja la venta anulada igual.

## Consecuencias
- Se acepta un retraso (segundos) entre el hecho y su reflejo en boleta y reportes; se documenta como retraso aceptado del módulo 9.
- Hay más estado auxiliar (banderas, ciclos) a cambio de que ningún corte deje una venta sin boleta ni una anulación sin efecto.

## Dónde está probado
`tests/test_resiliencia.py` (con cada servicio colgado o caído el sistema se recupera sin duplicar ni perder), `tests/test_negocio_pagos.py` (anulaciones, reembolsos, pago tras anulación), `tests/test_analitica.py` (idempotencia y desorden), `tests/test_unidad_carreras.py`.
