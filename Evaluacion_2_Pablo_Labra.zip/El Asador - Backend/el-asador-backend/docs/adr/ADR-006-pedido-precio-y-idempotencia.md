# ADR-006 · El servidor fija precios y total; la creación de pedidos es idempotente

**Estado:** aceptada · **Módulos:** M7, M10

## Contexto
El frontend original guardaba el carrito, los precios y el total en el navegador. Un valor enviado por el navegador no es confiable (error común de la pauta: «confiar en precios o pagos enviados por el frontend»). Además un doble clic o un reintento de red no debe crear dos pedidos.

## Decisión
- El navegador solo envía `items: [{id, cantidad}]`, `comuna`, `medioPago` y una cabecera `Idempotency-Key`. Cualquier otro campo se rechaza (`extra="forbid"` → 422).
- `orders` pregunta a `inventory` por los precios y la disponibilidad vigentes, calcula subtotal, despacho (según la zona y las reglas de cobertura) y total, y **guarda una copia** de nombre y precio en cada línea. El monto del cobro sale de este documento, nunca del navegador.
- La clave de idempotencia (8 a 64 caracteres) se guarda con el pedido bajo un índice único `(clienteId, claveIdempotencia)`: repetir la misma solicitud devuelve el pedido ya creado (200) en lugar de crear otro; la carrera entre dos solicitudes simultáneas termina en un solo pedido.
- Reglas del servidor: cliente activo y con cuenta, cantidad 1–20 por ítem y hasta 30 líneas, producto existente y disponible, comuna con cobertura, mayoría de edad para productos con alcohol y un máximo de 5 pedidos con pago pendiente por cliente.
- El «carrito» sigue siendo una comodidad del navegador; **no es un recurso del backend**. El pedido nace en «Pago pendiente» y sigue el flujo Pago pendiente → En preparación → En camino → Entregado, o Anulado.

## Consecuencias
- Un cambio de precio entre que el cliente arma el carrito y crea el pedido se refleja en el total del pedido (el cliente lo ve en «Mis pedidos» antes de pagar).
- Costo: una consulta a `inventory` por pedido (probada en las pruebas de resiliencia: con inventario caído no se crean pedidos a medias).
- No se implementó recuperación de stock porque `inventory` administra **disponibilidad** (disponible/agotado), no cantidades: no hay existencias que reservar ni devolver. Se declara en el informe (límites).

## Dónde está probado
`tests/test_negocio_pedidos.py` (precios, despacho, límites, idempotencia, concurrencia), `tests/test_unidad_reglas.py`, `tests/test_resiliencia.py::test_con_inventario_colgado_no_se_crean_pedidos_a_medias_y_lo_demas_sigue`, `scripts/verificar_controles.py` (caso 6).
