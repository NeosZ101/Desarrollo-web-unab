# ADR-001 · El gateway deja pasar solo lo que figura en una tabla de rutas

**Estado:** aceptada · **Módulos:** M5, M6

## Contexto
El navegador es una zona no confiable. Un gateway que reenvía «todo lo que empiece con /api» (proxy genérico) expone también rutas internas que nunca se pensaron para la web (por ejemplo, la confirmación de pago entre `payments` y `orders`). El caso exige que el control de acceso no dependa de ocultar botones.

## Alternativas
1. **Proxy genérico por prefijo** (`/api/orders/**` → orders): simple, pero cada ruta nueva queda expuesta sin que nadie decida su permiso.
2. **Autorización solo en cada servicio**: el gateway no sabe nada; un olvido en un servicio deja la ruta abierta y el atacante llega hasta el servicio.
3. **Tabla explícita en el gateway + segunda comprobación en cada servicio** (elegida).

## Decisión
`api-gateway/app/rutas.py` contiene 38 filas (S01–S38): método, ruta pública, servicio destino, ruta interna, acceso (anónimo, sesión o firma), roles, parámetros de consulta permitidos, formato del cuerpo, cabeceras que sí se reenvían, grupo de límite de solicitudes, clasificación de datos, requisitos que cubre y pantallas que la usan. Lo que no está en la tabla responde 404/405 y **no se reenvía**.
El gateway comprueba sesión y rol (primera capa) y descarta toda cabecera de identidad del navegador; cada servicio vuelve a comprobar el rol y la **pertenencia** del recurso con la identidad que el gateway afirma (segunda capa).

## Consecuencias
- Agregar una ruta exige decidir su permiso en un solo lugar; la matriz de permisos del informe se **genera** de esta tabla (`scripts/generar_documentos.py`) y una prueba falla si el documento se desactualiza.
- Costo: dos comprobaciones por solicitud (rol en gateway y servicio) y la tabla debe mantenerse; se acepta.
- Un error de configuración del gateway no basta para saltarse los permisos (segunda capa).

## Dónde está probado
`tests/test_seguridad_acceso.py` (401 sin sesión en toda ruta protegida, 403 por rol no listado, el gateway corta antes de molestar al servicio, lo que no está en la tabla no se reenvía), `tests/test_segunda_capa.py` (el servicio rechaza el rol equivocado aunque el gateway lo deje pasar), `tests/test_documentos.py` (matriz = código).
