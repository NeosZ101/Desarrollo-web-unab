# ADR-003 · Un secreto por par llamador→destino, tokens de Vault por servicio

**Estado:** aceptada · **Módulos:** M6, M7

## Contexto
La pauta prohíbe asignar el mismo secreto a todos los sistemas sin justificarlo y pide prever qué pasa si una clave se filtra o el gestor de secretos no responde.

## Decisión
- **Identidad entre servicios:** cada llamada interna lleva `X-Service-Name` y `X-Service-Secret`. Hay un secreto distinto por cada par llamador→destino (20 pares, `docs/matrices/llamadas_entre_servicios.md`). El secreto de `api-gateway→orders` no sirve para llamar a `inventory`, ni el de `payments→orders` para leer pedidos. Solo `api-gateway` y `graphql-gateway` pueden **afirmar** la identidad de un usuario; el GraphQL Gateway solo puede leer.
- **Vault (KV v2):** 30 referencias simbólicas en `secrets/manifest.tsv`. Cada servicio recibe su propio token de Vault con una política de **solo lectura** sobre lo suyo; las credenciales de base de datos pertenecen al servicio que accede (no al navegador ni al gateway). `scripts/seed_vault.py` carga los valores y crea políticas y tokens; `scripts/bootstrap.py` genera los valores aleatorios en `.env` (que no se versiona).
- **Proveedor de pagos:** la clave de API y la clave de firma de avisos son referencias distintas con finalidad distinta.

## Si una clave se filtra
1. Rotar solo esa referencia: `python scripts/seed_vault.py --rotar <ref>`. Los servicios recogen el valor nuevo al vencer `SECRET_TTL_SECONDS` (60 s).
2. Revocar un par = borrar su ruta en Vault: el destino deja de aceptar al llamador (403) y las pruebas lo verifican.
3. Credencial de base de datos: cambiar la clave en `.env`, reiniciar `mongo` y volver a sembrar `db/<servicio>`.
4. Token de Vault de un servicio: revocarlo y emitir uno nuevo; los demás servicios no se ven afectados.

## Si Vault no responde
El cliente (`common/vault_secrets.py`) espera como máximo 1 s por lectura (`VAULT_TIMEOUT_SECONDS`), **sigue sirviendo con los secretos ya cacheados** y deja de preguntarle a Vault durante 5 s tras un fallo (`VAULT_RETRY_AFTER_SECONDS`) para no encadenar esperas. Un secreto que Vault responde como **borrado o prohibido (404/403)** sí se revoca de inmediato aunque esté en caché. Sin copia en caché falla cerrado al instante (503 `SECRETOS_NO_DISPONIBLE`), sin dejar la solicitud colgada. El tiempo máximo acumulado de Vault en la cadena más larga (1 s por proceso) es menor que el plazo del gateway (5 s), así Vault colgado produce 503 y no 504.

## Consecuencias
- Más secretos que administrar (30) a cambio de acotar el daño de una filtración.
- Vault en modo desarrollo (en memoria, sin sellar) es solo para la demostración: en producción se necesita almacenamiento persistente, TLS, claves de desbloqueo repartidas y AppRole. El `docker-compose.yml` descarta el log de Vault porque el modo desarrollo imprime su token raíz.
- Ningún secreto aparece en el repositorio, en las imágenes, en el JavaScript ni en los logs (revisado por `tests/test_zz_logs_y_secretos.py`).

## Dónde está probado
`tests/test_seguridad_acceso.py` (secreto equivocado, de otro par, ausencia), `tests/test_secretos_vault.py` (rotación, revocación, Vault colgado/caído, recuperación), `tests/test_infraestructura_real.py` (con Vault y MongoDB reales), `tests/test_zz_logs_y_secretos.py`, `tests/test_despliegue.py` (tokens distintos, `.env` no versionado).
