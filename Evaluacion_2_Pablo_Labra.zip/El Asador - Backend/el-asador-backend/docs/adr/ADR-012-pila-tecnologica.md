# ADR-012 · FastAPI + MongoDB + Docker Compose frente a las restricciones del caso

**Estado:** aceptada · **Módulos:** M10

## Contexto
El caso de referencia de la asignatura (RNF3) menciona Oracle y .NET/J2EE, pero la pauta de esta evaluación pide «conservar las restricciones tecnológicas vigentes del curso» y exige: API Gateway, Auth Service, administrador de secretos, GraphQL Gateway, microservicios privados, persistencia real y despliegue reproducible sin cuenta de nube de pago.

## Decisión
- **Python 3.13 + FastAPI/Uvicorn** para todos los servicios (un contenedor por servicio, misma imagen base), **MongoDB** (Motor) como persistencia, **HashiCorp Vault** como administrador de secretos, **strawberry-graphql** para el GraphQL Gateway, **Docker Compose** con una red interna sin salida a Internet.
- Dependencias con versión exacta (`requirements/*.txt`); imágenes de terceros con etiqueta fija (nunca `latest`).
- Contenedores endurecidos: usuario sin privilegios, sistema de archivos de solo lectura, sin capacidades, `no-new-privileges`, límites de memoria y procesos.
- El servicio de correo y el proveedor de pagos son externos: se entregan **adaptadores de prueba** (`provider-sandbox` para pagos con la misma firma y los mismos estados que usa `payments`; correo en bandeja de salida con envío SMTP opcional) que preservan contrato, autenticación y transiciones.

## Consecuencias
- Se declara la diferencia con RNF3 (Oracle/.NET/J2EE): las capas siguen separadas (interfaz, reglas de negocio, repositorio de datos) y la integración es por servicios web, pero con otra pila.
- RNF4 (procedimientos almacenados) se reemplaza por reintentos y una bandeja de salida (`outbox`) consultable por el administrador, de donde salen los avisos por correo.

## Dónde está probado
`tests/test_despliegue.py` (compose, endurecimiento, versiones, puertos), `tests/test_infraestructura_real.py` (Vault y MongoDB reales). Docker no estuvo disponible en el entorno de desarrollo: los archivos se validaron con `docker compose config` y las pruebas estáticas. El compose principal se ejecutó después en el equipo del autor, el 7 y el 8 de noviembre de 2026 (`docs/evidencia/docker_humo.txt` y `docs/evidencia/docker_2026-11-08/`; ver «Límites declarados» del informe).
