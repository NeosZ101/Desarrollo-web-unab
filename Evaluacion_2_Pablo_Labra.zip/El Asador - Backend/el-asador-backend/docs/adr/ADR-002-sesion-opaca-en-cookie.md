# ADR-002 · Sesión opaca en cookie HttpOnly, revisada en el servidor en cada solicitud

**Estado:** aceptada · **Módulos:** M7

## Contexto
La pauta recuerda que un navegador no puede mantener confidencial una clave incluida en su código y pide explicar sesiones, expiración y revocación.

## Alternativas
1. **JWT firmado guardado en `localStorage`**: legible por cualquier script de la página (XSS), no se puede revocar antes de que expire sin una lista de bloqueo, y el rol queda copiado dentro del token.
2. **JWT en cookie HttpOnly**: se evita el robo por XSS, pero sigue sin revocación inmediata y exige una clave de firma compartida.
3. **Token opaco aleatorio en cookie HttpOnly + consulta al Auth Service en cada solicitud** (elegida).

## Decisión
- Al iniciar sesión, `auth` genera un token aleatorio (`secrets.token_urlsafe`), guarda **solo su SHA-256** y su vencimiento (2 horas, `SESSION_TTL_SECONDS`) y el gateway lo entrega en la cookie `session_token`: `HttpOnly`, `SameSite=Lax`, `Path=/`, `Secure` cuando se publica con HTTPS (`COOKIE_SECURE=true`). El cuerpo de la respuesta de login **no** contiene el token.
- En cada solicitud protegida el gateway consulta `auth /introspect`: así una sesión cerrada, un usuario desactivado o un cambio de rol surten efecto de inmediato. El logout borra la sesión en la base de datos.
- Las contraseñas se guardan con **argon2id** (sal aleatoria por contraseña). Si el usuario no existe se verifica contra un hash falso para no revelar su existencia por tiempo de respuesta; tras 5 intentos fallidos se bloquea la cuenta 15 minutos.
- Las solicitudes que modifican datos exigen `Origin` o `Referer` del propio sitio cuando viajan con cookie (defensa contra CSRF además de `SameSite=Lax`).

## Consecuencias
- Costo: una llamada interna por solicitud; se acepta porque la carga es baja y la revocación inmediata vale más (ver medición de latencia en `docs/evidencia/carga.md`, que incluye el recorrido de punta a punta).
- El token no está al alcance de JavaScript; un XSS no puede robarlo (aun así hay política de contenido que solo permite scripts propios).
- Dependencia: si `auth` cae, nadie puede operar con sesión; el catálogo público sigue disponible (probado en `tests/test_resiliencia.py`).

## Dónde está probado
`tests/test_seguridad_acceso.py` (cookie HttpOnly, token fuera del cuerpo, logout revoca, cookie basura, Origin ajeno), `tests/test_limites_tasa.py` (bloqueo de cuenta, 429), `tests/test_unidad_reglas.py` (política de claves).
