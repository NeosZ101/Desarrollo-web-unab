# ADR-010 · Plazos escalonados, cortacircuitos y comportamiento con dependencias caídas

**Estado:** aceptada · **Módulos:** M3, M6

## Contexto
Cada solicitud del navegador atraviesa varias capas (gateway → servicio → otro servicio → base de datos o Vault). Un servicio colgado (acepta la conexión y no contesta) es peor que uno caído: sin plazos ordenados, cada capa espera lo mismo, la de arriba corta primero y el usuario ve un error genérico mientras los servicios de abajo siguen ocupados.

## Decisión
**Plazos escalonados** (`common/plazos.py`; se sobrescriben con variables de entorno): servicio→servicio **2 s**, GraphQL (por llamada) **2 s** y consulta completa **5 s**, servicio→proveedor de pagos **3 s**, gateway→servicios **6 s**, lectura de Vault **1 s**. La regla es que la cadena más larga cabe en el plazo de la capa de arriba: dos llamadas internas seguidas (2 × 2 = 4 s) y pago (2 + 3 = 5 s) < 6 s; GraphQL (2 × 2 ≤ 5 s) < 6 s; tres procesos leyendo Vault (3 × 1 s) < 6 s. `tests/test_unidad_plazos.py` falla si alguien rompe la regla.
**Cortacircuitos** en `ClienteInterno`: tras un fallo de conexión o plazo de un destino, durante `CIRCUITO_PAUSA` (5 s) no se le vuelve a llamar y se responde al instante 503 con `Retry-After`; después se hace una prueba. Un 503 propio del destino («mi dependencia está caída») se conserva como `dependencia` y se propaga con su código saneado.
**Errores controlados:** timeouts → 504 `TIEMPO_AGOTADO`; destino caído o circuito abierto → 503 `SERVICIO_NO_DISPONIBLE`; respuesta inesperada o credencial rechazada → 502 `ERROR_DE_ORIGEN`. Nunca se devuelven trazas, nombres de servicios ni mensajes de base de datos.
**Aislamiento:** una dependencia caída solo afecta lo que depende de ella. Con `inventory` colgado se puede seguir viendo pedidos y sesión; con `graphql-gateway` colgado el resto de la web sigue; con `auth` colgado nadie pierde la sesión (se vuelve a validar al recuperarse) y el catálogo sigue público (con caché corta del gateway, solo GET anónimos).
**Cliente que se va:** si el gateway corta por plazo y el servicio responde después, el servicio detecta la desconexión y deja una línea de log, no una traza (hallazgo de la prueba de caos con Vault real; ver `common/app.py`).

## Consecuencias
- Reintentos seguros: las operaciones que modifican datos son idempotentes (clave de idempotencia, aviso de proveedor por identificador, folio por pago) para que un 504 pueda repetirse sin duplicar.
- Se prefiere fallar rápido con mensaje claro y `Retry-After` antes que dejar la solicitud colgada.

## Dónde está probado
`tests/test_resiliencia.py` (14 pruebas con procesos reales congelados con SIGSTOP o apagados: auth, clients, inventory, orders, payments, notifications, analytics, GraphQL, proveedor; el sistema converge solo), `tests/test_secretos_vault.py` (Vault colgado o caído), `tests/test_unidad_plazos.py`, `tests/test_unidad_logs.py` (desconexión del cliente).
