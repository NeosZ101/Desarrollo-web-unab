# ADR-005 · MongoDB con una base y un usuario por servicio

**Estado:** aceptada · **Módulos:** M8, M10

## Contexto
La pauta pide que cada servicio modifique únicamente los datos bajo su responsabilidad y que las colaboraciones usen contratos explícitos; «una agregación no autoriza acceder directamente a bases de datos de otros servicios».

## Alternativas
1. Una base compartida con todas las colecciones: un servicio vulnerado lee y escribe todo; los contratos se rompen «por atajo».
2. Una instancia de MongoDB por servicio: aislamiento máximo, pero siete instancias son excesivas para el volumen del caso.
3. **Una instancia, una base por servicio (`asador_<servicio>`) y un usuario por servicio con rol `readWrite` solo sobre su base** (elegida).

## Decisión
`mongo/init-users.js` crea siete bases y siete usuarios (`u_auth`, `u_clients`, `u_inventory`, `u_orders`, `u_payments`, `u_notifications`, `u_analytics`). Cada servicio lee su usuario desde Vault (`asador/db/<servicio>`) y se conecta con `authSource` igual a su base. Colecciones propias: auth (`usuarios`, `sesiones`), clients (`clientes`), inventory (`productos`, `promos`), orders (`pedidos`, `zonas`, `config`, `cotizaciones_evento`), payments (`pagos`, `ventas`, `eventos_proveedor`), notifications (`bandeja`, `mensajes_contacto`), analytics (`ventas`, `eventos`, `historico`). Según el servicio, además `contadores` (inventory, orders, payments), la bitácora `auditoria` y `_migraciones` (versión del esquema).
Los índices (únicos para RUN y correo, un solo cobro «iniciado» por pedido, clave de idempotencia por cliente, folio de venta único) los crea una migración versionada al arrancar (`common/migraciones.py`, colección `_migraciones`, idempotente).

## Consecuencias
- Un servicio vulnerado solo puede tocar su base. La comunicación entre servicios es solo por HTTP con contrato (matriz de llamadas).
- Los datos que necesita otro servicio se **copian al momento del hecho** (la línea del pedido guarda nombre y precio vigentes; la boleta guarda el cliente), así una edición posterior del catálogo no altera lo vendido.
- No hay transacciones entre bases: la consistencia se logra con operaciones condicionales, idempotencia y reconciliación (ADR-007, ADR-008).

## Dónde está probado
`tests/test_infraestructura_real.py` (con MongoDB real: cada usuario solo accede a su base, la autenticación es obligatoria, los índices únicos existen), `tests/test_despliegue.py` (usuarios y roles de `init-users.js`), pruebas de negocio de cada servicio.
