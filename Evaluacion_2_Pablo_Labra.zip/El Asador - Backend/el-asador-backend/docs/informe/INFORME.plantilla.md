# Informe de arquitectura y backend · Evaluación 2

**Caso 20 · Parrilladas «El Asador»** · Desarrollo Web y Móvil · Universidad Andrés Bello

## Portada

| | |
|---|---|
| **Caso** | 20 · Parrilladas «El Asador» (pedidos web con despacho, pago en línea, boleta digital y panel interno) |
| **Integrantes** | Pablo Labra (NeosZ101). Equipo de una sola persona |
| **Entrega** | Evaluación 2 · backend seguro completo, construido con los datos y los flujos del frontend de la C2 (el frontend integrado se valida en la Evaluación 3; fecha de entrega: lunes 9 de noviembre de 2026) |
| **Versión del frontend** | Entrega C2 (repositorio `NeosZ101/el-asador-frontend`, commit `554c292`, 21 de septiembre de 2026): 8 páginas en HTML5, CSS, JavaScript y Bootstrap 5 local. Sus pantallas, formularios y datos (`datos.js`) son el punto de partida de los servicios, los contratos y los datos de prueba. El proyecto del backend no incluye el frontend: de él se usan sus datos (`datos-frontend/`; ver «Brechas y supuestos declarados»). Demostración de la C2 sin backend (enlace tomado del README de la C2; no se verificó que siga publicado): <https://neosz101.github.io/el-asador-frontend/> |
| **Pila** | FastAPI · MongoDB · HashiCorp Vault · GraphQL (Strawberry) · Docker Compose |
| **Código** | 9 servicios propios + proveedor de pagos simulado + Vault + MongoDB |

### Requisitos que cubre el backend

Los requisitos funcionales (RF), casos de uso (CU) y no funcionales (RNF) se listan con su trazabilidad completa en el módulo 1. En resumen:

| RF | Requisito | Caso de uso |
|---|---|---|
| RF1 | Armar un pedido con los productos disponibles de la carta | CU5 Genera pedido |
| RF2 | La orden se prepara solo tras confirmar el pago | CU6 Realizar venta |
| RF3 | Anular una compra indicando el motivo | CU7 Anular compra |
| RF4 | Vender únicamente pedidos de clientes registrados | CU6 Realizar venta |
| RF5 | Registro de clientes con todos sus datos y correo existente | CU3 Administrar clientes |
| RF6 | Registro de clientes en el local por el administrador | CU3 Administrar clientes |
| RF7 | Administrar la disponibilidad de cada producto | CU4 Administrar productos |
| RF8 | Boleta digital por cada venta, enviada por correo | CU6 Realizar venta |
| RF9 | Reporte de ventas por período para el dueño | CU8 Generar reporte de ventas |
| RF10 | Mantenedores de productos, usuarios y clientes | CU2, CU3, CU4 |
| RF11 | Validar que el correo existe mediante una API de mensajería | CU3 Administrar clientes |
| RF12 | Autenticación de usuarios y acceso según perfil | CU1 Autenticar usuarios |
| RF13 | Orden de despacho en el orden de llegada (imprimible) | CU9 Obtener orden de despacho |

### Brechas y supuestos declarados

1. **Origen de los requisitos.** Los RF1–RF13, CU1–CU9 y RNF1–RNF16 siguen la estructura de requisitos del caso de referencia de la asignatura, adaptados a «El Asador» con lo que muestran las pantallas del frontend de la C2 (promociones, cotizador de eventos, zonas de despacho). La matriz de trazabilidad del módulo 1 enlaza cada requisito con sus servicios y sus pruebas, de modo que un cambio de requisito se revisa allí.
2. **Docker se ejecutó solo en el equipo del autor y solo con el compose principal.** El 7 de noviembre de 2026, en Docker Desktop para Windows, `docker compose up -d --build` construyó las 10 imágenes y levantó los 12 contenedores (todos `healthy`, salvo `vault-seed`, que termina por diseño) y `python scripts/smoke_test.py` dio **29 de 29** ([`docs/evidencia/docker_humo.txt`](evidencia/docker_humo.txt)). El primer intento falló: Vault no arrancaba porque la imagen intenta `setcap` y ese motor no lo permite (corregido con `SKIP_SETCAP: "true"` en `docker-compose.yml`). El 8 de noviembre de 2026 se repitió con la versión final de la entrega (el backend sin el frontend conectado, con el `Dockerfile` de un solo objetivo): las 10 imágenes se construyeron sin errores, los 12 contenedores quedaron `healthy`, la prueba de humo dio **29 de 29** y se registraron los casos C1–C6 sobre los contenedores ([módulo 7.4](#74-evidencia-de-la-ejecución-con-docker), [`docs/evidencia/docker_2026-11-08/`](evidencia/docker_2026-11-08/README.md)). Las pruebas automáticas y las mediciones de carga se ejecutaron con el sistema como procesos separados, con HashiCorp Vault y MongoDB **reales** (sin Docker) y con versiones simuladas, no dentro de contenedores. No se ejecutó `docker-compose.tls.yml` ni `docker-compose.carga.yml`.
3. **Alcance respecto del frontend.** Esta entrega es el backend con **datos del frontend**, no el frontend integrado (esa integración se valida en la Evaluación 3); la frase «backend completo integrado con el frontend» de la pauta se entiende en ese sentido. Aquí, «datos del frontend» son los datos de prueba de la C2 (carta y cuentas de demostración), los contratos REST de las operaciones de cada pantalla ([M1](#m1-servicios-contratos-y-trazabilidad)) y las consultas GraphQL de «Mis pedidos» y del panel interno, que las pruebas leen sin reescribirlas (`datos-frontend/consultas-graphql.json`, copiadas del JavaScript de la C2). Por eso los servicios, los contratos y los datos de prueba salen de las pantallas y los datos de la C2, y los flujos principales se demuestran por HTTP contra el sistema levantado ([10.4](#104-demostración-de-los-flujos-principales)). Por eso el proyecto del backend (`el-asador-backend/`) no incluye el frontend, solo esos datos. Las pruebas del código del navegador (sin secretos escritos, solo el carrito y la comuna en `localStorage`, política de contenido de las 8 páginas) y el recorrido en Chromium (106 comprobaciones) se hicieron sobre una copia adaptada del frontend y quedan fuera de esta entrega, para la Evaluación 3.
4. **Se ejecuta en localhost.** No hace falta publicar el sistema en un servidor: todo corre en el equipo de quien lo evalúa (`http://localhost:8000`). No existe una dirección pública del sistema.
5. **Desviaciones deliberadas respecto del caso de referencia:** RNF3 (Oracle, .NET/J2EE) se reemplaza por FastAPI y MongoDB, las restricciones del curso (ADR-012). RNF4 (procedimientos almacenados) se reemplaza por reintentos y una bandeja de salida.
6. **Integraciones externas simuladas.** El proveedor de pagos es `provider-sandbox`, un simulador propio con el mismo contrato que usa `payments` (clave de API, página de pago, aviso firmado). El correo usa por omisión un adaptador de prueba (`sandbox`); el envío SMTP y la validación por DNS MX están programados pero no se probaron.
7. **gRPC no se implementó.** La analítica usa HTTP/JSON (ADR-004). La pauta evalúa 6 de los 10 puntos de ese criterio con «evidencia reproducible de que la alternativa implementada satisface la carga y los requisitos»; esa evidencia son las mediciones de los módulos [9.3](#93-medición-de-carga-volumen-proyectado) y [9.4](#94-medición-de-carga-10-veces-el-volumen-proyectado), incluido el punto en que el reporte de 92 días deja de cumplir su objetivo.
8. **Vault corre en modo desarrollo** (en memoria, sellado automático): sirve para la evaluación y para demostrar el modelo de secretos, no para producción (ADR-003).
9. **Lo que no se mide no se afirma:** no hay medición de usabilidad (RNF10, RNF11) y, al no estar el frontend conectado al backend, tampoco se validó con este backend el HTML ni el diseño responsivo (RNF15, RNF16) ni la impresión de la boleta y de la orden de despacho; las cifras de rendimiento corresponden a un equipo de 2 CPU y 8 GB, con el generador de carga en el mismo equipo y datos sintéticos.
10. **Servicios sin pantalla que los llame:** S22, S23 y S25 (listar y consultar pedidos por REST) existen y las prueba la suite automática, pero el frontend de la C2 usa GraphQL (S38) en «Mis pedidos» y en el panel interno; S35 (aviso firmado) la invoca el proveedor simulado, no una pantalla. S36 (mensaje de contacto) no corresponde a ningún RF: existe porque el formulario de contacto del frontend lo necesita.
11. **Inventario:** el requisito pide administrar la **disponibilidad** de cada producto (RF7), no cantidades; por eso no se descuenta ni se recupera stock al vender o anular.

---

## M1 Servicios, contratos y trazabilidad

El sistema expone **38 servicios públicos** (S01–S38): cada uno es una fila de la tabla de rutas del API Gateway (`api-gateway/app/rutas.py`). Lo que no figura en esa tabla no se reenvía. El catálogo siguiente se genera desde esa misma tabla y desde la lectura del código de cada servicio; los ejemplos se capturaron ejecutando el sistema.

### 1.1 Catálogo de servicios y contratos

{{incluir matrices/servicios_y_contratos.md nivel=4 sin_titulo=1 hasta="## Modelos de entrada"}}

Los modelos de entrada (cada cuerpo JSON se valida con `extra="forbid"`: un campo no declarado se rechaza) están en [matrices/servicios_y_contratos.md](matrices/servicios_y_contratos.md).

### 1.2 Ejemplos JSON capturados

Se ejecutó el sistema completo y se guardó una petición y una respuesta reales de **cada** uno de los 38 servicios en [`docs/ejemplos/`](ejemplos/). Los valores secretos (cookie, claves, firmas) están enmascarados. Cuatro ejemplos representativos:

{{ejemplo S01}}

{{ejemplo S21}}

{{ejemplo S35}}

{{ejemplo S38}}

### 1.3 Trazabilidad requisito → pantalla → servicio → prueba → resultado → evidencia

{{incluir matrices/trazabilidad.md nivel=4 sin_titulo=1}}

---

## M2 UML de dominio y de servicios

### 2.1 Modelo de dominio

{{mermaid diagramas/01-dominio.mmd}}

**Notación.** Multiplicidades `1`, `0..1`, `0..*` y `1..*` en ambos extremos. `◆` composición (la parte no existe sin el todo), `◇` agregación, `→` asociación dirigida, `⇢` dependencia de uso (no relaciona registros de negocio), `«service»` servicio público. El diagrama es editable (Mermaid, texto plano en `docs/diagramas/01-dominio.mmd`).

### 2.2 Cardinalidades y regla de negocio que las justifica

| Relación | Cardinalidad | Regla de negocio | Dónde se aplica y prueba |
|---|---|---|---|
| Cliente — Pedido | 1 → 0..* | Cada cliente puede tener como máximo 5 pedidos en «Pago pendiente» a la vez (variable `MAX_PEDIDOS_PENDIENTES`), para que un cliente no acapare la cola ni llene la base con pedidos sin pagar. | `orders` · `test_maximo_de_pedidos_pendientes_por_cliente` |
| Pedido — LineaPedido | 1 ◆→ 1..30 | Un pedido sin líneas no existe y hay un tope de 30 líneas con 1 a 20 unidades cada una. | `orders` (modelo `PedidoIn`) · `test_limites_de_cantidad` |
| LineaPedido — Producto | 0..* ⇢ 1 | La línea **copia** el precio vigente al crear el pedido; un cambio posterior del catálogo no altera pedidos ya creados. | `orders` · `test_el_precio_del_pedido_es_el_vigente_en_el_servidor_y_no_cambia_despues` |
| Promoción — Producto | 0..* ◇→ 1..* | Un producto que forma parte de una promoción activa no se puede retirar de la carta. | `inventory` · `test_un_producto_que_forma_parte_de_una_promocion_activa_no_se_puede_retirar` |
| Pedido — ZonaDespacho | 0..* ⇢ 1 | El costo de despacho depende de la comuna; una comuna sin cobertura se rechaza. | `orders` · `test_comuna_sin_cobertura`, `test_costo_de_despacho_segun_la_comuna` |
| Pedido — Pago | 1 → 0..* | Un pago rechazado deja el pedido pendiente y se puede reintentar; por eso un pedido puede tener varios intentos, pero **solo uno queda aprobado** aunque lleguen avisos simultáneos. | `payments` · `test_pago_rechazado_deja_el_pedido_pendiente_y_se_puede_reintentar`, `test_dos_avisos_simultaneos_aprueban_solo_uno` |
| Pago — Reembolso | 1 ◆→ 0..1 | Solo hay reembolso si un pedido ya pagado se anula; lo registra el administrador o el proveedor. | `payments` · `test_anular_un_pedido_pagado_manualmente_genera_reembolso_pendiente` |
| Pago — Venta | 1 → 0..1 | La venta (y su boleta) nace únicamente de un pago aprobado. | `payments` · `test_flujo_completo_con_el_proveedor` |
| Venta — VentaAnalitica | 1 ⇢ 1 | La analítica recibe cada venta como evento **idempotente** (clave natural: el folio de la venta); repetirlo no la cuenta dos veces y anularla la resta una sola vez. | `analytics` · `test_un_evento_repetido_no_cambia_el_reporte`, `test_la_anulacion_resta_la_venta_y_repetirla_no_resta_dos_veces` |
| Cliente — Usuario | 0..1 — 1 | Un cliente dado de alta en el local puede no tener acceso web; las credenciales viven en `auth`, los datos personales en `clients`. | `clients` · `test_un_cliente_dado_de_alta_en_el_local_puede_activar_su_acceso_web` |
| Usuario — Sesión | 1 → 0..* | Cambiar la clave, el rol o desactivar al usuario cierra todas sus sesiones abiertas. | `auth` · `test_cambiar_la_clave_cierra_las_sesiones_abiertas_y_la_clave_vieja_deja_de_servir` |

### 2.3 Servicios y sus operaciones

Cada operación lleva el ID del servicio del módulo 1 (S01 a S38); `«port»` es el gestor de secretos y `«externo»` un tercero.

{{mermaid diagramas/02-servicios.mmd}}

### 2.4 Ciclo de vida del pedido

{{mermaid diagramas/06-estados-pedido.mmd}}

Solo el servicio `payments` puede mover un pedido de «Pago pendiente» a «En preparación»; el navegador no tiene ninguna ruta hacia esa transición (ADR-007). Una prueba unitaria compara la máquina de estados del código con esta tabla (`test_maquina_de_estados_coincide_con_la_tabla`).

---

## M3 Sistemas y persistencia

### 3.1 Matriz de sistemas

| Sistema | Responsabilidad | Datos que administra | Servicios asociados | Dependencias | Contrato de integración | Credencial o identidad requerida | Respuesta ante fallos |
|---|---|---|---|---|---|---|---|
| Navegador (frontend de la C2, no incluido) | Interfaz de las 8 páginas; no decide precios, pagos ni permisos | Cookie de sesión `HttpOnly`; solo el carrito (ids y cantidades) y la comuna en el navegador | Los 38 (S01–S38), solo a través del gateway | `api-gateway` | HTTP/JSON bajo `/api` en `127.0.0.1:8000` | Cookie de sesión opaca; ningún secreto | Recibe un error controlado, sin trazas ni nombres internos (ADR-010) |
| `api-gateway` | Única puerta pública: tabla de rutas, sesión, rol, origen, límite de tasa | Ninguno (caché del catálogo y contadores de tasa en memoria) | S01–S38 (las reenvía) | Todos los servicios, `vault` | Tabla de 38 rutas; hacia los servicios, HTTP/JSON con `X-Service-Name` y `X-Service-Secret` | Un secreto por destino (7 pares `api-gateway→X`) y token de Vault propio; descarta las cabeceras de identidad del navegador | Plazo de 6 s; 503/504 controlados; cortacircuitos; con `inventory` caído sirve la carta desde su caché corta (solo GET anónimos) |
| `auth` | Credenciales (argon2id) y sesiones | MongoDB `auth`: `usuarios`, `sesiones` | S01–S03, S16–S19 | MongoDB `auth`, `vault` | REST interno: `/login`, `/logout`, `/introspect`, `/users`, `/internal/credentials` | Secretos `api-gateway→auth` y `clients→auth`; usuario propio de MongoDB; token de Vault propio | Si no responde, las rutas con sesión no se atienden (error controlado) y la carta pública sigue; nadie pierde la sesión (ADR-010) |
| `clients` | Datos personales del cliente; registro como saga | MongoDB `clients`: `clientes` | S10–S15 | `auth`, `notifications`, MongoDB `clients`, `vault` | REST: `/clients`, `/clients/register`; interno: `/internal/clients/{id}/delivery-profile` | Secretos `api-gateway→clients`, `orders→clients` (entrantes), `clients→auth`, `clients→notifications` (salientes) | Registro idempotente como saga: repetirlo lo completa sin duplicar (ADR-011); 503 si `auth` o `notifications` no responden |
| `inventory` | Productos, promociones, precios y disponibilidad; autoridad del precio | MongoDB `inventory`: `productos`, `promos`, `contadores` | S04–S09 | MongoDB `inventory`, `vault` | REST: `/products`, `/promos`; interno: `/internal/items`, `/internal/pricing/resolve`, `/internal/summary` | Secretos `api-gateway→inventory`, `orders→inventory`, `graphql-gateway→inventory` | Si no responde, `orders` no crea pedidos (503: no puede fijar el precio) y la carta se sirve unos segundos desde la caché del gateway |
| `orders` | Pedidos, estado oficial, despacho y cotización de eventos | MongoDB `orders`: `pedidos`, `zonas`, `config`, `cotizaciones_evento`, `contadores` | S20–S28 | `clients`, `inventory`, `payments`, `notifications`, MongoDB `orders`, `vault` | REST: `/orders`, `/admin/orders`; interno: `payable`, `payment-confirmed`, `refund-done` | Entrantes: `api-gateway→orders`, `graphql-gateway→orders`, `payments→orders`; salientes: `orders→clients`, `→inventory`, `→payments`, `→notifications` | Pedido con clave de idempotencia (el reintento no duplica, ADR-006); anular primero y reintentar el cobro por cancelar (ADR-008) |
| `payments` | Pagos, ventas y boletas, reembolsos, conciliación; único que confirma un pago | MongoDB `payments`: `pagos`, `ventas`, `eventos_proveedor`, `contadores` | S29–S35 | `orders`, `analytics`, `notifications`, proveedor de pagos, MongoDB `payments`, `vault` | REST: pago de un pedido, administración de pagos, `/webhooks/provider`; interno: resumen y pagos por pedido | Entrantes: `api-gateway→payments`, `orders→payments`, `graphql-gateway→payments`; salientes: `payments→orders`, `→notifications`, `→analytics`; `provider/api-key` hacia el proveedor y `provider/webhook-secret` para verificar la firma de sus avisos | Un aviso repetido no aprueba dos veces (por identificador de evento); conciliación periódica; boleta, evento de analítica y reverso se reintentan en ciclos (ADR-007, ADR-008); proveedor caído: 503 `PROVEEDOR_PAGO_NO_DISPONIBLE` |
| `notifications` | Validación de correos, bandeja de salida, mensajes de contacto | MongoDB `notifications`: `bandeja`, `mensajes_contacto` | S36, S37 | Proveedor de correo (adaptador), MongoDB `notifications`, `vault` | REST: `/contact-messages`, `/outbox`; interno: `/internal/email/send`, `/internal/email/validate` | Secretos `api-gateway→notifications`, `clients→notifications`, `orders→notifications`, `payments→notifications`; `email/smtp` solo con `EMAIL_PROVIDER=smtp` | Bandeja de salida con reintentos y clave de idempotencia por correo; un correo que falla no bloquea la venta (ADR-008) |
| `analytics` | Reportes de ventas por período (modelo de lectura) | MongoDB `analytics`: `ventas`, `eventos`, `historico` | Ninguno público; se consulta por S38 | MongoDB `analytics`, `vault` | Interno: eventos `sale-registered` y `sale-reversed`; consulta `/internal/reports/sales` | Secretos `payments→analytics` y `graphql-gateway→analytics` | Eventos idempotentes (clave: el folio de la venta) y tolerantes al desorden; si cae, el pago no se bloquea y `payments` reenvía en su ciclo (ADR-008) |
| `graphql-gateway` | Consultas compuestas de solo lectura | Ninguno | S38 | `orders`, `inventory`, `payments`, `analytics` | `POST /graphql` (interno) | Entrante: `api-gateway→graphql-gateway`; salientes: un secreto por servicio consultado, que solo permite `GET` | Respuesta parcial: si `payments` no responde, «Mis pedidos» se ve sin el dato del pago; toda la consulta tiene un tope de 5 s (ADR-010) |
| `provider-sandbox` | Proveedor de pagos simulado: API con clave, página de pago y avisos firmados | Cobros en memoria | S35 (es quien la invoca) | `api-gateway` (aviso), `vault` | API `/v1/...` con clave; aviso con firma HMAC-SHA256 | `provider/api-key` (la verifica) y `provider/webhook-secret` (firma con ella) | Si no responde, `payments` devuelve 503 y el pedido sigue pendiente; un aviso perdido se recupera por conciliación (ADR-007) |
| `vault` | Secretos de servicio a servicio y credenciales de base de datos | Memoria (modo desarrollo; se vuelve a sembrar al arrancar) | — | — | HTTP, KV v2; solo lectura para los servicios | Token propio por servicio, con política de solo lectura sobre SUS secretos | Cada servicio conserva una caché y sigue sirviendo; sin caché, falla cerrado (ADR-003) |
| `vault-seed` | Tarea de arranque: carga los secretos y crea una política y un token por servicio | — | — | `vault` | `scripts/seed_vault.py` con `secrets/manifest.tsv` | Token raíz del Vault de desarrollo, solo durante el arranque | Termina por diseño; si falla, los servicios que dependen de ella no arrancan |
| `mongo` | Almacén de datos | Volumen `mongo-datos`: una base por servicio | — | — | Protocolo de MongoDB, solo red interna | Un usuario por servicio, con permisos solo sobre SU base (`db/<servicio>`) | Un servicio sin su base responde con error controlado; el resto del sistema sigue (ADR-010) |

Exposición: solo `api-gateway` (`127.0.0.1:8000`) y `provider-sandbox` (`127.0.0.1:8300`, página de pago) publican puertos; todo lo demás está en la red interna.

### 3.2 Mapa de componentes y redes

El mapa también está escrito como modelo C4 editable en Structurizr DSL: `docs/diagramas/El-Asador.dsl`.

{{mermaid diagramas/03-componentes-y-redes.mmd}}

### 3.3 Secuencia de integración

**Compra con pago en línea** (RF1, RF2, RF4, RF8):

{{mermaid diagramas/04-secuencia-compra.mmd}}

### 3.4 Consistencia entre servicios

Cada servicio tiene su propia base, por lo que no hay transacciones entre ellos. En su lugar se aplicaron patrones concretos, cada uno con su decisión (ADR) y sus pruebas:

| Situación | Mecanismo | ADR |
|---|---|---|
| Crear un pedido sin duplicarlo ante un reintento | Clave de idempotencia (`Idempotency-Key`) y precio fijado por el servidor | [006](adr/ADR-006-pedido-precio-y-idempotencia.md) |
| Confirmar un pago | Aviso firmado + confirmación idempotente + conciliación periódica | [007](adr/ADR-007-confirmacion-de-pago-y-reembolsos.md) |
| Anular un pedido ya pagado | Anular primero y reintentar el reembolso hasta que `payments` responda | [008](adr/ADR-008-anulacion-primero-y-reconciliacion.md) |
| Registro de cliente (`clients` + `auth` + `notifications`) | Saga idempotente: repetir el registro lo completa sin duplicar | [011](adr/ADR-011-registro-de-clientes-saga.md) |
| Un servicio no responde | Plazos jerárquicos, cortacircuitos y degradación parcial | [010](adr/ADR-010-resiliencia-y-plazos.md) |

---

## M4 Actores y permisos

### 4.1 Actores (stakeholders)

| Actor | Qué necesita | Qué no debe poder hacer |
|---|---|---|
| Visitante (sin sesión) | Ver la carta, promociones y zonas; cotizar un evento; enviar un mensaje de contacto; registrarse | Ver pedidos, clientes, pagos o reportes |
| Cliente | Armar pedidos, pagar, ver su boleta y anular lo suyo | Ver o tocar el pedido de otro cliente; marcar su pedido como pagado; ver datos de otros clientes |
| Administrador | Mantener productos, clientes y usuarios; confirmar pagos manuales; reembolsar; ver la bandeja de salida | Quitarse el acceso a sí mismo; dejar el sistema sin ningún administrador activo |
| Dueño | Ver reportes de ventas y el catálogo | Ver clientes, pedidos ni pagos (ni datos personales del reporte) |
| Despacho | Ver los pedidos pagados en orden de llegada, avanzar su estado e imprimir la orden | Anular, reembolsar, cambiar precios |
| Proveedor de pagos (tercero) | Avisar el resultado de un cobro | Cualquier cosa sin una firma válida; alterar un monto |
| Operación / TI | Levantar y rotar secretos del sistema | (No es un rol de la aplicación: opera Vault y MongoDB desde fuera) |
| Atacante | — | Todo lo anterior sin credenciales; los casos C2–C6 del módulo 7 lo ejercitan |

### 4.2 Matriz de permisos por ruta, verbo y condición

{{incluir matrices/permisos_por_rol.md nivel=4 sin_titulo=1}}

La autorización se comprueba **dos veces**: el gateway aplica el rol de la tabla de rutas y cada servicio privado vuelve a comprobar el rol y la pertenencia (por ejemplo, que el pedido sea del cliente de la sesión). Una prueba recorre todas las rutas con cada rol y exige que la matriz publicada coincida con la tabla del gateway (`test_la_matriz_de_permisos_del_informe_coincide_con_el_gateway`).

La fila de S23 permite comprobar que un cliente no consulta pedidos de otro (solo ve el SUYO); la regla la aplica `orders` como segunda capa. El recorrido de una consulta autorizada y de una denegada está en el [módulo 5.4](#54-recorrido-de-una-solicitud-autorizada-y-de-una-denegada).

---

## M5 API Gateway y fronteras de confianza

### 5.1 UML del gateway

{{mermaid diagramas/07-gateway-uml.mmd}}

### 5.2 Fronteras de confianza

{{mermaid diagramas/08-fronteras-de-confianza.mmd}}

| Flujo | De → a | Qué se comprueba al cruzar |
|---|---|---|
| F1 | Internet → gateway | Tabla de rutas, límite de tasa por IP, `Origin`/`Referer` en escrituras, tamaño y formato del cuerpo, cabeceras permitidas por ruta, sesión (introspección en `auth` en cada solicitud), rol |
| F2 | Proveedor → gateway | Firma HMAC-SHA256 sobre el cuerpo exacto, ventana de 300 s, monto y moneda, identificador de evento único |
| F3 | Gateway → servicio | Secreto propio del par llamador→destino, nombre del llamador y la identidad ya verificada; el servicio vuelve a comprobar rol y pertenencia |
| F4 | Servicio → MongoDB | Usuario propio con permisos solo sobre SU base |
| F5 | Servicio → Vault | Token propio de solo lectura sobre SUS secretos |

### 5.3 Decisiones de separación

| Decisión | Por qué se separó | ADR |
|---|---|---|
| Dos gateways: el API Gateway público y el GraphQL Gateway privado (no uno por servicio) | El API Gateway concentra los controles de entrada (sesión, rol, origen, tasa); el GraphQL Gateway es de solo lectura, solo lo llama el gateway y su caída no afecta a las escrituras. Un gateway por servicio duplicaría los controles sin crear una frontera nueva | [001](adr/ADR-001-gateway-tabla-de-rutas.md), [009](adr/ADR-009-graphql-solo-lectura.md) |
| El gateway es una tabla de rutas, no un proxy genérico | Una ruta interna (por ejemplo la confirmación de pago) no puede quedar expuesta por olvido | [001](adr/ADR-001-gateway-tabla-de-rutas.md) |
| `auth` aparte de `clients` | La contraseña nunca convive con los datos personales; se endurece y se prueba por separado | [002](adr/ADR-002-sesion-opaca-en-cookie.md), [011](adr/ADR-011-registro-de-clientes-saga.md) |
| `payments` aparte de `orders` | Quien decide el estado del pedido no puede ser quien confirma el dinero; solo `payments` puede confirmar | [007](adr/ADR-007-confirmacion-de-pago-y-reembolsos.md) |
| `analytics` aparte | Su carga y su forma de consulta son distintas de las del pedido | [004](adr/ADR-004-analitica-grpc.md) |
| Un secreto por par llamador→destino y un usuario de base por servicio | Una filtración o un servicio comprometido no abre los demás | [003](adr/ADR-003-secretos-en-vault.md), [005](adr/ADR-005-base-de-datos-por-servicio.md) |

### 5.4 Recorrido de una solicitud autorizada y de una denegada

Consulta protegida de un pedido (S23). La regla es la misma en los dos casos: en S23 un cliente solo ve el pedido si es SUYO, y la aplica `orders` como segunda capa, con la identidad que el gateway verificó. El titular recibe 200 (control 8 del [módulo 7.3](#73-resultados-de-los-6-casos-de-validación)); otro cliente recibe 403 con el mismo cuerpo que un pedido inexistente y sin datos del titular (control 1; `test_un_cliente_no_ve_el_pedido_de_otro_y_la_respuesta_no_revela_si_existe`).

![F03 Pedido propio](diagramas/render/D_F03_Propio.svg)

![F03 Pedido ajeno](diagramas/render/D_F03_Ajeno.svg)

---

## M6 Rutas, secretos y llamadas entre servicios

### 6.1 Matriz de rutas y controles

{{incluir matrices/rutas_y_controles.md nivel=4 sin_titulo=1}}

### 6.2 Inventario simbólico de secretos

{{incluir matrices/inventario_de_secretos.md nivel=4 sin_titulo=1}}

### 6.3 Llamadas entre servicios y secreto de cada par

{{incluir matrices/llamadas_entre_servicios.md nivel=4 sin_titulo=1}}

### 6.4 GraphQL y gRPC

Las operaciones GraphQL, su permiso por campo y sus límites están en el módulo 8. **gRPC no se implementa:** la decisión, con la carga proyectada y medida, está en el [ADR-004](adr/ADR-004-analitica-grpc.md) (módulo 9).

### 6.5 Plan ante filtración o caída de Vault

{{incluir adr/ADR-003-secretos-en-vault.md nivel=4}}

---

## M7 Datos, secretos y casos de validación

### 7.1 Clasificación de datos

{{clasificacion_de_datos}}

**Recorrido de un dato personal (la dirección de despacho):** el cliente la escribe en el formulario de registro → el gateway valida origen, tamaño y límites de tasa → `clients` la valida y la guarda (es la única autoridad de ese dato) → al crear un pedido, `orders` pide a `clients` solo el perfil de despacho con el secreto del par `orders→clients` y guarda en el pedido la dirección y la comuna necesarias para despachar → el pedido solo lo ven su cliente, el administrador y el despacho (el dueño no) → los logs no contienen correos ni RUN completos (`test_los_logs_no_dejan_correos_ni_ruts_completos`) y los reportes de analítica no llevan datos personales (`test_el_reporte_lo_ven_el_administrador_y_el_dueno_y_no_trae_datos_personales`).

### 7.2 Decisión sobre los secretos del cliente

**El backend no entrega al navegador ningún secreto del sistema.** Ninguna respuesta lleva claves de API, claves de firma, credenciales de servicio ni tokens de Vault, y el proyecto del backend no contiene JavaScript ni HTML del cliente (el frontend no forma parte de este proyecto). La única credencial que tiene el cliente es el token de sesión, que:

- es **opaco** (aleatorio, no un JWT con datos dentro) y el servidor guarda solo su hash SHA-256, así que ni una copia de la base permite reutilizarlo;
- viaja en una cookie `HttpOnly` (el JavaScript no puede leerla, lo que limita el robo por XSS) con `SameSite=Lax` y, detrás de HTTPS, `Secure`;
- se revisa en el servidor en **cada** solicitud, caduca a las 2 horas y se revoca al cerrar sesión, cambiar la clave, cambiar el rol o desactivar la cuenta;
- no se devuelve en el cuerpo de ninguna respuesta ni se escribe en los logs.

Alternativa descartada: JWT en `localStorage` (legible por cualquier script, no revocable sin lista de bloqueo). Detalle en el [ADR-002](adr/ADR-002-sesion-opaca-en-cookie.md).

| Afirmación de seguridad | Evidencia de ejecución |
|---|---|
| La cookie es `HttpOnly`/`SameSite` y el token no viaja en el cuerpo | `test_la_cookie_de_sesion_es_httponly_y_el_token_no_viaja_en_el_cuerpo`, `test_la_cookie_de_sesion_va_con_secure_httponly_y_samesite` |
| Ningún log contiene secretos, contraseñas ni tokens de sesión | `test_ningun_secreto_de_vault_ni_token_de_servicio_aparece_en_los_logs`, `test_ninguna_contrasena_ni_token_de_sesion_aparece_en_los_logs` |
| Ninguna respuesta expone campos internos ni secretos | `test_ninguna_respuesta_expone_campos_internos_secretos_ni_cabeceras_de_servicio`, `test_las_respuestas_nunca_contienen_secretos_de_vault` |
| Un secreto de un par no sirve para otro destino | `test_el_secreto_de_un_par_no_sirve_para_otro_destino`, `test_los_secretos_de_cada_par_son_distintos` |
| Las contraseñas se guardan con argon2id y ninguna colección guarda texto plano | `test_las_contrasenas_se_guardan_con_argon2id_y_ninguna_coleccion_guarda_texto_plano` (solo con MongoDB real) |
| Cada servicio de base de datos solo ve la suya | `test_infraestructura_real.py` (solo con MongoDB real) |
| Si Vault no responde, se usa la caché o se falla cerrado | `test_si_vault_no_responde_se_usa_la_cache_y_sin_cache_se_falla_cerrado` |

### 7.3 Resultados de los 6 casos de validación

Los seis casos (C1–C6) se ejecutaron contra el sistema levantado; cada fila es una solicitud HTTP real con su resultado esperado, el obtenido, el componente que lo verifica y la prueba automática que lo cubre.

{{incluir evidencia/controles.md nivel=4 sin_titulo=1 hasta="## M8 Agregación GraphQL ejecutada desde la pantalla"}}

### 7.4 Evidencia de la ejecución con Docker

La versión final del backend (el sistema se probó sin el frontend conectado) se levantó con Docker Compose el 8 de noviembre de 2026, a las 16:11 (hora de Chile), en Docker Desktop para Windows (Docker 29.9.2, Compose v5.6.1), y se probó por HTTP contra los contenedores. Todo lo que sigue es salida literal de las herramientas, guardada en [`docs/evidencia/docker_2026-11-08/`](evidencia/docker_2026-11-08/README.md).

| Qué se ejecutó | Resultado | Archivo |
|---|---|---|
| `docker compose up -d --build` | las 10 imágenes se construyeron sin errores y los 12 contenedores quedaron `healthy` (`vault-seed` termina por diseño) | [`03-up.txt`](evidencia/docker_2026-11-08/03-up.txt), [`04-ps.txt`](evidencia/docker_2026-11-08/04-ps.txt) |
| `python scripts/smoke_test.py` | **29 de 29** | [`05-smoke-test.txt`](evidencia/docker_2026-11-08/05-smoke-test.txt) |
| `capturas_http.py`: los casos C1–C4 y C6, el pedido, el pago y GraphQL, por HTTP contra `localhost:8000` | 27 de 27 comprobaciones (capturas 1 a 9) | [`capturas/`](evidencia/docker_2026-11-08/capturas) |
| Puertos alcanzables desde el equipo (`capturas_http.py`) | 3 de 4 como se esperaba; el cuarto, el 27017, lo atiende el MongoDB de Windows instalado en el equipo, no el proyecto (diagnóstico aparte) | [`10a`](evidencia/docker_2026-11-08/capturas/10a-c5-puertos-desde-el-equipo.txt), [`10c`](evidencia/docker_2026-11-08/capturas/10c-diagnostico-puerto-27017.txt) |
| `acceso_directo.py`: llamadas directas a los 8 servicios privados, desde dentro de la red de Docker | **16 de 16** rechazadas (403 `LLAMADOR_NO_PERMITIDO` sin credencial y 403 `SECRETO_INVALIDO` con un secreto inventado) | [`10b-c5-servicios-privados.txt`](evidencia/docker_2026-11-08/capturas/10b-c5-servicios-privados.txt) |

Cada «captura» es la transcripción de una solicitud HTTP real: las líneas con `>` son la petición y las líneas con `<` la respuesta, tal como viajaron. Se oculta el valor de la cookie de sesión y las listas largas se recortan a 2 elementos; lo demás no se edita. Las comprobaciones del final de cada captura comparan lo esperado con lo obtenido.

**Captura 1. C1, catálogo anónimo.** `GET /api/products` sin cookie: 200, sin `Set-Cookie` y solo con campos públicos.

{{codigo docs/evidencia/docker_2026-11-08/capturas/01-c1-catalogo-anonimo.txt text}}

**Captura 2. Inicio de sesión.** `POST /api/auth/login`: la sesión viaja en una cookie `HttpOnly` y `SameSite`; el token no aparece en el cuerpo de la respuesta.

{{codigo docs/evidencia/docker_2026-11-08/capturas/02-inicio-de-sesion-del-cliente.txt text}}

**Captura 3. Pedido.** `POST /api/orders` con `Idempotency-Key`: 201; el cliente solo envía identificadores y cantidades y el total lo calcula el servidor; repetir la petición con la misma clave devuelve el mismo pedido.

{{codigo docs/evidencia/docker_2026-11-08/capturas/03-pedido-creado-con-sesion-de-cliente.txt text}}

**Captura 4. Pago con el proveedor simulado.** Inicio del pago (201), pago en la página del proveedor (303) y el pedido en «En preparación» después del aviso firmado. La dirección de vuelta de la respuesta 303 es una pantalla del frontend de la C2 (`pedidos.html`), que no forma parte del proyecto del backend: el backend solo guarda esa dirección.

{{codigo docs/evidencia/docker_2026-11-08/capturas/04-pago-con-el-proveedor-simulado.txt text}}

**Captura 5. GraphQL «Mis pedidos».** La consulta `CONSULTA_PEDIDOS` de la C2 (`datos-frontend/consultas-graphql.json`), en una sola solicitud: trae el pedido con su cliente, sus líneas, su pago y su boleta.

{{codigo docs/evidencia/docker_2026-11-08/capturas/05-graphql-mis-pedidos.txt text}}

**Captura 6. C2, operación protegida sin sesión válida.** `POST /api/orders` sin cookie (401 `NO_AUTENTICADO`) y con una cookie inventada (401 `SESION_NO_VALIDA`).

{{codigo docs/evidencia/docker_2026-11-08/capturas/06-c2-operacion-protegida-sin-sesion-valida.txt text}}

**Captura 7. C3, administración desde un rol sin permiso.** Con la sesión de un cliente, crear un producto y listar los usuarios dan 403 `ROL_NO_AUTORIZADO`.

{{codigo docs/evidencia/docker_2026-11-08/capturas/07-c3-administracion-desde-un-rol-sin-permiso.txt text}}

**Captura 8. C4, pedido ajeno.** El cliente B pide el pedido del cliente A (403 `PROHIBIDO`, con la misma respuesta que un pedido inexistente) y no puede iniciar su pago; el dueño sí lo ve (200).

{{codigo docs/evidencia/docker_2026-11-08/capturas/08-c4-consulta-de-un-pedido-ajeno.txt text}}

**Captura 9. C6, pago con datos alterados.** Un cliente no puede confirmar un pago (403 `ROL_NO_AUTORIZADO`); un aviso del proveedor por 1 peso, sin firma o con una firma inventada, se rechaza (400 `AVISO_NO_VALIDO`).

{{codigo docs/evidencia/docker_2026-11-08/capturas/09-c6-confirmar-un-pago-con-datos-alterados.txt text}}

**Captura 10. C5, acceso directo al backend.** Tiene tres partes.

*(a) Desde el equipo.* Los puertos que el compose publica a propósito responden (8000, el gateway, y 8300, el proveedor simulado) y el de Vault (8200) está cerrado. El 27017 también respondió, y por eso su fila figura como «FALLA»: la comprobación solo mira si algo responde en ese puerto, no quién. Lo atiende `mongod.exe`, el servicio de Windows «MongoDB Server» instalado en el equipo del autor, ajeno a Docker (parte b).

{{codigo docs/evidencia/docker_2026-11-08/capturas/10a-c5-puertos-desde-el-equipo.txt text}}

*(b) Diagnóstico de ese puerto.* El único proceso que escucha en `127.0.0.1:27017` es `mongod.exe` (PID 4600, servicio de Windows). El contenedor del proyecto, `asador-mongo-1`, solo expone `27017/tcp` dentro de la red de Docker, sin puerto publicado hacia el equipo (`27017/tcp -> :0`), igual que Vault (`8200/tcp -> :0`); los únicos puertos publicados son `127.0.0.1:8000` y `127.0.0.1:8300`.

{{codigo docs/evidencia/docker_2026-11-08/capturas/10c-diagnostico-puerto-27017.txt text}}

*(c) Desde dentro de la red de Docker.* Se llamó directamente a los 8 servicios privados desde el contenedor del gateway, sin credencial de servicio y con un secreto inventado: las 16 llamadas se rechazaron con 403 (`LLAMADOR_NO_PERMITIDO` y `SECRETO_INVALIDO`).

{{codigo docs/evidencia/docker_2026-11-08/capturas/10b-c5-servicios-privados.txt text}}

**Alcance de esta evidencia.** Es una sola puesta en marcha, en un solo equipo, con los datos de demostración y el proveedor de pagos simulado. La evidencia amplia sigue siendo la suite automática ([10.3](#103-pruebas-ejecutadas)) y los controles C1–C6 de arriba; estas capturas muestran los mismos controles sobre los contenedores. El arranque (16:11) y las pruebas (16:17 a 16:19) fueron dos ejecuciones consecutivas de `verificar_docker.ps1`: la primera se detuvo tras el arranque por un defecto del propio script (PowerShell devolvió vacío un código de salida), que se corrigió, y la segunda, sobre el mismo sistema ya levantado, hizo las pruebas. Las herramientas con las que se obtuvo están en [`herramientas/`](evidencia/docker_2026-11-08/herramientas) y se ejecutan con `verificar_docker.ps1`.

---

## M8 GraphQL: agregación de solo lectura

### 8.1 Separación privada

El GraphQL Gateway es un servicio **privado y de solo lectura**: el navegador no puede alcanzarlo directamente; entra por `POST /api/graphql` (S38) del API Gateway, que ya verificó la sesión. Reglas (ADR-009): sin mutaciones ni suscripciones, sin GraphiQL ni introspección, solo `POST` con JSON, una sola vez cada servicio por consulta (DataLoader), límites de profundidad, alias, tokens y costo, y errores enmascarados. Su secreto con cada servicio permite únicamente métodos `GET` de lectura (`test_el_graphql_gateway_es_de_solo_lectura_aunque_tenga_su_secreto`).

### 8.2 Esquema

El esquema completo, generado desde el código, está en [`docs/graphql/schema.graphql`](graphql/schema.graphql).

{{codigo docs/graphql/schema.graphql graphql}}

### 8.3 Operaciones, autorización por campo y límites

{{incluir matrices/graphql.md nivel=4 sin_titulo=1}}

### 8.4 Consulta de prueba, respuesta esperada y agregación desde el frontend

La pantalla «Mis pedidos» de la C2 (`CONSULTA_PEDIDOS` de `datos-frontend/consultas-graphql.json`, copiada de su `pedidos.js`) pide en **una** consulta lo que sin GraphQL serían tres llamadas por pedido (pedido, pago y boleta), más las imágenes del catálogo. La evidencia siguiente se generó ejecutando exactamente esa consulta contra el sistema levantado, con el registro de las llamadas internas que hizo el GraphQL Gateway (una por servicio, sin el problema N+1) y la comprobación de que cada cliente solo ve sus pedidos. El panel interno (`CONSULTA_VENTAS` y `CONSULTA_DESPACHO`, de `admin.js`) se agrega de la misma forma desde tres servicios.

{{incluir evidencia/controles.md nivel=4 sin_titulo=1 desde="## M8 Agregación GraphQL ejecutada desde la pantalla" hasta="## Detalle de la agregación de tres servicios"}}

### 8.5 Mapa de clasificación de servicios

| Servicio | Naturaleza | Responsabilidad | Datos propios | Contrato | Dependencias | Justificación de que sea un servicio |
|---|---|---|---|---|---|---|
| `auth` | Soporte de seguridad · transaccional | Credenciales y sesiones | `usuarios`, `sesiones` | REST interno JSON: `/login`, `/logout`, `/introspect`, `/users`, `/internal/credentials` | MongoDB `auth`, Vault | La contraseña no convive con los datos personales; el servicio se puede endurecer y escalar aparte (ADR-002, ADR-011) |
| `clients` | Núcleo · transaccional | Datos personales y registro de clientes | `clientes` | REST interno: `/clients`, `/clients/register`, `/internal/clients/{id}/delivery-profile` | `auth`, `notifications`, MongoDB `clients`, Vault | Autoridad de los datos personales: los demás servicios piden solo lo que necesitan |
| `inventory` | Núcleo · catálogo | Productos, promociones, precios y disponibilidad | `productos`, `promos`, `contadores` | REST: `/products`, `/promos`; interno: `/internal/items`, `/internal/pricing/resolve`, `/internal/summary` | MongoDB `inventory`, Vault | Autoridad del precio; el requisito pide disponibilidad (RF7), no cantidades de stock |
| `orders` | Núcleo · transaccional | Pedidos, estado oficial, despacho, cotización de eventos | `pedidos`, `zonas`, `config`, `cotizaciones_evento`, `contadores` | REST: `/orders`, `/admin/orders`; interno: `payable`, `payment-confirmed`, `refund-done` | `clients`, `inventory`, `payments`, `notifications`, MongoDB, Vault | Autoridad del estado del pedido; fija precios y total en el servidor |
| `payments` | Núcleo · dinero e integración con tercero | Pagos, ventas, boletas, reembolsos, conciliación | `pagos`, `ventas`, `eventos_proveedor`, `contadores` | REST: pago de un pedido, administración de pagos, `/webhooks/provider`; interno: resumen y pagos por pedido | `orders`, `analytics`, `notifications`, proveedor de pagos, MongoDB, Vault | Único que puede confirmar un pago (ADR-007) |
| `notifications` | Soporte · integración de correo | Validar correos, enviar, bandeja de salida, mensajes de contacto | `bandeja`, `mensajes_contacto` | REST: `/contact-messages`, `/outbox`; interno: `/internal/email/send`, `/internal/email/validate` | Proveedor de correo (adaptador), MongoDB, Vault | Aísla al tercero de correo detrás de un adaptador |
| `analytics` | Modelo de lectura | Reportes de ventas por período | `ventas`, `eventos`, `historico` | Interno: eventos `sale-registered`, `sale-reversed`; consulta `/internal/reports/sales` | MongoDB `analytics`, Vault | Carga y forma de consulta distintas de las del pedido (ADR-004) |
| `graphql-gateway` | Agregación · solo lectura | Consultas compuestas para las pantallas | Ninguno | `POST /graphql` (interno) | `orders`, `inventory`, `payments`, `analytics` | Un único punto de agregación sin poder de escritura (ADR-009) |
| `api-gateway` | Borde | Única puerta pública | Ninguno (caché y contadores en memoria) | 38 rutas públicas (S01–S38) | Todos los servicios, Vault | Concentra los controles de entrada (ADR-001) |
| `provider-sandbox` | Tercero simulado | Proveedor de pagos | Cobros en memoria | API con clave `/v1/...`, página de pago, avisos firmados | `api-gateway` (aviso), Vault | Representa lo que no controlamos |

---

## M9 Analítica, gRPC y carga

### 9.1 Necesidades analíticas

| Necesidad | Quién | Frecuencia y volumen | Latencia y consistencia aceptadas | Privacidad | Solución adoptada |
|---|---|---|---|---|---|
| Reporte de ventas por período (RF9), con total por día, medio de pago y productos más vendidos | Dueño y administrador | Pocas consultas al día; hasta 92 días | p95 ≤ 1 s (30 días) y ≤ 2 s (92 días); el dato puede tener segundos de retraso | Solo agregados; sin datos personales | Consulta bajo demanda a `analytics` (agregación en MongoDB) vía GraphQL |
| Ingesta de cada venta | `payments` → `analytics` | Una por venta (proyección de 18 a 35 pedidos al día) | Idempotente y tolerante al orden; no bloquea el pago | Sin datos personales | Evento HTTP idempotente con reintento por reconciliación |
| Cola de despacho | Despacho | Consulta bajo demanda desde el panel | Consistente con `orders` | Datos de despacho solo para quien despacha | Lectura directa de `orders`; sin streaming |

### 9.2 Decisión: analítica con HTTP/JSON, sin gRPC

{{incluir adr/ADR-004-analitica-grpc.md nivel=4}}

### 9.3 Medición de carga (volumen proyectado)

{{incluir evidencia/carga.md nivel=4 sin_titulo=1}}

### 9.4 Medición de carga (10 veces el volumen proyectado)

{{incluir evidencia/carga_x10.md nivel=4 sin_titulo=1}}

---

## M10 Implementación, despliegue y pruebas

### 10.1 Código fuente y persistencia

```
api-gateway/        borde público (tabla de rutas, sesión, rol, origen, límites)
auth-service/       credenciales y sesiones
clients-service/    datos personales y registro
inventory-service/  catálogo, precios, disponibilidad
orders-service/     pedidos y estados
payments-service/   pagos, boletas, reembolsos
notifications-service/ correo y contacto
analytics-service/  reportes de ventas
graphql-gateway/    agregación de solo lectura
provider-sandbox/   proveedor de pagos simulado
common/             código compartido (secretos, cliente interno, errores, logs, plazos)
datos-frontend/     consultas GraphQL de las pantallas de la C2 (datos del frontend)
mongo/              creación de usuarios de base de datos (uno por servicio)
secrets/manifest.tsv inventario simbólico de secretos (sin valores)
scripts/            arranque, siembra, pruebas de humo y de carga, generadores de documentos
tests/              pruebas automáticas y de mutación
docs/               este informe, ADR, matrices, diagramas, ejemplos y evidencia
```

Cada servicio tiene su base y su usuario en MongoDB; el esquema se versiona con migraciones (`_migraciones`, ADR-005). Los datos de demostración se cargan solo si `SEED_DEMO_DATA=true`.

### 10.2 Despliegue reproducible

Desde un repositorio limpio, con Docker:

```
python scripts/bootstrap.py          # genera .env con los secretos (permisos 600, fuera de git)
docker compose up -d --build         # Vault, siembra, MongoDB, servicios y gateway
python scripts/smoke_test.py         # recorre el sistema de punta a punta; código de salida 0 solo si todo pasó
docker compose down -v               # detiene y borra también la base de datos (sin -v conserva los datos)
```

- **Referencias de secretos:** `secrets/manifest.tsv` lista las 30 referencias simbólicas (sin valores). `bootstrap.py` genera los valores aleatorios en `.env` y `seed_vault.py` los carga en Vault y crea un token de solo lectura por servicio.
- **Datos de prueba:** con `SEED_DEMO_DATA=true` (valor por omisión del compose) se cargan la carta, las zonas de despacho y las cuentas de demostración que lista el `README.md`; en cualquier uso que no sea una demostración se pone `false`.
- **Pruebas:** `pip install -r requirements/tests.txt` y `python -m pytest tests -q` (suite completa con Vault y MongoDB simulados); con servidores reales, `ASADOR_REAL=1 ASADOR_BIN=/ruta/a/bins python -m pytest tests -q`. Las dependencias están con versión fija en `requirements/`.
- **Health checks y logs:** cada servicio responde `/health` y el compose espera a que estén `healthy`; los logs son una línea JSON por solicitud con un `request_id` (cabecera `X-Request-ID`) y sin credenciales ni correos o RUN completos.

Sin Docker: `python scripts/demo_local.py` levanta el sistema completo como procesos (con Vault y MongoDB simulados, o con servidores reales si se indica `--real --bin <carpeta>`). El `README.md` de la raíz explica cada paso, las cuentas de demostración y cómo detener y limpiar.

**Todo corre en localhost**: no hay servidor ni dominio público. La puerta de entrada es `http://localhost:8000` y la página de pago del proveedor simulado, `http://localhost:8300`; ningún otro servicio publica puertos.

Docker Compose en localhost, según `docker-compose.yml` (ejecutado en Docker Desktop el 7 y el 8 de noviembre de 2026; ver `docs/evidencia/docker_humo.txt` y [`docs/evidencia/docker_2026-11-08/`](evidencia/docker_2026-11-08/README.md)):

![Despliegue con Docker Compose en localhost](diagramas/render/DEP_Compose_Local.svg)

### 10.3 Pruebas ejecutadas

{{resumen_pruebas}}

La corrida con servidores reales es del 7 de noviembre de 2026, anterior al retiro del frontend de la entrega: incluye 4 pruebas del código de las páginas que ya no están en el repositorio (una sobre la política de contenido de las 8 páginas y tres de `test_zz_logs_y_secretos` sobre el código del navegador) y la prueba de cabeceras de seguridad con su nombre anterior (que terminaba en «en_api_y_paginas»). No se repitió porque este entorno ya no tiene los servidores reales.

Las pruebas parten de contratos escritos aparte del código (`tests/contratos/*.json`), de modo que no verifican al código contra sí mismo.

### 10.4 Demostración de los flujos principales

La demostración es la prueba de humo (`scripts/smoke_test.py`): recorre por HTTP, contra el sistema levantado, los flujos principales con los datos de prueba del frontend. Cubre la carta pública, el registro, la sesión, el pedido con clave de idempotencia, el pago con el proveedor simulado y su aviso firmado, la boleta, GraphQL, el aislamiento entre clientes, el personal por rol y el cierre de sesión. Se ejecutó el 5 de noviembre de 2026 con HashiCorp Vault y MongoDB reales (sin Docker) y el 7 y el 8 de noviembre de 2026 con Docker Compose ([`docs/evidencia/docker_humo.txt`](evidencia/docker_humo.txt) y [`docs/evidencia/docker_2026-11-08/05-smoke-test.txt`](evidencia/docker_2026-11-08/05-smoke-test.txt)); en todas dio 29 de 29. Esta es la ejecución sin Docker:

{{codigo docs/evidencia/humo.txt text}}

La ejecución anterior es sobre el código final del backend, sin el frontend conectado y con servidores simulados. La misma prueba había dado 29 de 29 el 5 de noviembre con HashiCorp Vault y MongoDB reales ([`docs/evidencia/humo_reales_2026-11-05.txt`](evidencia/humo_reales_2026-11-05.txt)) y con Docker el 7 de noviembre ([`docs/evidencia/docker_humo.txt`](evidencia/docker_humo.txt)) y el 8 de noviembre, esta vez sobre el código final ([`docs/evidencia/docker_2026-11-08/05-smoke-test.txt`](evidencia/docker_2026-11-08/05-smoke-test.txt); capturas en el [módulo 7.4](#74-evidencia-de-la-ejecución-con-docker)).

La consulta protegida de un pedido, con una ejecución autorizada (control 8) y otra denegada con una cuenta distinta (control 1), está en el [módulo 7.3](#73-resultados-de-los-6-casos-de-validación) y su recorrido en el [5.4](#54-recorrido-de-una-solicitud-autorizada-y-de-una-denegada).
