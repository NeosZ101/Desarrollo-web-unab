# Matriz de trazabilidad: requisito | pantalla | servicio | prueba | resultado | evidencia (M10)

Generada por `scripts/generar_trazabilidad.py`. Pantallas y servicios salen de la tabla de rutas del API Gateway (`api-gateway/app/rutas.py`); los resultados, de los informes JUnit guardados en `docs/evidencia/` (no se escribe ningún resultado a mano).

**Origen de los requisitos:** RF1–RF13, CU1–CU9 y RNF1–RNF16 siguen la estructura de requisitos del caso de referencia de la asignatura, adaptados a «El Asador» con lo que muestran las pantallas del frontend de la C2. Está declarado en la portada del informe.

## Requisitos funcionales

| Requisito | Pantallas | Servicios | Pruebas (cantidad que lo ejercitan) | Resultado (simulado) | Resultado (Vault y MongoDB reales) | Evidencia |
|---|---|---|---|---|---|---|
| **RF1** Armar un pedido con los productos disponibles de la carta (CU5 Genera pedido) | P01, P02, P03, P07, P08 | S04, S05, S20, S21, S22, S23, S27, S28, S38 | `test_graphql` (3); `test_negocio_administracion` (5); `test_negocio_pedidos` (32); `test_unidad_reglas` (12) | 52 de 52 ✓ | 52 de 52 ✓ | [S04](../ejemplos/S04.json), [S05](../ejemplos/S05.json), [S20](../ejemplos/S20.json), …; [controles M8](../evidencia/controles.md) |
| **RF2** La orden se prepara solo tras confirmar el pago (CU6 Realizar venta) | P01, P07, P08 | S29, S30, S32, S34, S35 | `test_negocio_pagos` (24); `test_negocio_pedidos` (1); `test_unidad_carreras` (21); `test_unidad_reglas` (2) | 48 de 48 ✓ | 48 de 48 ✓ | [S29](../ejemplos/S29.json), [S30](../ejemplos/S30.json), [S32](../ejemplos/S32.json), …; [controles C6](../evidencia/controles.md) |
| **RF3** Anular una compra indicando el motivo (CU7 Anular compra) | P07, P08 | S24, S33 | `test_analitica` (6); `test_negocio_pagos` (5); `test_negocio_pedidos` (3); `test_unidad_reglas` (2) | 16 de 16 ✓ | 16 de 16 ✓ | [S24](../ejemplos/S24.json), [S33](../ejemplos/S33.json); [S24](../ejemplos/S24.json), [S33](../ejemplos/S33.json) |
| **RF4** Vender únicamente pedidos de clientes registrados (caja del cajero virtual) (CU6 Realizar venta) | P01, P07, P08 | S21, S29, S32 | `test_analitica` (1); `test_negocio_pagos` (2); `test_negocio_pedidos` (3); `test_seguridad_acceso` (6) | 12 de 12 ✓ | 12 de 12 ✓ | [S21](../ejemplos/S21.json), [S29](../ejemplos/S29.json), [S32](../ejemplos/S32.json) |
| **RF5** Registro de clientes con todos sus datos y correo existente (CU3 Administrar clientes) | P01, P06 | S10, S11 | `test_negocio_administracion` (19); `test_unidad_reglas` (26) | 45 de 45 ✓ | 45 de 45 ✓ | [S10](../ejemplos/S10.json), [S11](../ejemplos/S11.json) |
| **RF6** Registro de clientes en el local por el administrador (CU3 Administrar clientes) | P08 | S12, S13 | `test_negocio_administracion` (5) | 5 de 5 ✓ | 5 de 5 ✓ | [S12](../ejemplos/S12.json), [S13](../ejemplos/S13.json) |
| **RF7** Administrar la disponibilidad de cada producto (CU4 Administrar productos) | P01, P02, P08 | S04, S06, S07, S08 | `test_negocio_administracion` (23); `test_unidad_reglas` (9) | 32 de 32 ✓ | 32 de 32 ✓ | [S04](../ejemplos/S04.json), [S06](../ejemplos/S06.json), [S07](../ejemplos/S07.json), … |
| **RF8** Boleta digital por cada venta, enviada por correo (CU6 Realizar venta) | P07, P08 | S31, S37 | `test_graphql` (1); `test_negocio_administracion` (1); `test_negocio_pagos` (2) | 4 de 4 ✓ | 4 de 4 ✓ | [S31](../ejemplos/S31.json), [S37](../ejemplos/S37.json); el envío real por SMTP no se probó; la boleta queda en la bandeja de salida (S37) |
| **RF9** Reporte de ventas por período para el dueño (CU8 Generar reporte de ventas) | P07, P08 | S38 | `test_analitica` (7); `test_graphql` (1); `test_unidad_reglas` (1) | 9 de 9 ✓ | 9 de 9 ✓ | [S38](../ejemplos/S38.json); [carga](../evidencia/carga.md), [GraphQL](graphql.md) |
| **RF10** Mantenedores de productos, usuarios y clientes (CU2/CU3/CU4) | P08 | S06, S07, S09, S12, S14, S15, S16, S17, S18, S19 | `test_negocio_administracion` (69) | 69 de 69 ✓ | 69 de 69 ✓ | [S06](../ejemplos/S06.json), [S07](../ejemplos/S07.json), [S09](../ejemplos/S09.json), … |
| **RF11** Validar que el correo existe mediante una API de mensajería (CU3 Administrar clientes) | P06, P08 | S10, S13 | `test_negocio_administracion` (6) | 6 de 6 ✓ | 6 de 6 ✓ | [S10](../ejemplos/S10.json), [S13](../ejemplos/S13.json); proveedor de correo de prueba (`sandbox`): el buzón «no existe» por convención de nombre o dominio; la validación por DNS MX y el envío SMTP existen en el código pero no se probaron |
| **RF12** Autenticación de usuarios y acceso según perfil (CU1 Autenticar usuarios) | P01, P02, P03, P04, P05, P06, P07, P08, P09 | S01, S02, S03, S16, S17, S18 | `test_graphql` (1); `test_limites_tasa` (4); `test_negocio_administracion` (4); `test_seguridad_acceso` (89) | 98 de 98 ✓ | 98 de 98 ✓ | [S01](../ejemplos/S01.json), [S02](../ejemplos/S02.json), [S03](../ejemplos/S03.json), …; [controles C2, C3](../evidencia/controles.md) |
| **RF13** Orden de despacho en el orden de llegada (imprimible) (CU9 Obtener orden de despacho) | P07, P08 | S23, S25, S26, S38 | `test_graphql` (1); `test_negocio_pedidos` (4); `test_unidad_reglas` (1) | 6 de 6 ✓ | 6 de 6 ✓ | [S23](../ejemplos/S23.json), [S25](../ejemplos/S25.json), [S26](../ejemplos/S26.json), …; [S25](../ejemplos/S25.json), [S26](../ejemplos/S26.json); la impresión la hace el panel del frontend de la C2 (no incluido en esta entrega); el backend entrega la orden de despacho en el orden de llegada |

Pantallas: **P01** index.html · Inicio; **P02** productos.html · Carta y carrito; **P03** servicios.html · Servicios y cotizador de eventos; **P04** empresa.html · Empresa; **P05** contacto.html · Contacto; **P06** registro.html · Registro de clientes; **P07** pedidos.html · Mis pedidos, pago y boleta; **P08** admin.html · Panel interno (ventas, productos, clientes, usuarios, despacho); **P09** Ventana «Acceder» y menú de cuenta (todas las páginas).

## Requisitos no funcionales con prueba

| Requisito | Estado | Pruebas | Resultado (simulado) | Resultado (reales) | Evidencia |
|---|---|---|---|---|---|
| **RNF2** Capas separadas: interfaz, reglas de negocio y datos | cumple | `test_despliegue` (4); `test_segunda_capa` (4) | 8 de 8 ✓ | 8 de 8 ✓ | [diagrama de componentes](../diagramas/03-componentes-y-redes.mmd), [ADR-005](../adr/ADR-005-base-de-datos-por-servicio.md) |
| **RNF5** Integración entre sistemas por servicios web | cumple | `test_segunda_capa` (61); `test_seguridad_acceso` (20) | 81 de 81 ✓ | 81 de 81 ✓ | [llamadas entre servicios](llamadas_entre_servicios.md) |
| **RNF6** API de correo para envío y validación de cuentas | cumple con proveedor de prueba (`sandbox`); MX y SMTP no probados | `test_negocio_administracion` (13) | 13 de 13 ✓ | 13 de 13 ✓ | [ADR-012](../adr/ADR-012-pila-tecnologica.md) |
| **RNF7** Cifrado de clave y control de sesiones | cumple | `test_infraestructura_real` (1); `test_limites_tasa` (2); `test_seguridad_acceso` (4); `test_sesion_vence` (2); `test_unidad_reglas` (1) | 9 de 10 ✓, 1 omitidas | 10 de 10 ✓ | [ADR-002](../adr/ADR-002-sesion-opaca-en-cookie.md), [controles](../evidencia/controles.md). El hash argon2id en MongoDB real se comprueba solo en la ejecución con servicios reales |
| **RNF8** Validaciones en todas las entradas | cumple | `test_graphql` (6); `test_negocio_administracion` (58); `test_seguridad_acceso` (20); `test_unidad_reglas` (39) | 123 de 123 ✓ | 123 de 123 ✓ | [modelos de entrada](servicios_y_contratos.md) |
| **RNF13** Mensajes de error informativos y orientados al usuario final | cumple | `test_graphql` (2); `test_negocio_pedidos` (4); `test_seguridad_acceso` (1) | 7 de 7 ✓ | 7 de 7 ✓ | [ejemplos](../ejemplos/) |

## Requisitos no funcionales con tratamiento distinto (declarado)

| Requisito | Tratamiento | Motivo |
|---|---|---|
| RNF1 Ambiente web | Parcial | La interfaz web es el frontend de la C2, que no forma parte del proyecto del backend y no está conectado a él; el backend expone la API que ese frontend consumirá y se prueba por HTTP. La integración se valida en la Evaluación 3. |
| RNF3 Oracle y .NET/J2EE | **Desviación** | Se conservan las restricciones del curso: FastAPI + MongoDB ([ADR-012](../adr/ADR-012-pila-tecnologica.md)). |
| RNF4 Procedimientos almacenados y estructura para avisos | **Desviación** | Bandeja de salida (`outbox`) con reintentos, consultable por el administrador (S37). |
| RNF9 Interfaz con elementos de Windows | No aplica | La interfaz es web con Bootstrap 5. |
| RNF10 Aprendizaje < 4 h; RNF11 errores < 1 % | **No medidos** | Requieren usuarios reales; no se afirma cumplimiento. |
| RNF12 Manuales; RNF14 Ayuda en línea | Parcial | La ayuda en línea es parte del frontend de la C2 (no incluido en esta entrega); no hay manual de usuario separado. |
| RNF15 Diseño responsivo | **No evaluable aquí** | Es una propiedad del frontend; el backend no la determina. Se valida con la integración (Evaluación 3). |
| RNF16 Interfaces bien formadas | **No verificado** | Es una propiedad del frontend (no incluido en esta entrega); no se ejecutó ningún validador de HTML. |
