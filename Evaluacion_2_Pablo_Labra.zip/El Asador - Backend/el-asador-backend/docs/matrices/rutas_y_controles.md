# Matriz de rutas y controles del API Gateway (M6)

Lo que no está en esta tabla no se reenvía (404). Los parámetros de ruta se validan con la expresión indicada ANTES de reenviar; de la consulta solo pasan los parámetros listados; del navegador solo viajan las cabeceras listadas (el resto se descarta, y las de identidad `X-Authenticated-*` las escribe el gateway, nunca el cliente).

| ID | Ruta | Acceso | Límite de tasa | Caché | Invalida | Protección CSRF | Parámetros de ruta | Consulta permitida | Cabeceras reenviadas |
|---|---|---|---|---|---|---|---|---|---|
| S01 | POST /api/auth/login | anonimo | login | — | — | Origin/Referer exacto si viene; obligatorio si hay cookie de sesión | — | — | ninguna |
| S02 | POST /api/auth/logout | anonimo | general | — | — | Origin/Referer exacto si viene; obligatorio si hay cookie de sesión | — | — | ninguna |
| S03 | GET /api/auth/me | anonimo | general | — | — | — (solo lectura) | — | — | ninguna |
| S04 | GET /api/products | anonimo | general | 10 s | — | — (solo lectura) | — | categoria, available, q, limit, offset | ninguna |
| S05 | GET /api/promos | anonimo | general | 10 s | — | — (solo lectura) | — | — | ninguna |
| S06 | POST /api/products | sesion | general | — | catalogo | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | — | — | ninguna |
| S07 | PUT /api/products/{producto} | sesion | general | — | catalogo | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | producto=`[a-z0-9]{2,12}` | — | ninguna |
| S08 | PUT /api/products/{producto}/availability | sesion | general | — | catalogo | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | producto=`[a-z0-9]{2,12}` | — | ninguna |
| S09 | DELETE /api/products/{producto} | sesion | general | — | catalogo | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | producto=`[a-z0-9]{2,12}` | — | ninguna |
| S10 | POST /api/clients/register | anonimo | registro | — | — | Origin/Referer exacto si viene; obligatorio si hay cookie de sesión | — | — | ninguna |
| S11 | GET /api/clients/me | sesion | general | — | — | — (solo lectura) | — | — | ninguna |
| S12 | GET /api/clients | sesion | general | — | — | — (solo lectura) | — | q, limit, offset | ninguna |
| S13 | POST /api/clients | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | — | — | ninguna |
| S14 | PUT /api/clients/{cliente} | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | cliente=`c-[a-z0-9]{4,12}` | — | ninguna |
| S15 | DELETE /api/clients/{cliente} | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | cliente=`c-[a-z0-9]{4,12}` | — | ninguna |
| S16 | GET /api/users | sesion | general | — | — | — (solo lectura) | — | limit, offset | ninguna |
| S17 | POST /api/users | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | — | — | ninguna |
| S18 | PUT /api/users/{usuario} | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | usuario=`u-[a-z0-9]{2,20}` | — | ninguna |
| S19 | DELETE /api/users/{usuario} | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | usuario=`u-[a-z0-9]{2,20}` | — | ninguna |
| S20 | GET /api/delivery-zones | anonimo | general | 30 s | — | — (solo lectura) | — | — | ninguna |
| S21 | POST /api/orders | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | — | — | Idempotency-Key |
| S22 | GET /api/orders | sesion | general | — | — | — (solo lectura) | — | limit, offset | ninguna |
| S23 | GET /api/orders/{pedido} | sesion | general | — | — | — (solo lectura) | pedido=`A-\d{3,9}` | — | ninguna |
| S24 | POST /api/orders/{pedido}/cancellation | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | pedido=`A-\d{3,9}` | — | ninguna |
| S25 | GET /api/admin/orders | sesion | general | — | — | — (solo lectura) | — | estado, limit, offset | ninguna |
| S26 | PUT /api/admin/orders/{pedido}/status | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | pedido=`A-\d{3,9}` | — | ninguna |
| S27 | GET /api/event-config | anonimo | general | 30 s | — | — (solo lectura) | — | — | ninguna |
| S28 | POST /api/event-quotes | anonimo | formularios | — | — | Origin/Referer exacto si viene; obligatorio si hay cookie de sesión | — | — | ninguna |
| S29 | POST /api/orders/{pedido}/payment | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | pedido=`A-\d{3,9}` | — | ninguna |
| S30 | GET /api/orders/{pedido}/payment | sesion | general | — | — | — (solo lectura) | pedido=`A-\d{3,9}` | — | ninguna |
| S31 | GET /api/orders/{pedido}/receipt | sesion | general | — | — | — (solo lectura) | pedido=`A-\d{3,9}` | — | ninguna |
| S32 | POST /api/admin/orders/{pedido}/payment-confirmation | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | pedido=`A-\d{3,9}` | — | ninguna |
| S33 | POST /api/admin/orders/{pedido}/refund | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | pedido=`A-\d{3,9}` | — | ninguna |
| S34 | GET /api/admin/payments | sesion | general | — | — | — (solo lectura) | — | estado, reembolso, modo, limit, offset | ninguna |
| S35 | POST /api/webhooks/provider | firma | webhook | — | — | no aplica (firma HMAC del proveedor) | — | — | X-Provider-Signature, X-Provider-Event-Id |
| S36 | POST /api/contact-messages | anonimo | formularios | — | — | Origin/Referer exacto si viene; obligatorio si hay cookie de sesión | — | — | ninguna |
| S37 | GET /api/admin/outbox | sesion | general | — | — | — (solo lectura) | — | limit | ninguna |
| S38 | POST /api/graphql | sesion | graphql | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | — | — | ninguna |
