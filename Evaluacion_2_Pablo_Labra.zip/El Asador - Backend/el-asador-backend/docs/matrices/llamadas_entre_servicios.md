# Llamadas entre servicios y secreto de cada par (M3 / M6)

20 pares llamador→destino. Cada par usa SU secreto (`X-Service-Name` + `X-Service-Secret`, guardado en Vault bajo el nombre indicado): el secreto de un par no sirve para otro destino ni para otro llamador. Solo `api-gateway` y `graphql-gateway` pueden afirmar una identidad de usuario.

| Llamador | Destino | Secreto en Vault (nombre) | Rutas que el llamador puede usar |
|---|---|---|---|
| api-gateway | auth | asador/svc/api-gateway-to-auth | POST /introspect; POST /login; POST /logout; GET /users; POST /users; DELETE /users/{id}; PUT /users/{id} |
| api-gateway | clients | asador/svc/api-gateway-to-clients | GET /clients; POST /clients; GET /clients/me; POST /clients/register; DELETE /clients/{id}; PUT /clients/{id} |
| api-gateway | graphql-gateway | asador/svc/api-gateway-to-graphql-gateway | POST /graphql |
| api-gateway | inventory | asador/svc/api-gateway-to-inventory | GET /products; POST /products; DELETE /products/{id}; PUT /products/{id}; PUT /products/{id}/availability; GET /promos |
| api-gateway | notifications | asador/svc/api-gateway-to-notifications | POST /contact-messages; GET /outbox |
| api-gateway | orders | asador/svc/api-gateway-to-orders | GET /admin/orders; PUT /admin/orders/{id}/status; GET /delivery-zones; GET /event-config; POST /event-quotes; GET /orders; POST /orders; GET /orders/{id}; POST /orders/{id}/cancellation |
| api-gateway | payments | asador/svc/api-gateway-to-payments | POST /admin/orders/{id}/payment-confirmation; POST /admin/orders/{id}/refund; GET /admin/payments; GET /orders/{id}/payment; POST /orders/{id}/payment; GET /orders/{id}/receipt; POST /webhooks/provider |
| clients | auth | asador/svc/clients-to-auth | POST /internal/credentials; DELETE /internal/credentials/{user_id}; PUT /internal/credentials/{user_id}/estado |
| clients | notifications | asador/svc/clients-to-notifications | POST /internal/email/send; POST /internal/email/validate |
| graphql-gateway | analytics | asador/svc/graphql-gateway-to-analytics | GET /internal/reports/sales |
| graphql-gateway | inventory | asador/svc/graphql-gateway-to-inventory | GET /internal/items; GET /internal/summary |
| graphql-gateway | orders | asador/svc/graphql-gateway-to-orders | GET /admin/orders; GET /admin/orders/summary; GET /orders; GET /orders/{id} |
| graphql-gateway | payments | asador/svc/graphql-gateway-to-payments | GET /internal/payments/by-orders; GET /internal/summary |
| orders | clients | asador/svc/orders-to-clients | GET /internal/clients/{id}/delivery-profile |
| orders | inventory | asador/svc/orders-to-inventory | GET /internal/items; POST /internal/pricing/resolve |
| orders | notifications | asador/svc/orders-to-notifications | POST /internal/email/send |
| orders | payments | asador/svc/orders-to-payments | POST /internal/orders/{id}/payment-cancel |
| payments | analytics | asador/svc/payments-to-analytics | POST /internal/events/sale-registered; POST /internal/events/sale-reversed |
| payments | notifications | asador/svc/payments-to-notifications | POST /internal/email/send |
| payments | orders | asador/svc/payments-to-orders | GET /internal/orders/{id}/payable; POST /internal/orders/{id}/payment-confirmed; POST /internal/orders/{id}/refund-done |
