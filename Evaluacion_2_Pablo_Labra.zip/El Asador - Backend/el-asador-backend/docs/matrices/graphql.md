# GraphQL Gateway: operaciones y autorización por campo (M8)

Solo lectura (el esquema no tiene `Mutation`). Se atiende por `POST /api/graphql` (S38); el navegador no puede llegar a los servicios privados. Esquema completo: [`docs/graphql/schema.graphql`](../graphql/schema.graphql).

## Operaciones y campos con permiso propio

| Tipo | Campo | Roles que pueden pedirlo |
|---|---|---|
| Query | misPedidos | cliente |
| Query | panelAdmin | cualquier sesión (el dato se acota por pertenencia) |
| Query | pedidosAdmin | administrador, despacho |
| Query | reporteVentas | administrador, dueno |
| PanelAdmin | pagos | administrador |
| PanelAdmin | pedidosPorEstado | administrador, despacho |
| PanelAdmin | productos | administrador, dueno |
| Pedido | cliente | cliente, administrador, despacho |

Los datos personales del pedido (`Pedido.cliente`) los ven el cliente dueño, el administrador y el despacho; **el dueño no**. `misPedidos` solo devuelve pedidos del cliente de la sesión: la pertenencia la aplica el servicio `orders` con la identidad, no el resolver.

## Límites de consulta

| Control | Valor | Dónde |
|---|---|---|
| Introspección | desactivada | `DisableIntrospection` |
| Profundidad máxima | 6 | `QueryDepthLimiter` |
| Alias por consulta | 10 | `MaxAliasesLimiter` |
| Tokens por documento | 1200 | `MaxTokensLimiter` |
| Costo estimado | máximo 1500 (1 + hijos × `limit`) | `LimiteDeCosto` (rechaza antes de ejecutar) |
| Errores inesperados | enmascarados (`Error interno`) | `MaskErrors` |
| Paginación | `limit` entre 1 y 50, con `offset` | `acotar()` |
| Anti N+1 | DataLoader por solicitud | `Contexto._cargar_items/_cargar_pagos` |
