# Catálogo de servicios y contratos (M1)

Generado por `scripts/generar_documentos.py` desde la tabla `RUTAS` del API Gateway y la lectura del código de cada servicio. Un servicio es una ruta pública que el navegador puede usar; el API Gateway no reenvía nada que no figure aquí.

**Entrada:** de dónde sale cada dato. **Salida:** estado HTTP de éxito y forma de la respuesta capturada en una ejecución real (`docs/ejemplos/`). **Errores:** los `ErrorNegocio` que el servicio puede lanzar (estado y código), además de los 400/401/403/422/429/5xx comunes que aplican el gateway y la validación.

| ID | Ruta pública | Servicio y ruta interna | Acceso | Entrada | Salida | Errores propios | Datos | RF | Pantallas | Ejemplo |
|---|---|---|---|---|---|---|---|---|---|---|
| S01 | POST /api/auth/login | auth /login | anónimo | cuerpo: LoginIn | 200 {usuario: {…}, expira_en} | 401 CREDENCIALES_INVALIDAS | secreto | RF12 | P09, P06 | [S01](../ejemplos/S01.json) |
| S02 | POST /api/auth/logout | auth /logout | anónimo | — | 200 {ok} |  | publico | RF12 | P09, P08 | [S02](../ejemplos/S02.json) |
| S03 | GET /api/auth/me | auth /introspect | anónimo | — | 200 {usuario: {…}, expira_en} | — | personal | RF12 | P01, P02, P03, P04, P05, P06, P07, P08 | [S03](../ejemplos/S03.json) |
| S04 | GET /api/products | inventory /products | anónimo | consulta: categoria, available, q, limit, offset | 200 [{id, categoria, nombre, precio, disponible, imagen, descripcion, incluye: [], alcohol, personas}] | 400 FILTRO_INVALIDO | publico | RF1, RF7 | P01, P02, P08 | [S04](../ejemplos/S04.json) |
| S05 | GET /api/promos | inventory /promos | anónimo | — | 200 [{id, nombre, descripcion, vigencia, descuento, imagen, componentes: [{…}], precioNormal, precio, disponible, incluye: [], alcohol}] |  | publico | RF1 | P01, P02, P08 | [S05](../ejemplos/S05.json) |
| S06 | POST /api/products | inventory /products | sesión (administrador, dueno) | cuerpo: ProductoIn | 201 {id, categoria, nombre, precio, disponible, imagen, descripcion, incluye: [], alcohol} |  | publico | RF7, RF10 | P08 | [S06](../ejemplos/S06.json) |
| S07 | PUT /api/products/{producto} | inventory /products/{producto} | sesión (administrador, dueno) | ruta: producto; cuerpo: ProductoIn | 200 {id, categoria, nombre, precio, disponible, imagen, descripcion, incluye: [], alcohol} | 404 PRODUCTO_NO_ENCONTRADO | publico | RF7, RF10 | P08 | [S07](../ejemplos/S07.json) |
| S08 | PUT /api/products/{producto}/availability | inventory /products/{producto}/availability | sesión (administrador, dueno) | ruta: producto; cuerpo: DisponibilidadIn | 200 {id, categoria, nombre, precio, disponible, imagen, descripcion, incluye: [], alcohol} | 404 PRODUCTO_NO_ENCONTRADO | publico | RF7 | P08 | [S08](../ejemplos/S08.json) |
| S09 | DELETE /api/products/{producto} | inventory /products/{producto} | sesión (administrador, dueno) | ruta: producto | 200 {id, retirado} | 404 PRODUCTO_NO_ENCONTRADO, 409 PRODUCTO_EN_PROMO | publico | RF10 | P08 | [S09](../ejemplos/S09.json) |
| S10 | POST /api/clients/register | clients /clients/register | anónimo | cuerpo: RegistroWeb | 201 {id, run, nombre, correo, telefono, region, provincia, comuna, direccion, nacimiento, sexo, origen, estado, tieneAcceso} | 409 CUENTA_NO_DISPONIBLE, 422 CLAVE_DEBIL, 422 CORREO_NO_EXISTE, 422 UBICACION_INVALIDA, 503 SERVICIO_NO_DISPONIBLE, 503 VALIDACION_CORREO_NO_DISPONIBLE | restringido | RF5, RF11 | P06 | [S10](../ejemplos/S10.json) |
| S11 | GET /api/clients/me | clients /clients/me | sesión (cliente) | — | 200 {id, run, nombre, correo, telefono, region, provincia, comuna, direccion, nacimiento, sexo, origen, estado, tieneAcceso} | 404 CLIENTE_NO_ENCONTRADO | restringido | RF5 | P01 | [S11](../ejemplos/S11.json) |
| S12 | GET /api/clients | clients /clients | sesión (administrador) | consulta: q, limit, offset | 200 [{id, run, nombre, correo, telefono, region, provincia, comuna, direccion, nacimiento, sexo, origen, estado, tieneAcceso}] |  | restringido | RF6, RF10 | P08 | [S12](../ejemplos/S12.json) |
| S13 | POST /api/clients | clients /clients | sesión (administrador) | cuerpo: ClienteLocal | 201 {id, run, nombre, correo, telefono, region, provincia, comuna, direccion, nacimiento, sexo, origen, estado, tieneAcceso} | 409 CLIENTE_EXISTE, 422 CORREO_NO_EXISTE, 422 UBICACION_INVALIDA, 503 VALIDACION_CORREO_NO_DISPONIBLE | restringido | RF6, RF11 | P08 | [S13](../ejemplos/S13.json) |
| S14 | PUT /api/clients/{cliente} | clients /clients/{cliente} | sesión (administrador) | ruta: cliente; cuerpo: ClienteReemplazo | 200 {id, run, nombre, correo, telefono, region, provincia, comuna, direccion, nacimiento, sexo, origen, estado, tieneAcceso} | 404 CLIENTE_NO_ENCONTRADO, 422 UBICACION_INVALIDA | restringido | RF10 | P08 | [S14](../ejemplos/S14.json) |
| S15 | DELETE /api/clients/{cliente} | clients /clients/{cliente} | sesión (administrador) | ruta: cliente | 200 {id, estado} | 404 CLIENTE_NO_ENCONTRADO, 503 SERVICIO_NO_DISPONIBLE | restringido | RF10 | P08 | [S15](../ejemplos/S15.json) |
| S16 | GET /api/users | auth /users | sesión (administrador) | consulta: limit, offset | 200 {total, items: [{…}]} |  | personal | RF10, RF12 | P08 | [S16](../ejemplos/S16.json) |
| S17 | POST /api/users | auth /users | sesión (administrador) | cuerpo: UsuarioNuevo | 201 {id, username, nombre, rol, roles: [], activo, creadoEn} | 409 USUARIO_EXISTE, 422 CLAVE_DEBIL | secreto | RF10, RF12 | P08 | [S17](../ejemplos/S17.json) |
| S18 | PUT /api/users/{usuario} | auth /users/{usuario} | sesión (administrador) | ruta: usuario; cuerpo: UsuarioReemplazo | 200 {id, username, nombre, rol, roles: [], activo, creadoEn} | 404 USUARIO_NO_ENCONTRADO, 409 AUTOEDICION_NO_PERMITIDA, 409 ULTIMO_ADMINISTRADOR, 422 CLAVE_DEBIL | secreto | RF10, RF12 | P08 | [S18](../ejemplos/S18.json) |
| S19 | DELETE /api/users/{usuario} | auth /users/{usuario} | sesión (administrador) | ruta: usuario | 200 {id, activo} | 404 USUARIO_NO_ENCONTRADO, 409 AUTOEDICION_NO_PERMITIDA, 409 ULTIMO_ADMINISTRADOR | personal | RF10 | P08 | [S19](../ejemplos/S19.json) |
| S20 | GET /api/delivery-zones | orders /delivery-zones | anónimo | — | 200 {reglas: {…}, comunas: [{…}]} |  | publico | RF1 | P01, P03, P08 | [S20](../ejemplos/S20.json) |
| S21 | POST /api/orders | orders /orders | sesión (cliente) | cuerpo: PedidoIn; cabeceras: Idempotency-Key | 201 {id, fecha, origen, cliente: {…}, lineas: [{…}], subtotal, despacho, total, pago, estado, reembolso, historial: [{…}]} | 400 IDEMPOTENCY_KEY_INVALIDA, 403 CUENTA_DE_CLIENTE_REQUERIDA, 403 PROHIBIDO, 409 CLIENTE_INACTIVO, 409 DEMASIADOS_PEDIDOS_PENDIENTES, 409 ITEM_NO_DISPONIBLE, 422 CANTIDAD_EXCEDIDA, 422 COMUNA_SIN_COBERTURA, 422 CONFIRMAR_MAYORIA_EDAD, 422 ITEMS_INVALIDOS, 422 ITEM_INEXISTENTE, 422 MENOR_DE_EDAD, 503 SERVICIO_NO_DISPONIBLE | restringido | RF1, RF4 | P01 | [S21](../ejemplos/S21.json) |
| S22 | GET /api/orders | orders /orders | sesión (cliente) | consulta: limit, offset | 200 [{id, fecha, origen, cliente: {…}, lineas: [{…}], subtotal, despacho, total, pago, estado, reembolso, historial: [{…}]}] | 403 PROHIBIDO | restringido | RF1 | — | [S22](../ejemplos/S22.json) |
| S23 | GET /api/orders/{pedido} | orders /orders/{pedido} | sesión (cliente, administrador, despacho) | ruta: pedido | 200 {id, fecha, origen, cliente: {…}, lineas: [{…}], subtotal, despacho, total, pago, estado, reembolso, historial: [{…}]} | 403 PROHIBIDO, 404 PEDIDO_NO_ENCONTRADO | restringido | RF1, RF13 | — | [S23](../ejemplos/S23.json) |
| S24 | POST /api/orders/{pedido}/cancellation | orders /orders/{pedido}/cancellation | sesión (cliente, administrador) | ruta: pedido; cuerpo: AnulacionIn | 200 {id, fecha, origen, cliente: {…}, lineas: [{…}], subtotal, despacho, total, pago, estado, reembolso, historial: [{…}], motivoAnulacion, anuladoPor, fechaAnulacion} | 403 PROHIBIDO, 404 PEDIDO_NO_ENCONTRADO, 409 CONFLICTO_DE_ESTADO, 409 NO_SE_PUEDE_ANULAR, 422 MOTIVO_INVALIDO | restringido | RF3 | P07, P08 | [S24](../ejemplos/S24.json) |
| S25 | GET /api/admin/orders | orders /admin/orders | sesión (administrador, despacho) | consulta: estado, limit, offset | 200 [{id, fecha, origen, cliente: {…}, lineas: [{…}], subtotal, despacho, total, pago, estado, reembolso, historial: [{…}], clienteId}] | 400 FILTRO_INVALIDO | restringido | RF13 | P08 | [S25](../ejemplos/S25.json) |
| S26 | PUT /api/admin/orders/{pedido}/status | orders /admin/orders/{pedido}/status | sesión (administrador, despacho) | ruta: pedido; cuerpo: EstadoIn | 200 {id, fecha, origen, cliente: {…}, lineas: [{…}], subtotal, despacho, total, pago, estado, reembolso, historial: [{…}], clienteId} | 404 PEDIDO_NO_ENCONTRADO, 409 CONFLICTO_DE_ESTADO, 409 TRANSICION_NO_PERMITIDA | restringido | RF13 | P08 | [S26](../ejemplos/S26.json) |
| S27 | GET /api/event-config | orders /event-config | anónimo | — | 200 {minPersonas, maxPersonas, precioParrillero, menus: [{…}], extras: {…}} | 503 SERVICIO_NO_DISPONIBLE | publico | RF1 | P03 | [S27](../ejemplos/S27.json) |
| S28 | POST /api/event-quotes | orders /event-quotes | anónimo | cuerpo: CotizacionIn | 201 {folio, estimado, detalle: [{…}], correo, personas} | 422 COMUNA_SIN_COBERTURA, 422 COTIZACION_INVALIDA, 422 FECHA_PASADA, 503 SERVICIO_NO_DISPONIBLE | personal | RF1 | P03 | [S28](../ejemplos/S28.json) |
| S29 | POST /api/orders/{pedido}/payment | payments /orders/{pedido}/payment | sesión (cliente) | ruta: pedido | 201 {id, pedidoId, estado, medio, modo, monto, creadoEn, aprobadoEn, checkoutUrl, reembolso} | 403 PROHIBIDO, 404 PEDIDO_NO_ENCONTRADO, 409 PAGO_EN_PROCESO, 409 PEDIDO_NO_PAGABLE, 503 PROVEEDOR_PAGO_NO_DISPONIBLE, 503 SERVICIO_NO_DISPONIBLE | restringido | RF2, RF4 | P01, P07 | [S29](../ejemplos/S29.json) |
| S30 | GET /api/orders/{pedido}/payment | payments /orders/{pedido}/payment | sesión (cliente, administrador) | ruta: pedido | 200 {id, pedidoId, estado, medio, modo, monto, creadoEn, aprobadoEn, checkoutUrl, reembolso} | 403 PROHIBIDO, 404 PEDIDO_NO_ENCONTRADO, 404 SIN_PAGO, 503 SERVICIO_NO_DISPONIBLE | restringido | RF2 | P07 | [S30](../ejemplos/S30.json) |
| S31 | GET /api/orders/{pedido}/receipt | payments /orders/{pedido}/receipt | sesión (cliente, administrador) | ruta: pedido | 200 {folio, fecha, pedidoId, estado, emisor: {…}, cliente: {…}, lineas: [{…}], subtotal, despacho, neto, iva, ivaTasa, total, medioPago} | 403 PROHIBIDO, 404 PEDIDO_NO_ENCONTRADO, 404 SIN_BOLETA, 503 SERVICIO_NO_DISPONIBLE | restringido | RF8 | P07 | [S31](../ejemplos/S31.json) |
| S32 | POST /api/admin/orders/{pedido}/payment-confirmation | payments /admin/orders/{pedido}/payment-confirmation | sesión (administrador) | ruta: pedido; cuerpo: ConfirmacionManual | 200 {resultado, pago: {…}} | 403 PROHIBIDO, 404 PEDIDO_NO_ENCONTRADO, 409 MEDIO_NO_MANUAL, 409 PEDIDO_NO_PAGABLE, 503 SERVICIO_NO_DISPONIBLE | restringido | RF2, RF4 | P08 | [S32](../ejemplos/S32.json) |
| S33 | POST /api/admin/orders/{pedido}/refund | payments /admin/orders/{pedido}/refund | sesión (administrador) | ruta: pedido; cuerpo: ReembolsoIn | 200 {id, pedidoId, estado, medio, modo, monto, creadoEn, aprobadoEn, reembolso: {…}} | 404 SIN_REEMBOLSO, 422 REFERENCIA_REQUERIDA, 502 PROVEEDOR_RECHAZO, 503 PROVEEDOR_PAGO_NO_DISPONIBLE | restringido | RF3 | P08 | [S33](../ejemplos/S33.json) |
| S34 | GET /api/admin/payments | payments /admin/payments | sesión (administrador) | consulta: estado, reembolso, modo, limit, offset | 200 [{id, pedidoId, estado, medio, modo, monto, creadoEn, aprobadoEn, reembolso}] |  | restringido | RF2 | P08 | [S34](../ejemplos/S34.json) |
| S35 | POST /api/webhooks/provider | payments /webhooks/provider | firma del proveedor | cuerpo: bytes tal cual (firma del proveedor); cabeceras: X-Provider-Signature, X-Provider-Event-Id | 200 {ok, resultado} | 400 AVISO_NO_VALIDO, 409 MONTO_NO_COINCIDE, 409 PAGO_NO_COINCIDE, 413 CUERPO_DEMASIADO_GRANDE, 503 SECRETOS_NO_DISPONIBLES | restringido | RF2 | — | [S35](../ejemplos/S35.json) |
| S36 | POST /api/contact-messages | notifications /contact-messages | anónimo | cuerpo: ContactoIn | 201 {id} | 422 CORREO_INVALIDO, 422 DESTINATARIO_INVALIDO | personal | — | P05 | [S36](../ejemplos/S36.json) |
| S37 | GET /api/admin/outbox | notifications /outbox | sesión (administrador) | consulta: limit | 200 [{id, tipo, para, asunto, estado, intentos, creadoEn}] |  | restringido | RF8 | P08 | [S37](../ejemplos/S37.json) |
| S38 | POST /api/graphql | graphql-gateway /graphql | sesión | cuerpo: JSON | 200 {data: {…}} | 400 SOLICITUD_INVALIDA, 413 CUERPO_DEMASIADO_GRANDE, 415 CONTENT_TYPE_INVALIDO, 504 CONSULTA_FUERA_DE_TIEMPO | restringido | RF1, RF9, RF13 | P07, P08 | [S38](../ejemplos/S38.json) |

## Modelos de entrada

Cada cuerpo JSON se valida con un modelo pydantic con `extra="forbid"`: un campo no declarado se rechaza (422), no se ignora.

### AnulacionIn

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| motivo | `Literal['Me equivoqué al armar el pedido', 'Ya no lo necesito', 'Se demora mucho el despacho', 'Encontré otra opción', 'Otro motivo']` | — | sí |
| detalle | `str` | largo 0–200 | no |

### ClienteLocal

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| nombre | `str` | largo 3–120 | sí |
| telefono | `str` | — | sí |
| direccion | `str` | largo 5–120 | sí |
| comuna | `str` | largo 3–40 | sí |
| run | `str` | — | sí |
| correo | `str` | largo 5–254 | sí |
| nacimiento | `str \| None` | — | no |
| sexo | `Literal['Femenino', 'Masculino', 'Otro', 'Prefiero no decirlo'] \| None` | — | no |
| region | `str \| None` | — | no |
| provincia | `str \| None` | — | no |

### ClienteReemplazo

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| nombre | `str` | largo 3–120 | sí |
| telefono | `str` | — | sí |
| direccion | `str` | largo 5–120 | sí |
| comuna | `str` | largo 3–40 | sí |
| nacimiento | `str \| None` | — | no |
| sexo | `Literal['Femenino', 'Masculino', 'Otro', 'Prefiero no decirlo'] \| None` | — | no |
| region | `str \| None` | — | no |
| provincia | `str \| None` | — | no |

### ConfirmacionManual

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| referencia | `str` | formato '^[A-Za-z0-9 ._/#-]{3,60}$' | sí |

### ContactoIn

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| nombre | `str` | largo 3–80 | sí |
| correo | `str` | largo 5–254 | sí |
| asunto | `Literal['Consulta sobre un pedido', 'Reclamo', 'Sugerencia', 'Evento o pedido especial', 'Otro']` | — | sí |
| mensaje | `str` | largo 10–2000 | sí |

### CotizacionIn

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| nombre | `str` | largo 3–80 | sí |
| correo | `str` | largo 5–254 | sí |
| fecha | `str` | formato '^\\d{4}-\\d{2}-\\d{2}$' | sí |
| personas | `int` | ≥ 1, ≤ 100000 | sí |
| menu | `Literal['clasico', 'parrillero', 'premium']` | — | sí |
| bebidas | `bool` | — | no |
| ensaladas | `bool` | — | no |
| parrillero | `bool` | — | no |
| comuna | `str \| None` | largo 0–40 | no |

### DisponibilidadIn

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| disponible | `bool` | — | sí |

### EstadoIn

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| estado | `Literal['En camino', 'Entregado']` | — | sí |

### LoginIn

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| username | `str` | largo 3–120 | sí |
| password | `str` | largo 1–128 | sí |

### PedidoIn

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| items | `list[ItemIn]` | largo 1–30 | sí |
| comuna | `str` | largo 3–40 | sí |
| indicaciones | `str` | largo 0–200 | no |
| medioPago | `Literal['Servipag', 'Transferencia bancaria', 'Depósito bancario']` | — | no |
| confirmaMayorEdad | `bool` | — | no |

### ProductoIn

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| nombre | `str` | largo 3–60 | sí |
| categoria | `Literal['parrilladas', 'parrilla', 'acompanamientos', 'bebidas']` | — | sí |
| precio | `int` | ≥ 500, ≤ 200000 | sí |
| descripcion | `str` | largo 10–160 | sí |
| imagen | `str` | — | sí |
| personas | `int \| None` | ≥ 1, ≤ 20 | no |
| incluye | `list[str]` | largo 0–12 | no |
| disponible | `bool` | — | no |
| alcohol | `bool` | — | no |

### ReembolsoIn

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| referencia | `str \| None` | formato '^[A-Za-z0-9 ._/#-]{3,60}$' | no |

### RegistroWeb

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| nombre | `str` | largo 3–120 | sí |
| telefono | `str` | — | sí |
| direccion | `str` | largo 5–120 | sí |
| comuna | `str` | largo 3–40 | sí |
| run | `str` | — | sí |
| correo | `str` | largo 5–254 | sí |
| nacimiento | `str` | — | sí |
| sexo | `Literal['Femenino', 'Masculino', 'Otro', 'Prefiero no decirlo']` | — | sí |
| region | `str` | — | sí |
| provincia | `str` | — | sí |
| clave | `str` | largo 8–128 | sí |

### UsuarioNuevo

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| username | `str` | — | sí |
| nombre | `str` | largo 2–80 | sí |
| rol | `Literal['administrador', 'dueno', 'despacho']` | — | sí |
| password | `str` | — | sí |

### UsuarioReemplazo

| Campo | Tipo | Reglas | Obligatorio |
|---|---|---|---|
| nombre | `str` | largo 2–80 | sí |
| rol | `Literal['administrador', 'dueno', 'despacho']` | — | sí |
| activo | `bool` | — | sí |
| password | `str \| None` | — | no |

## Pantallas

| ID | Pantalla |
|---|---|
| P01 | index.html · Inicio |
| P02 | productos.html · Carta y carrito |
| P03 | servicios.html · Servicios y cotizador de eventos |
| P04 | empresa.html · Empresa |
| P05 | contacto.html · Contacto |
| P06 | registro.html · Registro de clientes |
| P07 | pedidos.html · Mis pedidos, pago y boleta |
| P08 | admin.html · Panel interno (ventas, productos, clientes, usuarios, despacho) |
| P09 | Ventana «Acceder» y menú de cuenta (todas las páginas) |
