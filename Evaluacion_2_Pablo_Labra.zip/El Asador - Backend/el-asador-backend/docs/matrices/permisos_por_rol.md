# Matriz de permisos por ruta, verbo y condición (M4)

Generado desde `RUTAS` (rol exigido por el API Gateway). El servicio privado vuelve a comprobar el rol y la pertenencia: dos capas independientes (ver `tests/contratos/rutas_servicios.json`). «no (401)» = sin sesión; con sesión pero sin rol responde 403.

| ID | Verbo | Ruta | Anónimo | Cliente | Despacho | Administrador | Dueño | Condición que aplica el servicio |
|---|---|---|---|---|---|---|---|---|
| S01 | POST | /api/auth/login | sí | sí | sí | sí | sí | Bloqueo temporal tras varios intentos fallidos; misma respuesta y mismo trabajo (hash falso) si el usuario no existe |
| S02 | POST | /api/auth/logout | sí | sí | sí | sí | sí | — |
| S03 | GET | /api/auth/me | sí | sí | sí | sí | sí | Devuelve solo la identidad de la sesión (o null); nunca el token |
| S04 | GET | /api/products | sí | sí | sí | sí | sí | — |
| S05 | GET | /api/promos | sí | sí | sí | sí | sí | — |
| S06 | POST | /api/products | no (401) | no | no | sí | sí | Catálogo: administrador y dueño |
| S07 | PUT | /api/products/{producto} | no (401) | no | no | sí | sí | — |
| S08 | PUT | /api/products/{producto}/availability | no (401) | no | no | sí | sí | — |
| S09 | DELETE | /api/products/{producto} | no (401) | no | no | sí | sí | No se elimina un producto que forma parte de una promoción (409 PRODUCTO_EN_PROMO) |
| S10 | POST | /api/clients/register | sí | sí | sí | sí | sí | Crea cuenta de cliente (rol fijo «cliente», nunca elegido por el navegador); se comprueba que el correo exista; respuesta genérica si la cuenta ya existe |
| S11 | GET | /api/clients/me | no (401) | sí | no | no | no | No recibe identificador: devuelve el perfil del cliente de la SESIÓN |
| S12 | GET | /api/clients | no (401) | no | no | sí | no | — |
| S13 | POST | /api/clients | no (401) | no | no | sí | no | — |
| S14 | PUT | /api/clients/{cliente} | no (401) | no | no | sí | no | — |
| S15 | DELETE | /api/clients/{cliente} | no (401) | no | no | sí | no | — |
| S16 | GET | /api/users | no (401) | no | no | sí | no | Solo administrador |
| S17 | POST | /api/users | no (401) | no | no | sí | no | — |
| S18 | PUT | /api/users/{usuario} | no (401) | no | no | sí | no | El administrador no puede editarse a sí mismo ni dejar al sistema sin administradores (409) |
| S19 | DELETE | /api/users/{usuario} | no (401) | no | no | sí | no | El administrador no puede eliminarse a sí mismo ni al último administrador (409) |
| S20 | GET | /api/delivery-zones | sí | sí | sí | sí | sí | — |
| S21 | POST | /api/orders | no (401) | sí | no | no | no | Cuenta de cliente activa ligada a la sesión; máx. pedidos con pago pendiente; precios, despacho y total los calcula el servidor |
| S22 | GET | /api/orders | no (401) | sí | no | no | no | Solo los pedidos del cliente de la sesión |
| S23 | GET | /api/orders/{pedido} | no (401) | sí | sí | sí | no | Cliente: solo si el pedido es SUYO (ajeno e inexistente dan el mismo 403); administrador y despacho: cualquiera |
| S24 | POST | /api/orders/{pedido}/cancellation | no (401) | sí | no | sí | no | Cliente: solo su pedido; solo en «Pago pendiente» o «En preparación»; en «En preparación» queda reembolso pendiente |
| S25 | GET | /api/admin/orders | no (401) | no | sí | sí | no | — |
| S26 | PUT | /api/admin/orders/{pedido}/status | no (401) | no | sí | sí | no | Transiciones por rol: En preparación → En camino → Entregado (despacho y administrador); nunca se salta un estado |
| S27 | GET | /api/event-config | sí | sí | sí | sí | sí | — |
| S28 | POST | /api/event-quotes | sí | sí | sí | sí | sí | — |
| S29 | POST | /api/orders/{pedido}/payment | no (401) | sí | no | no | no | Cliente: solo su pedido en «Pago pendiente»; el monto lo entrega orders, no el navegador; un solo cobro iniciado por pedido |
| S30 | GET | /api/orders/{pedido}/payment | no (401) | sí | no | sí | no | Cliente: solo su pedido; administrador: cualquiera |
| S31 | GET | /api/orders/{pedido}/receipt | no (401) | sí | no | sí | no | Cliente: solo su pedido; administrador: cualquiera; 404 mientras la boleta no se emite |
| S32 | POST | /api/admin/orders/{pedido}/payment-confirmation | no (401) | no | no | sí | no | Solo transferencia o depósito (medios manuales) y pedido en «Pago pendiente»; exige referencia |
| S33 | POST | /api/admin/orders/{pedido}/refund | no (401) | no | no | sí | no | Solo pagos con reembolso pendiente; exige referencia del reembolso |
| S34 | GET | /api/admin/payments | no (401) | no | no | sí | no | — |
| S35 | POST | /api/webhooks/provider | firma | — | — | — | — | Firma HMAC del proveedor + ventana de tiempo + mismo monto y moneda que el cobro; evento repetido es idempotente |
| S36 | POST | /api/contact-messages | sí | sí | sí | sí | sí | — |
| S37 | GET | /api/admin/outbox | no (401) | no | no | sí | no | — |
| S38 | POST | /api/graphql | no (401) | sí | sí | sí | sí | Autorización campo por campo (ver graphql.md); además profundidad, alias, tamaño y costo acotados |

El dueño del negocio ve el catálogo y los reportes de ventas, pero **no** datos personales de clientes ni de entrega.
