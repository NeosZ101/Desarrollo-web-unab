# Evidencia de ejecución: casos de validación del módulo 7 y agregación del módulo 8

Generado por `scripts/verificar_controles.py` el 2026-11-05 03:33. 75 de 75 verificaciones cumplieron lo esperado (9 s).

**Entorno:** Linux-6.18.44-fc-v236-x86_64-with-glibc2.39; Python 3.13.18; Vault y MongoDB reales.

Cada fila es una solicitud HTTP real contra el sistema levantado como procesos (gateway, auth, clients, inventory, orders, payments, notifications, analytics y GraphQL Gateway). La columna «prueba» indica la prueba automática que protege la misma regla en la suite (`tests/`).

## C1 Catálogo anónimo

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | GET /api/products?limit=5 | anónimo (sin cookie) | 200; solo campos públicos del producto | 200; campos: alcohol, categoria, descripcion, disponible, id, imagen, incluye, nombre, personas, precio; sin Set-Cookie | api-gateway (ruta pública S04) + inventory | `test_seguridad_acceso::test_la_matriz_de_permisos_del_informe_coincide_con_el_gateway` | ✓ |
| 2 | GET /api/promos | anónimo | 200 | 200 | api-gateway (ruta pública S05) | `test_negocio_pedidos::test_zonas_de_despacho_publicas_coinciden_con_el_cobro` | ✓ |
| 3 | GET /api/delivery-zones | anónimo | 200 | 200 | api-gateway (ruta pública S20) | `test_negocio_pedidos::test_zonas_de_despacho_publicas_coinciden_con_el_cobro` | ✓ |
| 4 | GET /api/orders (control: lo privado sigue privado) | anónimo | 401 NO_AUTENTICADO | 401 NO_AUTENTICADO | api-gateway | `test_seguridad_acceso::test_sin_sesion_toda_ruta_protegida_responde_401` | ✓ |

## C2 Operación protegida sin sesión válida

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | POST /api/orders (sin cookie) | anónimo | 401 NO_AUTENTICADO | 401 NO_AUTENTICADO | api-gateway (tabla de rutas: exige sesión) | `test_seguridad_acceso::test_sin_sesion_toda_ruta_protegida_responde_401` | ✓ |
| 2 | POST /api/orders (cookie inventada) | token que no existe | 401 SESION_NO_VALIDA | 401 SESION_NO_VALIDA | auth (introspección en cada solicitud) | `test_seguridad_acceso::test_cookie_basura_se_trata_como_sin_sesion` | ✓ |
| 3 | GET /api/clients/me (token de una sesión ya cerrada) | cliente (antes del logout: 200) | 401 SESION_NO_VALIDA | 401 SESION_NO_VALIDA | auth (el logout revoca la sesión en el servidor) | `test_seguridad_acceso::test_cerrar_sesion_la_revoca_en_el_servidor` | ✓ |
| 4 | POST /api/graphql | anónimo | 401 NO_AUTENTICADO | 401 NO_AUTENTICADO | api-gateway (antes de llegar al GraphQL Gateway) | `test_graphql::test_graphql_exige_sesion` | ✓ |
| 5 | GET /api/clients/me con «Authorization: Bearer …» | anónimo | 401 (el sistema solo reconoce su cookie de sesión) | 401 NO_AUTENTICADO | api-gateway | `test_seguridad_acceso::test_cabeceras_de_identidad_enviadas_por_el_navegador_se_ignoran` | ✓ |

## C3 Administración desde un rol sin permiso

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | POST /api/products | sesión de cliente | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 2 | GET /api/users | sesión de cliente | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 3 | GET /api/clients | sesión de cliente | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 4 | PUT /api/admin/orders/A-1042/status | sesión de cliente | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 5 | POST /api/products | sesión de despacho | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 6 | GET /api/admin/payments | sesión de despacho | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 7 | POST /api/admin/orders/A-1042/refund | sesión de despacho | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 8 | POST /api/users | sesión de dueno | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 9 | GET /api/clients | sesión de dueno | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 10 | GET /api/admin/orders | sesión de dueno | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 11 | GET /api/admin/outbox | sesión de administrador | 200 (control: rol autorizado) | 200 | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 12 | efecto: no se creó ningún producto con los intentos del cliente y del despacho | — | el nombre del producto de prueba no existe en el catálogo | no existe en el catálogo | inventory | `test_seguridad_acceso::test_el_gateway_corta_el_rol_equivocado_antes_de_molestar_al_servicio` | ✓ |
| 13 | POST inventory /products con la identidad «cliente» afirmada por el propio gateway (segunda capa) | cliente (saltándose la comprobación del gateway) | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | inventory (el servicio vuelve a comprobar el rol) | `test_segunda_capa::test_el_servicio_vuelve_a_comprobar_el_rol_sin_fiarse_del_gateway` | ✓ |

## C4 Consulta de un pedido ajeno

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | GET /api/orders/A-1042 (pedido de otro cliente) | cliente B | 403 PROHIBIDO, mismo cuerpo que un pedido inexistente y sin datos de A | 403 PROHIBIDO; idéntico al de A-999999 (inexistente): True; datos de A en el cuerpo: 0 | orders (pertenencia: el cliente de la sesión debe ser el dueño del pedido) | `test_seguridad_acceso::test_un_cliente_no_ve_el_pedido_de_otro_y_la_respuesta_no_revela_si_existe` | ✓ |
| 2 | POST /api/orders/{pedido}/cancellation (anular) | cliente B | 403 PROHIBIDO | 403 PROHIBIDO | orders / payments (pertenencia) | `test_seguridad_acceso::test_un_cliente_no_opera_sobre_pedidos_ajenos` | ✓ |
| 3 | POST /api/orders/{pedido}/payment (iniciar el pago) | cliente B | 403 PROHIBIDO | 403 PROHIBIDO | orders / payments (pertenencia) | `test_seguridad_acceso::test_un_cliente_no_opera_sobre_pedidos_ajenos` | ✓ |
| 4 | GET /api/orders/{pedido}/payment (ver el pago) | cliente B | 403 PROHIBIDO | 403 PROHIBIDO | orders / payments (pertenencia) | `test_seguridad_acceso::test_un_cliente_no_opera_sobre_pedidos_ajenos` | ✓ |
| 5 | GET /api/orders/{pedido}/receipt (ver la boleta) | cliente B | 403 PROHIBIDO | 403 PROHIBIDO | orders / payments (pertenencia) | `test_seguridad_acceso::test_un_cliente_no_opera_sobre_pedidos_ajenos` | ✓ |
| 6 | GraphQL misPedidos | cliente B | 200 sin el pedido de A (la lista es solo la suya) | 200; 0 pedidos propios; el de A no aparece | graphql-gateway + orders (la identidad viaja al servicio) | `test_graphql::test_cada_cliente_ve_solo_sus_pedidos_en_graphql` | ✓ |
| 7 | GraphQL pedidosAdmin (pedidos de todos) | cliente B | PROHIBIDO y sin datos | 200 PROHIBIDO | graphql-gateway (permiso por campo) | `test_graphql::test_matriz_de_permisos_de_campos_graphql` | ✓ |
| 8 | GET /api/orders/A-1042 (control: el dueño sí) | cliente A (dueño) | 200 y estado «Pago pendiente» | 200; estado «Pago pendiente»; sin cambios tras los intentos de B | orders | `test_seguridad_acceso::test_el_pedido_ajeno_sigue_intacto_tras_los_intentos` | ✓ |
| 9 | GET /api/orders/A-1042 (control: el personal sí) | administrador | 200 | 200 | orders | `test_seguridad_acceso::test_el_personal_si_ve_cualquier_pedido_y_los_datos_de_despacho` | ✓ |

## C5 Acceso directo al backend sin identidad autorizada

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | GET auth/users sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | auth (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 2 | GET clients/clients sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | clients (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 3 | GET inventory/internal/summary sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | inventory (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 4 | GET orders/orders sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | orders (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 5 | GET payments/admin/payments sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | payments (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 6 | GET notifications/outbox sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | notifications (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 7 | GET analytics/internal/reports/sales sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | analytics (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 8 | POST graphql-gateway/graphql sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | graphql-gateway (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 9 | GET auth/users con un secreto inventado | se declara «api-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | auth (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 10 | GET clients/clients con un secreto inventado | se declara «api-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | clients (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 11 | GET inventory/internal/summary con un secreto inventado | se declara «graphql-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | inventory (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 12 | GET orders/orders con un secreto inventado | se declara «api-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | orders (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 13 | GET payments/admin/payments con un secreto inventado | se declara «api-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | payments (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 14 | GET notifications/outbox con un secreto inventado | se declara «api-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | notifications (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 15 | GET analytics/internal/reports/sales con un secreto inventado | se declara «graphql-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | analytics (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 16 | POST graphql-gateway/graphql con un secreto inventado | se declara «api-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | graphql-gateway (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 17 | GET inventory/products con el secreto del par «api-gateway→orders» | se declara «api-gateway» | 403 SECRETO_INVALIDO (cada par tiene su secreto) | 403 SECRETO_INVALIDO | inventory | `test_seguridad_acceso::test_el_secreto_de_un_par_no_sirve_para_otro_destino` | ✓ |
| 18 | GET orders/orders afirmando la identidad de un cliente, con secreto válido de «payments» | «payments» con identidad de cliente | 403 (solo gateways pueden afirmar identidad) | 403 LLAMADOR_NO_PERMITIDO | orders | `test_seguridad_acceso::test_solo_los_llamadores_de_confianza_pueden_afirmar_una_identidad` | ✓ |
| 19 | POST orders/…/cancellation desde el GraphQL Gateway (con su secreto) | «graphql-gateway» | 403 LLAMADOR_NO_PERMITIDO (solo lectura) | 403 LLAMADOR_NO_PERMITIDO | orders | `test_seguridad_acceso::test_el_graphql_gateway_es_de_solo_lectura_aunque_tenga_su_secreto` | ✓ |
| 20 | GET /api/admin/orders con cabeceras X-Authenticated-* y X-Service-* falsas | navegador anónimo | 401 (el gateway las descarta; la identidad sale de la sesión) | 401 NO_AUTENTICADO | api-gateway (lista blanca de cabeceras) | `test_seguridad_acceso::test_cabeceras_de_identidad_enviadas_por_el_navegador_se_ignoran` | ✓ |
| 21 | docker-compose.yml: servicios con puertos publicados | análisis estático del archivo (no se ejecutó docker compose) | solo api-gateway y provider-sandbox, y solo hacia 127.0.0.1; red «interna» sin salida a Internet | api-gateway: 127.0.0.1:8000:8000; provider-sandbox: 127.0.0.1:8300:8300; interna: internal=true | Docker Compose (redes) | `test_despliegue::test_solo_el_gateway_y_el_proveedor_simulado_publican_puertos_y_solo_hacia_localhost` | ✓ |

## C6 Confirmar un pago con datos alterados del frontend

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | POST /api/orders con «precio»: 1 y «total»: 1 dentro del cuerpo | cliente | 422 (campos no declarados se rechazan) | 422 VALIDACION | orders (modelo con extra=forbid; el precio sale del inventario) | `test_negocio_pedidos::test_un_precio_enviado_dentro_de_una_linea_se_rechaza` | ✓ |
| 2 | POST /api/orders (pedido legítimo): ¿quién fija el total? | cliente | el total lo calcula el servidor con los precios del inventario | total 15980 = 2 × 7990 + despacho 0; estado «Pago pendiente» | orders + inventory | `test_negocio_pedidos::test_el_servidor_calcula_el_total_y_el_navegador_no_puede_fijarlo` | ✓ |
| 3 | PUT /api/orders/{pedido} | cliente | 4xx (no es su operación o la ruta no existe en el gateway) | 404 RUTA_NO_ENCONTRADA | api-gateway / payments | `test_negocio_pagos::test_un_cliente_no_puede_marcar_su_pedido_como_pagado` | ✓ |
| 4 | PUT /api/admin/orders/{pedido}/status | cliente | 4xx (no es su operación o la ruta no existe en el gateway) | 403 ROL_NO_AUTORIZADO | api-gateway / payments | `test_negocio_pagos::test_un_cliente_no_puede_marcar_su_pedido_como_pagado` | ✓ |
| 5 | POST /api/admin/orders/{pedido}/payment-confirmation | cliente | 4xx (no es su operación o la ruta no existe en el gateway) | 403 ROL_NO_AUTORIZADO | api-gateway / payments | `test_negocio_pagos::test_un_cliente_no_puede_marcar_su_pedido_como_pagado` | ✓ |
| 6 | POST /api/orders/{pedido}/payment-confirmed | cliente | 4xx (no es su operación o la ruta no existe en el gateway) | 404 RUTA_NO_ENCONTRADA | api-gateway / payments | `test_negocio_pagos::test_un_cliente_no_puede_marcar_su_pedido_como_pagado` | ✓ |
| 7 | POST /api/webhooks/provider sin firma | anónimo | 400 AVISO_NO_VALIDO | 400 AVISO_NO_VALIDO | payments (firma HMAC del proveedor) | `test_negocio_pagos::test_aviso_sin_firma_o_con_firma_falsa_se_rechaza` | ✓ |
| 8 | POST /api/webhooks/provider firmado con una clave inventada | atacante | 400 AVISO_NO_VALIDO | 400 AVISO_NO_VALIDO | payments | `test_negocio_pagos::test_aviso_sin_firma_o_con_firma_falsa_se_rechaza` | ✓ |
| 9 | POST /api/webhooks/provider con el cuerpo alterado después de firmar | atacante | 400 AVISO_NO_VALIDO | 400 AVISO_NO_VALIDO | payments | `test_negocio_pagos::test_aviso_alterado_despues_de_firmar_se_rechaza` | ✓ |
| 10 | POST /api/webhooks/provider con firma válida pero de hace 1 hora (repetición) | atacante | 400 AVISO_NO_VALIDO (ventana de 300 s) | 400 AVISO_NO_VALIDO | payments | `test_negocio_pagos::test_aviso_antiguo_o_del_futuro_se_rechaza` | ✓ |
| 11 | POST /api/webhooks/provider firmado correctamente pero con monto 1 | quien conozca la clave de firma | 409 MONTO_NO_COINCIDE | 409 MONTO_NO_COINCIDE | payments (compara con el monto fijado por orders) | `test_negocio_pagos::test_aviso_con_monto_distinto_no_aprueba_el_pago` | ✓ |
| 12 | GET /api/orders/{pedido}?pago=aprobado (como al volver del proveedor) | cliente | el estado sigue «Pago pendiente» | 200 | orders (el estado solo cambia por payment-confirmed) | `test_negocio_pagos::test_volver_del_proveedor_con_pago_aprobado_en_la_url_no_paga_nada` | ✓ |
| 13 | estado final tras todos los intentos | — | «Pago pendiente» y cobro «iniciado» | pedido «Pago pendiente»; cobro «iniciado» | orders + payments | `test_negocio_pagos::test_un_cliente_no_puede_marcar_su_pedido_como_pagado` | ✓ |
| 14 | POST /api/webhooks/provider legítimo (control) | proveedor | 200 y el pedido pasa a «En preparación» | 200; pedido «En preparación» | payments → orders | `test_negocio_pagos::test_aviso_firmado_legitimo_aprueba_una_sola_vez_aunque_se_repita` | ✓ |

## M8 Agregación GraphQL ejecutada desde la pantalla

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | POST /api/graphql con la consulta EXACTA de pedidos.js (pedido + pago + boleta + líneas) | cliente con 4 pedidos, 1 pagado | 200 con datos de orders y payments (pedido + pago + boleta); cada servicio recibe UNA llamada para los 4 pedidos | 200; 4 pedidos; pedido pagado: pago «aprobado», boleta B-000002; llamadas por servicio: api-gateway=1, graphql-gateway=1, orders=1, payments=1, inventory=0 | graphql-gateway (DataLoader por solicitud) | `test_graphql::test_una_consulta_pide_cada_servicio_una_sola_vez_sin_problema_n_mas_1` | ✓ |
| 2 | POST /api/graphql con la consulta del panel de admin.js (pedidos por estado + productos + pagos) | administrador | 200 con datos de TRES servicios: orders, inventory y payments | 200; llamadas por servicio: api-gateway=1, graphql-gateway=1, orders=1, payments=1, inventory=1 | graphql-gateway (agrega tres servicios sin acceder a sus bases) | `test_graphql::test_el_panel_del_pie_pide_cada_dato_a_su_servicio` | ✓ |
| 3 | GraphQL pedidosAdmin { cliente { correo telefono direccion } } | dueño | PROHIBIDO; ningún dato personal en la respuesta | 200 PROHIBIDO | graphql-gateway (permiso por campo) | `test_graphql::test_el_dueno_no_alcanza_ningun_pedido_ni_dato_personal_por_graphql` | ✓ |
| 4 | GraphQL panelAdmin { pagos { iniciados } } | cliente | panelAdmin nulo y PROHIBIDO | 200 PROHIBIDO | graphql-gateway | `test_graphql::test_el_panel_para_un_cliente_es_nulo_y_prohibido` | ✓ |
| 5 | GraphQL misPedidos(clienteId: …) (pedir los de otro cliente por argumento) | cliente | CONSULTA_INVALIDA (el argumento no existe) | 200 CONSULTA_INVALIDA | graphql-gateway (esquema) | `test_graphql::test_no_existe_ningun_argumento_para_pedir_pedidos_de_otro_cliente` | ✓ |
| 6 | GraphQL introspección { __schema … } | cliente | CONSULTA_INVALIDA sin publicar el esquema | 200 CONSULTA_INVALIDA,CONSULTA_INVALIDA | graphql-gateway (DisableIntrospection) | `test_graphql::test_la_introspeccion_esta_desactivada` | ✓ |
| 7 | GraphQL con anidamiento de más de 6 niveles | cliente | rechazada antes de ejecutarse (profundidad máxima 6) | 200 CONSULTA_INVALIDA,CONSULTA_INVALIDA | graphql-gateway (QueryDepthLimiter) | `test_graphql::test_profundidad_maxima` | ✓ |
| 8 | GraphQL con 11 alias de la misma consulta | cliente | rechazada (máximo 10 alias) | 200 CONSULTA_INVALIDA | graphql-gateway (MaxAliasesLimiter) | `test_graphql::test_maximo_de_alias` | ✓ |
| 9 | POST graphql-gateway/graphql directo, sin credencial de servicio | ninguna | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | graphql-gateway (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |

## Detalle de la agregación (consulta de `pedidos.js`)

Consulta enviada por la pantalla «Mis pedidos»:

```graphql
query MisPedidos($desde: Int!) { misPedidos(limit: 20, offset: $desde) { total items { id fecha estado subtotal despacho total medioPago reembolso motivoAnulacion anuladoPor fechaAnulacion cliente { nombre direccion comuna } lineas { nombre cantidad precio subtotal } pago { id estado medio monto checkoutUrl instrucciones reembolso } boleta { folio total estado } } } }
```

Servicios que atendieron esa solicitud (por identificador de correlación) y rutas internas que recibieron:

```json
{
 "api-gateway": [
  "/api/graphql"
 ],
 "graphql-gateway": [
  "/graphql"
 ],
 "orders": [
  "/orders"
 ],
 "payments": [
  "/internal/payments/by-orders"
 ],
 "inventory": []
}
```

Parte de la respuesta (el pedido pagado):

```json
{
 "misPedidos": {
  "total": 4,
  "items": [
   {
    "id": "A-1047",
    "fecha": "2026-11-05T06:33:54.316Z",
    "estado": "En preparación",
    "subtotal": 7990,
    "despacho": 0,
    "total": 7990,
    "medioPago": "Servipag",
    "reembolso": "no_aplica",
    "motivoAnulacion": null,
    "anuladoPor": null,
    "fechaAnulacion": null,
    "cliente": {
     "nombre": "Cliente De Prueba",
     "direccion": "Calle Falsa 123",
     "comuna": "Ñuñoa"
    },
    "lineas": [
     {
      "nombre": "Choripán x4",
      "cantidad": 1,
      "precio": 7990,
      "subtotal": 7990
     }
    ],
    "pago": {
     "id": "pay-9eeae65d326944d0",
     "estado": "aprobado",
     "medio": "Servipag",
     "monto": 7990,
     "checkoutUrl": null,
     "instrucciones": null,
     "reembolso": null
    },
    "boleta": {
     "folio": "B-000002",
     "total": 7990,
     "estado": "vigente"
    }
   }
  ]
 }
}
```

## Detalle de la agregación de tres servicios (panel de `admin.js`)

```graphql
query Panel { panelAdmin { pedidosPorEstado { estado cantidad } productos { activos agotados } pagos { pagosManualesPorConfirmar reembolsosPendientes } } }
```

Rutas internas que recibió cada servicio por esa solicitud:

```json
{
 "api-gateway": [
  "/api/graphql"
 ],
 "graphql-gateway": [
  "/graphql"
 ],
 "orders": [
  "/admin/orders/summary"
 ],
 "payments": [
  "/internal/summary"
 ],
 "inventory": [
  "/internal/summary"
 ]
}
```

Respuesta:

```json
{
 "pedidosPorEstado": [
  {
   "estado": "Pago pendiente",
   "cantidad": 5
  },
  {
   "estado": "En preparación",
   "cantidad": 3
  },
  {
   "estado": "En camino",
   "cantidad": 1
  },
  {
   "estado": "Entregado",
   "cantidad": 1
  },
  {
   "estado": "Anulado",
   "cantidad": 0
  }
 ],
 "productos": {
  "activos": 13,
  "agotados": []
 },
 "pagos": {
  "pagosManualesPorConfirmar": 0,
  "reembolsosPendientes": 0
 }
}
```
