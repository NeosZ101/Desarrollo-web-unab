# Diagnostico de SOLO LECTURA: quien responde en 127.0.0.1:27017 en este equipo. No cambia nada.
#   powershell -ExecutionPolicy Bypass -File .\diagnostico_puerto_27017.ps1
$aqui = Split-Path -Parent $MyInvocation.MyCommand.Path
$repo = Join-Path $aqui "el-asador-backend"
$carpeta = Join-Path (Join-Path $aqui "resultados-docker") "capturas"
New-Item -ItemType Directory -Force -Path $carpeta | Out-Null
$f = Join-Path $carpeta "10c-diagnostico-puerto-27017.txt"
$l = @()
$l += ("Diagnostico del puerto 27017 en este equipo - " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
$l += ""
$l += "1) Conexiones que escuchan en el puerto 27017 (netstat -ano):"
$ids = @()
foreach ($x in (netstat -ano | Select-String ":27017\s")) {
    $l += ("   " + $x.Line.Trim())
    $ids += ($x.Line.Trim() -split "\s+")[-1]
}
if ($ids.Count -eq 0) { $l += "   (nadie escucha ahora)" }
$l += ""
$l += "2) Proceso dueno de cada conexion (tasklist):"
foreach ($id in ($ids | Sort-Object -Unique)) {
    $l += ("   PID " + $id + ": " + ((tasklist /FI ("PID eq " + $id) /FO CSV /NH) -join " "))
}
$l += ""
$l += "3) Contenedores de Docker que mencionan 27017 (docker ps -a):"
$ps = @(& docker ps -a --format "{{.Names}} | {{.Image}} | {{.Status}} | {{.Ports}}" 2>&1 | ForEach-Object { "$_" } | Where-Object { $_ -match "27017" })
if ($ps.Count -eq 0) { $l += "   (ninguno)" } else { foreach ($x in $ps) { $l += ("   " + $x) } }
$l += ""
$l += "4) Puertos PUBLICADOS por el proyecto asador (docker compose ps):"
Set-Location $repo
$cp = @(& docker compose ps --format "{{.Name}} | {{.Publishers}}" 2>&1 | ForEach-Object { "$_" })
foreach ($x in $cp) { $l += ("   " + $x) }
$l += ""
$l += "5) Servicios de Windows relacionados con MongoDB:"
$sv = @(Get-Service | Where-Object { $_.Name -like "*mongo*" -or $_.DisplayName -like "*mongo*" })
if ($sv.Count -eq 0) { $l += "   (ninguno)" } else { foreach ($s in $sv) { $l += ("   " + $s.Name + " | " + $s.Status + " | " + $s.DisplayName) } }
$l | Set-Content -LiteralPath $f -Encoding UTF8
$l | Out-Host
Write-Host ""
Write-Host "Listo. Guardado en resultados-docker\capturas\10c-diagnostico-puerto-27017.txt." -ForegroundColor Green
