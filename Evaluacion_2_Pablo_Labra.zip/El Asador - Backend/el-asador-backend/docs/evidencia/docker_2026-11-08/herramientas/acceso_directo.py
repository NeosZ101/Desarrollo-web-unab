"""C5: llamadas directas a los servicios privados DESDE DENTRO de la red de Docker, sin identidad o con un secreto inventado.

Se ejecuta dentro del contenedor del gateway (stdlib solamente):
  docker compose exec -T api-gateway python - < acceso_directo.py
Cada servicio privado debe rechazar al llamador: 403 LLAMADOR_NO_PERMITIDO (sin credencial) o 403 SECRETO_INVALIDO (secreto inventado).
"""
import json
import os
import urllib.error
import urllib.request

PLANTILLA = os.environ.get("ASADOR_PLANTILLA", "http://{servicio}:8000{ruta}")
OBJETIVOS = [("auth", "GET", "/users"), ("clients", "GET", "/clients"), ("inventory", "GET", "/internal/summary"), ("orders", "GET", "/orders"),
             ("payments", "GET", "/admin/payments"), ("notifications", "GET", "/outbox"),
             ("analytics", "GET", "/internal/reports/sales?desde=2026-01-01&hasta=2026-01-02"), ("graphql-gateway", "POST", "/graphql")]


def llamar(servicio, metodo, ruta, cabeceras):
    url = PLANTILLA.format(servicio=servicio, ruta=ruta)
    datos = b"{}" if metodo == "POST" else None
    if datos:
        cabeceras = dict(cabeceras, **{"Content-Type": "application/json"})
    peticion = urllib.request.Request(url, data=datos, method=metodo, headers=cabeceras)
    try:
        with urllib.request.urlopen(peticion, timeout=10) as r:
            return url, r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return url, e.code, e.read().decode("utf-8", "replace")
    except OSError as e:
        return url, 0, str(e)


def codigo(cuerpo):
    try:
        return json.loads(cuerpo).get("codigo")
    except ValueError:
        return None


def main():
    correctos = total = 0
    for titulo, cabeceras, esperado in (
            ("1) SIN credencial de servicio (ni X-Service-Name ni X-Service-Secret)", {}, "LLAMADOR_NO_PERMITIDO"),
            ("2) Declarando ser api-gateway, con un secreto inventado", {"X-Service-Name": "api-gateway", "X-Service-Secret": "secreto-inventado"}, "SECRETO_INVALIDO")):
        print(titulo + f"  ->  se espera 403 {esperado}")
        for servicio, metodo, ruta in OBJETIVOS:
            llamador = dict(cabeceras)
            if llamador and servicio in ("inventory", "analytics"):
                llamador["X-Service-Name"] = "graphql-gateway"
            url, estado, cuerpo = llamar(servicio, metodo, ruta, llamador)
            ok = estado == 403 and codigo(cuerpo) == esperado
            correctos, total = correctos + ok, total + 1
            print(f"  {'CUMPLE' if ok else 'FALLA '}  {metodo:<4} {url.split('?')[0]:<52} -> {estado} {codigo(cuerpo)}")
        print()
    print("Cuerpo completo de la primera respuesta (sin credencial):")
    print("  " + llamar("auth", "GET", "/users", {})[2])
    print(f"\n{correctos} de {total} llamadas fueron rechazadas como se esperaba")
    raise SystemExit(0 if correctos == total else 1)


main()
