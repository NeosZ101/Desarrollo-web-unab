#!/usr/bin/env python3
"""Captura intercambios HTTP REALES contra El Asador ya levantado y los guarda como texto (una captura = un archivo).

  python capturas_http.py --base http://localhost:8000 --repo el-asador-backend --salida resultados-docker\\capturas

Recorre los casos C1, C2, C3, C4 y C6 del informe y los flujos principales (inicio de sesión, pedido, pago, GraphQL) como lo haría el
navegador, y escribe la petición y la respuesta tal como viajaron. No se inventa nada: cada comprobación compara lo esperado con lo
que el sistema contestó. Se oculta lo secreto (valor de la cookie de sesión, claves) y las listas largas se recortan a 2 elementos.
Inicia sesión 2 veces (límite por omisión del sistema: 5 por minuto). Termina con código 0 solo si TODO coincide con lo esperado.
"""
import argparse
import datetime
import json
import random
import re
import socket
import sys
import time
import uuid
from pathlib import Path

import httpx

REGION = "Región Metropolitana de Santiago"
CAB_PETICION = ("host", "origin", "content-type", "idempotency-key", "cookie", "x-provider-signature", "x-provider-event-id")
CAB_RESPUESTA = ("content-type", "cache-control", "location", "set-cookie", "x-request-id", "x-total-count", "retry-after")
SECRETOS = {"password", "clave"}
TOPE = 2
resultados = []          # (captura, comprobación, cumplida)


def ahora():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def digito_verificador(n):
    suma, multiplicador = 0, 2
    for c in reversed(str(n)):
        suma += int(c) * multiplicador
        multiplicador = 2 if multiplicador == 7 else multiplicador + 1
    resto = 11 - suma % 11
    return "0" if resto == 11 else "K" if resto == 10 else str(resto)


def limpiar(valor):
    if isinstance(valor, dict):
        return {k: ("«secreto»" if k in SECRETOS and isinstance(v, str) else limpiar(v)) for k, v in valor.items()}
    if isinstance(valor, list):
        return [limpiar(v) for v in valor[:TOPE]] + ([f"… ({len(valor) - TOPE} más)"] if len(valor) > TOPE else [])
    return valor


def cuerpo_legible(contenido):
    if not contenido:
        return []
    try:
        return json.dumps(limpiar(json.loads(contenido)), ensure_ascii=False, indent=2).splitlines()
    except ValueError:
        return [contenido.decode("utf-8", "replace")[:300]]


def ocultar(valor):
    return re.sub(r"(session_token=)[^;\s]+", r"\1«valor secreto»", valor)


def intercambio(r):
    """Petición y respuesta como viajaron (solo las cabeceras que importan; el valor de la cookie va oculto)."""
    q = r.request
    t = [f"> {q.method} {q.url.raw_path.decode()} HTTP/1.1"]
    t += [f"> {k}: {ocultar(q.headers[k])}" for k in CAB_PETICION if k in q.headers]
    cuerpo = cuerpo_legible(q.content)
    if cuerpo:
        t += ["> "] + ["> " + x for x in cuerpo]
    t += ["", f"< {r.http_version} {r.status_code} {r.reason_phrase}"]
    for k in CAB_RESPUESTA:
        t += [f"< {k}: {ocultar(v)}" for v in r.headers.get_list(k)]
    cuerpo = cuerpo_legible(r.content)
    if cuerpo:
        t += ["< "] + ["< " + x for x in cuerpo]
    return "\n".join(t)


def sin_id(r):
    """El cuerpo de un error sin el identificador de correlación (que es distinto en cada respuesta)."""
    return {k: v for k, v in r.json().items() if k != "request_id"}


def codigo(r):
    try:
        return r.json().get("codigo")
    except (ValueError, AttributeError):
        return None


class Navegador:
    def __init__(self, base):
        self.c = httpx.Client(base_url=base.rstrip("/"), timeout=20, headers={"Origin": base.rstrip("/")})

    def __getattr__(self, nombre):
        return getattr(self.c, nombre)


class Capturas:
    def __init__(self, carpeta, base):
        self.carpeta, self.base = Path(carpeta), base
        self.carpeta.mkdir(parents=True, exist_ok=True)

    def guardar(self, numero, titulo, bloques, comprobaciones, extra=()):
        """bloques: [(subtítulo, respuesta httpx)]; comprobaciones: [(texto, cumplida)]; extra: líneas literales adicionales."""
        t = [f"Captura {numero} · {titulo}",
             f"Capturada el {ahora()} contra {self.base}. Las listas largas se recortan a {TOPE} elementos; lo demás es literal.",
             "=" * 100]
        for i, (sub, r) in enumerate(bloques, 1):
            t += ["", f"[{i}] {sub}", intercambio(r) if isinstance(r, httpx.Response) else str(r)]
        t += list(extra)
        t += ["", "=" * 100, "Comprobaciones:"]
        for texto, ok in comprobaciones:
            t.append(f"  {'CUMPLE ' if ok else 'FALLA  '} {texto}")
            resultados.append((f"{numero} {titulo}", texto, bool(ok)))
            print(f"  {'OK    ' if ok else 'FALLÓ '} [{numero}] {texto}", flush=True)
        nombre = f"{numero}-" + re.sub(r"[^a-z0-9]+", "-", titulo.lower().replace("é", "e").replace("í", "i").replace("ó", "o")
                                       .replace("á", "a").replace("ú", "u").replace("ñ", "n")).strip("-")[:60] + ".txt"
        (self.carpeta / nombre).write_text("\n".join(t) + "\n", encoding="utf-8")


def esperar(condicion, segundos=40):
    limite = time.time() + segundos
    while time.time() < limite:
        try:
            if condicion():
                return True
        except httpx.HTTPError:
            pass
        time.sleep(0.5)
    return False


def puerto_abierto(puerto):
    try:
        with socket.create_connection(("127.0.0.1", puerto), timeout=2):
            return True
    except OSError:
        return False


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    aqui = Path(__file__).resolve().parent
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://localhost:8000", help="dirección del API Gateway")
    ap.add_argument("--proveedor", default=None, help="dirección del proveedor de pagos simulado (por defecto, la que entrega el sistema)")
    ap.add_argument("--repo", default=str(aqui / "el-asador-backend"), help="carpeta del proyecto (se lee datos-frontend/consultas-graphql.json)")
    ap.add_argument("--salida", default=str(aqui / "resultados-docker" / "capturas"))
    a = ap.parse_args()
    base = a.base.rstrip("/")
    consulta = json.loads((Path(a.repo) / "datos-frontend" / "consultas-graphql.json").read_text(encoding="utf-8"))["CONSULTA_PEDIDOS"]
    cap = Capturas(a.salida, base)

    # ---------------- 01 · C1: catálogo anónimo ----------------
    anon = Navegador(base)
    r = anon.get("/api/products", params={"limit": 5})
    campos = sorted(r.json()[0]) if r.status_code == 200 and r.json() else []
    cap.guardar("01", "C1 Catálogo anónimo", [("GET del catálogo sin cookie de sesión", r)], [
        ("responde 200 con productos", r.status_code == 200 and len(r.json()) >= 1),
        ("no entrega cookie a un anónimo", not r.headers.get_list("set-cookie")),
        ("solo campos públicos (sin costos, ni existencias internas)", bool(campos) and not {"costo", "stock", "proveedor"} & set(campos))],
        extra=[f"Campos de cada producto: {', '.join(campos)}"])

    # ---------------- 02 · inicio de sesión ----------------
    cliente = Navegador(base)
    r = cliente.post("/api/auth/login", json={"username": "andrea.molina@correo.cl", "password": "cliente123"})
    cookie = r.headers.get("set-cookie", "").lower()
    cap.guardar("02", "Inicio de sesión del cliente", [("POST login (la clave se oculta en este texto)", r)], [
        ("responde 200", r.status_code == 200),
        ("la sesión viaja en una cookie HttpOnly", "httponly" in cookie and "session_token=" in cookie),
        ("la cookie es SameSite", "samesite" in cookie),
        ("el token de sesión NO va en el cuerpo de la respuesta", "session_token" not in r.text and "token" not in r.text.lower())])

    # ---------------- 03 · pedido ----------------
    llave = uuid.uuid4().hex
    cuerpo = {"items": [{"id": "p07", "cantidad": 2}], "comuna": "Ñuñoa", "medioPago": "Servipag"}
    r1 = cliente.post("/api/orders", json=cuerpo, headers={"Idempotency-Key": llave})
    r2 = cliente.post("/api/orders", json=cuerpo, headers={"Idempotency-Key": llave})
    ok3 = r1.status_code == 201
    pedido = r1.json() if ok3 else {}
    cap.guardar("03", "Pedido creado con sesión de cliente", [("POST pedido (el cliente no manda precios ni total)", r1),
                                                              ("La misma petición otra vez, con la misma Idempotency-Key", r2)], [
        ("crea el pedido: 201", ok3),
        ("el total lo calcula el servidor y es mayor que cero", ok3 and pedido.get("total", 0) > 0 and "precio" not in cuerpo["items"][0]),
        ("el estado inicial es «Pago pendiente»", ok3 and pedido.get("estado") == "Pago pendiente"),
        ("repetir la petición con la misma clave devuelve el MISMO pedido", r2.status_code in (200, 201) and r2.json().get("id") == pedido.get("id"))])
    if not ok3:
        return terminar()

    # ---------------- 04 · pago con el proveedor simulado ----------------
    rp = cliente.post(f"/api/orders/{pedido['id']}/payment")
    pago = rp.json() if rp.status_code in (200, 201) else {}
    bloques = [("Iniciar el pago del pedido", rp)]
    comp = [("el pago se inicia (200 o 201) y entrega la página del proveedor", rp.status_code in (200, 201) and "checkoutUrl" in pago)]
    if "checkoutUrl" in pago:
        checkout = pago["checkoutUrl"].rstrip("/")
        if a.proveedor:
            checkout = a.proveedor.rstrip("/") + "/" + checkout.split("/", 3)[3]
        rpay = httpx.post(checkout + "/pay", follow_redirects=False, timeout=15)
        listo = esperar(lambda: cliente.get(f"/api/orders/{pedido['id']}").json()["estado"] == "En preparación")
        rfin = cliente.get(f"/api/orders/{pedido['id']}")
        bloques += [("El cliente paga en la página del proveedor simulado (el proveedor avisa al sistema con un aviso firmado)", rpay),
                    ("El pedido después del aviso", rfin)]
        comp += [("el proveedor acepta el pago (303)", rpay.status_code == 303),
                 ("el aviso firmado deja el pedido «En preparación»", listo and rfin.json().get("estado") == "En preparación")]
    cap.guardar("04", "Pago con el proveedor simulado", bloques, comp)

    # ---------------- 05 · GraphQL «Mis pedidos» (consulta del frontend) ----------------
    r = cliente.post("/api/graphql", json={"query": consulta, "variables": {"desde": 0}})
    datos = (r.json().get("data") or {}).get("misPedidos") or {}
    fila = next((p for p in datos.get("items", []) if p["id"] == pedido["id"]), None)
    extra = [f"\nLa lista completa trae {len(datos.get('items', []))} pedido(s) de un total de {datos.get('total')}; lo mostrado arriba es el recorte."]
    if fila:
        extra.append(f"El pedido recién creado ({fila['id']}) figura con pago «{(fila.get('pago') or {}).get('estado')}» y {len(fila.get('lineas', []))} línea(s).")
    cap.guardar("05", "GraphQL Mis pedidos", [("POST /api/graphql con la consulta CONSULTA_PEDIDOS de datos-frontend/consultas-graphql.json", r)], [
        ("responde 200 y sin errores", r.status_code == 200 and "errors" not in r.json()),
        ("trae el pedido con su pago y sus líneas en UNA consulta", fila is not None and fila.get("pago") is not None and len(fila.get("lineas", [])) >= 1)],
        extra=extra)

    # ---------------- 06 · C2: operación protegida sin sesión válida ----------------
    sin_cookie = anon.post("/api/orders", json=cuerpo, headers={"Idempotency-Key": uuid.uuid4().hex})
    inventada = Navegador(base)
    inventada.cookies.set("session_token", "token-que-no-existe-" + uuid.uuid4().hex)
    con_basura = inventada.post("/api/orders", json=cuerpo, headers={"Idempotency-Key": uuid.uuid4().hex})
    cap.guardar("06", "C2 Operación protegida sin sesión válida", [("POST /api/orders sin cookie", sin_cookie),
                                                                    ("POST /api/orders con una cookie inventada", con_basura)], [
        ("sin cookie: 401 NO_AUTENTICADO", sin_cookie.status_code == 401 and codigo(sin_cookie) == "NO_AUTENTICADO"),
        ("cookie inventada: 401 SESION_NO_VALIDA", con_basura.status_code == 401 and codigo(con_basura) == "SESION_NO_VALIDA")])

    # ---------------- 07 · C3: administración desde un rol sin permiso ----------------
    producto = {"nombre": f"Producto no autorizado {uuid.uuid4().hex[:6]}", "categoria": "bebidas", "precio": 1000, "descripcion": "x", "imagen": "img/cerveza.svg"}
    crear = cliente.post("/api/products", json=producto)
    usuarios = cliente.get("/api/users")
    cap.guardar("07", "C3 Administración desde un rol sin permiso", [("POST /api/products con sesión de cliente", crear),
                                                                       ("GET /api/users con sesión de cliente", usuarios)], [
        ("crear un producto siendo cliente: 403 ROL_NO_AUTORIZADO", crear.status_code == 403 and codigo(crear) == "ROL_NO_AUTORIZADO"),
        ("listar usuarios siendo cliente: 403 ROL_NO_AUTORIZADO", usuarios.status_code == 403 and codigo(usuarios) == "ROL_NO_AUTORIZADO")])

    # ---------------- 08 · C4: pedido ajeno ----------------
    n = random.randint(30_000_000, 99_999_999)
    correo, clave = f"captura{n}@correo.cl", "clave-de-captura-123"
    otro = Navegador(base)
    otro.post("/api/clients/register", json={
        "run": f"{n}-{digito_verificador(n)}", "nombre": "Cliente B De Captura", "telefono": "+56 9 1234 5678", "direccion": "Calle Falsa 456",
        "comuna": "Ñuñoa", "correo": correo, "nacimiento": "1991-01-01", "sexo": "Otro", "region": REGION, "provincia": "Santiago", "clave": clave})
    otro.post("/api/auth/login", json={"username": correo, "password": clave})
    ajeno = otro.get(f"/api/orders/{pedido['id']}")
    inexistente = otro.get("/api/orders/A-999999")
    pagar_ajeno = otro.post(f"/api/orders/{pedido['id']}/payment")
    propio = cliente.get(f"/api/orders/{pedido['id']}")
    cap.guardar("08", "C4 Consulta de un pedido ajeno", [("El cliente B pide el pedido del cliente A", ajeno),
                                                          ("El cliente B pide un pedido que no existe", inexistente),
                                                          ("El cliente B intenta iniciar el pago del pedido de A", pagar_ajeno),
                                                          ("Control: el cliente A (dueño) pide su pedido", propio)], [
        ("pedido ajeno: 403 PROHIBIDO", ajeno.status_code == 403 and codigo(ajeno) == "PROHIBIDO"),
        ("la respuesta es IDÉNTICA a la de un pedido inexistente (no revela si existe)", inexistente.status_code == ajeno.status_code and sin_id(ajeno) == sin_id(inexistente)),
        ("el cliente B no puede iniciar el pago de un pedido ajeno (403 o 404)", pagar_ajeno.status_code in (403, 404)),
        ("el dueño sí lo ve: 200", propio.status_code == 200 and propio.json().get("id") == pedido["id"])])

    # ---------------- 09 · C6: confirmar un pago con datos alterados ----------------
    ahora_s = int(time.time())
    evento = "evt_" + uuid.uuid4().hex[:16]
    falso = {"id": evento, "type": "payment.succeeded", "created": ahora_s,
             "data": {"payment_id": "pay_falso", "reference": pago.get("id", "pago-desconocido"), "amount": 1, "currency": "CLP"}}
    confirmar = cliente.post(f"/api/admin/orders/{pedido['id']}/payment-confirmation", json={})
    sin_firma = httpx.post(base + "/api/webhooks/provider", json=falso, headers={"X-Provider-Event-Id": evento}, timeout=15)
    firma_falsa = httpx.post(base + "/api/webhooks/provider", json=falso, timeout=15, headers={
        "X-Provider-Event-Id": evento, "X-Provider-Signature": f"t={ahora_s},v1={uuid.uuid4().hex}{uuid.uuid4().hex}"})
    cap.guardar("09", "C6 Confirmar un pago con datos alterados", [("Un cliente intenta confirmar el pago él mismo", confirmar),
                                                                    ("Aviso del proveedor SIN firma (monto 1)", sin_firma),
                                                                    ("Aviso con una firma inventada (monto 1)", firma_falsa)], [
        ("un cliente no puede confirmar pagos: 403 ROL_NO_AUTORIZADO", confirmar.status_code == 403 and codigo(confirmar) == "ROL_NO_AUTORIZADO"),
        ("aviso sin firma: 400 AVISO_NO_VALIDO", sin_firma.status_code == 400 and codigo(sin_firma) == "AVISO_NO_VALIDO"),
        ("aviso con firma inventada: 400 AVISO_NO_VALIDO", firma_falsa.status_code == 400 and codigo(firma_falsa) == "AVISO_NO_VALIDO")])

    # ---------------- 10a · C5: qué puertos se alcanzan desde el equipo ----------------
    puertos = [(8000, "API Gateway", True), (8300, "proveedor de pagos simulado", True), (8200, "Vault", False), (27017, "MongoDB", False)]
    estados = [(p, nombre, esperado, puerto_abierto(p)) for p, nombre, esperado in puertos]
    t = [f"Captura 10a · C5 Puertos alcanzables desde el equipo (127.0.0.1)",
         f"Capturada el {ahora()}. Se intenta abrir una conexión TCP a cada puerto (espera máxima: 2 s).", "=" * 100, ""]
    comp = []
    for p, nombre, esperado, abierto in estados:
        t.append(f"  127.0.0.1:{p:<6} {nombre:<30} {'ABIERTO' if abierto else 'RECHAZADO'}   (se esperaba {'abierto: se publica a propósito' if esperado else 'rechazado: no se publica'})")
        comp.append((f"puerto {p} ({nombre}): {'abierto' if esperado else 'rechazado'}", abierto == esperado))
    t += ["", "=" * 100, "Comprobaciones:"]
    for texto, ok in comp:
        t.append(f"  {'CUMPLE ' if ok else 'FALLA  '} {texto}")
        resultados.append(("10a C5 Puertos", texto, ok))
        print(f"  {'OK    ' if ok else 'FALLÓ '} [10a] {texto}", flush=True)
    (cap.carpeta / "10a-c5-puertos-desde-el-equipo.txt").write_text("\n".join(t) + "\n", encoding="utf-8")
    return terminar()


def terminar():
    fallos = [(c, t) for c, t, ok in resultados if not ok]
    print(f"\n{len(resultados) - len(fallos)} de {len(resultados)} comprobaciones cumplidas")
    for c, t in fallos:
        print(f"  FALLA: [{c}] {t}")
    return 0 if not fallos else 1


if __name__ == "__main__":
    sys.exit(main())
