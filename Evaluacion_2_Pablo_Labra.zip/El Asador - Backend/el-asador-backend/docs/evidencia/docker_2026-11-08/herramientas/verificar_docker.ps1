# verificar_docker.ps1 -- Verificacion de la entrega con Docker (Evaluacion 2, "El Asador").
#
# Uso (desde la carpeta que contiene este archivo, con Docker Desktop abierto):
#   powershell -ExecutionPolicy Bypass -File .\verificar_docker.ps1
#
# Que hace, en orden:
#   1. Prepara .env (python scripts\bootstrap.py: secretos al azar, solo en este equipo; no se imprimen ni se copian).
#   2. Baja el proyecto "asador" y BORRA sus datos de demostracion (docker compose down -v): sin esto, los puertos 8000 y 8300
#      siguen ocupados por la corrida anterior y la base de datos conserva las claves viejas.
#   3. Construye y levanta todo (docker compose up -d --build). La primera vez puede tardar varios minutos.
#   4. Cuando esta listo (/ready), guarda el estado de los contenedores y corre scripts\smoke_test.py (se espera 29 de 29).
#   5. Espera 65 s (limite de inicios de sesion) y corre capturas_http.py y acceso_directo.py.
# Con -SoloPruebas se saltan los pasos 1 a 4 (para cuando el sistema ya esta levantado):
#   powershell -ExecutionPolicy Bypass -File .\verificar_docker.ps1 -SoloPruebas
# Todo queda en la carpeta resultados-docker\ (texto plano). Los resultados no llevan secretos: la cookie y las claves se ocultan.

param([switch]$SoloPruebas)   # -SoloPruebas: el sistema YA esta levantado; salta los pasos 1 a 4 y corre solo las pruebas y las capturas

$ErrorActionPreference = "Continue"
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

$aqui = Split-Path -Parent $MyInvocation.MyCommand.Path
$repo = Join-Path $aqui "el-asador-backend"
$out  = Join-Path $aqui "resultados-docker"
$caps = Join-Path $out "capturas"
if (-not (Test-Path (Join-Path $repo "docker-compose.yml"))) {
    Write-Host "No encuentro la carpeta el-asador-backend junto a este archivo." -ForegroundColor Red
    exit 1
}
New-Item -ItemType Directory -Force -Path $caps | Out-Null
Set-Location $repo

function Paso([string]$texto) {
    Write-Host ""
    Write-Host ("=== " + $texto + "  (" + (Get-Date -Format "HH:mm:ss") + ") ===") -ForegroundColor Cyan
}

# Ejecuta un programa, deja TODA su salida (normal y de error) en un archivo UTF-8, muestra las ultimas lineas y devuelve el codigo de salida.
function Correr {
    param([string]$Exe, [string[]]$Argumentos, [string]$Archivo, [int]$Ultimas = 25, [string]$Entrada = "")
    $o = $Archivo + ".out.tmp"
    $e = $Archivo + ".err.tmp"
    $parametros = @{ FilePath = $Exe; ArgumentList = $Argumentos; NoNewWindow = $true; PassThru = $true; RedirectStandardOutput = $o; RedirectStandardError = $e }
    if ($Entrada) { $parametros["RedirectStandardInput"] = $Entrada }
    $p = Start-Process @parametros
    $null = $p.Handle      # sin esto, en Windows PowerShell 5.1 ExitCode puede quedar vacio
    $p.WaitForExit()
    $lineas = @()
    if (Test-Path -LiteralPath $o) { $lineas += Get-Content -LiteralPath $o -Encoding UTF8 }
    if (Test-Path -LiteralPath $e) { $lineas += Get-Content -LiteralPath $e -Encoding UTF8 }
    if ($lineas.Count -eq 0) { $lineas = @("(el programa no escribio nada)") }
    $lineas | Set-Content -LiteralPath $Archivo -Encoding UTF8
    Remove-Item -LiteralPath $o, $e -ErrorAction SilentlyContinue
    $lineas | Select-Object -Last $Ultimas | Out-Host
    if ($null -eq $p.ExitCode) { return -1 }
    return [int]$p.ExitCode
}

# ---------------------------------------------------------------- 0. entorno
Paso "0. Entorno"
$info = @()
$info += ("Fecha: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
$info += ("Equipo: " + $env:COMPUTERNAME)
$info += ("Sistema: " + [Environment]::OSVersion.VersionString)
$info += (& docker --version 2>&1 | ForEach-Object { "$_" })
$info += (& docker compose version 2>&1 | ForEach-Object { "$_" })
$info += (& python --version 2>&1 | ForEach-Object { "$_" })
if (-not $SoloPruebas) { $info | Set-Content -LiteralPath (Join-Path $out "00-entorno.txt") -Encoding UTF8 }
$info | Out-Host
& docker info *> $null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Docker no responde. Abre Docker Desktop, espera a que diga 'Engine running' y vuelve a ejecutar este script." -ForegroundColor Red
    exit 1
}
& python -c "import httpx" *> $null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Falta la libreria httpx de Python: se instala (pip install httpx)."
    & python -m pip install --quiet httpx
}

if (-not $SoloPruebas) {
    # ---------------------------------------------------------------- 1. .env
    Paso "1. Secretos de esta maquina (.env)"
    $null = Correr "python" @("scripts\bootstrap.py") (Join-Path $out "01-bootstrap.txt") 8

    # ---------------------------------------------------------------- 2. bajar lo anterior
    Paso "2. Bajar la corrida anterior y borrar sus datos de demostracion"
    $null = Correr "docker" @("compose", "down", "-v", "--remove-orphans") (Join-Path $out "02-down.txt") 15

    # ---------------------------------------------------------------- 3. construir y levantar
    Paso "3. Construir y levantar (la primera vez tarda varios minutos; no cierres la ventana)"
    $codUp = Correr "docker" @("compose", "up", "-d", "--build") (Join-Path $out "03-up.txt") 40
    if ($codUp -gt 0) {
        Write-Host ""
        Write-Host ("docker compose up termino con codigo " + $codUp + ". Se guardan los ultimos registros y se detiene aqui.") -ForegroundColor Red
        $null = Correr "docker" @("compose", "ps", "-a") (Join-Path $out "03b-ps-tras-el-error.txt") 20
        $null = Correr "docker" @("compose", "logs", "--no-color", "--tail", "40") (Join-Path $out "03c-logs-tras-el-error.txt") 10
        Write-Host "Revisa los archivos de la carpeta resultados-docker." -ForegroundColor Yellow
        exit 2
    }

}

Paso "5. Esperar a que el sistema este listo (/ready)"
$listo = $false
for ($i = 0; $i -lt 90; $i++) {
    try {
        $r = Invoke-WebRequest -UseBasicParsing -Uri "http://localhost:8000/ready" -TimeoutSec 3
        if ($r.StatusCode -eq 200) { $listo = $true; break }
    } catch { }
    Start-Sleep -Seconds 2
}
if ($listo) { Write-Host "Listo: /ready responde 200." } else { Write-Host "ATENCION: /ready no respondio 200 en 3 minutos; se sigue igual para registrar lo que pase." -ForegroundColor Yellow }

Paso "5b. Estado de los contenedores con el sistema ya listo"
$null = Correr "docker" @("compose", "ps") (Join-Path $out "04-ps.txt") 20

# ---------------------------------------------------------------- 4. prueba de humo
Paso "6. Prueba de humo (python scripts\smoke_test.py)"
$codSmoke = Correr "python" @("scripts\smoke_test.py") (Join-Path $out "05-smoke-test.txt") 45

# ---------------------------------------------------------------- 5. capturas
Paso "7. Esperando 65 s (el sistema limita los inicios de sesion a 5 por minuto)"
Start-Sleep -Seconds 65

Paso "8. Capturas HTTP (casos C1-C4 y C6, pedido, pago y GraphQL)"
$codCap = Correr "python" @(('"' + $aqui + '\capturas_http.py"'), "--base", "http://localhost:8000", "--repo", ('"' + $repo + '"'), "--salida", ('"' + $caps + '"')) (Join-Path $out "06-capturas-consola.txt") 45

Paso "9. Caso C5: llamadas directas a los servicios privados, desde dentro de la red de Docker"
$codAcc = Correr "docker" @("compose", "exec", "-T", "api-gateway", "python", "-") (Join-Path $caps "10b-c5-servicios-privados.txt") 40 (Join-Path $aqui "acceso_directo.py")

# ---------------------------------------------------------------- resumen
Paso "Resumen"
Write-Host ("prueba de humo (se espera 0):      codigo " + $codSmoke)
Write-Host ("capturas HTTP (se espera 0):       codigo " + $codCap)
Write-Host ("servicios privados C5 (se espera 0): codigo " + $codAcc)
Write-Host ""
Write-Host "Archivos generados en resultados-docker:"
Get-ChildItem -Path $out -Recurse -File | ForEach-Object { Write-Host ("  " + $_.FullName.Substring($out.Length + 1) + "  (" + $_.Length + " bytes)") }
Write-Host ""
Write-Host "Listo. Los resultados quedaron en la carpeta resultados-docker." -ForegroundColor Green
Write-Host "El sistema sigue levantado. Para detenerlo y borrar los datos de demostracion: docker compose down -v (desde el-asador-backend)."
