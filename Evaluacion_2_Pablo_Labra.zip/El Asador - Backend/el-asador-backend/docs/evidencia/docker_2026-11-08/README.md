# Ejecución con Docker, 8 de noviembre de 2026

Ejecución de la **versión final** de la entrega (el backend, sin el frontend conectado, con el `Dockerfile` de un solo objetivo) en Docker Desktop para Windows, a partir de las 16:11 (hora de Chile). Docker 29.9.2, Compose v5.6.1, Python 3.14.7. Los archivos son la salida literal de las herramientas de [`herramientas/`](herramientas) (más el diagnóstico `10c`, de la misma máquina y de ese mismo día, 16:29); solo se quitaron el carácter de orden de bytes (BOM) y los saltos de línea de Windows. No hay secretos: el valor de la cookie de sesión se oculta, las claves de las cuentas se reemplazan por «secreto» y no se copió `.env` (se comprobó que ningún valor de `.env` aparece en estos archivos).

| Archivo | Qué es |
|---|---|
| `00-entorno.txt` | Versiones de Docker, Compose y Python |
| `01-bootstrap.txt` | `python scripts/bootstrap.py`: crea `.env` con secretos al azar (solo los nombres, nunca los valores) |
| `03-up.txt` | `docker compose up -d --build`: construcción de las 10 imágenes y arranque |
| `03b-ps-al-terminar-el-arranque.txt`, `03c-logs-al-terminar-el-arranque.txt` | Estado y registros de los contenedores justo al terminar el arranque (`vault-seed` termina por diseño; Vault no tiene registros porque el compose descarta su salida: el servidor de desarrollo imprime su token raíz al arrancar) |
| `04-ps.txt` | `docker compose ps` con el sistema ya listo: 12 contenedores `healthy` |
| `05-smoke-test.txt` | `python scripts/smoke_test.py`: 29 de 29 |
| `06-capturas-consola.txt` | Salida en consola de `capturas_http.py` |
| `capturas/01` a `capturas/09` | Transcripción de solicitudes HTTP reales (casos C1, C2, C3, C4 y C6, inicio de sesión, pedido, pago y GraphQL) |
| `capturas/10a`, `capturas/10b`, `capturas/10c` | Caso C5: puertos alcanzables desde el equipo, llamadas directas a los servicios privados desde dentro de la red de Docker y diagnóstico del puerto 27017 |
| `herramientas/` | `verificar_docker.ps1` (orquesta todo), `capturas_http.py`, `acceso_directo.py` y `diagnostico_puerto_27017.ps1`. Son las que se ejecutaron; en las dos `.ps1` solo se cambió el texto de ayuda de las últimas líneas de la consola |

## Cómo se obtuvo

Desde la carpeta que contiene el repositorio (`el-asador-backend/`) y las tres herramientas, con Docker Desktop abierto:

```
powershell -ExecutionPolicy Bypass -File .\verificar_docker.ps1
```

El script prepara `.env`, baja y borra los datos de la corrida anterior (`docker compose down -v`), construye y levanta todo, corre la prueba de humo, espera 65 s (el sistema limita los inicios de sesión a 5 por minuto) y ejecuta las capturas y el caso C5. Si el sistema ya está levantado, `-SoloPruebas` se salta la construcción. Fueron dos ejecuciones consecutivas del script. La primera (16:11) hizo la preparación, la construcción y el arranque (`00-entorno.txt` a `03c`) y se detuvo antes de la prueba de humo por un defecto del propio script: PowerShell devolvió vacío el código de salida de `docker compose up` y se tomó por un fallo, aunque el sistema había arrancado bien. El script se corrigió y una segunda ejecución con `-SoloPruebas` (16:17 a 16:19), sobre el mismo sistema ya levantado, produjo `04-ps.txt`, `05-smoke-test.txt`, `06-capturas-consola.txt` y las capturas.

## Qué se comprobó

- Construcción sin errores de las 10 imágenes y 12 contenedores `healthy`.
- Prueba de humo: **29 de 29**.
- `capturas_http.py`: 27 de 27 comprobaciones en las capturas 1 a 9 (cada captura termina con sus comprobaciones «CUMPLE»).
- `acceso_directo.py`: **16 de 16** llamadas directas a los servicios privados rechazadas (403 `LLAMADOR_NO_PERMITIDO` sin credencial y 403 `SECRETO_INVALIDO` con un secreto inventado).
- Puertos alcanzables desde el equipo (`10a`): 3 de 4 como se esperaba (8000 y 8300 abiertos a propósito y Vault, 8200, cerrado). El 27017 respondió, pero lo atiende el servicio de Windows «MongoDB Server» (`mongod.exe`) instalado en el equipo, no el contenedor del proyecto: `10c` lo demuestra (el único proceso que escucha es `mongod.exe`, y `asador-mongo-1` solo expone `27017/tcp` dentro de la red de Docker, sin publicarlo: `27017/tcp -> :0`).

## Límites

Es una sola ejecución, en un solo equipo, con los datos de demostración y el proveedor de pagos simulado. No reemplaza a la suite automática (`tests/`), que es la evidencia amplia; muestra los mismos controles sobre los contenedores.
