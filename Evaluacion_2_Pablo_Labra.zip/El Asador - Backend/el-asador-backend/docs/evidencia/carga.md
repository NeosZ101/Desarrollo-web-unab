# Prueba de carga de la analítica

Generado por `scripts/load_test.py`. **Todos los números salen de esta ejecución.**

## Entorno

- **modo**: pruebas
- **so**: Linux-6.18.44-fc-v236-x86_64-with-glibc2.39
- **cpu**: Intel(R) Xeon(R) Processor
- **nucleos**: 2
- **memoria total**: 7.8 GB
- **python**: 3.13.18
- **uvicorn**: 0.54.0
- **fastapi**: 0.162.0
- **base de datos**: MongoDB real (db version v8.0.23) con autenticación y un usuario por servicio, en el mismo equipo, sin Docker; secretos en HashiCorp Vault real (Vault v2.0.0, built 2025-11-05T06:06:22Z) en modo desarrollo
- **workers por servicio**: 1
- **generador de carga**: mismo equipo que los servicios (compite por CPU)

## Datos

- 3150 ventas vigentes repartidas en los últimos 90 días (cada una con 1 a 5 líneas); cargadas por la propia API de analytics en 8.5 s (371.5 ventas/s a 32 clientes simultáneos).
- Tamaño de los mensajes: evento «venta registrada» de 494 bytes en promedio (313–678, 1000 eventos generados); respuesta del reporte de 2938 bytes (30 días) y 7634 bytes (92 días).
- **Orden de la medición:** primero se cargan las ventas indicadas y se miden los reportes con exactamente esa cantidad (columna «Ventas en la base al empezar»); después la ingesta sostenida agrega más ventas y, al final, los reportes se repiten (casos «con la base crecida») para ver cómo cambian con el volumen.
- «Respuestas totales» cuenta también las respuestas de error, que son rápidas (un servicio que se rinde por plazo contesta de inmediato): la capacidad útil es la columna «Respuestas correctas».
- Duración de cada caso: 15 s (más 1 s de calentamiento que no se cuenta). Concurrencias: [1, 4, 16, 64].

## Resultados

| Caso | Ventas en la base al empezar | Clientes simultáneos | Solicitudes | Respuestas totales (req/s) | Respuestas correctas (req/s) | p50 (ms) | p95 (ms) | p99 (ms) | Máx (ms) | Errores | CPU analytics prom/máx (% de un núcleo) | Memoria analytics máx (MB) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Reporte de ventas 30 días, directo a analytics | 3150 | 1 | 806 | 53.7 | 53.7 | 17.7 | 24.2 | 29.9 | 38.7 | 0 | 15.6 / 18.0 | 121.8 |
| Reporte de ventas 30 días, directo a analytics | 3150 | 4 | 1274 | 84.8 | 84.9 | 46.0 | 67.5 | 90.8 | 110.9 | 0 | 23.8 / 27.9 | 121.9 |
| Reporte de ventas 30 días, directo a analytics | 3150 | 16 | 1120 | 73.4 | 73.2 | 209.1 | 286.8 | 407.1 | 764.4 | 0 | 21.2 / 28.0 | 122.0 |
| Reporte de ventas 92 días (máximo), directo a analytics | 3150 | 1 | 345 | 23.0 | 23.0 | 38.8 | 63.9 | 119.5 | 385.7 | 0 | 8.9 / 14.0 | 122.0 |
| Reporte de ventas 92 días (máximo), directo a analytics | 3150 | 4 | 553 | 36.7 | 36.6 | 104.8 | 149.8 | 173.9 | 234.6 | 0 | 15.5 / 18.0 | 122.0 |
| Reporte de ventas 92 días (máximo), directo a analytics | 3150 | 16 | 532 | 34.8 | 34.8 | 456.7 | 573.8 | 630.9 | 686.4 | 0 | 13.2 / 31.8 | 122.0 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 3150 | 1 | 443 | 29.5 | 29.5 | 29.1 | 59.6 | 79.7 | 133.9 | 0 | 9.7 / 12.0 | 122.0 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 3150 | 4 | 716 | 47.4 | 47.4 | 78.6 | 142.6 | 243.0 | 304.8 | 0 | 17.8 / 22.0 | 122.0 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 3150 | 16 | 729 | 48.1 | 48.0 | 309.5 | 585.5 | 826.1 | 1138.3 | 0 | 18.4 / 42.0 | 122.0 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 3150 | 1 | 250 | 16.6 | 16.7 | 53.9 | 116.3 | 140.5 | 159.6 | 0 | 7.7 / 10.0 | 122.0 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 3150 | 4 | 426 | 28.3 | 28.2 | 136.5 | 216.1 | 239.3 | 258.9 | 0 | 13.3 / 22.0 | 122.0 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 3150 | 16 | 426 | 27.7 | 27.7 | 583.3 | 881.9 | 1163.5 | 1253.3 | 0 | 12.4 / 32.0 | 122.1 |
| Ingesta de ventas (analytics) | 3150 | 1 | 4974 | 331.5 | 331.6 | 2.9 | 3.6 | 4.7 | 21.9 | 0 | 58.3 / 60.0 | 122.1 |
| Ingesta de ventas (analytics) | 8429 | 4 | 6776 | 451.6 | 451.7 | 8.4 | 12.4 | 18.8 | 76.5 | 0 | 85.2 / 91.9 | 122.1 |
| Ingesta de ventas (analytics) | 15662 | 16 | 8242 | 549.2 | 549.5 | 26.2 | 45.2 | 119.7 | 180.7 | 0 | 91.9 / 97.8 | 122.1 |
| Ingesta de ventas (analytics) | 24426 | 64 | 3806 | 250.2 | 250.4 | 176.2 | 743.1 | 1126.6 | 1946.6 | 0 | 50.8 / 83.7 | 122.6 |
| Reentrega del MISMO evento (idempotencia) | 28567 | 16 | 3049 | 434.9 | 435.6 | 24.2 | 137.4 | 226.4 | 564.3 | 0 | 69.4 / 95.8 | 122.6 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 28567 | 1 | 120 | 8.0 | 8.0 | 114.5 | 173.0 | 218.6 | 220.5 | 0 | 4.1 / 8.0 | 122.6 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 28567 | 4 | 191 | 12.6 | 12.6 | 316.2 | 403.8 | 478.2 | 521.2 | 0 | 6.2 / 13.8 | 122.6 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 28567 | 1 | 45 | 3.0 | 3.0 | 332.1 | 395.4 | 452.2 | 452.2 | 0 | 2.7 / 6.0 | 122.6 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 28567 | 4 | 66 | 4.3 | 4.3 | 963.1 | 1307.6 | 1418.6 | 1418.6 | 0 | 3.4 / 8.0 | 122.6 |

## CPU y memoria por servicio durante cada caso (promedio / máximo de CPU en % de un núcleo; memoria máxima en MB)

| Caso | Clientes | analytics | api-gateway | auth | graphql-gateway | mongo | payments |
|---|---|---|---|---|---|---|---|
| Reporte de ventas 30 días, directo a analytics | 1 | 15.6/18.0 · 121.8 MB | 0.1/2.0 · 62.1 MB | 0.1/2.0 · 77.6 MB | 0.1/2.0 · 70.0 MB | 79.7/83.9 · 419.1 MB | 0.2/2.0 · 80.1 MB |
| Reporte de ventas 30 días, directo a analytics | 4 | 23.8/27.9 · 121.9 MB | 0.1/2.0 · 62.1 MB | 0.1/2.0 · 77.6 MB | 0.1/2.0 · 70.0 MB | 162.4/171.7 · 712.2 MB | 0.2/2.0 · 80.1 MB |
| Reporte de ventas 30 días, directo a analytics | 16 | 21.2/28.0 · 122.0 MB | 0.1/2.0 · 62.1 MB | 0.1/2.0 · 77.6 MB | 0.1/2.0 · 70.0 MB | 168.3/173.9 · 974.3 MB | 0.1/2.0 · 80.1 MB |
| Reporte de ventas 92 días (máximo), directo a analytics | 1 | 8.9/14.0 · 122.0 MB | 0.1/2.0 · 62.1 MB | 0.2/2.0 · 77.6 MB | 0.1/2.0 · 70.0 MB | 108.3/181.8 · 993.0 MB | 0.1/2.0 · 80.1 MB |
| Reporte de ventas 92 días (máximo), directo a analytics | 4 | 15.5/18.0 · 122.0 MB | 0.1/2.0 · 62.1 MB | 0.1/2.0 · 77.6 MB | 0.1/2.0 · 70.0 MB | 177.0/181.8 · 967.1 MB | 0.2/2.0 · 80.1 MB |
| Reporte de ventas 92 días (máximo), directo a analytics | 16 | 13.2/31.8 · 122.0 MB | 0.1/2.0 · 62.1 MB | 0.1/2.0 · 77.6 MB | 0.1/2.0 · 70.0 MB | 179.8/185.9 · 966.7 MB | 0.2/2.0 · 80.1 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 1 | 9.7/12.0 · 122.0 MB | 10.1/14.0 · 64.2 MB | 6.1/10.0 · 78.2 MB | 16.4/20.0 · 73.0 MB | 67.6/135.8 · 968.4 MB | 0.1/2.0 · 80.1 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 4 | 17.8/22.0 · 122.0 MB | 17.6/24.0 · 66.9 MB | 11.2/17.9 · 81.9 MB | 29.5/38.0 · 75.2 MB | 94.7/113.6 · 962.8 MB | 0.2/2.0 · 80.1 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 16 | 18.4/42.0 · 122.0 MB | 20.9/42.0 · 86.7 MB | 12.0/22.0 · 90.3 MB | 29.2/45.4 · 99.6 MB | 101.7/119.9 · 942.3 MB | 0.2/2.0 · 80.1 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 1 | 7.7/10.0 · 122.0 MB | 8.2/12.0 · 86.7 MB | 4.9/8.0 · 90.3 MB | 13.1/16.0 · 99.6 MB | 74.7/87.9 · 942.9 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 4 | 13.3/22.0 · 122.0 MB | 11.7/20.0 · 86.7 MB | 7.7/12.0 · 90.3 MB | 21.8/32.0 · 99.6 MB | 130.7/149.8 · 937.4 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 16 | 12.4/32.0 · 122.1 MB | 12.8/59.4 · 86.7 MB | 6.9/14.0 · 90.3 MB | 20.8/37.6 · 100.0 MB | 137.6/153.1 · 920.3 MB | 0.2/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 1 | 58.3/60.0 · 122.1 MB | 0.1/2.0 · 86.7 MB | 0.1/2.0 · 90.3 MB | 0.1/2.0 · 100.0 MB | 27.1/34.0 · 920.4 MB | 0.2/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 4 | 85.2/91.9 · 122.1 MB | 0.1/2.0 · 86.7 MB | 0.1/2.0 · 90.3 MB | 0.1/2.0 · 100.0 MB | 34.2/75.9 · 915.0 MB | 0.2/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 16 | 91.9/97.8 · 122.1 MB | 0.1/2.0 · 86.7 MB | 0.1/2.0 · 90.3 MB | 0.1/2.0 · 100.0 MB | 26.2/30.0 · 913.3 MB | 0.1/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 64 | 50.8/83.7 · 122.6 MB | 0.1/2.0 · 86.7 MB | 0.1/2.0 · 90.3 MB | 0.1/2.0 · 100.0 MB | 17.7/27.9 · 878.9 MB | 0.1/2.0 · 80.2 MB |
| Reentrega del MISMO evento (idempotencia) | 16 | 69.4/95.8 · 122.6 MB | 0.0/0.0 · 86.7 MB | 0.1/1.9 · 90.3 MB | 0.1/2.0 · 100.0 MB | 17.3/25.9 · 861.1 MB | 0.3/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 1 | 4.1/8.0 · 122.6 MB | 5.1/8.0 · 86.7 MB | 3.2/6.0 · 90.3 MB | 7.2/11.9 · 100.0 MB | 83.3/97.8 · 857.3 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 4 | 6.2/13.8 · 122.6 MB | 7.0/19.7 · 86.7 MB | 4.2/8.0 · 90.3 MB | 10.1/18.0 · 100.0 MB | 164.4/179.9 · 851.3 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 1 | 2.7/6.0 · 122.6 MB | 3.2/8.0 · 86.7 MB | 1.9/4.0 · 90.3 MB | 4.4/8.0 · 100.0 MB | 99.2/115.9 · 843.5 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 4 | 3.4/8.0 · 122.6 MB | 4.0/15.9 · 86.7 MB | 2.6/15.9 · 90.3 MB | 5.9/23.9 · 100.0 MB | 177.3/193.8 · 839.7 MB | 0.2/2.0 · 80.2 MB |

**Idempotencia bajo carga:** el mismo evento enviado 3049 veces en paralelo; los totales del reporte NO cambiaron respecto de la primera entrega.

## Comparación con los objetivos declarados

Los objetivos se fijaron antes de medir (ADR-004). «Medido» es el peor valor entre los casos y concurrencias que cubre cada objetivo.

| Objetivo | Medido (peor caso) | Tope | Resultado |
|---|---|---|---|
| Ingesta de una venta: p95 ≤ 100 ms con hasta 16 emisores simultáneos | 45.2 | 100 | ✓ cumple |
| Reporte de 30 días de punta a punta (navegador→gateway→auth→GraphQL→analytics): p95 ≤ 1.000 ms con hasta 4 usuarios simultáneos | 142.6 | 1000 | ✓ cumple |
| Reporte de 92 días (el máximo permitido) de punta a punta: p95 ≤ 2.000 ms con hasta 4 usuarios simultáneos | 216.1 | 2000 | ✓ cumple |
| Sin errores en ningún caso con hasta 4 clientes simultáneos | 0 | 0 | ✓ cumple |

## Cómo leer esto

- Es una medición de ESTE entorno (sección «Entorno»). La base de datos es MongoDB real, así que el costo de las agregaciones es el de MongoDB; la red entre servicios es la del propio equipo (sin latencia de red real) y no se midió Docker.
- Los datos son sintéticos (generados con semilla fija); el reparto de ventas y de productos no es el de un restaurante real.
- El generador de carga corre en el mismo equipo y compite por CPU con los servicios: los resultados son un piso, no un techo.
- Para repetirlo con Docker y MongoDB reales: `docker compose -f docker-compose.yml -f docker-compose.carga.yml up -d` y `python scripts/load_test.py --modo externo ...` (ver README).
