# Pruebas de mutación

Cada fila rompe a propósito UNA regla del sistema (en una copia temporal) y ejecuta las pruebas que deberían notarlo.
**DETECTADA** = alguna prueba falló, como debe ser. **SOBREVIVE** = las pruebas siguen pasando (ver nota).

Resultado: **61 de 62** mutaciones detectadas.

| Id | Qué se rompió | Resultado | Primera prueba que falló | Nota |
|---|---|---|---|---|
| M01 | El aviso del proveedor se acepta aunque su firma sea falsa | DETECTADA | FAILED tests/test_negocio_pagos.py::test_aviso_sin_firma_o_con_firma_falsa_se_rechaza |  |
| M02 | Se aceptan avisos antiguos o del futuro (sin ventana de tiempo) | DETECTADA | FAILED tests/test_negocio_pagos.py::test_aviso_antiguo_o_del_futuro_se_rechaza |  |
| M03 | El monto del aviso no se compara con lo cobrado | DETECTADA | FAILED tests/test_negocio_pagos.py::test_aviso_con_monto_distinto_no_aprueba_el_pago |  |
| M04 | Un pago ya cerrado puede volver a aprobarse | DETECTADA | FAILED tests/test_negocio_pagos.py::test_aviso_firmado_legitimo_aprueba_una_sola_vez_aunque_se_repita |  |
| M05 | Un cliente puede iniciar el pago del pedido de otra persona | DETECTADA | FAILED tests/test_seguridad_acceso.py::test_un_cliente_no_opera_sobre_pedidos_ajenos[GET-/api/orders/A-1039/payment-None] |  |
| M06 | El administrador puede «confirmar a mano» un pago con el proveedor en línea | DETECTADA | FAILED tests/test_negocio_pagos.py::test_un_pedido_con_proveedor_no_se_confirma_a_mano |  |
| M07 | El IVA de la boleta se calcula mal | DETECTADA | FAILED tests/test_unidad_reglas.py::test_desglose_de_iva - assert (10001, 189... |  |
| M08 | Un cliente puede confirmar pagos y reembolsos (rol administrador ampliado) | DETECTADA | FAILED tests/test_segunda_capa.py::test_el_codigo_coincide_con_el_contrato_aprobado[rutas_servicios] |  |
| M09 | Un cliente puede ver o anular pedidos de otros (IDOR) | DETECTADA | FAILED tests/test_seguridad_acceso.py::test_un_cliente_no_ve_el_pedido_de_otro_y_la_respuesta_no_revela_si_existe |  |
| M10 | Se puede anular un pedido ya entregado | DETECTADA | FAILED tests/test_negocio_pedidos.py::test_un_pedido_anulado_no_se_puede_anular_ni_pagar |  |
| M11 | El despacho puede saltarse el ciclo de estados | DETECTADA | FAILED tests/test_negocio_pedidos.py::test_el_despacho_solo_avanza_en_orden |  |
| M12 | Un cliente puede acumular pedidos pendientes sin tope | DETECTADA | FAILED tests/test_negocio_pedidos.py::test_maximo_de_pedidos_pendientes_por_cliente |  |
| M13 | Repetir el envío (doble clic) crea otro pedido | DETECTADA | FAILED tests/test_negocio_pedidos.py::test_reintentar_el_ultimo_pedido_permitido_devuelve_el_mismo |  |
| M14 | El costo de despacho se redondea hacia abajo | DETECTADA | FAILED tests/test_negocio_pedidos.py::test_costo_de_despacho_segun_la_comuna[Santiago-2400] |  |
| M15 | El GraphQL gateway (solo lectura) puede crear pedidos | DETECTADA | FAILED tests/test_seguridad_acceso.py::test_el_graphql_gateway_es_de_solo_lectura_aunque_tenga_su_secreto |  |
| M16 | El gateway público puede marcar un pedido como pagado | DETECTADA | FAILED tests/test_segunda_capa.py::test_el_codigo_coincide_con_el_contrato_aprobado[rutas_servicios] |  |
| M17 | Un cliente puede avanzar el estado de despacho | DETECTADA | FAILED tests/test_segunda_capa.py::test_el_codigo_coincide_con_el_contrato_aprobado[rutas_servicios] |  |
| M18 | Se vende un producto agotado | DETECTADA | FAILED tests/test_negocio_pedidos.py::test_producto_inexistente_y_producto_agotado |  |
| M19 | El gateway reenvía cabeceras de identidad escritas por el navegador (suplantación) | DETECTADA | FAILED tests/test_seguridad_acceso.py::test_cabeceras_de_identidad_enviadas_por_el_navegador_se_ignoran | Las cabeceras del navegador se copian con el MISMO nombre que usa el gateway, así que pisan a las verdaderas. |
| M20 | El gateway deja de revisar el rol de la ruta | DETECTADA | FAILED tests/test_seguridad_acceso.py::test_el_gateway_corta_el_rol_equivocado_antes_de_molestar_al_servicio | La segunda capa también diría 403; por eso la prueba comprueba que el servicio NI SIQUIERA vio la solicitud. |
| M21 | No se revisa el origen de las solicitudes que modifican datos (CSRF) | DETECTADA | FAILED tests/test_seguridad_acceso.py::test_una_solicitud_que_modifica_datos_debe_venir_de_este_sitio |  |
| M22 | El límite de solicitudes cree en X-Forwarded-For | DETECTADA | FAILED tests/test_limites_tasa.py::test_x_forwarded_for_no_sirve_para_saltarse_el_limite |  |
| M23 | La cookie de sesión queda legible por JavaScript | DETECTADA | FAILED tests/test_limites_tasa.py::test_la_cookie_de_sesion_va_con_secure_httponly_y_samesite |  |
| M24 | No hay tope para el tamaño del cuerpo de una solicitud | DETECTADA | FAILED tests/test_seguridad_acceso.py::test_el_tope_de_tamano_tambien_corta_cuerpos_enviados_por_trozos |  |
| M25 | El servicio privado no verifica el secreto del llamador | DETECTADA | FAILED tests/test_seguridad_acceso.py::test_servicio_privado_rechaza_secreto_equivocado[auth] |  |
| M26 | Un servicio acepta a cualquier llamador conocido en cualquier ruta | DETECTADA | FAILED tests/test_segunda_capa.py::test_solo_los_llamadores_declarados_alcanzan_la_ruta[analytics:POST /internal/events/sale-registered] |  |
| M27 | Se acepta identidad de usuario enviada por cualquier servicio | DETECTADA | FAILED tests/test_unidad_guardia_graphql.py::test_un_servicio_sin_confianza_no_puede_afirmar_identidades_aunque_su_secreto_sea_valido |  |
| M28 | El servicio privado no aplica la segunda capa de roles | DETECTADA | FAILED tests/test_segunda_capa.py::test_el_servicio_vuelve_a_comprobar_el_rol_sin_fiarse_del_gateway[analytics:GET /internal/reports/sales] | Antes sobrevivía: el gateway ya filtra por rol. Ahora la prueba de segunda capa llama a cada servicio directo con un rol equivocado. |
| M29 | Los permisos por campo de GraphQL no se aplican | DETECTADA | FAILED tests/test_graphql.py::test_matriz_de_permisos_de_campos_graphql[dueno-panel.pagos] |  |
| M30 | No hay límite de costo en las consultas GraphQL | DETECTADA | FAILED tests/test_graphql.py::test_costo_maximo_con_la_consulta_real_de_la_pantalla |  |
| M31 | La introspección de GraphQL queda abierta | DETECTADA | FAILED tests/test_graphql.py::test_la_introspeccion_esta_desactivada - Assert... |  |
| M32 | No hay límite de profundidad en GraphQL | DETECTADA | FAILED tests/test_graphql.py::test_profundidad_maxima - AssertionError: {"dat... |  |
| M33 | GraphQL muestra errores internos al usuario | DETECTADA | FAILED tests/test_unidad_guardia_graphql.py::test_una_excepcion_inesperada_se_ve_como_error_interno_sin_su_texto |  |
| M34 | Un «limit» negativo resta costo a la consulta | DETECTADA | FAILED tests/test_graphql.py::test_un_limit_negativo_o_gigante_no_evita_el_costo |  |
| M35 | Las cuentas no se bloquean tras varios intentos fallidos | DETECTADA | FAILED tests/test_limites_tasa.py::test_la_cuenta_se_bloquea_tras_claves_incorrectas_sin_revelar_que_esta_bloqueada |  |
| M36 | Un usuario desactivado puede seguir entrando | DETECTADA | FAILED tests/test_negocio_administracion.py::test_desactivar_un_usuario_cierra_su_sesion_le_impide_entrar_y_se_puede_reactivar |  |
| M37 | Las sesiones de usuarios desactivados siguen válidas | SOBREVIVE |  | SOBREVIVE A PROPÓSITO (defensa en profundidad): desactivar a alguien YA revoca sus sesiones (_revocar), así que por HTTP no hay forma de verlo. Esta comprobación solo cierra la carrera «login en curso mientras se desactiva la cuenta». |
| M38 | Se aceptan contraseñas muy cortas | DETECTADA | FAILED tests/test_negocio_administracion.py::test_politica_de_claves_del_personal[corta] |  |
| M39 | Un secreto revocado en Vault se sigue usando desde la memoria | DETECTADA | FAILED tests/test_secretos_vault.py::test_borrar_un_secreto_lo_revoca_aunque_los_servicios_lo_tengan_en_cache |  |
| M40 | Una anulación puede ser «revivida» por un registro de venta posterior | DETECTADA | FAILED tests/test_analitica.py::test_si_la_anulacion_llega_antes_que_el_registro_la_venta_no_se_cuenta |  |
| M41 | El log de un login fallido deja la contraseña escrita | DETECTADA | FAILED tests/test_zz_logs_y_secretos.py::test_ninguna_contrasena_ni_token_de_sesion_aparece_en_los_logs |  |
| M42 | El log del registro deja el correo y el RUN del cliente | DETECTADA | FAILED tests/test_zz_logs_y_secretos.py::test_ningun_dato_personal_de_los_clientes_de_prueba_aparece_en_los_logs |  |
| M43 | El log del gateway deja escrito el token de sesión | DETECTADA | FAILED tests/test_zz_logs_y_secretos.py::test_ninguna_contrasena_ni_token_de_sesion_aparece_en_los_logs |  |
| M44 | (como M08) Un cliente puede confirmar pagos y reembolsos, visto solo por llamadas reales | DETECTADA | FAILED tests/test_segunda_capa.py::test_el_servicio_vuelve_a_comprobar_el_rol_sin_fiarse_del_gateway[payments:POST /admin/orders/{id}/payment-confirmation] | Sin la prueba que compara el código con el contrato: la llamada real al servicio con rol «cliente» debe dar 403 y no lo da. |
| M45 | (como M16) El gateway puede marcar un pedido como pagado, visto solo por llamadas reales | DETECTADA | FAILED tests/test_segunda_capa.py::test_solo_los_llamadores_declarados_alcanzan_la_ruta[orders:POST /internal/orders/{id}/payment-confirmed] |  |
| M46 | (como M17) Un cliente puede avanzar el despacho, visto solo por llamadas reales | DETECTADA | FAILED tests/test_segunda_capa.py::test_el_servicio_vuelve_a_comprobar_el_rol_sin_fiarse_del_gateway[orders:PUT /admin/orders/{id}/status] |  |
| M47 | El log de una librería deja escrito el texto de la excepción (puede traer credenciales o datos personales) | DETECTADA | FAILED tests/test_unidad_logs.py::test_el_texto_de_una_excepcion_de_una_libreria_no_se_escribe |  |
| M48 | Las líneas de log pierden el identificador de correlación | DETECTADA | FAILED tests/test_unidad_logs.py::test_la_linea_lleva_el_request_id_en_curso_y_el_explicito_manda |  |
| M49 | El servicio no fija el identificador de correlación al empezar la solicitud | DETECTADA | FAILED tests/test_unidad_logs.py::test_en_una_solicitud_real_toda_linea_lleva_su_request_id_y_ninguna_filtra_el_texto_de_la_excepcion |  |
| M50 | El plazo para hablar con Vault vuelve a ser largo (3 s): con Vault colgado el usuario recibe 504 | DETECTADA | FAILED tests/test_secretos_vault.py::test_si_vault_cae_el_sistema_sigue_con_los_secretos_que_ya_tenia_y_se_recupera[colgado] |  |
| M51 | Tras un fallo de Vault no se abre la pausa: cada lectura espera otra vez el plazo completo | DETECTADA | FAILED tests/test_secretos_vault.py::test_si_vault_cae_el_sistema_sigue_con_los_secretos_que_ya_tenia_y_se_recupera[colgado] |  |
| M52 | Al arrancar se respeta la pausa y el servicio se rinde sin volver a preguntarle a Vault | DETECTADA | FAILED tests/test_secretos_vault.py::test_esperar_reintenta_y_luego_falla_con_un_mensaje_claro |  |
| M53 | Si orders pierde la carrera al confirmar un pago, responde 409 en vez de reconocer la confirmación ya aplicada | DETECTADA | FAILED tests/test_unidad_carreras.py::test_la_misma_confirmacion_que_pierde_la_carrera_responde_igual_que_la_que_gano |  |
| M54 | Cualquier respuesta de orders que no sea 200 hace que payments devuelva el dinero (aunque el pedido sí avanzó) | DETECTADA | FAILED tests/test_unidad_carreras.py::test_una_respuesta_que_no_es_un_no_definitivo_no_devuelve_el_dinero_y_queda_para_reintento[409-CONFLICTO_DE_ESTADO] |  |
| M55 | Un segundo cobro del mismo pedido (TRANSICION_NO_PERMITIDA) deja de devolverse | DETECTADA | FAILED tests/test_unidad_carreras.py::test_un_no_definitivo_de_orders_devuelve_el_dinero[409-TRANSICION_NO_PERMITIDA-rechazado] |  |
| M56 | Si quien llamó ya se desconectó, el servicio lo trata como error inesperado y deja una traza que no es JSON en el log | DETECTADA | FAILED tests/test_unidad_logs.py::test_si_quien_llamo_se_desconecta_se_deja_una_linea_json_y_no_una_traza_ni_un_error_inesperado |  |
| M57 | El plazo del gateway vuelve a ser menor que la suma de llamadas internas: cortaría antes que los servicios y el usuario vería un 504 genérico | DETECTADA | FAILED tests/test_unidad_plazos.py::test_la_cadena_mas_larga_de_llamadas_internas_cabe_en_el_plazo_del_gateway |  |
| M58 | Un servicio vuelve a fijar su propio plazo sin pasar por plazos.py | DETECTADA | FAILED tests/test_unidad_plazos.py::test_ningun_servicio_fija_su_propio_plazo_por_fuera_de_plazos_py |  |
| M59 | El total de ventas del reporte vuelve a ser un Int de 32 bits: un período largo con más de 2.147 millones falla con «Error interno» | DETECTADA | FAILED tests/test_analitica.py::test_un_total_mayor_a_2147_millones_se_informa_completo_y_no_como_error_interno |  |
| M60 | Un error inesperado de GraphQL vuelve a enmascararse sin dejar rastro en el log | DETECTADA | FAILED tests/test_unidad_guardia_graphql.py::test_un_error_inesperado_deja_en_el_log_el_campo_y_el_tipo_pero_nunca_el_texto |  |
| M61 | El enmascarado vuelve a depender de que el error traiga una excepción asociada: un error con ruta pero sin excepción muestra su texto al navegador | DETECTADA | FAILED tests/test_unidad_guardia_graphql.py::test_un_error_con_ruta_pero_sin_excepcion_asociada_tambien_se_enmascara |  |
| M62 | El Auth Service acepta una sesión vencida: quien conserve la cookie puede seguir usándola | DETECTADA | FAILED tests/test_sesion_vence.py::test_la_sesion_vence_y_el_servidor_rechaza_el_token_que_alguien_conserve |  |
