# Prueba de carga de la analítica

Generado por `scripts/load_test.py`. **Todos los números salen de esta ejecución.**

## Entorno

- **modo**: pruebas
- **so**: Linux-6.18.44-fc-v236-x86_64-with-glibc2.39
- **cpu**: Intel(R) Xeon(R) Processor
- **nucleos**: 2
- **memoria total**: 7.8 GB
- **python**: 3.13.18
- **uvicorn**: 0.54.0
- **fastapi**: 0.162.0
- **base de datos**: MongoDB real (db version v8.0.23) con autenticación y un usuario por servicio, en el mismo equipo, sin Docker; secretos en HashiCorp Vault real (Vault v2.0.0, built 2025-11-05T06:12:38Z) en modo desarrollo
- **workers por servicio**: 1
- **generador de carga**: mismo equipo que los servicios (compite por CPU)

## Datos

- 31500 ventas vigentes repartidas en los últimos 90 días (cada una con 1 a 5 líneas); cargadas por la propia API de analytics en 80.9 s (389.3 ventas/s a 32 clientes simultáneos).
- Tamaño de los mensajes: evento «venta registrada» de 489 bytes en promedio (314–680, 1000 eventos generados); respuesta del reporte de 3020 bytes (30 días) y 7838 bytes (92 días).
- **Orden de la medición:** primero se cargan las ventas indicadas y se miden los reportes con exactamente esa cantidad (columna «Ventas en la base al empezar»); después la ingesta sostenida agrega más ventas y, al final, los reportes se repiten (casos «con la base crecida») para ver cómo cambian con el volumen.
- «Respuestas totales» cuenta también las respuestas de error, que son rápidas (un servicio que se rinde por plazo contesta de inmediato): la capacidad útil es la columna «Respuestas correctas».
- Duración de cada caso: 10 s (más 1 s de calentamiento que no se cuenta). Concurrencias: [1, 4, 16].

## Resultados

| Caso | Ventas en la base al empezar | Clientes simultáneos | Solicitudes | Respuestas totales (req/s) | Respuestas correctas (req/s) | p50 (ms) | p95 (ms) | p99 (ms) | Máx (ms) | Errores | CPU analytics prom/máx (% de un núcleo) | Memoria analytics máx (MB) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Reporte de ventas 30 días, directo a analytics | 31500 | 1 | 95 | 9.5 | 9.5 | 105.2 | 117.2 | 122.8 | 122.8 | 0 | 4.1 / 8.0 | 125.6 |
| Reporte de ventas 30 días, directo a analytics | 31500 | 4 | 138 | 13.5 | 13.5 | 298.9 | 358.4 | 379.5 | 418.4 | 0 | 5.1 / 8.0 | 125.6 |
| Reporte de ventas 30 días, directo a analytics | 31500 | 16 | 141 | 12.9 | 12.9 | 1305.6 | 1533.6 | 1785.5 | 1861.4 | 0 | 6.2 / 27.8 | 125.7 |
| Reporte de ventas 92 días (máximo), directo a analytics | 31500 | 1 | 31 | 3.1 | 3.1 | 322.4 | 375.0 | 401.1 | 401.1 | 0 | 2.4 / 4.0 | 125.7 |
| Reporte de ventas 92 días (máximo), directo a analytics | 31500 | 4 | 45 | 4.3 | 4.3 | 958.1 | 1150.7 | 1174.9 | 1174.9 | 0 | 3.0 / 6.0 | 125.7 |
| Reporte de ventas 92 días (máximo), directo a analytics | 31500 | 16 | 57 | 4.5 | 4.5 | 3609.0 | 4585.3 | 4729.8 | 4729.8 | 0 | 2.0 / 6.0 | 125.8 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 31500 | 1 | 80 | 8.0 | 8.0 | 118.3 | 163.4 | 174.1 | 174.1 | 0 | 3.6 / 6.0 | 125.8 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 31500 | 4 | 118 | 11.6 | 11.6 | 339.1 | 500.6 | 563.0 | 595.6 | 0 | 5.4 / 10.0 | 125.8 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 31500 | 16 | 126 | 11.8 | 11.8 | 1413.6 | 1838.2 | 2171.8 | 2190.6 | 0 | 4.6 / 10.0 | 125.8 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 31500 | 1 | 27 | 2.7 | 2.7 | 353.4 | 470.5 | 485.3 | 485.3 | 0 | 2.5 / 4.0 | 125.8 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 31500 | 4 | 45 | 4.3 | 4.4 | 970.7 | 1201.6 | 1312.4 | 1312.4 | 0 | 3.4 / 10.0 | 125.8 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 31500 | 16 | 870 | 84.3 | 0.0 | 88.6 | 394.8 | 2647.7 | 2651.1 | 870 | 2.1 / 24.0 | 125.9 |
| Ingesta de ventas (analytics) | 31500 | 1 | 3456 | 345.6 | 345.6 | 2.7 | 3.5 | 4.5 | 18.6 | 0 | 59.2 / 61.9 | 125.9 |
| Ingesta de ventas (analytics) | 35266 | 4 | 4315 | 431.4 | 431.5 | 8.8 | 13.3 | 20.7 | 57.3 | 0 | 86.7 / 89.9 | 125.9 |
| Ingesta de ventas (analytics) | 40029 | 16 | 5365 | 535.8 | 536.5 | 27.8 | 45.2 | 98.4 | 150.3 | 0 | 92.3 / 95.9 | 125.9 |
| Reentrega del MISMO evento (idempotencia) | 45875 | 16 | 2771 | 552.3 | 554.2 | 25.3 | 52.4 | 138.1 | 171.5 | 0 | 91.6 / 93.9 | 125.9 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 45875 | 1 | 53 | 5.3 | 5.2 | 189.5 | 222.6 | 269.9 | 269.9 | 0 | 3.1 / 6.0 | 125.9 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 45875 | 4 | 88 | 8.6 | 8.5 | 474.1 | 590.9 | 633.3 | 633.3 | 0 | 4.4 / 8.0 | 125.9 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 45875 | 1 | 20 | 2.0 | 2.0 | 499.1 | 603.3 | 603.3 | 603.3 | 0 | 2.1 / 4.0 | 125.9 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 45875 | 4 | 32 | 3.1 | 3.1 | 1410.4 | 1752.9 | 1791.5 | 1791.5 | 0 | 2.6 / 11.9 | 125.9 |

## CPU y memoria por servicio durante cada caso (promedio / máximo de CPU en % de un núcleo; memoria máxima en MB)

| Caso | Clientes | analytics | api-gateway | auth | graphql-gateway | mongo | payments |
|---|---|---|---|---|---|---|---|
| Reporte de ventas 30 días, directo a analytics | 1 | 4.1/8.0 · 125.6 MB | 0.1/2.0 · 62.2 MB | 0.1/2.0 · 77.7 MB | 0.0/0.0 · 70.1 MB | 98.3/103.9 · 336.4 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 30 días, directo a analytics | 4 | 5.1/8.0 · 125.6 MB | 0.1/2.0 · 62.2 MB | 0.1/2.0 · 77.7 MB | 0.1/2.0 · 70.1 MB | 190.9/193.9 · 459.7 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 30 días, directo a analytics | 16 | 6.2/27.8 · 125.7 MB | 0.1/2.0 · 62.2 MB | 0.1/2.0 · 77.7 MB | 0.1/2.0 · 70.1 MB | 188.9/195.8 · 492.0 MB | 0.3/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), directo a analytics | 1 | 2.4/4.0 · 125.7 MB | 0.1/2.0 · 62.2 MB | 0.1/2.0 · 77.7 MB | 0.2/2.0 · 70.1 MB | 111.5/145.9 · 505.4 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), directo a analytics | 4 | 3.0/6.0 · 125.7 MB | 0.0/0.0 · 62.2 MB | 0.0/0.0 · 77.7 MB | 0.1/2.0 · 70.1 MB | 193.9/196.5 · 509.8 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), directo a analytics | 16 | 2.0/6.0 · 125.8 MB | 0.1/2.0 · 62.2 MB | 0.2/2.0 · 77.7 MB | 0.1/2.0 · 70.1 MB | 195.2/199.8 · 511.4 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 1 | 3.6/6.0 · 125.8 MB | 4.5/8.0 · 64.2 MB | 2.7/6.0 · 78.5 MB | 6.4/10.0 · 72.3 MB | 86.6/96.0 · 512.0 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 4 | 5.4/10.0 · 125.8 MB | 6.9/25.9 · 65.9 MB | 3.8/10.0 · 81.5 MB | 9.3/19.9 · 74.1 MB | 165.4/181.9 · 521.5 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 16 | 4.6/10.0 · 125.8 MB | 8.1/69.4 · 83.8 MB | 3.7/19.8 · 86.2 MB | 8.2/16.0 · 82.3 MB | 167.7/191.8 · 522.6 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 1 | 2.5/4.0 · 125.8 MB | 3.2/6.0 · 83.8 MB | 1.8/4.0 · 86.2 MB | 4.8/14.0 · 82.3 MB | 99.1/113.9 · 523.2 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 4 | 3.4/10.0 · 125.8 MB | 4.0/17.9 · 83.8 MB | 2.4/10.0 · 86.2 MB | 5.3/17.9 · 82.3 MB | 179.3/195.5 · 524.5 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 16 | 2.1/24.0 · 125.9 MB | 31.8/67.2 · 84.6 MB | 13.8/37.6 · 100.5 MB | 29.6/63.9 · 98.2 MB | 107.5/197.8 · 526.1 MB | 0.1/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 1 | 59.2/61.9 · 125.9 MB | 0.0/0.0 · 84.6 MB | 0.1/2.0 · 100.5 MB | 0.1/2.0 · 98.2 MB | 20.8/24.0 · 526.5 MB | 0.1/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 4 | 86.7/89.9 · 125.9 MB | 0.1/2.0 · 84.6 MB | 0.1/2.0 · 100.5 MB | 0.1/2.0 · 98.2 MB | 32.0/44.0 · 526.6 MB | 0.2/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 16 | 92.3/95.9 · 125.9 MB | 0.1/2.0 · 84.6 MB | 0.1/2.0 · 100.5 MB | 0.1/2.0 · 98.2 MB | 28.0/31.8 · 526.7 MB | 0.1/2.0 · 80.2 MB |
| Reentrega del MISMO evento (idempotencia) | 16 | 91.6/93.9 · 125.9 MB | 0.0/0.0 · 84.6 MB | 0.2/2.0 · 100.5 MB | 0.2/2.0 · 98.2 MB | 20.8/24.0 · 526.7 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 1 | 3.1/6.0 · 125.9 MB | 4.3/8.0 · 84.6 MB | 2.7/10.0 · 100.5 MB | 5.4/10.0 · 98.2 MB | 88.1/95.9 · 526.8 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 4 | 4.4/8.0 · 125.9 MB | 5.3/15.8 · 84.6 MB | 3.3/9.8 · 100.5 MB | 7.9/27.6 · 98.2 MB | 172.1/183.8 · 527.0 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 1 | 2.1/4.0 · 125.9 MB | 3.0/8.0 · 84.6 MB | 1.6/4.0 · 100.5 MB | 3.7/8.0 · 98.2 MB | 92.9/105.9 · 527.1 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 4 | 2.6/11.9 · 125.9 MB | 3.3/19.9 · 84.6 MB | 1.7/10.0 · 100.5 MB | 4.4/23.9 · 98.2 MB | 182.4/197.8 · 527.2 MB | 0.2/2.0 · 80.2 MB |

## Errores (motivo de cada uno)

`SERVICIO_NO_DISPONIBLE` es la respuesta de diseño cuando un servicio no contesta dentro de su plazo o el cortacircuitos está abierto (falla rápido en vez de acumular espera). La última columna son los segundos que tardó el sistema en volver a contestar bien (3 respuestas correctas seguidas) una vez terminada la carga.

| Caso | Clientes | Errores de | Motivos | Segundos hasta recuperarse |
|---|---|---|---|---|
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 16 | 870 de 870 | `graphql:SERVICIO_NO_DISPONIBLE` ×870 | 5.0 |

**Idempotencia bajo carga:** el mismo evento enviado 2771 veces en paralelo; los totales del reporte NO cambiaron respecto de la primera entrega.

## Comparación con los objetivos declarados

Los objetivos se fijaron antes de medir (ADR-004). «Medido» es el peor valor entre los casos y concurrencias que cubre cada objetivo.

| Objetivo | Medido (peor caso) | Tope | Resultado |
|---|---|---|---|
| Ingesta de una venta: p95 ≤ 100 ms con hasta 16 emisores simultáneos | 45.2 | 100 | ✓ cumple |
| Reporte de 30 días de punta a punta (navegador→gateway→auth→GraphQL→analytics): p95 ≤ 1.000 ms con hasta 4 usuarios simultáneos | 500.6 | 1000 | ✓ cumple |
| Reporte de 92 días (el máximo permitido) de punta a punta: p95 ≤ 2.000 ms con hasta 4 usuarios simultáneos | 1201.6 | 2000 | ✓ cumple |
| Sin errores en ningún caso con hasta 4 clientes simultáneos | 0 | 0 | ✓ cumple |

## Cómo leer esto

- Es una medición de ESTE entorno (sección «Entorno»). La base de datos es MongoDB real, así que el costo de las agregaciones es el de MongoDB; la red entre servicios es la del propio equipo (sin latencia de red real) y no se midió Docker.
- Los datos son sintéticos (generados con semilla fija); el reparto de ventas y de productos no es el de un restaurante real.
- El generador de carga corre en el mismo equipo y compite por CPU con los servicios: los resultados son un piso, no un techo.
- Para repetirlo con Docker y MongoDB reales: `docker compose -f docker-compose.yml -f docker-compose.carga.yml up -d` y `python scripts/load_test.py --modo externo ...` (ver README).
