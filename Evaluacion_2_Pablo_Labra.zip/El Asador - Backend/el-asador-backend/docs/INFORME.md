# Informe de arquitectura y backend · Evaluación 2

**Caso 20 · Parrilladas «El Asador»** · Desarrollo Web y Móvil · Universidad Andrés Bello

## Portada

| | |
|---|---|
| **Caso** | 20 · Parrilladas «El Asador» (pedidos web con despacho, pago en línea, boleta digital y panel interno) |
| **Integrantes** | Pablo Labra (NeosZ101). Equipo de una sola persona |
| **Entrega** | Evaluación 2 · backend seguro completo, construido con los datos y los flujos del frontend de la C2 (el frontend integrado se valida en la Evaluación 3; fecha de entrega: lunes 9 de noviembre de 2026) |
| **Versión del frontend** | Entrega C2 (repositorio `NeosZ101/el-asador-frontend`, commit `554c292`, 21 de septiembre de 2026): 8 páginas en HTML5, CSS, JavaScript y Bootstrap 5 local. Sus pantallas, formularios y datos (`datos.js`) son el punto de partida de los servicios, los contratos y los datos de prueba. El proyecto del backend no incluye el frontend: de él se usan sus datos (`datos-frontend/`; ver «Brechas y supuestos declarados»). Demostración de la C2 sin backend (enlace tomado del README de la C2; no se verificó que siga publicado): <https://neosz101.github.io/el-asador-frontend/> |
| **Pila** | FastAPI · MongoDB · HashiCorp Vault · GraphQL (Strawberry) · Docker Compose |
| **Código** | 9 servicios propios + proveedor de pagos simulado + Vault + MongoDB |

### Requisitos que cubre el backend

Los requisitos funcionales (RF), casos de uso (CU) y no funcionales (RNF) se listan con su trazabilidad completa en el módulo 1. En resumen:

| RF | Requisito | Caso de uso |
|---|---|---|
| RF1 | Armar un pedido con los productos disponibles de la carta | CU5 Genera pedido |
| RF2 | La orden se prepara solo tras confirmar el pago | CU6 Realizar venta |
| RF3 | Anular una compra indicando el motivo | CU7 Anular compra |
| RF4 | Vender únicamente pedidos de clientes registrados | CU6 Realizar venta |
| RF5 | Registro de clientes con todos sus datos y correo existente | CU3 Administrar clientes |
| RF6 | Registro de clientes en el local por el administrador | CU3 Administrar clientes |
| RF7 | Administrar la disponibilidad de cada producto | CU4 Administrar productos |
| RF8 | Boleta digital por cada venta, enviada por correo | CU6 Realizar venta |
| RF9 | Reporte de ventas por período para el dueño | CU8 Generar reporte de ventas |
| RF10 | Mantenedores de productos, usuarios y clientes | CU2, CU3, CU4 |
| RF11 | Validar que el correo existe mediante una API de mensajería | CU3 Administrar clientes |
| RF12 | Autenticación de usuarios y acceso según perfil | CU1 Autenticar usuarios |
| RF13 | Orden de despacho en el orden de llegada (imprimible) | CU9 Obtener orden de despacho |

### Brechas y supuestos declarados

1. **Origen de los requisitos.** Los RF1–RF13, CU1–CU9 y RNF1–RNF16 siguen la estructura de requisitos del caso de referencia de la asignatura, adaptados a «El Asador» con lo que muestran las pantallas del frontend de la C2 (promociones, cotizador de eventos, zonas de despacho). La matriz de trazabilidad del módulo 1 enlaza cada requisito con sus servicios y sus pruebas, de modo que un cambio de requisito se revisa allí.
2. **Docker se ejecutó solo en el equipo del autor y solo con el compose principal.** El 7 de noviembre de 2026, en Docker Desktop para Windows, `docker compose up -d --build` construyó las 10 imágenes y levantó los 12 contenedores (todos `healthy`, salvo `vault-seed`, que termina por diseño) y `python scripts/smoke_test.py` dio **29 de 29** ([`docs/evidencia/docker_humo.txt`](evidencia/docker_humo.txt)). El primer intento falló: Vault no arrancaba porque la imagen intenta `setcap` y ese motor no lo permite (corregido con `SKIP_SETCAP: "true"` en `docker-compose.yml`). El 8 de noviembre de 2026 se repitió con la versión final de la entrega (el backend sin el frontend conectado, con el `Dockerfile` de un solo objetivo): las 10 imágenes se construyeron sin errores, los 12 contenedores quedaron `healthy`, la prueba de humo dio **29 de 29** y se registraron los casos C1–C6 sobre los contenedores ([módulo 7.4](#74-evidencia-de-la-ejecución-con-docker), [`docs/evidencia/docker_2026-11-08/`](evidencia/docker_2026-11-08/README.md)). Las pruebas automáticas y las mediciones de carga se ejecutaron con el sistema como procesos separados, con HashiCorp Vault y MongoDB **reales** (sin Docker) y con versiones simuladas, no dentro de contenedores. No se ejecutó `docker-compose.tls.yml` ni `docker-compose.carga.yml`.
3. **Alcance respecto del frontend.** Esta entrega es el backend con **datos del frontend**, no el frontend integrado (esa integración se valida en la Evaluación 3); la frase «backend completo integrado con el frontend» de la pauta se entiende en ese sentido. Aquí, «datos del frontend» son los datos de prueba de la C2 (carta y cuentas de demostración), los contratos REST de las operaciones de cada pantalla ([M1](#m1-servicios-contratos-y-trazabilidad)) y las consultas GraphQL de «Mis pedidos» y del panel interno, que las pruebas leen sin reescribirlas (`datos-frontend/consultas-graphql.json`, copiadas del JavaScript de la C2). Por eso los servicios, los contratos y los datos de prueba salen de las pantallas y los datos de la C2, y los flujos principales se demuestran por HTTP contra el sistema levantado ([10.4](#104-demostración-de-los-flujos-principales)). Por eso el proyecto del backend (`el-asador-backend/`) no incluye el frontend, solo esos datos. Las pruebas del código del navegador (sin secretos escritos, solo el carrito y la comuna en `localStorage`, política de contenido de las 8 páginas) y el recorrido en Chromium (106 comprobaciones) se hicieron sobre una copia adaptada del frontend y quedan fuera de esta entrega, para la Evaluación 3.
4. **Se ejecuta en localhost.** No hace falta publicar el sistema en un servidor: todo corre en el equipo de quien lo evalúa (`http://localhost:8000`). No existe una dirección pública del sistema.
5. **Desviaciones deliberadas respecto del caso de referencia:** RNF3 (Oracle, .NET/J2EE) se reemplaza por FastAPI y MongoDB, las restricciones del curso (ADR-012). RNF4 (procedimientos almacenados) se reemplaza por reintentos y una bandeja de salida.
6. **Integraciones externas simuladas.** El proveedor de pagos es `provider-sandbox`, un simulador propio con el mismo contrato que usa `payments` (clave de API, página de pago, aviso firmado). El correo usa por omisión un adaptador de prueba (`sandbox`); el envío SMTP y la validación por DNS MX están programados pero no se probaron.
7. **gRPC no se implementó.** La analítica usa HTTP/JSON (ADR-004). La pauta evalúa 6 de los 10 puntos de ese criterio con «evidencia reproducible de que la alternativa implementada satisface la carga y los requisitos»; esa evidencia son las mediciones de los módulos [9.3](#93-medición-de-carga-volumen-proyectado) y [9.4](#94-medición-de-carga-10-veces-el-volumen-proyectado), incluido el punto en que el reporte de 92 días deja de cumplir su objetivo.
8. **Vault corre en modo desarrollo** (en memoria, sellado automático): sirve para la evaluación y para demostrar el modelo de secretos, no para producción (ADR-003).
9. **Lo que no se mide no se afirma:** no hay medición de usabilidad (RNF10, RNF11) y, al no estar el frontend conectado al backend, tampoco se validó con este backend el HTML ni el diseño responsivo (RNF15, RNF16) ni la impresión de la boleta y de la orden de despacho; las cifras de rendimiento corresponden a un equipo de 2 CPU y 8 GB, con el generador de carga en el mismo equipo y datos sintéticos.
10. **Servicios sin pantalla que los llame:** S22, S23 y S25 (listar y consultar pedidos por REST) existen y las prueba la suite automática, pero el frontend de la C2 usa GraphQL (S38) en «Mis pedidos» y en el panel interno; S35 (aviso firmado) la invoca el proveedor simulado, no una pantalla. S36 (mensaje de contacto) no corresponde a ningún RF: existe porque el formulario de contacto del frontend lo necesita.
11. **Inventario:** el requisito pide administrar la **disponibilidad** de cada producto (RF7), no cantidades; por eso no se descuenta ni se recupera stock al vender o anular.

---

## M1 Servicios, contratos y trazabilidad

El sistema expone **38 servicios públicos** (S01–S38): cada uno es una fila de la tabla de rutas del API Gateway (`api-gateway/app/rutas.py`). Lo que no figura en esa tabla no se reenvía. El catálogo siguiente se genera desde esa misma tabla y desde la lectura del código de cada servicio; los ejemplos se capturaron ejecutando el sistema.

### 1.1 Catálogo de servicios y contratos

Generado por `scripts/generar_documentos.py` desde la tabla `RUTAS` del API Gateway y la lectura del código de cada servicio. Un servicio es una ruta pública que el navegador puede usar; el API Gateway no reenvía nada que no figure aquí.

**Entrada:** de dónde sale cada dato. **Salida:** estado HTTP de éxito y forma de la respuesta capturada en una ejecución real (`docs/ejemplos/`). **Errores:** los `ErrorNegocio` que el servicio puede lanzar (estado y código), además de los 400/401/403/422/429/5xx comunes que aplican el gateway y la validación.

| ID | Ruta pública | Servicio y ruta interna | Acceso | Entrada | Salida | Errores propios | Datos | RF | Pantallas | Ejemplo |
|---|---|---|---|---|---|---|---|---|---|---|
| S01 | POST /api/auth/login | auth /login | anónimo | cuerpo: LoginIn | 200 {usuario: {…}, expira_en} | 401 CREDENCIALES_INVALIDAS | secreto | RF12 | P09, P06 | [S01](ejemplos/S01.json) |
| S02 | POST /api/auth/logout | auth /logout | anónimo | — | 200 {ok} |  | publico | RF12 | P09, P08 | [S02](ejemplos/S02.json) |
| S03 | GET /api/auth/me | auth /introspect | anónimo | — | 200 {usuario: {…}, expira_en} | — | personal | RF12 | P01, P02, P03, P04, P05, P06, P07, P08 | [S03](ejemplos/S03.json) |
| S04 | GET /api/products | inventory /products | anónimo | consulta: categoria, available, q, limit, offset | 200 [{id, categoria, nombre, precio, disponible, imagen, descripcion, incluye: [], alcohol, personas}] | 400 FILTRO_INVALIDO | publico | RF1, RF7 | P01, P02, P08 | [S04](ejemplos/S04.json) |
| S05 | GET /api/promos | inventory /promos | anónimo | — | 200 [{id, nombre, descripcion, vigencia, descuento, imagen, componentes: [{…}], precioNormal, precio, disponible, incluye: [], alcohol}] |  | publico | RF1 | P01, P02, P08 | [S05](ejemplos/S05.json) |
| S06 | POST /api/products | inventory /products | sesión (administrador, dueno) | cuerpo: ProductoIn | 201 {id, categoria, nombre, precio, disponible, imagen, descripcion, incluye: [], alcohol} |  | publico | RF7, RF10 | P08 | [S06](ejemplos/S06.json) |
| S07 | PUT /api/products/{producto} | inventory /products/{producto} | sesión (administrador, dueno) | ruta: producto; cuerpo: ProductoIn | 200 {id, categoria, nombre, precio, disponible, imagen, descripcion, incluye: [], alcohol} | 404 PRODUCTO_NO_ENCONTRADO | publico | RF7, RF10 | P08 | [S07](ejemplos/S07.json) |
| S08 | PUT /api/products/{producto}/availability | inventory /products/{producto}/availability | sesión (administrador, dueno) | ruta: producto; cuerpo: DisponibilidadIn | 200 {id, categoria, nombre, precio, disponible, imagen, descripcion, incluye: [], alcohol} | 404 PRODUCTO_NO_ENCONTRADO | publico | RF7 | P08 | [S08](ejemplos/S08.json) |
| S09 | DELETE /api/products/{producto} | inventory /products/{producto} | sesión (administrador, dueno) | ruta: producto | 200 {id, retirado} | 404 PRODUCTO_NO_ENCONTRADO, 409 PRODUCTO_EN_PROMO | publico | RF10 | P08 | [S09](ejemplos/S09.json) |
| S10 | POST /api/clients/register | clients /clients/register | anónimo | cuerpo: RegistroWeb | 201 {id, run, nombre, correo, telefono, region, provincia, comuna, direccion, nacimiento, sexo, origen, estado, tieneAcceso} | 409 CUENTA_NO_DISPONIBLE, 422 CLAVE_DEBIL, 422 CORREO_NO_EXISTE, 422 UBICACION_INVALIDA, 503 SERVICIO_NO_DISPONIBLE, 503 VALIDACION_CORREO_NO_DISPONIBLE | restringido | RF5, RF11 | P06 | [S10](ejemplos/S10.json) |
| S11 | GET /api/clients/me | clients /clients/me | sesión (cliente) | — | 200 {id, run, nombre, correo, telefono, region, provincia, comuna, direccion, nacimiento, sexo, origen, estado, tieneAcceso} | 404 CLIENTE_NO_ENCONTRADO | restringido | RF5 | P01 | [S11](ejemplos/S11.json) |
| S12 | GET /api/clients | clients /clients | sesión (administrador) | consulta: q, limit, offset | 200 [{id, run, nombre, correo, telefono, region, provincia, comuna, direccion, nacimiento, sexo, origen, estado, tieneAcceso}] |  | restringido | RF6, RF10 | P08 | [S12](ejemplos/S12.json) |
| S13 | POST /api/clients | clients /clients | sesión (administrador) | cuerpo: ClienteLocal | 201 {id, run, nombre, correo, telefono, region, provincia, comuna, direccion, nacimiento, sexo, origen, estado, tieneAcceso} | 409 CLIENTE_EXISTE, 422 CORREO_NO_EXISTE, 422 UBICACION_INVALIDA, 503 VALIDACION_CORREO_NO_DISPONIBLE | restringido | RF6, RF11 | P08 | [S13](ejemplos/S13.json) |
| S14 | PUT /api/clients/{cliente} | clients /clients/{cliente} | sesión (administrador) | ruta: cliente; cuerpo: ClienteReemplazo | 200 {id, run, nombre, correo, telefono, region, provincia, comuna, direccion, nacimiento, sexo, origen, estado, tieneAcceso} | 404 CLIENTE_NO_ENCONTRADO, 422 UBICACION_INVALIDA | restringido | RF10 | P08 | [S14](ejemplos/S14.json) |
| S15 | DELETE /api/clients/{cliente} | clients /clients/{cliente} | sesión (administrador) | ruta: cliente | 200 {id, estado} | 404 CLIENTE_NO_ENCONTRADO, 503 SERVICIO_NO_DISPONIBLE | restringido | RF10 | P08 | [S15](ejemplos/S15.json) |
| S16 | GET /api/users | auth /users | sesión (administrador) | consulta: limit, offset | 200 {total, items: [{…}]} |  | personal | RF10, RF12 | P08 | [S16](ejemplos/S16.json) |
| S17 | POST /api/users | auth /users | sesión (administrador) | cuerpo: UsuarioNuevo | 201 {id, username, nombre, rol, roles: [], activo, creadoEn} | 409 USUARIO_EXISTE, 422 CLAVE_DEBIL | secreto | RF10, RF12 | P08 | [S17](ejemplos/S17.json) |
| S18 | PUT /api/users/{usuario} | auth /users/{usuario} | sesión (administrador) | ruta: usuario; cuerpo: UsuarioReemplazo | 200 {id, username, nombre, rol, roles: [], activo, creadoEn} | 404 USUARIO_NO_ENCONTRADO, 409 AUTOEDICION_NO_PERMITIDA, 409 ULTIMO_ADMINISTRADOR, 422 CLAVE_DEBIL | secreto | RF10, RF12 | P08 | [S18](ejemplos/S18.json) |
| S19 | DELETE /api/users/{usuario} | auth /users/{usuario} | sesión (administrador) | ruta: usuario | 200 {id, activo} | 404 USUARIO_NO_ENCONTRADO, 409 AUTOEDICION_NO_PERMITIDA, 409 ULTIMO_ADMINISTRADOR | personal | RF10 | P08 | [S19](ejemplos/S19.json) |
| S20 | GET /api/delivery-zones | orders /delivery-zones | anónimo | — | 200 {reglas: {…}, comunas: [{…}]} |  | publico | RF1 | P01, P03, P08 | [S20](ejemplos/S20.json) |
| S21 | POST /api/orders | orders /orders | sesión (cliente) | cuerpo: PedidoIn; cabeceras: Idempotency-Key | 201 {id, fecha, origen, cliente: {…}, lineas: [{…}], subtotal, despacho, total, pago, estado, reembolso, historial: [{…}]} | 400 IDEMPOTENCY_KEY_INVALIDA, 403 CUENTA_DE_CLIENTE_REQUERIDA, 403 PROHIBIDO, 409 CLIENTE_INACTIVO, 409 DEMASIADOS_PEDIDOS_PENDIENTES, 409 ITEM_NO_DISPONIBLE, 422 CANTIDAD_EXCEDIDA, 422 COMUNA_SIN_COBERTURA, 422 CONFIRMAR_MAYORIA_EDAD, 422 ITEMS_INVALIDOS, 422 ITEM_INEXISTENTE, 422 MENOR_DE_EDAD, 503 SERVICIO_NO_DISPONIBLE | restringido | RF1, RF4 | P01 | [S21](ejemplos/S21.json) |
| S22 | GET /api/orders | orders /orders | sesión (cliente) | consulta: limit, offset | 200 [{id, fecha, origen, cliente: {…}, lineas: [{…}], subtotal, despacho, total, pago, estado, reembolso, historial: [{…}]}] | 403 PROHIBIDO | restringido | RF1 | — | [S22](ejemplos/S22.json) |
| S23 | GET /api/orders/{pedido} | orders /orders/{pedido} | sesión (cliente, administrador, despacho) | ruta: pedido | 200 {id, fecha, origen, cliente: {…}, lineas: [{…}], subtotal, despacho, total, pago, estado, reembolso, historial: [{…}]} | 403 PROHIBIDO, 404 PEDIDO_NO_ENCONTRADO | restringido | RF1, RF13 | — | [S23](ejemplos/S23.json) |
| S24 | POST /api/orders/{pedido}/cancellation | orders /orders/{pedido}/cancellation | sesión (cliente, administrador) | ruta: pedido; cuerpo: AnulacionIn | 200 {id, fecha, origen, cliente: {…}, lineas: [{…}], subtotal, despacho, total, pago, estado, reembolso, historial: [{…}], motivoAnulacion, anuladoPor, fechaAnulacion} | 403 PROHIBIDO, 404 PEDIDO_NO_ENCONTRADO, 409 CONFLICTO_DE_ESTADO, 409 NO_SE_PUEDE_ANULAR, 422 MOTIVO_INVALIDO | restringido | RF3 | P07, P08 | [S24](ejemplos/S24.json) |
| S25 | GET /api/admin/orders | orders /admin/orders | sesión (administrador, despacho) | consulta: estado, limit, offset | 200 [{id, fecha, origen, cliente: {…}, lineas: [{…}], subtotal, despacho, total, pago, estado, reembolso, historial: [{…}], clienteId}] | 400 FILTRO_INVALIDO | restringido | RF13 | P08 | [S25](ejemplos/S25.json) |
| S26 | PUT /api/admin/orders/{pedido}/status | orders /admin/orders/{pedido}/status | sesión (administrador, despacho) | ruta: pedido; cuerpo: EstadoIn | 200 {id, fecha, origen, cliente: {…}, lineas: [{…}], subtotal, despacho, total, pago, estado, reembolso, historial: [{…}], clienteId} | 404 PEDIDO_NO_ENCONTRADO, 409 CONFLICTO_DE_ESTADO, 409 TRANSICION_NO_PERMITIDA | restringido | RF13 | P08 | [S26](ejemplos/S26.json) |
| S27 | GET /api/event-config | orders /event-config | anónimo | — | 200 {minPersonas, maxPersonas, precioParrillero, menus: [{…}], extras: {…}} | 503 SERVICIO_NO_DISPONIBLE | publico | RF1 | P03 | [S27](ejemplos/S27.json) |
| S28 | POST /api/event-quotes | orders /event-quotes | anónimo | cuerpo: CotizacionIn | 201 {folio, estimado, detalle: [{…}], correo, personas} | 422 COMUNA_SIN_COBERTURA, 422 COTIZACION_INVALIDA, 422 FECHA_PASADA, 503 SERVICIO_NO_DISPONIBLE | personal | RF1 | P03 | [S28](ejemplos/S28.json) |
| S29 | POST /api/orders/{pedido}/payment | payments /orders/{pedido}/payment | sesión (cliente) | ruta: pedido | 201 {id, pedidoId, estado, medio, modo, monto, creadoEn, aprobadoEn, checkoutUrl, reembolso} | 403 PROHIBIDO, 404 PEDIDO_NO_ENCONTRADO, 409 PAGO_EN_PROCESO, 409 PEDIDO_NO_PAGABLE, 503 PROVEEDOR_PAGO_NO_DISPONIBLE, 503 SERVICIO_NO_DISPONIBLE | restringido | RF2, RF4 | P01, P07 | [S29](ejemplos/S29.json) |
| S30 | GET /api/orders/{pedido}/payment | payments /orders/{pedido}/payment | sesión (cliente, administrador) | ruta: pedido | 200 {id, pedidoId, estado, medio, modo, monto, creadoEn, aprobadoEn, checkoutUrl, reembolso} | 403 PROHIBIDO, 404 PEDIDO_NO_ENCONTRADO, 404 SIN_PAGO, 503 SERVICIO_NO_DISPONIBLE | restringido | RF2 | P07 | [S30](ejemplos/S30.json) |
| S31 | GET /api/orders/{pedido}/receipt | payments /orders/{pedido}/receipt | sesión (cliente, administrador) | ruta: pedido | 200 {folio, fecha, pedidoId, estado, emisor: {…}, cliente: {…}, lineas: [{…}], subtotal, despacho, neto, iva, ivaTasa, total, medioPago} | 403 PROHIBIDO, 404 PEDIDO_NO_ENCONTRADO, 404 SIN_BOLETA, 503 SERVICIO_NO_DISPONIBLE | restringido | RF8 | P07 | [S31](ejemplos/S31.json) |
| S32 | POST /api/admin/orders/{pedido}/payment-confirmation | payments /admin/orders/{pedido}/payment-confirmation | sesión (administrador) | ruta: pedido; cuerpo: ConfirmacionManual | 200 {resultado, pago: {…}} | 403 PROHIBIDO, 404 PEDIDO_NO_ENCONTRADO, 409 MEDIO_NO_MANUAL, 409 PEDIDO_NO_PAGABLE, 503 SERVICIO_NO_DISPONIBLE | restringido | RF2, RF4 | P08 | [S32](ejemplos/S32.json) |
| S33 | POST /api/admin/orders/{pedido}/refund | payments /admin/orders/{pedido}/refund | sesión (administrador) | ruta: pedido; cuerpo: ReembolsoIn | 200 {id, pedidoId, estado, medio, modo, monto, creadoEn, aprobadoEn, reembolso: {…}} | 404 SIN_REEMBOLSO, 422 REFERENCIA_REQUERIDA, 502 PROVEEDOR_RECHAZO, 503 PROVEEDOR_PAGO_NO_DISPONIBLE | restringido | RF3 | P08 | [S33](ejemplos/S33.json) |
| S34 | GET /api/admin/payments | payments /admin/payments | sesión (administrador) | consulta: estado, reembolso, modo, limit, offset | 200 [{id, pedidoId, estado, medio, modo, monto, creadoEn, aprobadoEn, reembolso}] |  | restringido | RF2 | P08 | [S34](ejemplos/S34.json) |
| S35 | POST /api/webhooks/provider | payments /webhooks/provider | firma del proveedor | cuerpo: bytes tal cual (firma del proveedor); cabeceras: X-Provider-Signature, X-Provider-Event-Id | 200 {ok, resultado} | 400 AVISO_NO_VALIDO, 409 MONTO_NO_COINCIDE, 409 PAGO_NO_COINCIDE, 413 CUERPO_DEMASIADO_GRANDE, 503 SECRETOS_NO_DISPONIBLES | restringido | RF2 | — | [S35](ejemplos/S35.json) |
| S36 | POST /api/contact-messages | notifications /contact-messages | anónimo | cuerpo: ContactoIn | 201 {id} | 422 CORREO_INVALIDO, 422 DESTINATARIO_INVALIDO | personal | — | P05 | [S36](ejemplos/S36.json) |
| S37 | GET /api/admin/outbox | notifications /outbox | sesión (administrador) | consulta: limit | 200 [{id, tipo, para, asunto, estado, intentos, creadoEn}] |  | restringido | RF8 | P08 | [S37](ejemplos/S37.json) |
| S38 | POST /api/graphql | graphql-gateway /graphql | sesión | cuerpo: JSON | 200 {data: {…}} | 400 SOLICITUD_INVALIDA, 413 CUERPO_DEMASIADO_GRANDE, 415 CONTENT_TYPE_INVALIDO, 504 CONSULTA_FUERA_DE_TIEMPO | restringido | RF1, RF9, RF13 | P07, P08 | [S38](ejemplos/S38.json) |

Los modelos de entrada (cada cuerpo JSON se valida con `extra="forbid"`: un campo no declarado se rechaza) están en [matrices/servicios_y_contratos.md](matrices/servicios_y_contratos.md).

### 1.2 Ejemplos JSON capturados

Se ejecutó el sistema completo y se guardó una petición y una respuesta reales de **cada** uno de los 38 servicios en [`docs/ejemplos/`](ejemplos/). Los valores secretos (cookie, claves, firmas) están enmascarados. Cuatro ejemplos representativos:

**S01** · petición

```http
POST /api/auth/login
origin: http://127.0.0.1:45531
content-type: application/json
{
  "username": "prueba49503846@correo.cl",
  "password": "«secreto»"
}
```

respuesta

```http
HTTP 200
content-type: application/json
set-cookie: session_token=«valor secreto»; HttpOnly; Max-Age=7200; Path=/; SameSite=lax
x-request-id: b4945c3a3e054131
cache-control: no-store
{
  "usuario": {
    "user_id": "u-88a3b2720067",
    "username": "prueba49503846@correo.cl",
    "nombre": "Cliente De Prueba",
    "roles": [
      "cliente"
    ],
    "client_id": "c-f51311091a"
  },
  "expira_en": 7200
}
```

**S21** · petición

```http
POST /api/orders
origin: http://127.0.0.1:45531
idempotency-key: 8ff630136c4e41f884028114b30254cd
content-type: application/json
{
  "items": [
    {
      "id": "p07",
      "cantidad": 1
    }
  ],
  "comuna": "Ñuñoa",
  "medioPago": "Servipag"
}
```

respuesta

```http
HTTP 201
content-type: application/json
x-request-id: 77b54087defc48f3
cache-control: no-store
{
  "id": "A-1042",
  "fecha": "2026-11-05T06:34:05.091Z",
  "origen": "web",
  "cliente": {
    "nombre": "Cliente De Prueba",
    "correo": "prueba49503846@correo.cl",
    "telefono": "+56 9 1234 5678",
    "direccion": "Calle Falsa 123",
    "comuna": "Ñuñoa",
    "indicaciones": ""
  },
  "lineas": [
    {
      "itemId": "p07",
      "nombre": "Choripán x4",
      "cantidad": 1,
      "precio": 7990
    }
  ],
  "subtotal": 7990,
  "despacho": 0,
  "total": 7990,
  "pago": "Servipag",
  "estado": "Pago pendiente",
  "reembolso": "no_aplica",
  "historial": [
    {
      "estado": "Pago pendiente",
      "fecha": "2026-11-05T06:34:05.091Z",
      "por": "Cliente"
    }
  ]
}
```

**S35** · petición

```http
POST /api/webhooks/provider
content-type: application/json
x-provider-signature: «firma HMAC»
x-provider-event-id: evt_4d65c87078ff4fda
{
  "id": "evt_4d65c87078ff4fda",
  "type": "payment.succeeded",
  "created": 1793860445,
  "data": {
    "payment_id": "prv_5smN7IdqZHUlgn2kIVE",
    "reference": "pay-08dfc5f5bcdb494e",
    "amount": 7990,
    "currency": "CLP"
  }
}
```

respuesta

```http
HTTP 200
content-type: application/json
x-request-id: 926b3b7d28244db4
cache-control: no-store
{
  "ok": true,
  "resultado": "aprobado"
}
```

**S38** · petición

```http
POST /api/graphql
origin: http://127.0.0.1:45531
content-type: application/json
{
  "query": "query MisPedidos($desde: Int!) { misPedidos(limit: 20, offset: $desde) { total items { id fecha estado subtotal despacho total medioPago reembolso motivoAnulacion anuladoPor fechaAnulacion cliente { nombre direccion comuna } lineas { nombre cantidad precio subtotal } pago { id estado medio monto checkoutUrl instrucciones reembolso } boleta { folio total estado } } } }",
  "variables": {
    "desde": 0
  }
}
```

respuesta

```http
HTTP 200
content-type: application/json
x-request-id: ad52e64ad2364fa8
cache-control: no-store
{
  "data": {
    "misPedidos": {
      "total": 1,
      "items": [
        {
          "id": "A-1042",
          "fecha": "2026-11-05T06:34:05.091Z",
          "estado": "En preparación",
          "subtotal": 7990,
          "despacho": 0,
          "total": 7990,
          "medioPago": "Servipag",
          "reembolso": "no_aplica",
          "motivoAnulacion": null,
          "anuladoPor": null,
          "fechaAnulacion": null,
          "cliente": {
            "nombre": "Cliente De Prueba",
            "direccion": "Calle Falsa 123",
            "comuna": "Ñuñoa"
          },
          "lineas": [
            {
              "nombre": "Choripán x4",
              "cantidad": 1,
              "precio": 7990,
              "subtotal": 7990
            }
          ],
          "pago": {
            "id": "pay-1c6c92e357df418f",
            "estado": "aprobado",
            "medio": "Servipag",
            "monto": 7990,
            "checkoutUrl": null,
            "instrucciones": null,
            "reembolso": null
          },
          "boleta": {
            "folio": "B-000001",
            "total": 7990,
            "estado": "vigente"
          }
        }
      ]
    }
  }
}
```

### 1.3 Trazabilidad requisito → pantalla → servicio → prueba → resultado → evidencia

Generada por `scripts/generar_trazabilidad.py`. Pantallas y servicios salen de la tabla de rutas del API Gateway (`api-gateway/app/rutas.py`); los resultados, de los informes JUnit guardados en `docs/evidencia/` (no se escribe ningún resultado a mano).

**Origen de los requisitos:** RF1–RF13, CU1–CU9 y RNF1–RNF16 siguen la estructura de requisitos del caso de referencia de la asignatura, adaptados a «El Asador» con lo que muestran las pantallas del frontend de la C2. Está declarado en la portada del informe.

#### Requisitos funcionales

| Requisito | Pantallas | Servicios | Pruebas (cantidad que lo ejercitan) | Resultado (simulado) | Resultado (Vault y MongoDB reales) | Evidencia |
|---|---|---|---|---|---|---|
| **RF1** Armar un pedido con los productos disponibles de la carta (CU5 Genera pedido) | P01, P02, P03, P07, P08 | S04, S05, S20, S21, S22, S23, S27, S28, S38 | `test_graphql` (3); `test_negocio_administracion` (5); `test_negocio_pedidos` (32); `test_unidad_reglas` (12) | 52 de 52 ✓ | 52 de 52 ✓ | [S04](ejemplos/S04.json), [S05](ejemplos/S05.json), [S20](ejemplos/S20.json), …; [controles M8](evidencia/controles.md) |
| **RF2** La orden se prepara solo tras confirmar el pago (CU6 Realizar venta) | P01, P07, P08 | S29, S30, S32, S34, S35 | `test_negocio_pagos` (24); `test_negocio_pedidos` (1); `test_unidad_carreras` (21); `test_unidad_reglas` (2) | 48 de 48 ✓ | 48 de 48 ✓ | [S29](ejemplos/S29.json), [S30](ejemplos/S30.json), [S32](ejemplos/S32.json), …; [controles C6](evidencia/controles.md) |
| **RF3** Anular una compra indicando el motivo (CU7 Anular compra) | P07, P08 | S24, S33 | `test_analitica` (6); `test_negocio_pagos` (5); `test_negocio_pedidos` (3); `test_unidad_reglas` (2) | 16 de 16 ✓ | 16 de 16 ✓ | [S24](ejemplos/S24.json), [S33](ejemplos/S33.json); [S24](ejemplos/S24.json), [S33](ejemplos/S33.json) |
| **RF4** Vender únicamente pedidos de clientes registrados (caja del cajero virtual) (CU6 Realizar venta) | P01, P07, P08 | S21, S29, S32 | `test_analitica` (1); `test_negocio_pagos` (2); `test_negocio_pedidos` (3); `test_seguridad_acceso` (6) | 12 de 12 ✓ | 12 de 12 ✓ | [S21](ejemplos/S21.json), [S29](ejemplos/S29.json), [S32](ejemplos/S32.json) |
| **RF5** Registro de clientes con todos sus datos y correo existente (CU3 Administrar clientes) | P01, P06 | S10, S11 | `test_negocio_administracion` (19); `test_unidad_reglas` (26) | 45 de 45 ✓ | 45 de 45 ✓ | [S10](ejemplos/S10.json), [S11](ejemplos/S11.json) |
| **RF6** Registro de clientes en el local por el administrador (CU3 Administrar clientes) | P08 | S12, S13 | `test_negocio_administracion` (5) | 5 de 5 ✓ | 5 de 5 ✓ | [S12](ejemplos/S12.json), [S13](ejemplos/S13.json) |
| **RF7** Administrar la disponibilidad de cada producto (CU4 Administrar productos) | P01, P02, P08 | S04, S06, S07, S08 | `test_negocio_administracion` (23); `test_unidad_reglas` (9) | 32 de 32 ✓ | 32 de 32 ✓ | [S04](ejemplos/S04.json), [S06](ejemplos/S06.json), [S07](ejemplos/S07.json), … |
| **RF8** Boleta digital por cada venta, enviada por correo (CU6 Realizar venta) | P07, P08 | S31, S37 | `test_graphql` (1); `test_negocio_administracion` (1); `test_negocio_pagos` (2) | 4 de 4 ✓ | 4 de 4 ✓ | [S31](ejemplos/S31.json), [S37](ejemplos/S37.json); el envío real por SMTP no se probó; la boleta queda en la bandeja de salida (S37) |
| **RF9** Reporte de ventas por período para el dueño (CU8 Generar reporte de ventas) | P07, P08 | S38 | `test_analitica` (7); `test_graphql` (1); `test_unidad_reglas` (1) | 9 de 9 ✓ | 9 de 9 ✓ | [S38](ejemplos/S38.json); [carga](evidencia/carga.md), [GraphQL](matrices/graphql.md) |
| **RF10** Mantenedores de productos, usuarios y clientes (CU2/CU3/CU4) | P08 | S06, S07, S09, S12, S14, S15, S16, S17, S18, S19 | `test_negocio_administracion` (69) | 69 de 69 ✓ | 69 de 69 ✓ | [S06](ejemplos/S06.json), [S07](ejemplos/S07.json), [S09](ejemplos/S09.json), … |
| **RF11** Validar que el correo existe mediante una API de mensajería (CU3 Administrar clientes) | P06, P08 | S10, S13 | `test_negocio_administracion` (6) | 6 de 6 ✓ | 6 de 6 ✓ | [S10](ejemplos/S10.json), [S13](ejemplos/S13.json); proveedor de correo de prueba (`sandbox`): el buzón «no existe» por convención de nombre o dominio; la validación por DNS MX y el envío SMTP existen en el código pero no se probaron |
| **RF12** Autenticación de usuarios y acceso según perfil (CU1 Autenticar usuarios) | P01, P02, P03, P04, P05, P06, P07, P08, P09 | S01, S02, S03, S16, S17, S18 | `test_graphql` (1); `test_limites_tasa` (4); `test_negocio_administracion` (4); `test_seguridad_acceso` (89) | 98 de 98 ✓ | 98 de 98 ✓ | [S01](ejemplos/S01.json), [S02](ejemplos/S02.json), [S03](ejemplos/S03.json), …; [controles C2, C3](evidencia/controles.md) |
| **RF13** Orden de despacho en el orden de llegada (imprimible) (CU9 Obtener orden de despacho) | P07, P08 | S23, S25, S26, S38 | `test_graphql` (1); `test_negocio_pedidos` (4); `test_unidad_reglas` (1) | 6 de 6 ✓ | 6 de 6 ✓ | [S23](ejemplos/S23.json), [S25](ejemplos/S25.json), [S26](ejemplos/S26.json), …; [S25](ejemplos/S25.json), [S26](ejemplos/S26.json); la impresión la hace el panel del frontend de la C2 (no incluido en esta entrega); el backend entrega la orden de despacho en el orden de llegada |

Pantallas: **P01** index.html · Inicio; **P02** productos.html · Carta y carrito; **P03** servicios.html · Servicios y cotizador de eventos; **P04** empresa.html · Empresa; **P05** contacto.html · Contacto; **P06** registro.html · Registro de clientes; **P07** pedidos.html · Mis pedidos, pago y boleta; **P08** admin.html · Panel interno (ventas, productos, clientes, usuarios, despacho); **P09** Ventana «Acceder» y menú de cuenta (todas las páginas).

#### Requisitos no funcionales con prueba

| Requisito | Estado | Pruebas | Resultado (simulado) | Resultado (reales) | Evidencia |
|---|---|---|---|---|---|
| **RNF2** Capas separadas: interfaz, reglas de negocio y datos | cumple | `test_despliegue` (4); `test_segunda_capa` (4) | 8 de 8 ✓ | 8 de 8 ✓ | [diagrama de componentes](diagramas/03-componentes-y-redes.mmd), [ADR-005](adr/ADR-005-base-de-datos-por-servicio.md) |
| **RNF5** Integración entre sistemas por servicios web | cumple | `test_segunda_capa` (61); `test_seguridad_acceso` (20) | 81 de 81 ✓ | 81 de 81 ✓ | [llamadas entre servicios](matrices/llamadas_entre_servicios.md) |
| **RNF6** API de correo para envío y validación de cuentas | cumple con proveedor de prueba (`sandbox`); MX y SMTP no probados | `test_negocio_administracion` (13) | 13 de 13 ✓ | 13 de 13 ✓ | [ADR-012](adr/ADR-012-pila-tecnologica.md) |
| **RNF7** Cifrado de clave y control de sesiones | cumple | `test_infraestructura_real` (1); `test_limites_tasa` (2); `test_seguridad_acceso` (4); `test_sesion_vence` (2); `test_unidad_reglas` (1) | 9 de 10 ✓, 1 omitidas | 10 de 10 ✓ | [ADR-002](adr/ADR-002-sesion-opaca-en-cookie.md), [controles](evidencia/controles.md). El hash argon2id en MongoDB real se comprueba solo en la ejecución con servicios reales |
| **RNF8** Validaciones en todas las entradas | cumple | `test_graphql` (6); `test_negocio_administracion` (58); `test_seguridad_acceso` (20); `test_unidad_reglas` (39) | 123 de 123 ✓ | 123 de 123 ✓ | [modelos de entrada](matrices/servicios_y_contratos.md) |
| **RNF13** Mensajes de error informativos y orientados al usuario final | cumple | `test_graphql` (2); `test_negocio_pedidos` (4); `test_seguridad_acceso` (1) | 7 de 7 ✓ | 7 de 7 ✓ | [ejemplos](ejemplos) |

#### Requisitos no funcionales con tratamiento distinto (declarado)

| Requisito | Tratamiento | Motivo |
|---|---|---|
| RNF1 Ambiente web | Parcial | La interfaz web es el frontend de la C2, que no forma parte del proyecto del backend y no está conectado a él; el backend expone la API que ese frontend consumirá y se prueba por HTTP. La integración se valida en la Evaluación 3. |
| RNF3 Oracle y .NET/J2EE | **Desviación** | Se conservan las restricciones del curso: FastAPI + MongoDB ([ADR-012](adr/ADR-012-pila-tecnologica.md)). |
| RNF4 Procedimientos almacenados y estructura para avisos | **Desviación** | Bandeja de salida (`outbox`) con reintentos, consultable por el administrador (S37). |
| RNF9 Interfaz con elementos de Windows | No aplica | La interfaz es web con Bootstrap 5. |
| RNF10 Aprendizaje < 4 h; RNF11 errores < 1 % | **No medidos** | Requieren usuarios reales; no se afirma cumplimiento. |
| RNF12 Manuales; RNF14 Ayuda en línea | Parcial | La ayuda en línea es parte del frontend de la C2 (no incluido en esta entrega); no hay manual de usuario separado. |
| RNF15 Diseño responsivo | **No evaluable aquí** | Es una propiedad del frontend; el backend no la determina. Se valida con la integración (Evaluación 3). |
| RNF16 Interfaces bien formadas | **No verificado** | Es una propiedad del frontend (no incluido en esta entrega); no se ejecutó ningún validador de HTML. |

---

## M2 UML de dominio y de servicios

### 2.1 Modelo de dominio

```mermaid
classDiagram
    direction LR
    class Usuario {
        +id : u-xxxx
        +username : correo
        +nombre
        +rol : administrador|dueno|despacho|cliente
        +activo : bool
        +passwordHash : argon2id
        +intentosFallidos
        +bloqueadoHasta
    }
    class Sesion {
        +id : SHA-256 del token
        +userId
        +expira
    }
    class Cliente {
        +id : c-xxxx
        +run
        +nombre
        +correo
        +telefono
        +direccion
        +comuna / provincia / region
        +nacimiento / sexo
        +estado : activo|inactivo
        +origen : Web|Local
        +tieneAcceso
    }
    class Producto {
        +id : p01..
        +categoria
        +nombre
        +precio : CLP
        +disponible : bool
        +alcohol : bool
    }
    class Promocion {
        +id
        +descuento
        +vigencia
        +activa
    }
    class ZonaDespacho {
        +comuna
        +km
    }
    class Pedido {
        +id : A-nnnn
        +estado
        +subtotal / despacho / total
        +medioPago
        +claveIdempotencia
        +reembolso
    }
    class LineaPedido {
        +itemId
        +nombre (copia)
        +precio (copia)
        +cantidad 1..20
    }
    class HitoEstado {
        +estado
        +fecha
        +por
    }
    class Pago {
        +id : pay-xxxx
        +estado : iniciado|aprobado|rechazado|cancelado
        +modo : proveedor|manual
        +monto
        +origenAprobacion
    }
    class Reembolso {
        +estado : pendiente|realizado
        +motivo
        +automatico
    }
    class Venta {
        +folio : B-nnnnnn
        +total / neto / iva
        +estado : vigente|anulada
    }
    class EventoProveedor {
        +id : evt_xxxx
        +tipo
    }
    class CorreoEnviado {
        +tipo
        +para (enmascarado al listar)
        +estado / intentos
        +clave : idempotencia
    }
    class MensajeContacto
    class VentaAnalitica {
        +eventoId : venta:folio
        +fechaLocal
        +total
        +estado
    }

    Usuario "1" --> "0..*" Sesion : abre
    Cliente "0..1" -- "1" Usuario : credencial web (authUserId)
    Cliente "1" --> "0..*" Pedido : realiza
    Pedido "1" *-- "1..30" LineaPedido : contiene
    Pedido "1" *-- "1..*" HitoEstado : historial
    LineaPedido "0..*" ..> "1" Producto : copia precio de
    Promocion "0..*" o-- "1..*" Producto : agrupa
    Pedido "0..*" ..> "1" ZonaDespacho : despacho según comuna
    Pedido "1" --> "0..*" Pago : se paga con
    Pago "1" *-- "0..1" Reembolso : devolución
    Pago "1" --> "0..1" Venta : origina
    Venta "1" --> "1" Pedido : de
    Venta "1" ..> "0..1" CorreoEnviado : boleta
    Venta "1" ..> "1" VentaAnalitica : evento idempotente
    Pago "1" ..> "0..*" EventoProveedor : avisos firmados
    MensajeContacto ..> CorreoEnviado : autorrespuesta
```

**Notación.** Multiplicidades `1`, `0..1`, `0..*` y `1..*` en ambos extremos. `◆` composición (la parte no existe sin el todo), `◇` agregación, `→` asociación dirigida, `⇢` dependencia de uso (no relaciona registros de negocio), `«service»` servicio público. El diagrama es editable (Mermaid, texto plano en `docs/diagramas/01-dominio.mmd`).

### 2.2 Cardinalidades y regla de negocio que las justifica

| Relación | Cardinalidad | Regla de negocio | Dónde se aplica y prueba |
|---|---|---|---|
| Cliente — Pedido | 1 → 0..* | Cada cliente puede tener como máximo 5 pedidos en «Pago pendiente» a la vez (variable `MAX_PEDIDOS_PENDIENTES`), para que un cliente no acapare la cola ni llene la base con pedidos sin pagar. | `orders` · `test_maximo_de_pedidos_pendientes_por_cliente` |
| Pedido — LineaPedido | 1 ◆→ 1..30 | Un pedido sin líneas no existe y hay un tope de 30 líneas con 1 a 20 unidades cada una. | `orders` (modelo `PedidoIn`) · `test_limites_de_cantidad` |
| LineaPedido — Producto | 0..* ⇢ 1 | La línea **copia** el precio vigente al crear el pedido; un cambio posterior del catálogo no altera pedidos ya creados. | `orders` · `test_el_precio_del_pedido_es_el_vigente_en_el_servidor_y_no_cambia_despues` |
| Promoción — Producto | 0..* ◇→ 1..* | Un producto que forma parte de una promoción activa no se puede retirar de la carta. | `inventory` · `test_un_producto_que_forma_parte_de_una_promocion_activa_no_se_puede_retirar` |
| Pedido — ZonaDespacho | 0..* ⇢ 1 | El costo de despacho depende de la comuna; una comuna sin cobertura se rechaza. | `orders` · `test_comuna_sin_cobertura`, `test_costo_de_despacho_segun_la_comuna` |
| Pedido — Pago | 1 → 0..* | Un pago rechazado deja el pedido pendiente y se puede reintentar; por eso un pedido puede tener varios intentos, pero **solo uno queda aprobado** aunque lleguen avisos simultáneos. | `payments` · `test_pago_rechazado_deja_el_pedido_pendiente_y_se_puede_reintentar`, `test_dos_avisos_simultaneos_aprueban_solo_uno` |
| Pago — Reembolso | 1 ◆→ 0..1 | Solo hay reembolso si un pedido ya pagado se anula; lo registra el administrador o el proveedor. | `payments` · `test_anular_un_pedido_pagado_manualmente_genera_reembolso_pendiente` |
| Pago — Venta | 1 → 0..1 | La venta (y su boleta) nace únicamente de un pago aprobado. | `payments` · `test_flujo_completo_con_el_proveedor` |
| Venta — VentaAnalitica | 1 ⇢ 1 | La analítica recibe cada venta como evento **idempotente** (clave natural: el folio de la venta); repetirlo no la cuenta dos veces y anularla la resta una sola vez. | `analytics` · `test_un_evento_repetido_no_cambia_el_reporte`, `test_la_anulacion_resta_la_venta_y_repetirla_no_resta_dos_veces` |
| Cliente — Usuario | 0..1 — 1 | Un cliente dado de alta en el local puede no tener acceso web; las credenciales viven en `auth`, los datos personales en `clients`. | `clients` · `test_un_cliente_dado_de_alta_en_el_local_puede_activar_su_acceso_web` |
| Usuario — Sesión | 1 → 0..* | Cambiar la clave, el rol o desactivar al usuario cierra todas sus sesiones abiertas. | `auth` · `test_cambiar_la_clave_cierra_las_sesiones_abiertas_y_la_clave_vieja_deja_de_servir` |

### 2.3 Servicios y sus operaciones

Cada operación lleva el ID del servicio del módulo 1 (S01 a S38); `«port»` es el gestor de secretos y `«externo»` un tercero.

```mermaid
classDiagram
    direction LR
    class ApiGateway {
        <<service>>
        +login() S01
        +logout() S02
        +me() S03
        +reenviar(Ruta) S04..S37
    }
    class AuthService {
        <<service>>
        +login(LoginIn)
        +introspect(token)
        +logout(token)
        +usuarios CRUD (S16..S19)
        +credenciales de cliente (interno)
    }
    class ClientsService {
        <<service>>
        +register(RegistroWeb) S10
        +me() S11
        +clientes CRUD (S12..S15)
        +delivery-profile (interno)
    }
    class InventoryService {
        <<service>>
        +products (S04, S06..S09)
        +promos (S05)
        +pricing/resolve (interno)
    }
    class OrdersService {
        <<service>>
        +crear / listar / ver pedido (S21..S23)
        +anular (S24)
        +despacho: listar / avanzar (S25, S26)
        +zonas y cotización (S20, S27, S28)
        +payable / payment-confirmed / refund-done (interno)
    }
    class PaymentsService {
        <<service>>
        +iniciar y ver pago (S29, S30)
        +boleta (S31)
        +confirmación manual y reembolso (S32, S33)
        +listado (S34)
        +webhook del proveedor (S35)
        +payment-cancel (interno)
    }
    class NotificationsService {
        <<service>>
        +contacto (S36)
        +bandeja (S37)
        +validate / send (interno)
    }
    class AnalyticsService {
        <<service>>
        +sale-registered / sale-reversed (interno)
        +reports/sales (interno)
    }
    class GraphQLGateway {
        <<service>>
        +graphql (S38) misPedidos, pedidosAdmin, panelAdmin, reporteVentas
    }
    class VaultSecrets {
        <<port>>
        +valor(ruta)
    }
    class ProveedorPago {
        <<externo>>
    }
    class ProveedorCorreo {
        <<externo>>
    }
    ApiGateway ..> AuthService : introspección + login
    ApiGateway ..> ClientsService
    ApiGateway ..> InventoryService
    ApiGateway ..> OrdersService
    ApiGateway ..> PaymentsService
    ApiGateway ..> NotificationsService
    ApiGateway ..> GraphQLGateway
    GraphQLGateway ..> OrdersService : solo lectura
    GraphQLGateway ..> PaymentsService : solo lectura
    GraphQLGateway ..> InventoryService : solo lectura
    GraphQLGateway ..> AnalyticsService : solo lectura
    ClientsService ..> AuthService : crea credencial (saga)
    ClientsService ..> NotificationsService : valida correo
    OrdersService ..> ClientsService : perfil de entrega
    OrdersService ..> InventoryService : precios y disponibilidad
    OrdersService ..> PaymentsService : cancelar pago
    OrdersService ..> NotificationsService : cotización
    PaymentsService ..> OrdersService : monto y confirmación
    PaymentsService ..> AnalyticsService : eventos de venta
    PaymentsService ..> NotificationsService : boleta
    PaymentsService ..> ProveedorPago : cobro y conciliación
    NotificationsService ..> ProveedorCorreo : validar y enviar
    ApiGateway ..> VaultSecrets
    AuthService ..> VaultSecrets
    PaymentsService ..> VaultSecrets
```

### 2.4 Ciclo de vida del pedido

```mermaid
stateDiagram-v2
    [*] --> PagoPendiente: POST /orders (cliente)
    PagoPendiente --> EnPreparacion: payments confirma el pago (servicio, nunca el navegador)
    EnPreparacion --> EnCamino: despacho / administrador
    EnCamino --> Entregado: despacho / administrador
    PagoPendiente --> Anulado: cliente / administrador
    EnPreparacion --> Anulado: cliente / administrador (queda reembolso pendiente)
    Entregado --> [*]
    Anulado --> [*]
    PagoPendiente: Pago pendiente
    EnPreparacion: En preparación
    EnCamino: En camino
```

Solo el servicio `payments` puede mover un pedido de «Pago pendiente» a «En preparación»; el navegador no tiene ninguna ruta hacia esa transición (ADR-007). Una prueba unitaria compara la máquina de estados del código con esta tabla (`test_maquina_de_estados_coincide_con_la_tabla`).

---

## M3 Sistemas y persistencia

### 3.1 Matriz de sistemas

| Sistema | Responsabilidad | Datos que administra | Servicios asociados | Dependencias | Contrato de integración | Credencial o identidad requerida | Respuesta ante fallos |
|---|---|---|---|---|---|---|---|
| Navegador (frontend de la C2, no incluido) | Interfaz de las 8 páginas; no decide precios, pagos ni permisos | Cookie de sesión `HttpOnly`; solo el carrito (ids y cantidades) y la comuna en el navegador | Los 38 (S01–S38), solo a través del gateway | `api-gateway` | HTTP/JSON bajo `/api` en `127.0.0.1:8000` | Cookie de sesión opaca; ningún secreto | Recibe un error controlado, sin trazas ni nombres internos (ADR-010) |
| `api-gateway` | Única puerta pública: tabla de rutas, sesión, rol, origen, límite de tasa | Ninguno (caché del catálogo y contadores de tasa en memoria) | S01–S38 (las reenvía) | Todos los servicios, `vault` | Tabla de 38 rutas; hacia los servicios, HTTP/JSON con `X-Service-Name` y `X-Service-Secret` | Un secreto por destino (7 pares `api-gateway→X`) y token de Vault propio; descarta las cabeceras de identidad del navegador | Plazo de 6 s; 503/504 controlados; cortacircuitos; con `inventory` caído sirve la carta desde su caché corta (solo GET anónimos) |
| `auth` | Credenciales (argon2id) y sesiones | MongoDB `auth`: `usuarios`, `sesiones` | S01–S03, S16–S19 | MongoDB `auth`, `vault` | REST interno: `/login`, `/logout`, `/introspect`, `/users`, `/internal/credentials` | Secretos `api-gateway→auth` y `clients→auth`; usuario propio de MongoDB; token de Vault propio | Si no responde, las rutas con sesión no se atienden (error controlado) y la carta pública sigue; nadie pierde la sesión (ADR-010) |
| `clients` | Datos personales del cliente; registro como saga | MongoDB `clients`: `clientes` | S10–S15 | `auth`, `notifications`, MongoDB `clients`, `vault` | REST: `/clients`, `/clients/register`; interno: `/internal/clients/{id}/delivery-profile` | Secretos `api-gateway→clients`, `orders→clients` (entrantes), `clients→auth`, `clients→notifications` (salientes) | Registro idempotente como saga: repetirlo lo completa sin duplicar (ADR-011); 503 si `auth` o `notifications` no responden |
| `inventory` | Productos, promociones, precios y disponibilidad; autoridad del precio | MongoDB `inventory`: `productos`, `promos`, `contadores` | S04–S09 | MongoDB `inventory`, `vault` | REST: `/products`, `/promos`; interno: `/internal/items`, `/internal/pricing/resolve`, `/internal/summary` | Secretos `api-gateway→inventory`, `orders→inventory`, `graphql-gateway→inventory` | Si no responde, `orders` no crea pedidos (503: no puede fijar el precio) y la carta se sirve unos segundos desde la caché del gateway |
| `orders` | Pedidos, estado oficial, despacho y cotización de eventos | MongoDB `orders`: `pedidos`, `zonas`, `config`, `cotizaciones_evento`, `contadores` | S20–S28 | `clients`, `inventory`, `payments`, `notifications`, MongoDB `orders`, `vault` | REST: `/orders`, `/admin/orders`; interno: `payable`, `payment-confirmed`, `refund-done` | Entrantes: `api-gateway→orders`, `graphql-gateway→orders`, `payments→orders`; salientes: `orders→clients`, `→inventory`, `→payments`, `→notifications` | Pedido con clave de idempotencia (el reintento no duplica, ADR-006); anular primero y reintentar el cobro por cancelar (ADR-008) |
| `payments` | Pagos, ventas y boletas, reembolsos, conciliación; único que confirma un pago | MongoDB `payments`: `pagos`, `ventas`, `eventos_proveedor`, `contadores` | S29–S35 | `orders`, `analytics`, `notifications`, proveedor de pagos, MongoDB `payments`, `vault` | REST: pago de un pedido, administración de pagos, `/webhooks/provider`; interno: resumen y pagos por pedido | Entrantes: `api-gateway→payments`, `orders→payments`, `graphql-gateway→payments`; salientes: `payments→orders`, `→notifications`, `→analytics`; `provider/api-key` hacia el proveedor y `provider/webhook-secret` para verificar la firma de sus avisos | Un aviso repetido no aprueba dos veces (por identificador de evento); conciliación periódica; boleta, evento de analítica y reverso se reintentan en ciclos (ADR-007, ADR-008); proveedor caído: 503 `PROVEEDOR_PAGO_NO_DISPONIBLE` |
| `notifications` | Validación de correos, bandeja de salida, mensajes de contacto | MongoDB `notifications`: `bandeja`, `mensajes_contacto` | S36, S37 | Proveedor de correo (adaptador), MongoDB `notifications`, `vault` | REST: `/contact-messages`, `/outbox`; interno: `/internal/email/send`, `/internal/email/validate` | Secretos `api-gateway→notifications`, `clients→notifications`, `orders→notifications`, `payments→notifications`; `email/smtp` solo con `EMAIL_PROVIDER=smtp` | Bandeja de salida con reintentos y clave de idempotencia por correo; un correo que falla no bloquea la venta (ADR-008) |
| `analytics` | Reportes de ventas por período (modelo de lectura) | MongoDB `analytics`: `ventas`, `eventos`, `historico` | Ninguno público; se consulta por S38 | MongoDB `analytics`, `vault` | Interno: eventos `sale-registered` y `sale-reversed`; consulta `/internal/reports/sales` | Secretos `payments→analytics` y `graphql-gateway→analytics` | Eventos idempotentes (clave: el folio de la venta) y tolerantes al desorden; si cae, el pago no se bloquea y `payments` reenvía en su ciclo (ADR-008) |
| `graphql-gateway` | Consultas compuestas de solo lectura | Ninguno | S38 | `orders`, `inventory`, `payments`, `analytics` | `POST /graphql` (interno) | Entrante: `api-gateway→graphql-gateway`; salientes: un secreto por servicio consultado, que solo permite `GET` | Respuesta parcial: si `payments` no responde, «Mis pedidos» se ve sin el dato del pago; toda la consulta tiene un tope de 5 s (ADR-010) |
| `provider-sandbox` | Proveedor de pagos simulado: API con clave, página de pago y avisos firmados | Cobros en memoria | S35 (es quien la invoca) | `api-gateway` (aviso), `vault` | API `/v1/...` con clave; aviso con firma HMAC-SHA256 | `provider/api-key` (la verifica) y `provider/webhook-secret` (firma con ella) | Si no responde, `payments` devuelve 503 y el pedido sigue pendiente; un aviso perdido se recupera por conciliación (ADR-007) |
| `vault` | Secretos de servicio a servicio y credenciales de base de datos | Memoria (modo desarrollo; se vuelve a sembrar al arrancar) | — | — | HTTP, KV v2; solo lectura para los servicios | Token propio por servicio, con política de solo lectura sobre SUS secretos | Cada servicio conserva una caché y sigue sirviendo; sin caché, falla cerrado (ADR-003) |
| `vault-seed` | Tarea de arranque: carga los secretos y crea una política y un token por servicio | — | — | `vault` | `scripts/seed_vault.py` con `secrets/manifest.tsv` | Token raíz del Vault de desarrollo, solo durante el arranque | Termina por diseño; si falla, los servicios que dependen de ella no arrancan |
| `mongo` | Almacén de datos | Volumen `mongo-datos`: una base por servicio | — | — | Protocolo de MongoDB, solo red interna | Un usuario por servicio, con permisos solo sobre SU base (`db/<servicio>`) | Un servicio sin su base responde con error controlado; el resto del sistema sigue (ADR-010) |

Exposición: solo `api-gateway` (`127.0.0.1:8000`) y `provider-sandbox` (`127.0.0.1:8300`, página de pago) publican puertos; todo lo demás está en la red interna.

### 3.2 Mapa de componentes y redes

El mapa también está escrito como modelo C4 editable en Structurizr DSL: `docs/diagramas/El-Asador.dsl`.

```mermaid
flowchart TB
    subgraph EXT["Zona no confiable (Internet / navegador)"]
        NAV["Navegador\nHTML + JS (responsive)"]
        PROV["Proveedor de pagos\n(simulado: provider-sandbox)"]
    end
    subgraph PUB["Red «publica»"]
        GW["api-gateway :8000\nunico acceso al sistema"]
        SB["provider-sandbox :8300"]
    end
    subgraph INT["Red «interna» (internal: true, sin salida a Internet)"]
        GQL["graphql-gateway"]
        AUTH["auth"]
        CLI["clients"]
        INV["inventory"]
        ORD["orders"]
        PAY["payments"]
        NOT["notifications"]
        ANA["analytics"]
        VAULT[("Vault\nsecretos")]
        MONGO[("MongoDB\nuna base y un usuario por servicio")]
    end
    NAV -->|"HTTPS/HTTP + cookie HttpOnly"| GW
    NAV -->|"paga en la pagina del proveedor"| SB
    SB -->|"webhook firmado (HMAC)"| GW
    GW --> AUTH & CLI & INV & ORD & PAY & NOT & GQL
    GQL --> ORD & PAY & INV & ANA
    CLI --> AUTH & NOT
    ORD --> CLI & INV & PAY & NOT
    PAY --> ORD & ANA & NOT
    PAY -. "cobro / conciliacion" .-> SB
    AUTH & CLI & INV & ORD & PAY & NOT & ANA --> MONGO
    GW & GQL & AUTH & CLI & INV & ORD & PAY & NOT & ANA -. "secretos (token propio, solo lectura)" .-> VAULT
    PROV -.- SB
```

### 3.3 Secuencia de integración

**Compra con pago en línea** (RF1, RF2, RF4, RF8):

```mermaid
sequenceDiagram
    autonumber
    actor C as Cliente (navegador)
    participant GW as api-gateway
    participant AU as auth
    participant CL as clients
    participant OR as orders
    participant IN as inventory
    participant PA as payments
    participant PV as proveedor de pagos
    participant AN as analytics
    participant NO as notifications
    C->>GW: POST /api/clients/register (S10)
    GW->>CL: registrar (secreto del par gateway→clients)
    CL->>NO: ¿el correo existe? (S validate)
    CL->>AU: crear credencial (argon2id)
    C->>GW: POST /api/auth/login (S01)
    GW->>AU: login → token opaco
    GW-->>C: Set-Cookie session_token (HttpOnly)
    C->>GW: POST /api/orders (S21) + Idempotency-Key
    GW->>AU: introspección de la sesión
    GW->>OR: crear pedido + identidad firmada por el gateway
    OR->>CL: perfil de entrega (cliente activo, mayoría de edad si hay alcohol)
    OR->>IN: precios y disponibilidad (el navegador no manda precios)
    OR-->>C: pedido «Pago pendiente» con total calculado en el servidor
    C->>GW: POST /api/orders/{id}/payment (S29)
    GW->>PA: iniciar pago
    PA->>OR: ¿cuánto cobrar? (payable)
    PA->>PV: crear cobro
    PA-->>C: checkoutUrl
    C->>PV: paga en la página del proveedor
    PV->>GW: POST /api/webhooks/provider (S35) firmado
    GW->>PA: aviso (firma + ventana + monto + idempotencia)
    PA->>OR: payment-confirmed (pagoId, monto)
    OR-->>PA: «En preparación»
    PA->>PA: crea venta + folio de boleta
    PA->>AN: sale-registered (idempotente)
    PA->>NO: boleta por correo (clave boleta:folio)
    C->>GW: GET /api/orders/{id}/receipt (S31)
```

### 3.4 Consistencia entre servicios

Cada servicio tiene su propia base, por lo que no hay transacciones entre ellos. En su lugar se aplicaron patrones concretos, cada uno con su decisión (ADR) y sus pruebas:

| Situación | Mecanismo | ADR |
|---|---|---|
| Crear un pedido sin duplicarlo ante un reintento | Clave de idempotencia (`Idempotency-Key`) y precio fijado por el servidor | [006](adr/ADR-006-pedido-precio-y-idempotencia.md) |
| Confirmar un pago | Aviso firmado + confirmación idempotente + conciliación periódica | [007](adr/ADR-007-confirmacion-de-pago-y-reembolsos.md) |
| Anular un pedido ya pagado | Anular primero y reintentar el reembolso hasta que `payments` responda | [008](adr/ADR-008-anulacion-primero-y-reconciliacion.md) |
| Registro de cliente (`clients` + `auth` + `notifications`) | Saga idempotente: repetir el registro lo completa sin duplicar | [011](adr/ADR-011-registro-de-clientes-saga.md) |
| Un servicio no responde | Plazos jerárquicos, cortacircuitos y degradación parcial | [010](adr/ADR-010-resiliencia-y-plazos.md) |

---

## M4 Actores y permisos

### 4.1 Actores (stakeholders)

| Actor | Qué necesita | Qué no debe poder hacer |
|---|---|---|
| Visitante (sin sesión) | Ver la carta, promociones y zonas; cotizar un evento; enviar un mensaje de contacto; registrarse | Ver pedidos, clientes, pagos o reportes |
| Cliente | Armar pedidos, pagar, ver su boleta y anular lo suyo | Ver o tocar el pedido de otro cliente; marcar su pedido como pagado; ver datos de otros clientes |
| Administrador | Mantener productos, clientes y usuarios; confirmar pagos manuales; reembolsar; ver la bandeja de salida | Quitarse el acceso a sí mismo; dejar el sistema sin ningún administrador activo |
| Dueño | Ver reportes de ventas y el catálogo | Ver clientes, pedidos ni pagos (ni datos personales del reporte) |
| Despacho | Ver los pedidos pagados en orden de llegada, avanzar su estado e imprimir la orden | Anular, reembolsar, cambiar precios |
| Proveedor de pagos (tercero) | Avisar el resultado de un cobro | Cualquier cosa sin una firma válida; alterar un monto |
| Operación / TI | Levantar y rotar secretos del sistema | (No es un rol de la aplicación: opera Vault y MongoDB desde fuera) |
| Atacante | — | Todo lo anterior sin credenciales; los casos C2–C6 del módulo 7 lo ejercitan |

### 4.2 Matriz de permisos por ruta, verbo y condición

Generado desde `RUTAS` (rol exigido por el API Gateway). El servicio privado vuelve a comprobar el rol y la pertenencia: dos capas independientes (ver `tests/contratos/rutas_servicios.json`). «no (401)» = sin sesión; con sesión pero sin rol responde 403.

| ID | Verbo | Ruta | Anónimo | Cliente | Despacho | Administrador | Dueño | Condición que aplica el servicio |
|---|---|---|---|---|---|---|---|---|
| S01 | POST | /api/auth/login | sí | sí | sí | sí | sí | Bloqueo temporal tras varios intentos fallidos; misma respuesta y mismo trabajo (hash falso) si el usuario no existe |
| S02 | POST | /api/auth/logout | sí | sí | sí | sí | sí | — |
| S03 | GET | /api/auth/me | sí | sí | sí | sí | sí | Devuelve solo la identidad de la sesión (o null); nunca el token |
| S04 | GET | /api/products | sí | sí | sí | sí | sí | — |
| S05 | GET | /api/promos | sí | sí | sí | sí | sí | — |
| S06 | POST | /api/products | no (401) | no | no | sí | sí | Catálogo: administrador y dueño |
| S07 | PUT | /api/products/{producto} | no (401) | no | no | sí | sí | — |
| S08 | PUT | /api/products/{producto}/availability | no (401) | no | no | sí | sí | — |
| S09 | DELETE | /api/products/{producto} | no (401) | no | no | sí | sí | No se elimina un producto que forma parte de una promoción (409 PRODUCTO_EN_PROMO) |
| S10 | POST | /api/clients/register | sí | sí | sí | sí | sí | Crea cuenta de cliente (rol fijo «cliente», nunca elegido por el navegador); se comprueba que el correo exista; respuesta genérica si la cuenta ya existe |
| S11 | GET | /api/clients/me | no (401) | sí | no | no | no | No recibe identificador: devuelve el perfil del cliente de la SESIÓN |
| S12 | GET | /api/clients | no (401) | no | no | sí | no | — |
| S13 | POST | /api/clients | no (401) | no | no | sí | no | — |
| S14 | PUT | /api/clients/{cliente} | no (401) | no | no | sí | no | — |
| S15 | DELETE | /api/clients/{cliente} | no (401) | no | no | sí | no | — |
| S16 | GET | /api/users | no (401) | no | no | sí | no | Solo administrador |
| S17 | POST | /api/users | no (401) | no | no | sí | no | — |
| S18 | PUT | /api/users/{usuario} | no (401) | no | no | sí | no | El administrador no puede editarse a sí mismo ni dejar al sistema sin administradores (409) |
| S19 | DELETE | /api/users/{usuario} | no (401) | no | no | sí | no | El administrador no puede eliminarse a sí mismo ni al último administrador (409) |
| S20 | GET | /api/delivery-zones | sí | sí | sí | sí | sí | — |
| S21 | POST | /api/orders | no (401) | sí | no | no | no | Cuenta de cliente activa ligada a la sesión; máx. pedidos con pago pendiente; precios, despacho y total los calcula el servidor |
| S22 | GET | /api/orders | no (401) | sí | no | no | no | Solo los pedidos del cliente de la sesión |
| S23 | GET | /api/orders/{pedido} | no (401) | sí | sí | sí | no | Cliente: solo si el pedido es SUYO (ajeno e inexistente dan el mismo 403); administrador y despacho: cualquiera |
| S24 | POST | /api/orders/{pedido}/cancellation | no (401) | sí | no | sí | no | Cliente: solo su pedido; solo en «Pago pendiente» o «En preparación»; en «En preparación» queda reembolso pendiente |
| S25 | GET | /api/admin/orders | no (401) | no | sí | sí | no | — |
| S26 | PUT | /api/admin/orders/{pedido}/status | no (401) | no | sí | sí | no | Transiciones por rol: En preparación → En camino → Entregado (despacho y administrador); nunca se salta un estado |
| S27 | GET | /api/event-config | sí | sí | sí | sí | sí | — |
| S28 | POST | /api/event-quotes | sí | sí | sí | sí | sí | — |
| S29 | POST | /api/orders/{pedido}/payment | no (401) | sí | no | no | no | Cliente: solo su pedido en «Pago pendiente»; el monto lo entrega orders, no el navegador; un solo cobro iniciado por pedido |
| S30 | GET | /api/orders/{pedido}/payment | no (401) | sí | no | sí | no | Cliente: solo su pedido; administrador: cualquiera |
| S31 | GET | /api/orders/{pedido}/receipt | no (401) | sí | no | sí | no | Cliente: solo su pedido; administrador: cualquiera; 404 mientras la boleta no se emite |
| S32 | POST | /api/admin/orders/{pedido}/payment-confirmation | no (401) | no | no | sí | no | Solo transferencia o depósito (medios manuales) y pedido en «Pago pendiente»; exige referencia |
| S33 | POST | /api/admin/orders/{pedido}/refund | no (401) | no | no | sí | no | Solo pagos con reembolso pendiente; exige referencia del reembolso |
| S34 | GET | /api/admin/payments | no (401) | no | no | sí | no | — |
| S35 | POST | /api/webhooks/provider | firma | — | — | — | — | Firma HMAC del proveedor + ventana de tiempo + mismo monto y moneda que el cobro; evento repetido es idempotente |
| S36 | POST | /api/contact-messages | sí | sí | sí | sí | sí | — |
| S37 | GET | /api/admin/outbox | no (401) | no | no | sí | no | — |
| S38 | POST | /api/graphql | no (401) | sí | sí | sí | sí | Autorización campo por campo (ver graphql.md); además profundidad, alias, tamaño y costo acotados |

El dueño del negocio ve el catálogo y los reportes de ventas, pero **no** datos personales de clientes ni de entrega.

La autorización se comprueba **dos veces**: el gateway aplica el rol de la tabla de rutas y cada servicio privado vuelve a comprobar el rol y la pertenencia (por ejemplo, que el pedido sea del cliente de la sesión). Una prueba recorre todas las rutas con cada rol y exige que la matriz publicada coincida con la tabla del gateway (`test_la_matriz_de_permisos_del_informe_coincide_con_el_gateway`).

La fila de S23 permite comprobar que un cliente no consulta pedidos de otro (solo ve el SUYO); la regla la aplica `orders` como segunda capa. El recorrido de una consulta autorizada y de una denegada está en el [módulo 5.4](#54-recorrido-de-una-solicitud-autorizada-y-de-una-denegada).

---

## M5 API Gateway y fronteras de confianza

### 5.1 UML del gateway

```mermaid
classDiagram
    direction TB
    class ApiGateway {
        <<FastAPI app>>
        +reenviar(request, ruta, identidad)
        +cabeceras_seguridad() CSP, nosniff, X-Frame-Options DENY
        +no_existe() 404 uniforme
    }
    class RouteDefinition {
        <<Ruta · dataclass inmutable>>
        +id S01..S38
        +metodo
        +patron
        +destino
        +ruta_interna
        +acceso : anonimo|sesion|firma
        +roles
        +query / cabeceras permitidas
        +params : regex por segmento
        +limite : grupo de tasa
        +cache / invalida
        +datos : clasificacion
        +rf / paginas
    }
    class AuthenticationPolicy {
        <<sesion()>>
        +lee cookie session_token
        +introspecta en auth en CADA solicitud
        +rechaza 401
    }
    class AuthorizationPolicy {
        <<roles de la Ruta>>
        +403 si el rol no esta en Ruta.roles
        +segunda comprobacion en el servicio privado
    }
    class OriginPolicy {
        <<verificar_origen()>>
        +Origin/Referer exacto en escrituras
        +obligatorio con sesion o cookie
    }
    class RateLimitPolicy {
        <<Limitador>>
        +ventana deslizante en memoria por IP del socket y grupo
        +429 con Retry-After
    }
    class RequestSanitizer {
        <<leer_cuerpo / VALOR_CABECERA>>
        +tamano maximo 16 KB (webhook 64 KB)
        +JSON valido (400 si es ilegible o demasiado anidado)
        +lista blanca de cabeceras
    }
    class UpstreamClient {
        <<ClienteInterno>>
        +X-Service-Name + X-Service-Secret por par
        +X-Authenticated-* solo desde el gateway
        +plazo + cortacircuito
        +X-Request-ID
    }
    class SecretProvider {
        <<VaultSecrets>>
        +token propio de solo lectura
        +cache con TTL, pausa si Vault cae
    }
    class ResponseCache {
        <<cache_leer / cache_guardar>>
        +solo GET anonimos (S04, S05)
        +se invalida al escribir el catalogo
    }
    ApiGateway --> RouteDefinition : tabla RUTAS (lo que no esta, 404)
    ApiGateway --> OriginPolicy
    ApiGateway --> RateLimitPolicy
    ApiGateway --> AuthenticationPolicy
    ApiGateway --> AuthorizationPolicy
    ApiGateway --> RequestSanitizer
    ApiGateway --> UpstreamClient
    ApiGateway --> ResponseCache
    UpstreamClient --> SecretProvider
    AuthenticationPolicy --> UpstreamClient : introspect
    AuthorizationPolicy ..> RouteDefinition : lee roles
```

### 5.2 Fronteras de confianza

```mermaid
flowchart LR
    subgraph Z0["Z0 · No confiable"]
        B["Navegador / cualquier cliente"]
        P["Proveedor externo (webhook)"]
    end
    subgraph Z1["Z1 · Borde (api-gateway)"]
        G["Gateway: tabla de rutas, sesion, rol, Origin, tasa, limites de cuerpo, cabeceras"]
    end
    subgraph Z2["Z2 · Servicios privados (red interna)"]
        S["Cada servicio: valida X-Service-Name + secreto del par, vuelve a comprobar rol y pertenencia, valida el cuerpo (pydantic extra=forbid)"]
    end
    subgraph Z3["Z3 · Almacenes"]
        V[("Vault")]
        M[("MongoDB")]
    end
    B -- "F1: Internet" --> G
    P -- "F2: firma HMAC + ventana + monto" --> G
    G -- "F3: secreto del par + identidad afirmada por el gateway" --> S
    S -- "F4: usuario propio de BD (solo SU base)" --> M
    S -- "F5: token propio, solo lectura de SUS secretos" --> V
```

| Flujo | De → a | Qué se comprueba al cruzar |
|---|---|---|
| F1 | Internet → gateway | Tabla de rutas, límite de tasa por IP, `Origin`/`Referer` en escrituras, tamaño y formato del cuerpo, cabeceras permitidas por ruta, sesión (introspección en `auth` en cada solicitud), rol |
| F2 | Proveedor → gateway | Firma HMAC-SHA256 sobre el cuerpo exacto, ventana de 300 s, monto y moneda, identificador de evento único |
| F3 | Gateway → servicio | Secreto propio del par llamador→destino, nombre del llamador y la identidad ya verificada; el servicio vuelve a comprobar rol y pertenencia |
| F4 | Servicio → MongoDB | Usuario propio con permisos solo sobre SU base |
| F5 | Servicio → Vault | Token propio de solo lectura sobre SUS secretos |

### 5.3 Decisiones de separación

| Decisión | Por qué se separó | ADR |
|---|---|---|
| Dos gateways: el API Gateway público y el GraphQL Gateway privado (no uno por servicio) | El API Gateway concentra los controles de entrada (sesión, rol, origen, tasa); el GraphQL Gateway es de solo lectura, solo lo llama el gateway y su caída no afecta a las escrituras. Un gateway por servicio duplicaría los controles sin crear una frontera nueva | [001](adr/ADR-001-gateway-tabla-de-rutas.md), [009](adr/ADR-009-graphql-solo-lectura.md) |
| El gateway es una tabla de rutas, no un proxy genérico | Una ruta interna (por ejemplo la confirmación de pago) no puede quedar expuesta por olvido | [001](adr/ADR-001-gateway-tabla-de-rutas.md) |
| `auth` aparte de `clients` | La contraseña nunca convive con los datos personales; se endurece y se prueba por separado | [002](adr/ADR-002-sesion-opaca-en-cookie.md), [011](adr/ADR-011-registro-de-clientes-saga.md) |
| `payments` aparte de `orders` | Quien decide el estado del pedido no puede ser quien confirma el dinero; solo `payments` puede confirmar | [007](adr/ADR-007-confirmacion-de-pago-y-reembolsos.md) |
| `analytics` aparte | Su carga y su forma de consulta son distintas de las del pedido | [004](adr/ADR-004-analitica-grpc.md) |
| Un secreto por par llamador→destino y un usuario de base por servicio | Una filtración o un servicio comprometido no abre los demás | [003](adr/ADR-003-secretos-en-vault.md), [005](adr/ADR-005-base-de-datos-por-servicio.md) |

### 5.4 Recorrido de una solicitud autorizada y de una denegada

Consulta protegida de un pedido (S23). La regla es la misma en los dos casos: en S23 un cliente solo ve el pedido si es SUYO, y la aplica `orders` como segunda capa, con la identidad que el gateway verificó. El titular recibe 200 (control 8 del [módulo 7.3](#73-resultados-de-los-6-casos-de-validación)); otro cliente recibe 403 con el mismo cuerpo que un pedido inexistente y sin datos del titular (control 1; `test_un_cliente_no_ve_el_pedido_de_otro_y_la_respuesta_no_revela_si_existe`).

![F03 Pedido propio](diagramas/render/D_F03_Propio.svg)

![F03 Pedido ajeno](diagramas/render/D_F03_Ajeno.svg)

---

## M6 Rutas, secretos y llamadas entre servicios

### 6.1 Matriz de rutas y controles

Lo que no está en esta tabla no se reenvía (404). Los parámetros de ruta se validan con la expresión indicada ANTES de reenviar; de la consulta solo pasan los parámetros listados; del navegador solo viajan las cabeceras listadas (el resto se descarta, y las de identidad `X-Authenticated-*` las escribe el gateway, nunca el cliente).

| ID | Ruta | Acceso | Límite de tasa | Caché | Invalida | Protección CSRF | Parámetros de ruta | Consulta permitida | Cabeceras reenviadas |
|---|---|---|---|---|---|---|---|---|---|
| S01 | POST /api/auth/login | anonimo | login | — | — | Origin/Referer exacto si viene; obligatorio si hay cookie de sesión | — | — | ninguna |
| S02 | POST /api/auth/logout | anonimo | general | — | — | Origin/Referer exacto si viene; obligatorio si hay cookie de sesión | — | — | ninguna |
| S03 | GET /api/auth/me | anonimo | general | — | — | — (solo lectura) | — | — | ninguna |
| S04 | GET /api/products | anonimo | general | 10 s | — | — (solo lectura) | — | categoria, available, q, limit, offset | ninguna |
| S05 | GET /api/promos | anonimo | general | 10 s | — | — (solo lectura) | — | — | ninguna |
| S06 | POST /api/products | sesion | general | — | catalogo | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | — | — | ninguna |
| S07 | PUT /api/products/{producto} | sesion | general | — | catalogo | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | producto=`[a-z0-9]{2,12}` | — | ninguna |
| S08 | PUT /api/products/{producto}/availability | sesion | general | — | catalogo | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | producto=`[a-z0-9]{2,12}` | — | ninguna |
| S09 | DELETE /api/products/{producto} | sesion | general | — | catalogo | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | producto=`[a-z0-9]{2,12}` | — | ninguna |
| S10 | POST /api/clients/register | anonimo | registro | — | — | Origin/Referer exacto si viene; obligatorio si hay cookie de sesión | — | — | ninguna |
| S11 | GET /api/clients/me | sesion | general | — | — | — (solo lectura) | — | — | ninguna |
| S12 | GET /api/clients | sesion | general | — | — | — (solo lectura) | — | q, limit, offset | ninguna |
| S13 | POST /api/clients | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | — | — | ninguna |
| S14 | PUT /api/clients/{cliente} | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | cliente=`c-[a-z0-9]{4,12}` | — | ninguna |
| S15 | DELETE /api/clients/{cliente} | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | cliente=`c-[a-z0-9]{4,12}` | — | ninguna |
| S16 | GET /api/users | sesion | general | — | — | — (solo lectura) | — | limit, offset | ninguna |
| S17 | POST /api/users | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | — | — | ninguna |
| S18 | PUT /api/users/{usuario} | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | usuario=`u-[a-z0-9]{2,20}` | — | ninguna |
| S19 | DELETE /api/users/{usuario} | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | usuario=`u-[a-z0-9]{2,20}` | — | ninguna |
| S20 | GET /api/delivery-zones | anonimo | general | 30 s | — | — (solo lectura) | — | — | ninguna |
| S21 | POST /api/orders | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | — | — | Idempotency-Key |
| S22 | GET /api/orders | sesion | general | — | — | — (solo lectura) | — | limit, offset | ninguna |
| S23 | GET /api/orders/{pedido} | sesion | general | — | — | — (solo lectura) | pedido=`A-\d{3,9}` | — | ninguna |
| S24 | POST /api/orders/{pedido}/cancellation | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | pedido=`A-\d{3,9}` | — | ninguna |
| S25 | GET /api/admin/orders | sesion | general | — | — | — (solo lectura) | — | estado, limit, offset | ninguna |
| S26 | PUT /api/admin/orders/{pedido}/status | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | pedido=`A-\d{3,9}` | — | ninguna |
| S27 | GET /api/event-config | anonimo | general | 30 s | — | — (solo lectura) | — | — | ninguna |
| S28 | POST /api/event-quotes | anonimo | formularios | — | — | Origin/Referer exacto si viene; obligatorio si hay cookie de sesión | — | — | ninguna |
| S29 | POST /api/orders/{pedido}/payment | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | pedido=`A-\d{3,9}` | — | ninguna |
| S30 | GET /api/orders/{pedido}/payment | sesion | general | — | — | — (solo lectura) | pedido=`A-\d{3,9}` | — | ninguna |
| S31 | GET /api/orders/{pedido}/receipt | sesion | general | — | — | — (solo lectura) | pedido=`A-\d{3,9}` | — | ninguna |
| S32 | POST /api/admin/orders/{pedido}/payment-confirmation | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | pedido=`A-\d{3,9}` | — | ninguna |
| S33 | POST /api/admin/orders/{pedido}/refund | sesion | general | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | pedido=`A-\d{3,9}` | — | ninguna |
| S34 | GET /api/admin/payments | sesion | general | — | — | — (solo lectura) | — | estado, reembolso, modo, limit, offset | ninguna |
| S35 | POST /api/webhooks/provider | firma | webhook | — | — | no aplica (firma HMAC del proveedor) | — | — | X-Provider-Signature, X-Provider-Event-Id |
| S36 | POST /api/contact-messages | anonimo | formularios | — | — | Origin/Referer exacto si viene; obligatorio si hay cookie de sesión | — | — | ninguna |
| S37 | GET /api/admin/outbox | sesion | general | — | — | — (solo lectura) | — | limit | ninguna |
| S38 | POST /api/graphql | sesion | graphql | — | — | Origin/Referer obligatorio y exacto + cookie SameSite=Lax | — | — | ninguna |

### 6.2 Inventario simbólico de secretos

Solo nombres, quién los usa y su ciclo de vida. **Ningún valor** vive en el repositorio, en las imágenes ni en el navegador: `scripts/bootstrap.py` los genera al arrancar y `scripts/seed_vault.py` los guarda en Vault (rotar: `--rotar <ref>`).

30 secretos.

| Referencia (ruta en Vault) | Tipo | Campos | Lo lee | Lo verifica | Finalidad | Alcance | Rotación y revocación |
|---|---|---|---|---|---|---|---|
| `asador/svc/api-gateway-to-auth` | secreto-servicio | value | api-gateway | auth | Introspección de sesión, login/logout y mantenedor de usuarios | Solo autentica llamadas de api-gateway hacia auth | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/api-gateway-to-clients` | secreto-servicio | value | api-gateway | clients | Registro y mantenedor de clientes | Solo autentica llamadas de api-gateway hacia clients | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/api-gateway-to-inventory` | secreto-servicio | value | api-gateway | inventory | Catálogo público y mantenedor de productos | Solo autentica llamadas de api-gateway hacia inventory | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/api-gateway-to-orders` | secreto-servicio | value | api-gateway | orders | Pedidos, despacho, zonas y cotizaciones de eventos | Solo autentica llamadas de api-gateway hacia orders | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/api-gateway-to-payments` | secreto-servicio | value | api-gateway | payments | Inicio de pagos, aviso del proveedor, confirmación manual y boletas | Solo autentica llamadas de api-gateway hacia payments | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/api-gateway-to-notifications` | secreto-servicio | value | api-gateway | notifications | Formulario de contacto | Solo autentica llamadas de api-gateway hacia notifications | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/api-gateway-to-graphql-gateway` | secreto-servicio | value | api-gateway | graphql-gateway | Agregaciones GraphQL con identidad verificada | Solo autentica llamadas de api-gateway hacia graphql-gateway | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/graphql-gateway-to-orders` | secreto-servicio | value | graphql-gateway | orders | Leer pedidos para agregarlos (solo lectura) | Solo autentica llamadas de graphql-gateway hacia orders | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/graphql-gateway-to-inventory` | secreto-servicio | value | graphql-gateway | inventory | Leer descripciones públicas de productos (solo lectura) | Solo autentica llamadas de graphql-gateway hacia inventory | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/graphql-gateway-to-payments` | secreto-servicio | value | graphql-gateway | payments | Leer estado de pago de un pedido (solo lectura) | Solo autentica llamadas de graphql-gateway hacia payments | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/graphql-gateway-to-analytics` | secreto-servicio | value | graphql-gateway | analytics | Leer reportes de ventas (solo lectura) | Solo autentica llamadas de graphql-gateway hacia analytics | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/orders-to-inventory` | secreto-servicio | value | orders | inventory | Resolver precios y disponibilidad de los ítems de un pedido | Solo autentica llamadas de orders hacia inventory | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/orders-to-clients` | secreto-servicio | value | orders | clients | Leer perfil de entrega del cliente que compra | Solo autentica llamadas de orders hacia clients | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/orders-to-payments` | secreto-servicio | value | orders | payments | Anular/reembolsar pagos de un pedido anulado | Solo autentica llamadas de orders hacia payments | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/orders-to-notifications` | secreto-servicio | value | orders | notifications | Avisos de cotización de eventos | Solo autentica llamadas de orders hacia notifications | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/payments-to-orders` | secreto-servicio | value | payments | orders | Consultar monto a pagar y confirmar el pago (única vía de cambio a 'En preparación') | Solo autentica llamadas de payments hacia orders | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/payments-to-notifications` | secreto-servicio | value | payments | notifications | Enviar boleta digital por correo | Solo autentica llamadas de payments hacia notifications | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/payments-to-analytics` | secreto-servicio | value | payments | analytics | Publicar ventas registradas/anuladas | Solo autentica llamadas de payments hacia analytics | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/clients-to-auth` | secreto-servicio | value | clients | auth | Crear/desactivar credenciales de clientes | Solo autentica llamadas de clients hacia auth | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/svc/clients-to-notifications` | secreto-servicio | value | clients | notifications | Validar existencia del correo y enviar bienvenida | Solo autentica llamadas de clients hacia notifications | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/provider/api-key` | credencial-proveedor | value | payments | provider-sandbox | Crear/consultar/reembolsar pagos en el proveedor (sandbox) | Solo API de pagos del proveedor; sin acceso a otras cuentas | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/provider/webhook-secret` | clave-firma | value | provider-sandbox | payments | Firma HMAC-SHA256 de los avisos del proveedor; payments la usa para verificarlos | Solo verificación de avisos de pago | Rotar con seed_vault.py --rotar <ref>; los servicios recogen el valor nuevo al vencer SECRET_TTL_SECONDS (60 s). Revocar = borrar la ruta: el destino rechaza (403). |
| `asador/db/auth` | credencial-bd | user,password | auth | mongo | Acceso de auth a su base asador_auth | Rol readWrite solo sobre asador_auth | Cambiar password en .env + reiniciar mongo (usuario) y volver a ejecutar seed_vault.py --rotar db/auth |
| `asador/db/clients` | credencial-bd | user,password | clients | mongo | Acceso de clients a su base asador_clients | Rol readWrite solo sobre asador_clients | Cambiar password en .env + reiniciar mongo (usuario) y volver a ejecutar seed_vault.py --rotar db/clients |
| `asador/db/inventory` | credencial-bd | user,password | inventory | mongo | Acceso de inventory a su base asador_inventory | Rol readWrite solo sobre asador_inventory | Cambiar password en .env + reiniciar mongo (usuario) y volver a ejecutar seed_vault.py --rotar db/inventory |
| `asador/db/orders` | credencial-bd | user,password | orders | mongo | Acceso de orders a su base asador_orders | Rol readWrite solo sobre asador_orders | Cambiar password en .env + reiniciar mongo (usuario) y volver a ejecutar seed_vault.py --rotar db/orders |
| `asador/db/payments` | credencial-bd | user,password | payments | mongo | Acceso de payments a su base asador_payments | Rol readWrite solo sobre asador_payments | Cambiar password en .env + reiniciar mongo (usuario) y volver a ejecutar seed_vault.py --rotar db/payments |
| `asador/db/notifications` | credencial-bd | user,password | notifications | mongo | Acceso de notifications a su base asador_notifications | Rol readWrite solo sobre asador_notifications | Cambiar password en .env + reiniciar mongo (usuario) y volver a ejecutar seed_vault.py --rotar db/notifications |
| `asador/db/analytics` | credencial-bd | user,password | analytics | mongo | Acceso de analytics a su base asador_analytics | Rol readWrite solo sobre asador_analytics | Cambiar password en .env + reiniciar mongo (usuario) y volver a ejecutar seed_vault.py --rotar db/analytics |
| `asador/email/smtp` | credencial-proveedor | host,user,password | notifications | smtp-externo | Envío real de correos (solo con EMAIL_PROVIDER=smtp) | Solo envío SMTP | Rotar en el proveedor SMTP y actualizar en Vault |

### 6.3 Llamadas entre servicios y secreto de cada par

20 pares llamador→destino. Cada par usa SU secreto (`X-Service-Name` + `X-Service-Secret`, guardado en Vault bajo el nombre indicado): el secreto de un par no sirve para otro destino ni para otro llamador. Solo `api-gateway` y `graphql-gateway` pueden afirmar una identidad de usuario.

| Llamador | Destino | Secreto en Vault (nombre) | Rutas que el llamador puede usar |
|---|---|---|---|
| api-gateway | auth | asador/svc/api-gateway-to-auth | POST /introspect; POST /login; POST /logout; GET /users; POST /users; DELETE /users/{id}; PUT /users/{id} |
| api-gateway | clients | asador/svc/api-gateway-to-clients | GET /clients; POST /clients; GET /clients/me; POST /clients/register; DELETE /clients/{id}; PUT /clients/{id} |
| api-gateway | graphql-gateway | asador/svc/api-gateway-to-graphql-gateway | POST /graphql |
| api-gateway | inventory | asador/svc/api-gateway-to-inventory | GET /products; POST /products; DELETE /products/{id}; PUT /products/{id}; PUT /products/{id}/availability; GET /promos |
| api-gateway | notifications | asador/svc/api-gateway-to-notifications | POST /contact-messages; GET /outbox |
| api-gateway | orders | asador/svc/api-gateway-to-orders | GET /admin/orders; PUT /admin/orders/{id}/status; GET /delivery-zones; GET /event-config; POST /event-quotes; GET /orders; POST /orders; GET /orders/{id}; POST /orders/{id}/cancellation |
| api-gateway | payments | asador/svc/api-gateway-to-payments | POST /admin/orders/{id}/payment-confirmation; POST /admin/orders/{id}/refund; GET /admin/payments; GET /orders/{id}/payment; POST /orders/{id}/payment; GET /orders/{id}/receipt; POST /webhooks/provider |
| clients | auth | asador/svc/clients-to-auth | POST /internal/credentials; DELETE /internal/credentials/{user_id}; PUT /internal/credentials/{user_id}/estado |
| clients | notifications | asador/svc/clients-to-notifications | POST /internal/email/send; POST /internal/email/validate |
| graphql-gateway | analytics | asador/svc/graphql-gateway-to-analytics | GET /internal/reports/sales |
| graphql-gateway | inventory | asador/svc/graphql-gateway-to-inventory | GET /internal/items; GET /internal/summary |
| graphql-gateway | orders | asador/svc/graphql-gateway-to-orders | GET /admin/orders; GET /admin/orders/summary; GET /orders; GET /orders/{id} |
| graphql-gateway | payments | asador/svc/graphql-gateway-to-payments | GET /internal/payments/by-orders; GET /internal/summary |
| orders | clients | asador/svc/orders-to-clients | GET /internal/clients/{id}/delivery-profile |
| orders | inventory | asador/svc/orders-to-inventory | GET /internal/items; POST /internal/pricing/resolve |
| orders | notifications | asador/svc/orders-to-notifications | POST /internal/email/send |
| orders | payments | asador/svc/orders-to-payments | POST /internal/orders/{id}/payment-cancel |
| payments | analytics | asador/svc/payments-to-analytics | POST /internal/events/sale-registered; POST /internal/events/sale-reversed |
| payments | notifications | asador/svc/payments-to-notifications | POST /internal/email/send |
| payments | orders | asador/svc/payments-to-orders | GET /internal/orders/{id}/payable; POST /internal/orders/{id}/payment-confirmed; POST /internal/orders/{id}/refund-done |

### 6.4 GraphQL y gRPC

Las operaciones GraphQL, su permiso por campo y sus límites están en el módulo 8. **gRPC no se implementa:** la decisión, con la carga proyectada y medida, está en el [ADR-004](adr/ADR-004-analitica-grpc.md) (módulo 9).

### 6.5 Plan ante filtración o caída de Vault

#### ADR-003 · Un secreto por par llamador→destino, tokens de Vault por servicio

**Estado:** aceptada · **Módulos:** M6, M7

##### Contexto
La pauta prohíbe asignar el mismo secreto a todos los sistemas sin justificarlo y pide prever qué pasa si una clave se filtra o el gestor de secretos no responde.

##### Decisión
- **Identidad entre servicios:** cada llamada interna lleva `X-Service-Name` y `X-Service-Secret`. Hay un secreto distinto por cada par llamador→destino (20 pares, `docs/matrices/llamadas_entre_servicios.md`). El secreto de `api-gateway→orders` no sirve para llamar a `inventory`, ni el de `payments→orders` para leer pedidos. Solo `api-gateway` y `graphql-gateway` pueden **afirmar** la identidad de un usuario; el GraphQL Gateway solo puede leer.
- **Vault (KV v2):** 30 referencias simbólicas en `secrets/manifest.tsv`. Cada servicio recibe su propio token de Vault con una política de **solo lectura** sobre lo suyo; las credenciales de base de datos pertenecen al servicio que accede (no al navegador ni al gateway). `scripts/seed_vault.py` carga los valores y crea políticas y tokens; `scripts/bootstrap.py` genera los valores aleatorios en `.env` (que no se versiona).
- **Proveedor de pagos:** la clave de API y la clave de firma de avisos son referencias distintas con finalidad distinta.

##### Si una clave se filtra
1. Rotar solo esa referencia: `python scripts/seed_vault.py --rotar <ref>`. Los servicios recogen el valor nuevo al vencer `SECRET_TTL_SECONDS` (60 s).
2. Revocar un par = borrar su ruta en Vault: el destino deja de aceptar al llamador (403) y las pruebas lo verifican.
3. Credencial de base de datos: cambiar la clave en `.env`, reiniciar `mongo` y volver a sembrar `db/<servicio>`.
4. Token de Vault de un servicio: revocarlo y emitir uno nuevo; los demás servicios no se ven afectados.

##### Si Vault no responde
El cliente (`common/vault_secrets.py`) espera como máximo 1 s por lectura (`VAULT_TIMEOUT_SECONDS`), **sigue sirviendo con los secretos ya cacheados** y deja de preguntarle a Vault durante 5 s tras un fallo (`VAULT_RETRY_AFTER_SECONDS`) para no encadenar esperas. Un secreto que Vault responde como **borrado o prohibido (404/403)** sí se revoca de inmediato aunque esté en caché. Sin copia en caché falla cerrado al instante (503 `SECRETOS_NO_DISPONIBLE`), sin dejar la solicitud colgada. El tiempo máximo acumulado de Vault en la cadena más larga (1 s por proceso) es menor que el plazo del gateway (5 s), así Vault colgado produce 503 y no 504.

##### Consecuencias
- Más secretos que administrar (30) a cambio de acotar el daño de una filtración.
- Vault en modo desarrollo (en memoria, sin sellar) es solo para la demostración: en producción se necesita almacenamiento persistente, TLS, claves de desbloqueo repartidas y AppRole. El `docker-compose.yml` descarta el log de Vault porque el modo desarrollo imprime su token raíz.
- Ningún secreto aparece en el repositorio, en las imágenes, en el JavaScript ni en los logs (revisado por `tests/test_zz_logs_y_secretos.py`).

##### Dónde está probado
`tests/test_seguridad_acceso.py` (secreto equivocado, de otro par, ausencia), `tests/test_secretos_vault.py` (rotación, revocación, Vault colgado/caído, recuperación), `tests/test_infraestructura_real.py` (con Vault y MongoDB reales), `tests/test_zz_logs_y_secretos.py`, `tests/test_despliegue.py` (tokens distintos, `.env` no versionado).

---

## M7 Datos, secretos y casos de validación

### 7.1 Clasificación de datos

| Clase | Qué incluye | Servicios públicos que la transportan | Protección |
|---|---|---|---|
| **Público** | Información que ya es pública o que no identifica a nadie: carta, promociones, zonas de despacho, cierre de sesión. | S02, S04, S05, S06, S07, S08, S09, S20, S27 (9) | Sin sesión (lectura); la escritura del catálogo exige rol. |
| **Personal** | Identifica a una persona pero con bajo daño si se filtra: nombre y correo de un usuario, de una cotización o de un mensaje de contacto. | S03, S16, S19, S28, S36 (5) | Sesión o validación de formulario; no se registra completo en los logs. |
| **Restringido** | Datos de clientes, pedidos, pagos, boletas, reembolsos, bandeja de salida y reportes: solo su dueño o los roles que los necesitan. | S10, S11, S12, S13, S14, S15, S21, S22, S23, S24, S25, S26, S29, S30, S31, S32, S33, S34, S35, S37, S38 (21) | Sesión, rol y pertenencia comprobados en el gateway y en el servicio; acceso a la base solo con el usuario del servicio. |
| **Secreto** | Credenciales: la contraseña al iniciar sesión o crear un usuario. (Los secretos de infraestructura no pasan por ninguna ruta pública: ver el inventario de secretos.) | S01, S17, S18 (3) | Nunca se guarda en claro (argon2id), no se registra en logs ni se devuelve en respuestas. |

**Recorrido de un dato personal (la dirección de despacho):** el cliente la escribe en el formulario de registro → el gateway valida origen, tamaño y límites de tasa → `clients` la valida y la guarda (es la única autoridad de ese dato) → al crear un pedido, `orders` pide a `clients` solo el perfil de despacho con el secreto del par `orders→clients` y guarda en el pedido la dirección y la comuna necesarias para despachar → el pedido solo lo ven su cliente, el administrador y el despacho (el dueño no) → los logs no contienen correos ni RUN completos (`test_los_logs_no_dejan_correos_ni_ruts_completos`) y los reportes de analítica no llevan datos personales (`test_el_reporte_lo_ven_el_administrador_y_el_dueno_y_no_trae_datos_personales`).

### 7.2 Decisión sobre los secretos del cliente

**El backend no entrega al navegador ningún secreto del sistema.** Ninguna respuesta lleva claves de API, claves de firma, credenciales de servicio ni tokens de Vault, y el proyecto del backend no contiene JavaScript ni HTML del cliente (el frontend no forma parte de este proyecto). La única credencial que tiene el cliente es el token de sesión, que:

- es **opaco** (aleatorio, no un JWT con datos dentro) y el servidor guarda solo su hash SHA-256, así que ni una copia de la base permite reutilizarlo;
- viaja en una cookie `HttpOnly` (el JavaScript no puede leerla, lo que limita el robo por XSS) con `SameSite=Lax` y, detrás de HTTPS, `Secure`;
- se revisa en el servidor en **cada** solicitud, caduca a las 2 horas y se revoca al cerrar sesión, cambiar la clave, cambiar el rol o desactivar la cuenta;
- no se devuelve en el cuerpo de ninguna respuesta ni se escribe en los logs.

Alternativa descartada: JWT en `localStorage` (legible por cualquier script, no revocable sin lista de bloqueo). Detalle en el [ADR-002](adr/ADR-002-sesion-opaca-en-cookie.md).

| Afirmación de seguridad | Evidencia de ejecución |
|---|---|
| La cookie es `HttpOnly`/`SameSite` y el token no viaja en el cuerpo | `test_la_cookie_de_sesion_es_httponly_y_el_token_no_viaja_en_el_cuerpo`, `test_la_cookie_de_sesion_va_con_secure_httponly_y_samesite` |
| Ningún log contiene secretos, contraseñas ni tokens de sesión | `test_ningun_secreto_de_vault_ni_token_de_servicio_aparece_en_los_logs`, `test_ninguna_contrasena_ni_token_de_sesion_aparece_en_los_logs` |
| Ninguna respuesta expone campos internos ni secretos | `test_ninguna_respuesta_expone_campos_internos_secretos_ni_cabeceras_de_servicio`, `test_las_respuestas_nunca_contienen_secretos_de_vault` |
| Un secreto de un par no sirve para otro destino | `test_el_secreto_de_un_par_no_sirve_para_otro_destino`, `test_los_secretos_de_cada_par_son_distintos` |
| Las contraseñas se guardan con argon2id y ninguna colección guarda texto plano | `test_las_contrasenas_se_guardan_con_argon2id_y_ninguna_coleccion_guarda_texto_plano` (solo con MongoDB real) |
| Cada servicio de base de datos solo ve la suya | `test_infraestructura_real.py` (solo con MongoDB real) |
| Si Vault no responde, se usa la caché o se falla cerrado | `test_si_vault_no_responde_se_usa_la_cache_y_sin_cache_se_falla_cerrado` |

### 7.3 Resultados de los 6 casos de validación

Los seis casos (C1–C6) se ejecutaron contra el sistema levantado; cada fila es una solicitud HTTP real con su resultado esperado, el obtenido, el componente que lo verifica y la prueba automática que lo cubre.

Generado por `scripts/verificar_controles.py` el 2026-11-05 03:33. 75 de 75 verificaciones cumplieron lo esperado (9 s).

**Entorno:** Linux-6.18.44-fc-v236-x86_64-with-glibc2.39; Python 3.13.18; Vault y MongoDB reales.

Cada fila es una solicitud HTTP real contra el sistema levantado como procesos (gateway, auth, clients, inventory, orders, payments, notifications, analytics y GraphQL Gateway). La columna «prueba» indica la prueba automática que protege la misma regla en la suite (`tests/`).

#### C1 Catálogo anónimo

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | GET /api/products?limit=5 | anónimo (sin cookie) | 200; solo campos públicos del producto | 200; campos: alcohol, categoria, descripcion, disponible, id, imagen, incluye, nombre, personas, precio; sin Set-Cookie | api-gateway (ruta pública S04) + inventory | `test_seguridad_acceso::test_la_matriz_de_permisos_del_informe_coincide_con_el_gateway` | ✓ |
| 2 | GET /api/promos | anónimo | 200 | 200 | api-gateway (ruta pública S05) | `test_negocio_pedidos::test_zonas_de_despacho_publicas_coinciden_con_el_cobro` | ✓ |
| 3 | GET /api/delivery-zones | anónimo | 200 | 200 | api-gateway (ruta pública S20) | `test_negocio_pedidos::test_zonas_de_despacho_publicas_coinciden_con_el_cobro` | ✓ |
| 4 | GET /api/orders (control: lo privado sigue privado) | anónimo | 401 NO_AUTENTICADO | 401 NO_AUTENTICADO | api-gateway | `test_seguridad_acceso::test_sin_sesion_toda_ruta_protegida_responde_401` | ✓ |

#### C2 Operación protegida sin sesión válida

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | POST /api/orders (sin cookie) | anónimo | 401 NO_AUTENTICADO | 401 NO_AUTENTICADO | api-gateway (tabla de rutas: exige sesión) | `test_seguridad_acceso::test_sin_sesion_toda_ruta_protegida_responde_401` | ✓ |
| 2 | POST /api/orders (cookie inventada) | token que no existe | 401 SESION_NO_VALIDA | 401 SESION_NO_VALIDA | auth (introspección en cada solicitud) | `test_seguridad_acceso::test_cookie_basura_se_trata_como_sin_sesion` | ✓ |
| 3 | GET /api/clients/me (token de una sesión ya cerrada) | cliente (antes del logout: 200) | 401 SESION_NO_VALIDA | 401 SESION_NO_VALIDA | auth (el logout revoca la sesión en el servidor) | `test_seguridad_acceso::test_cerrar_sesion_la_revoca_en_el_servidor` | ✓ |
| 4 | POST /api/graphql | anónimo | 401 NO_AUTENTICADO | 401 NO_AUTENTICADO | api-gateway (antes de llegar al GraphQL Gateway) | `test_graphql::test_graphql_exige_sesion` | ✓ |
| 5 | GET /api/clients/me con «Authorization: Bearer …» | anónimo | 401 (el sistema solo reconoce su cookie de sesión) | 401 NO_AUTENTICADO | api-gateway | `test_seguridad_acceso::test_cabeceras_de_identidad_enviadas_por_el_navegador_se_ignoran` | ✓ |

#### C3 Administración desde un rol sin permiso

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | POST /api/products | sesión de cliente | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 2 | GET /api/users | sesión de cliente | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 3 | GET /api/clients | sesión de cliente | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 4 | PUT /api/admin/orders/A-1042/status | sesión de cliente | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 5 | POST /api/products | sesión de despacho | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 6 | GET /api/admin/payments | sesión de despacho | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 7 | POST /api/admin/orders/A-1042/refund | sesión de despacho | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 8 | POST /api/users | sesión de dueno | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 9 | GET /api/clients | sesión de dueno | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 10 | GET /api/admin/orders | sesión de dueno | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 11 | GET /api/admin/outbox | sesión de administrador | 200 (control: rol autorizado) | 200 | api-gateway (rol exigido por la ruta) | `test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway` | ✓ |
| 12 | efecto: no se creó ningún producto con los intentos del cliente y del despacho | — | el nombre del producto de prueba no existe en el catálogo | no existe en el catálogo | inventory | `test_seguridad_acceso::test_el_gateway_corta_el_rol_equivocado_antes_de_molestar_al_servicio` | ✓ |
| 13 | POST inventory /products con la identidad «cliente» afirmada por el propio gateway (segunda capa) | cliente (saltándose la comprobación del gateway) | 403 ROL_NO_AUTORIZADO | 403 ROL_NO_AUTORIZADO | inventory (el servicio vuelve a comprobar el rol) | `test_segunda_capa::test_el_servicio_vuelve_a_comprobar_el_rol_sin_fiarse_del_gateway` | ✓ |

#### C4 Consulta de un pedido ajeno

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | GET /api/orders/A-1042 (pedido de otro cliente) | cliente B | 403 PROHIBIDO, mismo cuerpo que un pedido inexistente y sin datos de A | 403 PROHIBIDO; idéntico al de A-999999 (inexistente): True; datos de A en el cuerpo: 0 | orders (pertenencia: el cliente de la sesión debe ser el dueño del pedido) | `test_seguridad_acceso::test_un_cliente_no_ve_el_pedido_de_otro_y_la_respuesta_no_revela_si_existe` | ✓ |
| 2 | POST /api/orders/{pedido}/cancellation (anular) | cliente B | 403 PROHIBIDO | 403 PROHIBIDO | orders / payments (pertenencia) | `test_seguridad_acceso::test_un_cliente_no_opera_sobre_pedidos_ajenos` | ✓ |
| 3 | POST /api/orders/{pedido}/payment (iniciar el pago) | cliente B | 403 PROHIBIDO | 403 PROHIBIDO | orders / payments (pertenencia) | `test_seguridad_acceso::test_un_cliente_no_opera_sobre_pedidos_ajenos` | ✓ |
| 4 | GET /api/orders/{pedido}/payment (ver el pago) | cliente B | 403 PROHIBIDO | 403 PROHIBIDO | orders / payments (pertenencia) | `test_seguridad_acceso::test_un_cliente_no_opera_sobre_pedidos_ajenos` | ✓ |
| 5 | GET /api/orders/{pedido}/receipt (ver la boleta) | cliente B | 403 PROHIBIDO | 403 PROHIBIDO | orders / payments (pertenencia) | `test_seguridad_acceso::test_un_cliente_no_opera_sobre_pedidos_ajenos` | ✓ |
| 6 | GraphQL misPedidos | cliente B | 200 sin el pedido de A (la lista es solo la suya) | 200; 0 pedidos propios; el de A no aparece | graphql-gateway + orders (la identidad viaja al servicio) | `test_graphql::test_cada_cliente_ve_solo_sus_pedidos_en_graphql` | ✓ |
| 7 | GraphQL pedidosAdmin (pedidos de todos) | cliente B | PROHIBIDO y sin datos | 200 PROHIBIDO | graphql-gateway (permiso por campo) | `test_graphql::test_matriz_de_permisos_de_campos_graphql` | ✓ |
| 8 | GET /api/orders/A-1042 (control: el dueño sí) | cliente A (dueño) | 200 y estado «Pago pendiente» | 200; estado «Pago pendiente»; sin cambios tras los intentos de B | orders | `test_seguridad_acceso::test_el_pedido_ajeno_sigue_intacto_tras_los_intentos` | ✓ |
| 9 | GET /api/orders/A-1042 (control: el personal sí) | administrador | 200 | 200 | orders | `test_seguridad_acceso::test_el_personal_si_ve_cualquier_pedido_y_los_datos_de_despacho` | ✓ |

#### C5 Acceso directo al backend sin identidad autorizada

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | GET auth/users sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | auth (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 2 | GET clients/clients sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | clients (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 3 | GET inventory/internal/summary sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | inventory (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 4 | GET orders/orders sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | orders (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 5 | GET payments/admin/payments sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | payments (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 6 | GET notifications/outbox sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | notifications (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 7 | GET analytics/internal/reports/sales sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | analytics (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 8 | POST graphql-gateway/graphql sin credencial de servicio | ninguna (sin X-Service-Name/Secret) | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | graphql-gateway (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |
| 9 | GET auth/users con un secreto inventado | se declara «api-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | auth (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 10 | GET clients/clients con un secreto inventado | se declara «api-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | clients (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 11 | GET inventory/internal/summary con un secreto inventado | se declara «graphql-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | inventory (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 12 | GET orders/orders con un secreto inventado | se declara «api-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | orders (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 13 | GET payments/admin/payments con un secreto inventado | se declara «api-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | payments (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 14 | GET notifications/outbox con un secreto inventado | se declara «api-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | notifications (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 15 | GET analytics/internal/reports/sales con un secreto inventado | se declara «graphql-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | analytics (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 16 | POST graphql-gateway/graphql con un secreto inventado | se declara «api-gateway» | 403 SECRETO_INVALIDO | 403 SECRETO_INVALIDO | graphql-gateway (compara con el secreto del par en Vault) | `test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado` | ✓ |
| 17 | GET inventory/products con el secreto del par «api-gateway→orders» | se declara «api-gateway» | 403 SECRETO_INVALIDO (cada par tiene su secreto) | 403 SECRETO_INVALIDO | inventory | `test_seguridad_acceso::test_el_secreto_de_un_par_no_sirve_para_otro_destino` | ✓ |
| 18 | GET orders/orders afirmando la identidad de un cliente, con secreto válido de «payments» | «payments» con identidad de cliente | 403 (solo gateways pueden afirmar identidad) | 403 LLAMADOR_NO_PERMITIDO | orders | `test_seguridad_acceso::test_solo_los_llamadores_de_confianza_pueden_afirmar_una_identidad` | ✓ |
| 19 | POST orders/…/cancellation desde el GraphQL Gateway (con su secreto) | «graphql-gateway» | 403 LLAMADOR_NO_PERMITIDO (solo lectura) | 403 LLAMADOR_NO_PERMITIDO | orders | `test_seguridad_acceso::test_el_graphql_gateway_es_de_solo_lectura_aunque_tenga_su_secreto` | ✓ |
| 20 | GET /api/admin/orders con cabeceras X-Authenticated-* y X-Service-* falsas | navegador anónimo | 401 (el gateway las descarta; la identidad sale de la sesión) | 401 NO_AUTENTICADO | api-gateway (lista blanca de cabeceras) | `test_seguridad_acceso::test_cabeceras_de_identidad_enviadas_por_el_navegador_se_ignoran` | ✓ |
| 21 | docker-compose.yml: servicios con puertos publicados | análisis estático del archivo (no se ejecutó docker compose) | solo api-gateway y provider-sandbox, y solo hacia 127.0.0.1; red «interna» sin salida a Internet | api-gateway: 127.0.0.1:8000:8000; provider-sandbox: 127.0.0.1:8300:8300; interna: internal=true | Docker Compose (redes) | `test_despliegue::test_solo_el_gateway_y_el_proveedor_simulado_publican_puertos_y_solo_hacia_localhost` | ✓ |

#### C6 Confirmar un pago con datos alterados del frontend

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | POST /api/orders con «precio»: 1 y «total»: 1 dentro del cuerpo | cliente | 422 (campos no declarados se rechazan) | 422 VALIDACION | orders (modelo con extra=forbid; el precio sale del inventario) | `test_negocio_pedidos::test_un_precio_enviado_dentro_de_una_linea_se_rechaza` | ✓ |
| 2 | POST /api/orders (pedido legítimo): ¿quién fija el total? | cliente | el total lo calcula el servidor con los precios del inventario | total 15980 = 2 × 7990 + despacho 0; estado «Pago pendiente» | orders + inventory | `test_negocio_pedidos::test_el_servidor_calcula_el_total_y_el_navegador_no_puede_fijarlo` | ✓ |
| 3 | PUT /api/orders/{pedido} | cliente | 4xx (no es su operación o la ruta no existe en el gateway) | 404 RUTA_NO_ENCONTRADA | api-gateway / payments | `test_negocio_pagos::test_un_cliente_no_puede_marcar_su_pedido_como_pagado` | ✓ |
| 4 | PUT /api/admin/orders/{pedido}/status | cliente | 4xx (no es su operación o la ruta no existe en el gateway) | 403 ROL_NO_AUTORIZADO | api-gateway / payments | `test_negocio_pagos::test_un_cliente_no_puede_marcar_su_pedido_como_pagado` | ✓ |
| 5 | POST /api/admin/orders/{pedido}/payment-confirmation | cliente | 4xx (no es su operación o la ruta no existe en el gateway) | 403 ROL_NO_AUTORIZADO | api-gateway / payments | `test_negocio_pagos::test_un_cliente_no_puede_marcar_su_pedido_como_pagado` | ✓ |
| 6 | POST /api/orders/{pedido}/payment-confirmed | cliente | 4xx (no es su operación o la ruta no existe en el gateway) | 404 RUTA_NO_ENCONTRADA | api-gateway / payments | `test_negocio_pagos::test_un_cliente_no_puede_marcar_su_pedido_como_pagado` | ✓ |
| 7 | POST /api/webhooks/provider sin firma | anónimo | 400 AVISO_NO_VALIDO | 400 AVISO_NO_VALIDO | payments (firma HMAC del proveedor) | `test_negocio_pagos::test_aviso_sin_firma_o_con_firma_falsa_se_rechaza` | ✓ |
| 8 | POST /api/webhooks/provider firmado con una clave inventada | atacante | 400 AVISO_NO_VALIDO | 400 AVISO_NO_VALIDO | payments | `test_negocio_pagos::test_aviso_sin_firma_o_con_firma_falsa_se_rechaza` | ✓ |
| 9 | POST /api/webhooks/provider con el cuerpo alterado después de firmar | atacante | 400 AVISO_NO_VALIDO | 400 AVISO_NO_VALIDO | payments | `test_negocio_pagos::test_aviso_alterado_despues_de_firmar_se_rechaza` | ✓ |
| 10 | POST /api/webhooks/provider con firma válida pero de hace 1 hora (repetición) | atacante | 400 AVISO_NO_VALIDO (ventana de 300 s) | 400 AVISO_NO_VALIDO | payments | `test_negocio_pagos::test_aviso_antiguo_o_del_futuro_se_rechaza` | ✓ |
| 11 | POST /api/webhooks/provider firmado correctamente pero con monto 1 | quien conozca la clave de firma | 409 MONTO_NO_COINCIDE | 409 MONTO_NO_COINCIDE | payments (compara con el monto fijado por orders) | `test_negocio_pagos::test_aviso_con_monto_distinto_no_aprueba_el_pago` | ✓ |
| 12 | GET /api/orders/{pedido}?pago=aprobado (como al volver del proveedor) | cliente | el estado sigue «Pago pendiente» | 200 | orders (el estado solo cambia por payment-confirmed) | `test_negocio_pagos::test_volver_del_proveedor_con_pago_aprobado_en_la_url_no_paga_nada` | ✓ |
| 13 | estado final tras todos los intentos | — | «Pago pendiente» y cobro «iniciado» | pedido «Pago pendiente»; cobro «iniciado» | orders + payments | `test_negocio_pagos::test_un_cliente_no_puede_marcar_su_pedido_como_pagado` | ✓ |
| 14 | POST /api/webhooks/provider legítimo (control) | proveedor | 200 y el pedido pasa a «En preparación» | 200; pedido «En preparación» | payments → orders | `test_negocio_pagos::test_aviso_firmado_legitimo_aprueba_una_sola_vez_aunque_se_repita` | ✓ |

### 7.4 Evidencia de la ejecución con Docker

La versión final del backend (el sistema se probó sin el frontend conectado) se levantó con Docker Compose el 8 de noviembre de 2026, a las 16:11 (hora de Chile), en Docker Desktop para Windows (Docker 29.9.2, Compose v5.6.1), y se probó por HTTP contra los contenedores. Todo lo que sigue es salida literal de las herramientas, guardada en [`docs/evidencia/docker_2026-11-08/`](evidencia/docker_2026-11-08/README.md).

| Qué se ejecutó | Resultado | Archivo |
|---|---|---|
| `docker compose up -d --build` | las 10 imágenes se construyeron sin errores y los 12 contenedores quedaron `healthy` (`vault-seed` termina por diseño) | [`03-up.txt`](evidencia/docker_2026-11-08/03-up.txt), [`04-ps.txt`](evidencia/docker_2026-11-08/04-ps.txt) |
| `python scripts/smoke_test.py` | **29 de 29** | [`05-smoke-test.txt`](evidencia/docker_2026-11-08/05-smoke-test.txt) |
| `capturas_http.py`: los casos C1–C4 y C6, el pedido, el pago y GraphQL, por HTTP contra `localhost:8000` | 27 de 27 comprobaciones (capturas 1 a 9) | [`capturas/`](evidencia/docker_2026-11-08/capturas) |
| Puertos alcanzables desde el equipo (`capturas_http.py`) | 3 de 4 como se esperaba; el cuarto, el 27017, lo atiende el MongoDB de Windows instalado en el equipo, no el proyecto (diagnóstico aparte) | [`10a`](evidencia/docker_2026-11-08/capturas/10a-c5-puertos-desde-el-equipo.txt), [`10c`](evidencia/docker_2026-11-08/capturas/10c-diagnostico-puerto-27017.txt) |
| `acceso_directo.py`: llamadas directas a los 8 servicios privados, desde dentro de la red de Docker | **16 de 16** rechazadas (403 `LLAMADOR_NO_PERMITIDO` sin credencial y 403 `SECRETO_INVALIDO` con un secreto inventado) | [`10b-c5-servicios-privados.txt`](evidencia/docker_2026-11-08/capturas/10b-c5-servicios-privados.txt) |

Cada «captura» es la transcripción de una solicitud HTTP real: las líneas con `>` son la petición y las líneas con `<` la respuesta, tal como viajaron. Se oculta el valor de la cookie de sesión y las listas largas se recortan a 2 elementos; lo demás no se edita. Las comprobaciones del final de cada captura comparan lo esperado con lo obtenido.

**Captura 1. C1, catálogo anónimo.** `GET /api/products` sin cookie: 200, sin `Set-Cookie` y solo con campos públicos.

```text
Captura 01 · C1 Catálogo anónimo
Capturada el 2026-11-08 16:19:18 contra http://localhost:8000. Las listas largas se recortan a 2 elementos; lo demás es literal.
====================================================================================================

[1] GET del catálogo sin cookie de sesión
> GET /api/products?limit=5 HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000

< HTTP/1.1 200 OK
< content-type: application/json
< cache-control: no-store
< x-request-id: fc5fd572364a4146
< x-total-count: 13
< 
< [
<   {
<     "id": "p01",
<     "categoria": "parrilladas",
<     "nombre": "Parrillada para 2",
<     "precio": 24990,
<     "disponible": true,
<     "imagen": "img/parrillada-2.svg",
<     "descripcion": "Lomo vetado, chorizos parrilleros y pollo, con papas rústicas.",
<     "incluye": [
<       "Lomo vetado 300 g",
<       "2 chorizos parrilleros",
<       "… (2 más)"
<     ],
<     "alcohol": false,
<     "personas": 2
<   },
<   {
<     "id": "p02",
<     "categoria": "parrilladas",
<     "nombre": "Parrillada familiar",
<     "precio": 44990,
<     "disponible": true,
<     "imagen": "img/parrillada-familiar.svg",
<     "descripcion": "Para 4 personas: lomo, costillar, chorizos y pollo, con ensalada y pebre.",
<     "incluye": [
<       "Lomo vetado 600 g",
<       "Costillar de cerdo",
<       "… (4 más)"
<     ],
<     "alcohol": false,
<     "personas": 4
<   },
<   "… (3 más)"
< ]
Campos de cada producto: alcohol, categoria, descripcion, disponible, id, imagen, incluye, nombre, personas, precio

====================================================================================================
Comprobaciones:
  CUMPLE  responde 200 con productos
  CUMPLE  no entrega cookie a un anónimo
  CUMPLE  solo campos públicos (sin costos, ni existencias internas)
```

**Captura 2. Inicio de sesión.** `POST /api/auth/login`: la sesión viaja en una cookie `HttpOnly` y `SameSite`; el token no aparece en el cuerpo de la respuesta.

```text
Captura 02 · Inicio de sesión del cliente
Capturada el 2026-11-08 16:19:20 contra http://localhost:8000. Las listas largas se recortan a 2 elementos; lo demás es literal.
====================================================================================================

[1] POST login (la clave se oculta en este texto)
> POST /api/auth/login HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> content-type: application/json
> 
> {
>   "username": "andrea.molina@correo.cl",
>   "password": "«secreto»"
> }

< HTTP/1.1 200 OK
< content-type: application/json
< cache-control: no-store
< set-cookie: session_token=«valor secreto»; HttpOnly; Max-Age=7200; Path=/; SameSite=lax
< x-request-id: c25029168ac44935
< 
< {
<   "usuario": {
<     "user_id": "u-c0001",
<     "username": "andrea.molina@correo.cl",
<     "nombre": "Andrea Molina Fuentes",
<     "roles": [
<       "cliente"
<     ],
<     "client_id": "c-0001"
<   },
<   "expira_en": 7200
< }

====================================================================================================
Comprobaciones:
  CUMPLE  responde 200
  CUMPLE  la sesión viaja en una cookie HttpOnly
  CUMPLE  la cookie es SameSite
  CUMPLE  el token de sesión NO va en el cuerpo de la respuesta
```

**Captura 3. Pedido.** `POST /api/orders` con `Idempotency-Key`: 201; el cliente solo envía identificadores y cantidades y el total lo calcula el servidor; repetir la petición con la misma clave devuelve el mismo pedido.

```text
Captura 03 · Pedido creado con sesión de cliente
Capturada el 2026-11-08 16:19:20 contra http://localhost:8000. Las listas largas se recortan a 2 elementos; lo demás es literal.
====================================================================================================

[1] POST pedido (el cliente no manda precios ni total)
> POST /api/orders HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> content-type: application/json
> idempotency-key: 84a1beb9443b4d6b84c703703caff5b7
> cookie: session_token=«valor secreto»
> 
> {
>   "items": [
>     {
>       "id": "p07",
>       "cantidad": 2
>     }
>   ],
>   "comuna": "Ñuñoa",
>   "medioPago": "Servipag"
> }

< HTTP/1.1 201 Created
< content-type: application/json
< cache-control: no-store
< x-request-id: 68d87d6e1df24878
< 
< {
<   "id": "A-1043",
<   "fecha": "2026-11-08T19:19:20.381Z",
<   "origen": "web",
<   "cliente": {
<     "nombre": "Andrea Molina Fuentes",
<     "correo": "andrea.molina@correo.cl",
<     "telefono": "+56 9 5555 0101",
<     "direccion": "Los Aromos 1234, depto. 51",
<     "comuna": "Ñuñoa",
<     "indicaciones": ""
<   },
<   "lineas": [
<     {
<       "itemId": "p07",
<       "nombre": "Choripán x4",
<       "cantidad": 2,
<       "precio": 7990
<     }
<   ],
<   "subtotal": 15980,
<   "despacho": 0,
<   "total": 15980,
<   "pago": "Servipag",
<   "estado": "Pago pendiente",
<   "reembolso": "no_aplica",
<   "historial": [
<     {
<       "estado": "Pago pendiente",
<       "fecha": "2026-11-08T19:19:20.381Z",
<       "por": "Cliente"
<     }
<   ]
< }

[2] La misma petición otra vez, con la misma Idempotency-Key
> POST /api/orders HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> content-type: application/json
> idempotency-key: 84a1beb9443b4d6b84c703703caff5b7
> cookie: session_token=«valor secreto»
> 
> {
>   "items": [
>     {
>       "id": "p07",
>       "cantidad": 2
>     }
>   ],
>   "comuna": "Ñuñoa",
>   "medioPago": "Servipag"
> }

< HTTP/1.1 200 OK
< content-type: application/json
< cache-control: no-store
< x-request-id: a498fe32efa2403a
< 
< {
<   "id": "A-1043",
<   "fecha": "2026-11-08T19:19:20.381Z",
<   "origen": "web",
<   "cliente": {
<     "nombre": "Andrea Molina Fuentes",
<     "correo": "andrea.molina@correo.cl",
<     "telefono": "+56 9 5555 0101",
<     "direccion": "Los Aromos 1234, depto. 51",
<     "comuna": "Ñuñoa",
<     "indicaciones": ""
<   },
<   "lineas": [
<     {
<       "itemId": "p07",
<       "nombre": "Choripán x4",
<       "cantidad": 2,
<       "precio": 7990
<     }
<   ],
<   "subtotal": 15980,
<   "despacho": 0,
<   "total": 15980,
<   "pago": "Servipag",
<   "estado": "Pago pendiente",
<   "reembolso": "no_aplica",
<   "historial": [
<     {
<       "estado": "Pago pendiente",
<       "fecha": "2026-11-08T19:19:20.381Z",
<       "por": "Cliente"
<     }
<   ]
< }

====================================================================================================
Comprobaciones:
  CUMPLE  crea el pedido: 201
  CUMPLE  el total lo calcula el servidor y es mayor que cero
  CUMPLE  el estado inicial es «Pago pendiente»
  CUMPLE  repetir la petición con la misma clave devuelve el MISMO pedido
```

**Captura 4. Pago con el proveedor simulado.** Inicio del pago (201), pago en la página del proveedor (303) y el pedido en «En preparación» después del aviso firmado. La dirección de vuelta de la respuesta 303 es una pantalla del frontend de la C2 (`pedidos.html`), que no forma parte del proyecto del backend: el backend solo guarda esa dirección.

```text
Captura 04 · Pago con el proveedor simulado
Capturada el 2026-11-08 16:19:23 contra http://localhost:8000. Las listas largas se recortan a 2 elementos; lo demás es literal.
====================================================================================================

[1] Iniciar el pago del pedido
> POST /api/orders/A-1043/payment HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> cookie: session_token=«valor secreto»

< HTTP/1.1 201 Created
< content-type: application/json
< cache-control: no-store
< x-request-id: 8201fc0a3e994812
< 
< {
<   "id": "pay-f9a49e46ca644eea",
<   "pedidoId": "A-1043",
<   "estado": "iniciado",
<   "medio": "Servipag",
<   "modo": "proveedor",
<   "monto": 15980,
<   "creadoEn": "2026-11-08T19:19:20.450Z",
<   "aprobadoEn": null,
<   "checkoutUrl": "http://localhost:8300/checkout/prv_G3YIAxAx1VjfIPdZcXs",
<   "reembolso": null
< }

[2] El cliente paga en la página del proveedor simulado (el proveedor avisa al sistema con un aviso firmado)
> POST /checkout/prv_G3YIAxAx1VjfIPdZcXs/pay HTTP/1.1
> host: localhost:8300

< HTTP/1.1 303 See Other
< cache-control: no-store
< location: http://localhost:8000/pedidos.html?pedido=A-1043&pago=aprobado
< x-request-id: 81f5336f7f8d4f1b

[3] El pedido después del aviso
> GET /api/orders/A-1043 HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> cookie: session_token=«valor secreto»

< HTTP/1.1 200 OK
< content-type: application/json
< cache-control: no-store
< x-request-id: 2be56af8218d4771
< 
< {
<   "id": "A-1043",
<   "fecha": "2026-11-08T19:19:20.381Z",
<   "origen": "web",
<   "cliente": {
<     "nombre": "Andrea Molina Fuentes",
<     "correo": "andrea.molina@correo.cl",
<     "telefono": "+56 9 5555 0101",
<     "direccion": "Los Aromos 1234, depto. 51",
<     "comuna": "Ñuñoa",
<     "indicaciones": ""
<   },
<   "lineas": [
<     {
<       "itemId": "p07",
<       "nombre": "Choripán x4",
<       "cantidad": 2,
<       "precio": 7990
<     }
<   ],
<   "subtotal": 15980,
<   "despacho": 0,
<   "total": 15980,
<   "pago": "Servipag",
<   "estado": "En preparación",
<   "reembolso": "no_aplica",
<   "historial": [
<     {
<       "estado": "Pago pendiente",
<       "fecha": "2026-11-08T19:19:20.381Z",
<       "por": "Cliente"
<     },
<     {
<       "estado": "En preparación",
<       "fecha": "2026-11-08T19:19:22.572Z",
<       "por": "Sistema de pagos"
<     }
<   ]
< }

====================================================================================================
Comprobaciones:
  CUMPLE  el pago se inicia (200 o 201) y entrega la página del proveedor
  CUMPLE  el proveedor acepta el pago (303)
  CUMPLE  el aviso firmado deja el pedido «En preparación»
```

**Captura 5. GraphQL «Mis pedidos».** La consulta `CONSULTA_PEDIDOS` de la C2 (`datos-frontend/consultas-graphql.json`), en una sola solicitud: trae el pedido con su cliente, sus líneas, su pago y su boleta.

```text
Captura 05 · GraphQL Mis pedidos
Capturada el 2026-11-08 16:19:23 contra http://localhost:8000. Las listas largas se recortan a 2 elementos; lo demás es literal.
====================================================================================================

[1] POST /api/graphql con la consulta CONSULTA_PEDIDOS de datos-frontend/consultas-graphql.json
> POST /api/graphql HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> content-type: application/json
> cookie: session_token=«valor secreto»
> 
> {
>   "query": "query MisPedidos($desde: Int!) { misPedidos(limit: 20, offset: $desde) { total items { id fecha estado subtotal despacho total medioPago reembolso motivoAnulacion anuladoPor fechaAnulacion cliente { nombre direccion comuna } lineas { nombre cantidad precio subtotal } pago { id estado medio monto checkoutUrl instrucciones reembolso } boleta { folio total estado } } } }",
>   "variables": {
>     "desde": 0
>   }
> }

< HTTP/1.1 200 OK
< content-type: application/json
< cache-control: no-store
< x-request-id: b36e39fe88cc4b9f
< 
< {
<   "data": {
<     "misPedidos": {
<       "total": 2,
<       "items": [
<         {
<           "id": "A-1043",
<           "fecha": "2026-11-08T19:19:20.381Z",
<           "estado": "En preparación",
<           "subtotal": 15980,
<           "despacho": 0,
<           "total": 15980,
<           "medioPago": "Servipag",
<           "reembolso": "no_aplica",
<           "motivoAnulacion": null,
<           "anuladoPor": null,
<           "fechaAnulacion": null,
<           "cliente": {
<             "nombre": "Andrea Molina Fuentes",
<             "direccion": "Los Aromos 1234, depto. 51",
<             "comuna": "Ñuñoa"
<           },
<           "lineas": [
<             {
<               "nombre": "Choripán x4",
<               "cantidad": 2,
<               "precio": 7990,
<               "subtotal": 15980
<             }
<           ],
<           "pago": {
<             "id": "pay-f9a49e46ca644eea",
<             "estado": "aprobado",
<             "medio": "Servipag",
<             "monto": 15980,
<             "checkoutUrl": null,
<             "instrucciones": null,
<             "reembolso": null
<           },
<           "boleta": {
<             "folio": "B-000002",
<             "total": 15980,
<             "estado": "vigente"
<           }
<         },
<         {
<           "id": "A-1038",
<           "fecha": "2026-11-06T17:41:52.728Z",
<           "estado": "Entregado",
<           "subtotal": 50970,
<           "despacho": 0,
<           "total": 50970,
<           "medioPago": "Servipag",
<           "reembolso": "no_aplica",
<           "motivoAnulacion": null,
<           "anuladoPor": null,
<           "fechaAnulacion": null,
<           "cliente": {
<             "nombre": "Andrea Molina Fuentes",
<             "direccion": "Los Aromos 1234, depto. 51",
<             "comuna": "Providencia"
<           },
<           "lineas": [
<             {
<               "nombre": "Parrillada familiar",
<               "cantidad": 1,
<               "precio": 44990,
<               "subtotal": 44990
<             },
<             {
<               "nombre": "Bebida 1,5 L",
<               "cantidad": 2,
<               "precio": 2990,
<               "subtotal": 5980
<             }
<           ],
<           "pago": null,
<           "boleta": null
<         }
<       ]
<     }
<   }
< }

La lista completa trae 2 pedido(s) de un total de 2; lo mostrado arriba es el recorte.
El pedido recién creado (A-1043) figura con pago «aprobado» y 1 línea(s).

====================================================================================================
Comprobaciones:
  CUMPLE  responde 200 y sin errores
  CUMPLE  trae el pedido con su pago y sus líneas en UNA consulta
```

**Captura 6. C2, operación protegida sin sesión válida.** `POST /api/orders` sin cookie (401 `NO_AUTENTICADO`) y con una cookie inventada (401 `SESION_NO_VALIDA`).

```text
Captura 06 · C2 Operación protegida sin sesión válida
Capturada el 2026-11-08 16:19:27 contra http://localhost:8000. Las listas largas se recortan a 2 elementos; lo demás es literal.
====================================================================================================

[1] POST /api/orders sin cookie
> POST /api/orders HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> content-type: application/json
> idempotency-key: bec18eb0ffe544af8c6c0352c1b8a60a
> 
> {
>   "items": [
>     {
>       "id": "p07",
>       "cantidad": 2
>     }
>   ],
>   "comuna": "Ñuñoa",
>   "medioPago": "Servipag"
> }

< HTTP/1.1 401 Unauthorized
< content-type: application/json
< cache-control: no-store
< x-request-id: ead59bfc109f4fbd
< 
< {
<   "detail": "Sesión requerida",
<   "codigo": "NO_AUTENTICADO",
<   "request_id": "ead59bfc109f4fbd"
< }

[2] POST /api/orders con una cookie inventada
> POST /api/orders HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> content-type: application/json
> idempotency-key: 85750019bb854b888e1345b4dd5e8670
> cookie: session_token=«valor secreto»
> 
> {
>   "items": [
>     {
>       "id": "p07",
>       "cantidad": 2
>     }
>   ],
>   "comuna": "Ñuñoa",
>   "medioPago": "Servipag"
> }

< HTTP/1.1 401 Unauthorized
< content-type: application/json
< cache-control: no-store
< set-cookie: session_token=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax
< x-request-id: 8d2bcc23c1ee4eeb
< 
< {
<   "detail": "Tu sesión terminó. Vuelve a ingresar.",
<   "codigo": "SESION_NO_VALIDA",
<   "request_id": "8d2bcc23c1ee4eeb"
< }

====================================================================================================
Comprobaciones:
  CUMPLE  sin cookie: 401 NO_AUTENTICADO
  CUMPLE  cookie inventada: 401 SESION_NO_VALIDA
```

**Captura 7. C3, administración desde un rol sin permiso.** Con la sesión de un cliente, crear un producto y listar los usuarios dan 403 `ROL_NO_AUTORIZADO`.

```text
Captura 07 · C3 Administración desde un rol sin permiso
Capturada el 2026-11-08 16:19:27 contra http://localhost:8000. Las listas largas se recortan a 2 elementos; lo demás es literal.
====================================================================================================

[1] POST /api/products con sesión de cliente
> POST /api/products HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> content-type: application/json
> cookie: session_token=«valor secreto»
> 
> {
>   "nombre": "Producto no autorizado 84a3d8",
>   "categoria": "bebidas",
>   "precio": 1000,
>   "descripcion": "x",
>   "imagen": "img/cerveza.svg"
> }

< HTTP/1.1 403 Forbidden
< content-type: application/json
< cache-control: no-store
< x-request-id: d9a5b6fde14f49c4
< 
< {
<   "detail": "No tiene permisos para esta operación",
<   "codigo": "ROL_NO_AUTORIZADO",
<   "request_id": "d9a5b6fde14f49c4"
< }

[2] GET /api/users con sesión de cliente
> GET /api/users HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> cookie: session_token=«valor secreto»

< HTTP/1.1 403 Forbidden
< content-type: application/json
< cache-control: no-store
< x-request-id: e34787bc3fb84b38
< 
< {
<   "detail": "No tiene permisos para esta operación",
<   "codigo": "ROL_NO_AUTORIZADO",
<   "request_id": "e34787bc3fb84b38"
< }

====================================================================================================
Comprobaciones:
  CUMPLE  crear un producto siendo cliente: 403 ROL_NO_AUTORIZADO
  CUMPLE  listar usuarios siendo cliente: 403 ROL_NO_AUTORIZADO
```

**Captura 8. C4, pedido ajeno.** El cliente B pide el pedido del cliente A (403 `PROHIBIDO`, con la misma respuesta que un pedido inexistente) y no puede iniciar su pago; el dueño sí lo ve (200).

```text
Captura 08 · C4 Consulta de un pedido ajeno
Capturada el 2026-11-08 16:19:29 contra http://localhost:8000. Las listas largas se recortan a 2 elementos; lo demás es literal.
====================================================================================================

[1] El cliente B pide el pedido del cliente A
> GET /api/orders/A-1043 HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> cookie: session_token=«valor secreto»

< HTTP/1.1 403 Forbidden
< content-type: application/json
< cache-control: no-store
< x-request-id: 99086f4602e74333
< 
< {
<   "detail": "No tiene permisos para esta operación",
<   "codigo": "PROHIBIDO",
<   "request_id": "99086f4602e74333"
< }

[2] El cliente B pide un pedido que no existe
> GET /api/orders/A-999999 HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> cookie: session_token=«valor secreto»

< HTTP/1.1 403 Forbidden
< content-type: application/json
< cache-control: no-store
< x-request-id: 8ca56b322e664cbc
< 
< {
<   "detail": "No tiene permisos para esta operación",
<   "codigo": "PROHIBIDO",
<   "request_id": "8ca56b322e664cbc"
< }

[3] El cliente B intenta iniciar el pago del pedido de A
> POST /api/orders/A-1043/payment HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> cookie: session_token=«valor secreto»

< HTTP/1.1 403 Forbidden
< content-type: application/json
< cache-control: no-store
< x-request-id: 11ee83da25f84322
< 
< {
<   "detail": "No tiene permisos para esta operación",
<   "codigo": "PROHIBIDO",
<   "request_id": "11ee83da25f84322"
< }

[4] Control: el cliente A (dueño) pide su pedido
> GET /api/orders/A-1043 HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> cookie: session_token=«valor secreto»

< HTTP/1.1 200 OK
< content-type: application/json
< cache-control: no-store
< x-request-id: 59119d3accba499a
< 
< {
<   "id": "A-1043",
<   "fecha": "2026-11-08T19:19:20.381Z",
<   "origen": "web",
<   "cliente": {
<     "nombre": "Andrea Molina Fuentes",
<     "correo": "andrea.molina@correo.cl",
<     "telefono": "+56 9 5555 0101",
<     "direccion": "Los Aromos 1234, depto. 51",
<     "comuna": "Ñuñoa",
<     "indicaciones": ""
<   },
<   "lineas": [
<     {
<       "itemId": "p07",
<       "nombre": "Choripán x4",
<       "cantidad": 2,
<       "precio": 7990
<     }
<   ],
<   "subtotal": 15980,
<   "despacho": 0,
<   "total": 15980,
<   "pago": "Servipag",
<   "estado": "En preparación",
<   "reembolso": "no_aplica",
<   "historial": [
<     {
<       "estado": "Pago pendiente",
<       "fecha": "2026-11-08T19:19:20.381Z",
<       "por": "Cliente"
<     },
<     {
<       "estado": "En preparación",
<       "fecha": "2026-11-08T19:19:22.572Z",
<       "por": "Sistema de pagos"
<     }
<   ]
< }

====================================================================================================
Comprobaciones:
  CUMPLE  pedido ajeno: 403 PROHIBIDO
  CUMPLE  la respuesta es IDÉNTICA a la de un pedido inexistente (no revela si existe)
  CUMPLE  el cliente B no puede iniciar el pago de un pedido ajeno (403 o 404)
  CUMPLE  el dueño sí lo ve: 200
```

**Captura 9. C6, pago con datos alterados.** Un cliente no puede confirmar un pago (403 `ROL_NO_AUTORIZADO`); un aviso del proveedor por 1 peso, sin firma o con una firma inventada, se rechaza (400 `AVISO_NO_VALIDO`).

```text
Captura 09 · C6 Confirmar un pago con datos alterados
Capturada el 2026-11-08 16:19:33 contra http://localhost:8000. Las listas largas se recortan a 2 elementos; lo demás es literal.
====================================================================================================

[1] Un cliente intenta confirmar el pago él mismo
> POST /api/admin/orders/A-1043/payment-confirmation HTTP/1.1
> host: localhost:8000
> origin: http://localhost:8000
> content-type: application/json
> cookie: session_token=«valor secreto»
> 
> {}

< HTTP/1.1 403 Forbidden
< content-type: application/json
< cache-control: no-store
< x-request-id: 88fcf7ecdb0e4f39
< 
< {
<   "detail": "No tiene permisos para esta operación",
<   "codigo": "ROL_NO_AUTORIZADO",
<   "request_id": "88fcf7ecdb0e4f39"
< }

[2] Aviso del proveedor SIN firma (monto 1)
> POST /api/webhooks/provider HTTP/1.1
> host: localhost:8000
> content-type: application/json
> x-provider-event-id: evt_dabd1ef27f024396
> 
> {
>   "id": "evt_dabd1ef27f024396",
>   "type": "payment.succeeded",
>   "created": 1794165569,
>   "data": {
>     "payment_id": "pay_falso",
>     "reference": "pay-f9a49e46ca644eea",
>     "amount": 1,
>     "currency": "CLP"
>   }
> }

< HTTP/1.1 400 Bad Request
< content-type: application/json
< cache-control: no-store
< x-request-id: 2a3f236fd17f4c7b
< 
< {
<   "detail": "Aviso no válido",
<   "codigo": "AVISO_NO_VALIDO",
<   "request_id": "2a3f236fd17f4c7b"
< }

[3] Aviso con una firma inventada (monto 1)
> POST /api/webhooks/provider HTTP/1.1
> host: localhost:8000
> content-type: application/json
> x-provider-signature: t=1794165569,v1=a4683659912349a99d771aea3072d484acf0e40baf4b474fb96061d1baec54a7
> x-provider-event-id: evt_dabd1ef27f024396
> 
> {
>   "id": "evt_dabd1ef27f024396",
>   "type": "payment.succeeded",
>   "created": 1794165569,
>   "data": {
>     "payment_id": "pay_falso",
>     "reference": "pay-f9a49e46ca644eea",
>     "amount": 1,
>     "currency": "CLP"
>   }
> }

< HTTP/1.1 400 Bad Request
< content-type: application/json
< cache-control: no-store
< x-request-id: 33f7616e99ae4653
< 
< {
<   "detail": "Aviso no válido",
<   "codigo": "AVISO_NO_VALIDO",
<   "request_id": "33f7616e99ae4653"
< }

====================================================================================================
Comprobaciones:
  CUMPLE  un cliente no puede confirmar pagos: 403 ROL_NO_AUTORIZADO
  CUMPLE  aviso sin firma: 400 AVISO_NO_VALIDO
  CUMPLE  aviso con firma inventada: 400 AVISO_NO_VALIDO
```

**Captura 10. C5, acceso directo al backend.** Tiene tres partes.

*(a) Desde el equipo.* Los puertos que el compose publica a propósito responden (8000, el gateway, y 8300, el proveedor simulado) y el de Vault (8200) está cerrado. El 27017 también respondió, y por eso su fila figura como «FALLA»: la comprobación solo mira si algo responde en ese puerto, no quién. Lo atiende `mongod.exe`, el servicio de Windows «MongoDB Server» instalado en el equipo del autor, ajeno a Docker (parte b).

```text
Captura 10a · C5 Puertos alcanzables desde el equipo (127.0.0.1)
Capturada el 2026-11-08 16:19:35. Se intenta abrir una conexión TCP a cada puerto (espera máxima: 2 s).
====================================================================================================

  127.0.0.1:8000   API Gateway                    ABIERTO   (se esperaba abierto: se publica a propósito)
  127.0.0.1:8300   proveedor de pagos simulado    ABIERTO   (se esperaba abierto: se publica a propósito)
  127.0.0.1:8200   Vault                          RECHAZADO   (se esperaba rechazado: no se publica)
  127.0.0.1:27017  MongoDB                        ABIERTO   (se esperaba rechazado: no se publica)

====================================================================================================
Comprobaciones:
  CUMPLE  puerto 8000 (API Gateway): abierto
  CUMPLE  puerto 8300 (proveedor de pagos simulado): abierto
  CUMPLE  puerto 8200 (Vault): rechazado
  FALLA   puerto 27017 (MongoDB): rechazado
```

*(b) Diagnóstico de ese puerto.* El único proceso que escucha en `127.0.0.1:27017` es `mongod.exe` (PID 4600, servicio de Windows). El contenedor del proyecto, `asador-mongo-1`, solo expone `27017/tcp` dentro de la red de Docker, sin puerto publicado hacia el equipo (`27017/tcp -> :0`), igual que Vault (`8200/tcp -> :0`); los únicos puertos publicados son `127.0.0.1:8000` y `127.0.0.1:8300`.

```text
Diagnostico del puerto 27017 en este equipo - 2026-11-08 16:29:46

1) Conexiones que escuchan en el puerto 27017 (netstat -ano):
   TCP    127.0.0.1:27017        0.0.0.0:0              LISTENING       4600

2) Proceso dueno de cada conexion (tasklist):
   PID 4600: "mongod.exe","4600","Services","0","55.972 KB"

3) Contenedores de Docker que mencionan 27017 (docker ps -a):
   asador-mongo-1 | mongo:8.0 | Up 18 minutes (healthy) | 27017/tcp

4) Puertos PUBLICADOS por el proyecto asador (docker compose ps):
   asador-analytics-1 | []
   asador-api-gateway-1 | [8000/tcp -> 127.0.0.1:8000]
   asador-auth-1 | []
   asador-clients-1 | []
   asador-graphql-gateway-1 | []
   asador-inventory-1 | []
   asador-mongo-1 | [27017/tcp -> :0]
   asador-notifications-1 | []
   asador-orders-1 | []
   asador-payments-1 | []
   asador-provider-sandbox-1 | [8300/tcp -> 127.0.0.1:8300]
   asador-vault-1 | [8200/tcp -> :0]

5) Servicios de Windows relacionados con MongoDB:
   MongoDB | Running | MongoDB Server (MongoDB)
```

*(c) Desde dentro de la red de Docker.* Se llamó directamente a los 8 servicios privados desde el contenedor del gateway, sin credencial de servicio y con un secreto inventado: las 16 llamadas se rechazaron con 403 (`LLAMADOR_NO_PERMITIDO` y `SECRETO_INVALIDO`).

```text
1) SIN credencial de servicio (ni X-Service-Name ni X-Service-Secret)  ->  se espera 403 LLAMADOR_NO_PERMITIDO
  CUMPLE  GET  http://auth:8000/users                               -> 403 LLAMADOR_NO_PERMITIDO
  CUMPLE  GET  http://clients:8000/clients                          -> 403 LLAMADOR_NO_PERMITIDO
  CUMPLE  GET  http://inventory:8000/internal/summary               -> 403 LLAMADOR_NO_PERMITIDO
  CUMPLE  GET  http://orders:8000/orders                            -> 403 LLAMADOR_NO_PERMITIDO
  CUMPLE  GET  http://payments:8000/admin/payments                  -> 403 LLAMADOR_NO_PERMITIDO
  CUMPLE  GET  http://notifications:8000/outbox                     -> 403 LLAMADOR_NO_PERMITIDO
  CUMPLE  GET  http://analytics:8000/internal/reports/sales         -> 403 LLAMADOR_NO_PERMITIDO
  CUMPLE  POST http://graphql-gateway:8000/graphql                  -> 403 LLAMADOR_NO_PERMITIDO

2) Declarando ser api-gateway, con un secreto inventado  ->  se espera 403 SECRETO_INVALIDO
  CUMPLE  GET  http://auth:8000/users                               -> 403 SECRETO_INVALIDO
  CUMPLE  GET  http://clients:8000/clients                          -> 403 SECRETO_INVALIDO
  CUMPLE  GET  http://inventory:8000/internal/summary               -> 403 SECRETO_INVALIDO
  CUMPLE  GET  http://orders:8000/orders                            -> 403 SECRETO_INVALIDO
  CUMPLE  GET  http://payments:8000/admin/payments                  -> 403 SECRETO_INVALIDO
  CUMPLE  GET  http://notifications:8000/outbox                     -> 403 SECRETO_INVALIDO
  CUMPLE  GET  http://analytics:8000/internal/reports/sales         -> 403 SECRETO_INVALIDO
  CUMPLE  POST http://graphql-gateway:8000/graphql                  -> 403 SECRETO_INVALIDO

Cuerpo completo de la primera respuesta (sin credencial):
  {"detail":"Llamada no autorizada","codigo":"LLAMADOR_NO_PERMITIDO","request_id":"99b22ce373e6413e"}

16 de 16 llamadas fueron rechazadas como se esperaba
```

**Alcance de esta evidencia.** Es una sola puesta en marcha, en un solo equipo, con los datos de demostración y el proveedor de pagos simulado. La evidencia amplia sigue siendo la suite automática ([10.3](#103-pruebas-ejecutadas)) y los controles C1–C6 de arriba; estas capturas muestran los mismos controles sobre los contenedores. El arranque (16:11) y las pruebas (16:17 a 16:19) fueron dos ejecuciones consecutivas de `verificar_docker.ps1`: la primera se detuvo tras el arranque por un defecto del propio script (PowerShell devolvió vacío un código de salida), que se corrigió, y la segunda, sobre el mismo sistema ya levantado, hizo las pruebas. Las herramientas con las que se obtuvo están en [`herramientas/`](evidencia/docker_2026-11-08/herramientas) y se ejecutan con `verificar_docker.ps1`.

---

## M8 GraphQL: agregación de solo lectura

### 8.1 Separación privada

El GraphQL Gateway es un servicio **privado y de solo lectura**: el navegador no puede alcanzarlo directamente; entra por `POST /api/graphql` (S38) del API Gateway, que ya verificó la sesión. Reglas (ADR-009): sin mutaciones ni suscripciones, sin GraphiQL ni introspección, solo `POST` con JSON, una sola vez cada servicio por consulta (DataLoader), límites de profundidad, alias, tokens y costo, y errores enmascarados. Su secreto con cada servicio permite únicamente métodos `GET` de lectura (`test_el_graphql_gateway_es_de_solo_lectura_aunque_tenga_su_secreto`).

### 8.2 Esquema

El esquema completo, generado desde el código, está en [`docs/graphql/schema.graphql`](graphql/schema.graphql).

```graphql
type Boleta {
  folio: String!
  total: Int!
  estado: String!
}

type ConteoEstado {
  estado: String!
  cantidad: Int!
}

type DatosCliente {
  nombre: String!
  correo: String!
  telefono: String!
  direccion: String!
  comuna: String!
  indicaciones: String!
}

type DiaVenta {
  fecha: String!
  pedidos: Int!
  ventas: Monto!
  ticketPromedio: Int!
}

type Hito {
  estado: String!
  fecha: String!
  por: String!
}

type Linea {
  itemId: String
  nombre: String!
  cantidad: Int!
  precio: Int!
  subtotal: Int!
  imagen: String
  disponible: Boolean
}

type MedioVenta {
  medio: String!
  pedidos: Int!
  ventas: Monto!
}

"""Monto en pesos chilenos, entero sin el tope de 32 bits de Int"""
scalar Monto

type PaginaPedidos {
  total: Int!
  items: [Pedido!]!
}

type Pago {
  id: String!
  estado: String!
  medio: String!
  monto: Int!
  checkoutUrl: String
  instrucciones: String
  reembolso: String
}

type PanelAdmin {
  pedidosPorEstado: [ConteoEstado!]!
  productos: ResumenProductos!
  pagos: ResumenPagos!
}

type Pedido {
  id: ID!
  fecha: String!
  origen: String!
  estado: String!
  subtotal: Int!
  despacho: Int!
  total: Int!
  medioPago: String!
  reembolso: String!
  motivoAnulacion: String
  anuladoPor: String
  fechaAnulacion: String
  lineas: [Linea!]!
  historial: [Hito!]!
  cliente: DatosCliente!
  pago: Pago
  boleta: Boleta
}

type ProductoVendido {
  nombre: String!
  unidades: Int!
  ventas: Monto!
}

type Query {
  misPedidos(limit: Int! = 10, offset: Int! = 0): PaginaPedidos
  pedidosAdmin(estado: String! = "activos", limit: Int! = 50, offset: Int! = 0): PaginaPedidos
  panelAdmin: PanelAdmin
  reporteVentas(desde: String!, hasta: String!): ReporteVentas
}

type ReporteVentas {
  desde: String!
  hasta: String!
  dias: [DiaVenta!]!
  totales: TotalesVenta!
  porMedioPago: [MedioVenta!]!
  topProductos: [ProductoVendido!]!
}

type ResumenPagos {
  iniciados: Int!
  aprobados: Int!
  reembolsosPendientes: Int!
  pagosManualesPorConfirmar: Int!
}

type ResumenProductos {
  activos: Int!
  agotados: [String!]!
}

type TotalesVenta {
  ventas: Monto!
  pedidos: Int!
  ticketPromedio: Int!
  mejorDia: String
}
```

### 8.3 Operaciones, autorización por campo y límites

Solo lectura (el esquema no tiene `Mutation`). Se atiende por `POST /api/graphql` (S38); el navegador no puede llegar a los servicios privados. Esquema completo: [`docs/graphql/schema.graphql`](graphql/schema.graphql).

#### Operaciones y campos con permiso propio

| Tipo | Campo | Roles que pueden pedirlo |
|---|---|---|
| Query | misPedidos | cliente |
| Query | panelAdmin | cualquier sesión (el dato se acota por pertenencia) |
| Query | pedidosAdmin | administrador, despacho |
| Query | reporteVentas | administrador, dueno |
| PanelAdmin | pagos | administrador |
| PanelAdmin | pedidosPorEstado | administrador, despacho |
| PanelAdmin | productos | administrador, dueno |
| Pedido | cliente | cliente, administrador, despacho |

Los datos personales del pedido (`Pedido.cliente`) los ven el cliente dueño, el administrador y el despacho; **el dueño no**. `misPedidos` solo devuelve pedidos del cliente de la sesión: la pertenencia la aplica el servicio `orders` con la identidad, no el resolver.

#### Límites de consulta

| Control | Valor | Dónde |
|---|---|---|
| Introspección | desactivada | `DisableIntrospection` |
| Profundidad máxima | 6 | `QueryDepthLimiter` |
| Alias por consulta | 10 | `MaxAliasesLimiter` |
| Tokens por documento | 1200 | `MaxTokensLimiter` |
| Costo estimado | máximo 1500 (1 + hijos × `limit`) | `LimiteDeCosto` (rechaza antes de ejecutar) |
| Errores inesperados | enmascarados (`Error interno`) | `MaskErrors` |
| Paginación | `limit` entre 1 y 50, con `offset` | `acotar()` |
| Anti N+1 | DataLoader por solicitud | `Contexto._cargar_items/_cargar_pagos` |

### 8.4 Consulta de prueba, respuesta esperada y agregación desde el frontend

La pantalla «Mis pedidos» de la C2 (`CONSULTA_PEDIDOS` de `datos-frontend/consultas-graphql.json`, copiada de su `pedidos.js`) pide en **una** consulta lo que sin GraphQL serían tres llamadas por pedido (pedido, pago y boleta), más las imágenes del catálogo. La evidencia siguiente se generó ejecutando exactamente esa consulta contra el sistema levantado, con el registro de las llamadas internas que hizo el GraphQL Gateway (una por servicio, sin el problema N+1) y la comprobación de que cada cliente solo ve sus pedidos. El panel interno (`CONSULTA_VENTAS` y `CONSULTA_DESPACHO`, de `admin.js`) se agrega de la misma forma desde tres servicios.

#### M8 Agregación GraphQL ejecutada desde la pantalla

| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |
|---|---|---|---|---|---|---|---|
| 1 | POST /api/graphql con la consulta EXACTA de pedidos.js (pedido + pago + boleta + líneas) | cliente con 4 pedidos, 1 pagado | 200 con datos de orders y payments (pedido + pago + boleta); cada servicio recibe UNA llamada para los 4 pedidos | 200; 4 pedidos; pedido pagado: pago «aprobado», boleta B-000002; llamadas por servicio: api-gateway=1, graphql-gateway=1, orders=1, payments=1, inventory=0 | graphql-gateway (DataLoader por solicitud) | `test_graphql::test_una_consulta_pide_cada_servicio_una_sola_vez_sin_problema_n_mas_1` | ✓ |
| 2 | POST /api/graphql con la consulta del panel de admin.js (pedidos por estado + productos + pagos) | administrador | 200 con datos de TRES servicios: orders, inventory y payments | 200; llamadas por servicio: api-gateway=1, graphql-gateway=1, orders=1, payments=1, inventory=1 | graphql-gateway (agrega tres servicios sin acceder a sus bases) | `test_graphql::test_el_panel_del_pie_pide_cada_dato_a_su_servicio` | ✓ |
| 3 | GraphQL pedidosAdmin { cliente { correo telefono direccion } } | dueño | PROHIBIDO; ningún dato personal en la respuesta | 200 PROHIBIDO | graphql-gateway (permiso por campo) | `test_graphql::test_el_dueno_no_alcanza_ningun_pedido_ni_dato_personal_por_graphql` | ✓ |
| 4 | GraphQL panelAdmin { pagos { iniciados } } | cliente | panelAdmin nulo y PROHIBIDO | 200 PROHIBIDO | graphql-gateway | `test_graphql::test_el_panel_para_un_cliente_es_nulo_y_prohibido` | ✓ |
| 5 | GraphQL misPedidos(clienteId: …) (pedir los de otro cliente por argumento) | cliente | CONSULTA_INVALIDA (el argumento no existe) | 200 CONSULTA_INVALIDA | graphql-gateway (esquema) | `test_graphql::test_no_existe_ningun_argumento_para_pedir_pedidos_de_otro_cliente` | ✓ |
| 6 | GraphQL introspección { __schema … } | cliente | CONSULTA_INVALIDA sin publicar el esquema | 200 CONSULTA_INVALIDA,CONSULTA_INVALIDA | graphql-gateway (DisableIntrospection) | `test_graphql::test_la_introspeccion_esta_desactivada` | ✓ |
| 7 | GraphQL con anidamiento de más de 6 niveles | cliente | rechazada antes de ejecutarse (profundidad máxima 6) | 200 CONSULTA_INVALIDA,CONSULTA_INVALIDA | graphql-gateway (QueryDepthLimiter) | `test_graphql::test_profundidad_maxima` | ✓ |
| 8 | GraphQL con 11 alias de la misma consulta | cliente | rechazada (máximo 10 alias) | 200 CONSULTA_INVALIDA | graphql-gateway (MaxAliasesLimiter) | `test_graphql::test_maximo_de_alias` | ✓ |
| 9 | POST graphql-gateway/graphql directo, sin credencial de servicio | ninguna | 403 LLAMADOR_NO_PERMITIDO | 403 LLAMADOR_NO_PERMITIDO | graphql-gateway (guardia de servicio) | `test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial` | ✓ |

#### Detalle de la agregación (consulta de `pedidos.js`)

Consulta enviada por la pantalla «Mis pedidos»:

```graphql
query MisPedidos($desde: Int!) { misPedidos(limit: 20, offset: $desde) { total items { id fecha estado subtotal despacho total medioPago reembolso motivoAnulacion anuladoPor fechaAnulacion cliente { nombre direccion comuna } lineas { nombre cantidad precio subtotal } pago { id estado medio monto checkoutUrl instrucciones reembolso } boleta { folio total estado } } } }
```

Servicios que atendieron esa solicitud (por identificador de correlación) y rutas internas que recibieron:

```json
{
 "api-gateway": [
  "/api/graphql"
 ],
 "graphql-gateway": [
  "/graphql"
 ],
 "orders": [
  "/orders"
 ],
 "payments": [
  "/internal/payments/by-orders"
 ],
 "inventory": []
}
```

Parte de la respuesta (el pedido pagado):

```json
{
 "misPedidos": {
  "total": 4,
  "items": [
   {
    "id": "A-1047",
    "fecha": "2026-11-05T06:33:54.316Z",
    "estado": "En preparación",
    "subtotal": 7990,
    "despacho": 0,
    "total": 7990,
    "medioPago": "Servipag",
    "reembolso": "no_aplica",
    "motivoAnulacion": null,
    "anuladoPor": null,
    "fechaAnulacion": null,
    "cliente": {
     "nombre": "Cliente De Prueba",
     "direccion": "Calle Falsa 123",
     "comuna": "Ñuñoa"
    },
    "lineas": [
     {
      "nombre": "Choripán x4",
      "cantidad": 1,
      "precio": 7990,
      "subtotal": 7990
     }
    ],
    "pago": {
     "id": "pay-9eeae65d326944d0",
     "estado": "aprobado",
     "medio": "Servipag",
     "monto": 7990,
     "checkoutUrl": null,
     "instrucciones": null,
     "reembolso": null
    },
    "boleta": {
     "folio": "B-000002",
     "total": 7990,
     "estado": "vigente"
    }
   }
  ]
 }
}
```

### 8.5 Mapa de clasificación de servicios

| Servicio | Naturaleza | Responsabilidad | Datos propios | Contrato | Dependencias | Justificación de que sea un servicio |
|---|---|---|---|---|---|---|
| `auth` | Soporte de seguridad · transaccional | Credenciales y sesiones | `usuarios`, `sesiones` | REST interno JSON: `/login`, `/logout`, `/introspect`, `/users`, `/internal/credentials` | MongoDB `auth`, Vault | La contraseña no convive con los datos personales; el servicio se puede endurecer y escalar aparte (ADR-002, ADR-011) |
| `clients` | Núcleo · transaccional | Datos personales y registro de clientes | `clientes` | REST interno: `/clients`, `/clients/register`, `/internal/clients/{id}/delivery-profile` | `auth`, `notifications`, MongoDB `clients`, Vault | Autoridad de los datos personales: los demás servicios piden solo lo que necesitan |
| `inventory` | Núcleo · catálogo | Productos, promociones, precios y disponibilidad | `productos`, `promos`, `contadores` | REST: `/products`, `/promos`; interno: `/internal/items`, `/internal/pricing/resolve`, `/internal/summary` | MongoDB `inventory`, Vault | Autoridad del precio; el requisito pide disponibilidad (RF7), no cantidades de stock |
| `orders` | Núcleo · transaccional | Pedidos, estado oficial, despacho, cotización de eventos | `pedidos`, `zonas`, `config`, `cotizaciones_evento`, `contadores` | REST: `/orders`, `/admin/orders`; interno: `payable`, `payment-confirmed`, `refund-done` | `clients`, `inventory`, `payments`, `notifications`, MongoDB, Vault | Autoridad del estado del pedido; fija precios y total en el servidor |
| `payments` | Núcleo · dinero e integración con tercero | Pagos, ventas, boletas, reembolsos, conciliación | `pagos`, `ventas`, `eventos_proveedor`, `contadores` | REST: pago de un pedido, administración de pagos, `/webhooks/provider`; interno: resumen y pagos por pedido | `orders`, `analytics`, `notifications`, proveedor de pagos, MongoDB, Vault | Único que puede confirmar un pago (ADR-007) |
| `notifications` | Soporte · integración de correo | Validar correos, enviar, bandeja de salida, mensajes de contacto | `bandeja`, `mensajes_contacto` | REST: `/contact-messages`, `/outbox`; interno: `/internal/email/send`, `/internal/email/validate` | Proveedor de correo (adaptador), MongoDB, Vault | Aísla al tercero de correo detrás de un adaptador |
| `analytics` | Modelo de lectura | Reportes de ventas por período | `ventas`, `eventos`, `historico` | Interno: eventos `sale-registered`, `sale-reversed`; consulta `/internal/reports/sales` | MongoDB `analytics`, Vault | Carga y forma de consulta distintas de las del pedido (ADR-004) |
| `graphql-gateway` | Agregación · solo lectura | Consultas compuestas para las pantallas | Ninguno | `POST /graphql` (interno) | `orders`, `inventory`, `payments`, `analytics` | Un único punto de agregación sin poder de escritura (ADR-009) |
| `api-gateway` | Borde | Única puerta pública | Ninguno (caché y contadores en memoria) | 38 rutas públicas (S01–S38) | Todos los servicios, Vault | Concentra los controles de entrada (ADR-001) |
| `provider-sandbox` | Tercero simulado | Proveedor de pagos | Cobros en memoria | API con clave `/v1/...`, página de pago, avisos firmados | `api-gateway` (aviso), Vault | Representa lo que no controlamos |

---

## M9 Analítica, gRPC y carga

### 9.1 Necesidades analíticas

| Necesidad | Quién | Frecuencia y volumen | Latencia y consistencia aceptadas | Privacidad | Solución adoptada |
|---|---|---|---|---|---|
| Reporte de ventas por período (RF9), con total por día, medio de pago y productos más vendidos | Dueño y administrador | Pocas consultas al día; hasta 92 días | p95 ≤ 1 s (30 días) y ≤ 2 s (92 días); el dato puede tener segundos de retraso | Solo agregados; sin datos personales | Consulta bajo demanda a `analytics` (agregación en MongoDB) vía GraphQL |
| Ingesta de cada venta | `payments` → `analytics` | Una por venta (proyección de 18 a 35 pedidos al día) | Idempotente y tolerante al orden; no bloquea el pago | Sin datos personales | Evento HTTP idempotente con reintento por reconciliación |
| Cola de despacho | Despacho | Consulta bajo demanda desde el panel | Consistente con `orders` | Datos de despacho solo para quien despacha | Lectura directa de `orders`; sin streaming |

### 9.2 Decisión: analítica con HTTP/JSON, sin gRPC

#### ADR-004 · Analítica en un servicio separado con HTTP/JSON; gRPC no se implementa

**Estado:** aceptada · **Módulos:** M9

##### Contexto
La analítica del caso es el **reporte de ventas** (RF9): total por día, por medio de pago y productos más vendidos, para el dueño y el administrador. Hay dos flujos:

1. **Ingesta:** `payments` avisa a `analytics` cada vez que una venta se registra o se revierte (un evento de unos 490 bytes de promedio, entre 312 y 680 en la prueba).
2. **Consulta:** el panel interno pide el reporte de un período de hasta 92 días a través del GraphQL Gateway (respuesta de 3 KB para 30 días y de 8 KB para 92).

**Volumen proyectado.** El volumen es un **supuesto de diseño**, no un dato del cliente: de **18 a 35 pedidos al día**. El 18 es la base de la historia de ejemplo del reporte del frontend de la C2 (`analytics-service/app/main.py`, `historia_de_ejemplo`: de 0 a 32 pedidos al día según el día de la semana) y el 35 es la cota alta que se usó para probar: **3.150 ventas en los últimos 90 días**. Eso es una venta cada 40 minutos en una jornada de 24 horas, o una cada 20 minutos si el local vende 12 horas. Los usuarios del reporte son pocos (administrador y dueño): se proyectan hasta 4 consultas simultáneas en el peor momento, que es la concurrencia que cubren los objetivos de más abajo.

Estas necesidades no piden transmisión en tiempo real: el panel interno consulta al abrir la pantalla o al cambiar el período, sin sondeo periódico (los únicos reintentos con espera del frontend están en «Mis pedidos», al volver del pago) y un retraso de segundos en el reporte es aceptable (tabla 9.1 del informe).

##### Alternativas
| Alternativa | A favor | En contra |
|---|---|---|
| **A. HTTP/JSON entre servicios (elegida)** | El resto del sistema ya habla así (cortacircuitos, plazos, secretos por par, logs con identificador de solicitud, pruebas de contrato); se puede depurar con `curl`; sin dependencias nuevas | Mensajes más grandes que en un formato binario (no se midió cuánto) |
| B. gRPC (protobuf sobre HTTP/2) entre `payments`→`analytics` y `graphql-gateway`→`analytics` | Esquema tipado y mensajes compactos; transmisión de flujos | Segundo protocolo que operar: otro puerto y otro servidor en `analytics`, código generado, un cliente con sus propios plazos/reintentos/cortacircuitos y una segunda forma de pasar el secreto del par y la identidad; el navegador no puede hablar gRPC sin un proxy adicional (gRPC-web) |
| C. Transmisión al navegador (SSE o WebSocket) para ver ventas en vivo | Panel que se actualiza solo | Ningún requisito lo pide; agrega conexiones largas al gateway y revalidar la sesión durante la conexión |
| D. Reporte precalculado por día | Consulta de costo constante | Más estado que mantener consistente con anulaciones tardías; no hizo falta según la medición |

##### Decisión
- **Analítica en su propio servicio** (`analytics`, base propia, usuario propio de MongoDB), alcanzado solo por `payments` (escribe eventos) y por `graphql-gateway` (lee reportes). Cada par tiene su secreto en Vault.
- **HTTP/JSON, sin gRPC ni transmisión.** La decisión se apoya en los requisitos y en la carga proyectada de arriba, **no en una comparación medida con gRPC: no se implementó una variante gRPC, así que no se afirma nada sobre cuánto más rápida o más liviana sería.** Lo que sí se midió es que la implementación actual cumple los objetivos con el volumen proyectado (ver más abajo), es decir, la latencia o el tamaño de los mensajes no son el problema que gRPC resolvería.
- **Consulta bajo demanda con agregación en MongoDB** sobre el modelo de lectura `ventas` (índice `(estado, fechaLocal)`), más una tabla `historico` de totales diarios para los días de ejemplo anteriores al sistema.
- **Ingesta idempotente y tolerante al orden:** cada evento tiene identificador; repetirlo no cambia el reporte y una anulación que llega antes que el registro deja la venta anulada (ADR-008). Si `analytics` no responde, el pago no se bloquea: la reconciliación reintenta.
- **Privacidad:** el evento lleva el folio y el número de pedido, los montos, el medio de pago, la comuna de despacho y las líneas de producto; no lleva nombre, RUN, correo ni dirección, y el reporte devuelve solo agregados. Lo ven solo el administrador y el dueño (el servicio lo vuelve a comprobar).

##### Objetivos antes de medir
Se fijaron **antes** de ejecutar la prueba y están en `scripts/load_test.py` (`OBJETIVOS`); el informe compara cada uno con el peor valor medido:

| Objetivo | Tope |
|---|---|
| Ingesta de una venta, con hasta 16 emisores simultáneos | p95 ≤ 100 ms |
| Reporte de 30 días de punta a punta (navegador→gateway→auth→GraphQL→analytics), con hasta 4 usuarios simultáneos | p95 ≤ 1.000 ms |
| Reporte de 92 días (el máximo permitido) de punta a punta, con hasta 4 usuarios simultáneos | p95 ≤ 2.000 ms |
| Sin errores en ningún caso, con hasta 4 clientes simultáneos | 0 errores |

##### Resultados medidos
Medición real con **MongoDB v8.0.23 y HashiCorp Vault reales**, sin Docker, en un equipo de 2 CPU y 7,8 GB, con el generador de carga **en el mismo equipo** (compite por CPU); datos sintéticos con semilla fija; 15 s por caso más 1 s de calentamiento; concurrencias 1, 4, 16 y 64. El entorno completo, cada caso con su rendimiento, p50/p95/p99, errores y CPU y memoria de cada proceso están en [`carga.md`](evidencia/carga.md) (volumen proyectado) y [`carga_x10.md`](evidencia/carga_x10.md) (diez veces el volumen).

**Orden de la medición.** Los reportes se miden primero, con exactamente las ventas declaradas; después la ingesta agrega ventas y al final los reportes se repiten con la base crecida (cada caso registra cuántas ventas había al empezar). *La primera versión de la prueba medía los reportes después de la ingesta, con una base unas 8 veces mayor que la declarada; se corrigió y se repitió todo.*

**Con el volumen proyectado (3.150 ventas, 15 s por caso):**

| Medición | Resultado |
|---|---|
| Ingesta, 1 / 4 / 16 emisores | p95 3,6 / 12,4 / 45,2 ms; 331,6 / 451,7 / 549,5 ventas por segundo; 0 errores |
| Reporte de 30 días de punta a punta, 1 / 4 / 16 usuarios | p95 59,6 / 142,6 / 585,5 ms; 0 errores |
| Reporte de 92 días de punta a punta, 1 / 4 / 16 usuarios | p95 116,3 / 216,1 / 881,9 ms; 0 errores |
| Reentrega del mismo evento 3.049 veces en paralelo | los totales no cambiaron; 0 errores |
| Reporte de 92 días de punta a punta con la base crecida a 28.567 ventas, 1 / 4 usuarios | p95 395,4 / 1.307,6 ms; 0 errores |
| Objetivos | **los 4 se cumplen** (peor caso: 216,1 ms frente a 2.000 ms en el reporte de 92 días) |

**Con diez veces el volumen (31.500 ventas, 10 s por caso):**

| Medición | Resultado |
|---|---|
| Ingesta, 1 / 4 / 16 emisores | p95 3,5 / 13,3 / 45,2 ms; 345,6 / 431,5 / 536,5 ventas por segundo; 0 errores |
| Reporte de 30 días de punta a punta, 1 / 4 / 16 usuarios | p95 163,4 / 500,6 / 1.838,2 ms; 0 errores |
| Reporte de 92 días de punta a punta, 1 / 4 usuarios | p95 470,5 / 1.201,6 ms; 0 errores |
| Reporte de 92 días de punta a punta, **16 usuarios simultáneos** | **las 870 solicitudes fallaron** con `SERVICIO_NO_DISPONIBLE` (fallan rápido, no esperan); el sistema volvió a responder bien 5,0 s después de terminar la carga |
| Reportes con la base crecida a 45.875 ventas, 4 usuarios | 30 días: p95 590,9 ms; 92 días: **p95 1.752,9 ms** (el margen frente al plazo de 2 s es estrecho) |
| Objetivos | **los 4 se cumplen** (peor caso: 1.201,6 ms frente a 2.000 ms) |

**Recursos.** Durante los casos de reporte `mongod` usó en promedio entre 68 % y 180 % de un núcleo (hasta 195 % con 10× el volumen; el equipo tiene 2 núcleos), mientras que ninguno de los procesos de Python (`analytics`, `graphql-gateway`, `api-gateway`, `auth`) superó el 70 % de un núcleo en esos casos (en los de ingesta, `analytics` llegó a 98 % de un núcleo: es un solo proceso). La memoria máxima de `analytics` fue de 123 a 126 MB, la de `graphql-gateway` 100 MB y la del API Gateway 87 MB; la de `mongod` varió entre ejecuciones (526 y 993 MB) y no se investigó la causa. Tamaño de los mensajes: evento de 489 a 494 bytes en promedio (312–680) y respuesta del reporte de 3 KB (30 días) y 7,6 a 7,8 KB (92 días).

**Lo que estas cifras NO muestran.** Todos los datos de la prueba están dentro de los últimos 90 días, así que cada reporte de 92 días recorre *todas* las ventas de la base; con un historial más largo recorrería solo las del período pedido (el plan de ejecución usa el índice `(estado, fechaLocal)`: `test_el_reporte_de_ventas_usa_el_indice_de_fecha_y_solo_lee_las_ventas_del_periodo`, con MongoDB real). No se midió Docker, ni red real entre contenedores, ni un MongoDB en otra máquina; el generador de carga compite por CPU con los servicios; los datos son sintéticos.

##### Consecuencias
- **Cumple lo proyectado:** con 3.150 ventas el sistema cumple los cuatro objetivos medidos y el costo de gRPC (segundo protocolo, código generado, gRPC-web para el navegador) no se justifica por lo medido.
- **Cuello de botella medido:** el costo de un reporte lo pone MongoDB, no los servicios de Python: durante los casos de reporte `mongod` usó en promedio entre 68 % y 195 % de un núcleo (el equipo tiene 2) mientras que ningún proceso de Python superó el 70 % en esos casos. Cada reporte hace tres agregaciones seguidas sobre las mismas ventas. No se perfiló qué parte del trabajo de MongoDB pesa más.
- **Comportamiento al saturarse:** con el volumen proyectado no hubo errores ni con 16 usuarios simultáneos. A diez veces ese volumen, 16 reportes de 92 días a la vez superan el plazo de 2 s de las llamadas a `analytics`, el cortacircuitos se abre y el usuario recibe `SERVICIO_NO_DISPONIBLE` de inmediato en vez de esperar sin límite (diseño de ADR-010); el sistema volvió a responder bien 5,0 s después de terminar la carga. Con las 4 consultas simultáneas proyectadas como máximo se cumplen los objetivos incluso a 10×, pero el margen del reporte de 92 días se reduce (1,75 s de p95 frente al plazo de 2 s con unas 46.000 ventas en el período).
- **Defecto encontrado por la medición:** a diez veces el volumen el reporte de 92 días superaba los 2.147 millones de pesos y el tipo `Int` de GraphQL (32 bits) lo rechazaba como «Error interno»; se corrigió con el tipo `Monto`.
- **Si el volumen real fuera de ese orden** (unos 350 pedidos al día o más), lo primero que se agota es el margen del reporte de 92 días. Las mejoras, ordenadas por costo, son: (1) calcular las tres agregaciones en una sola pasada (`$facet`), (2) guardar totales diarios precalculados en `historico` al llegar cada evento, (3) caché de corta duración del reporte. **Ninguna está implementada ni medida**: son opciones, no resultados.
- **Cuándo se reconsideraría gRPC:** si la ingesta pasara a miles de eventos por segundo entre servicios propios, o si apareciera un consumidor interno que necesite transmisión de flujos. Nunca hacia el navegador. Si el panel necesitara ventas en vivo, la opción prevista es SSE o WebSocket detrás del API Gateway, que revalida la sesión.

##### Dónde está implementado y probado
- Implementación: `analytics-service/app/main.py` (eventos `sale-registered` y `sale-reversed`, reporte `GET /internal/reports/sales`), `payments-service/app/main.py` (emisión y reconciliación), `graphql-gateway/app/schema.py` (`reporteVentas`).
- Pruebas: `tests/test_analitica.py` (idempotencia, orden de llegada, agrupaciones, período de 92 días, totales mayores a 2.147 millones, privacidad), `tests/test_graphql.py`, `tests/test_resiliencia.py` (`test_con_analitica_colgada_el_pago_avanza_y_la_venta_se_cuenta_una_vez_al_volver`, `test_con_analitica_colgada_el_reporte_falla_solo_en_su_campo`).
- Medición: `scripts/load_test.py` → `docs/evidencia/carga.md` y `carga_x10.md`.

### 9.3 Medición de carga (volumen proyectado)

Generado por `scripts/load_test.py`. **Todos los números salen de esta ejecución.**

#### Entorno

- **modo**: pruebas
- **so**: Linux-6.18.44-fc-v236-x86_64-with-glibc2.39
- **cpu**: Intel(R) Xeon(R) Processor
- **nucleos**: 2
- **memoria total**: 7.8 GB
- **python**: 3.13.18
- **uvicorn**: 0.54.0
- **fastapi**: 0.162.0
- **base de datos**: MongoDB real (db version v8.0.23) con autenticación y un usuario por servicio, en el mismo equipo, sin Docker; secretos en HashiCorp Vault real (Vault v2.0.0, built 2025-11-05T06:06:22Z) en modo desarrollo
- **workers por servicio**: 1
- **generador de carga**: mismo equipo que los servicios (compite por CPU)

#### Datos

- 3150 ventas vigentes repartidas en los últimos 90 días (cada una con 1 a 5 líneas); cargadas por la propia API de analytics en 8.5 s (371.5 ventas/s a 32 clientes simultáneos).
- Tamaño de los mensajes: evento «venta registrada» de 494 bytes en promedio (313–678, 1000 eventos generados); respuesta del reporte de 2938 bytes (30 días) y 7634 bytes (92 días).
- **Orden de la medición:** primero se cargan las ventas indicadas y se miden los reportes con exactamente esa cantidad (columna «Ventas en la base al empezar»); después la ingesta sostenida agrega más ventas y, al final, los reportes se repiten (casos «con la base crecida») para ver cómo cambian con el volumen.
- «Respuestas totales» cuenta también las respuestas de error, que son rápidas (un servicio que se rinde por plazo contesta de inmediato): la capacidad útil es la columna «Respuestas correctas».
- Duración de cada caso: 15 s (más 1 s de calentamiento que no se cuenta). Concurrencias: [1, 4, 16, 64].

#### Resultados

| Caso | Ventas en la base al empezar | Clientes simultáneos | Solicitudes | Respuestas totales (req/s) | Respuestas correctas (req/s) | p50 (ms) | p95 (ms) | p99 (ms) | Máx (ms) | Errores | CPU analytics prom/máx (% de un núcleo) | Memoria analytics máx (MB) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Reporte de ventas 30 días, directo a analytics | 3150 | 1 | 806 | 53.7 | 53.7 | 17.7 | 24.2 | 29.9 | 38.7 | 0 | 15.6 / 18.0 | 121.8 |
| Reporte de ventas 30 días, directo a analytics | 3150 | 4 | 1274 | 84.8 | 84.9 | 46.0 | 67.5 | 90.8 | 110.9 | 0 | 23.8 / 27.9 | 121.9 |
| Reporte de ventas 30 días, directo a analytics | 3150 | 16 | 1120 | 73.4 | 73.2 | 209.1 | 286.8 | 407.1 | 764.4 | 0 | 21.2 / 28.0 | 122.0 |
| Reporte de ventas 92 días (máximo), directo a analytics | 3150 | 1 | 345 | 23.0 | 23.0 | 38.8 | 63.9 | 119.5 | 385.7 | 0 | 8.9 / 14.0 | 122.0 |
| Reporte de ventas 92 días (máximo), directo a analytics | 3150 | 4 | 553 | 36.7 | 36.6 | 104.8 | 149.8 | 173.9 | 234.6 | 0 | 15.5 / 18.0 | 122.0 |
| Reporte de ventas 92 días (máximo), directo a analytics | 3150 | 16 | 532 | 34.8 | 34.8 | 456.7 | 573.8 | 630.9 | 686.4 | 0 | 13.2 / 31.8 | 122.0 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 3150 | 1 | 443 | 29.5 | 29.5 | 29.1 | 59.6 | 79.7 | 133.9 | 0 | 9.7 / 12.0 | 122.0 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 3150 | 4 | 716 | 47.4 | 47.4 | 78.6 | 142.6 | 243.0 | 304.8 | 0 | 17.8 / 22.0 | 122.0 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 3150 | 16 | 729 | 48.1 | 48.0 | 309.5 | 585.5 | 826.1 | 1138.3 | 0 | 18.4 / 42.0 | 122.0 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 3150 | 1 | 250 | 16.6 | 16.7 | 53.9 | 116.3 | 140.5 | 159.6 | 0 | 7.7 / 10.0 | 122.0 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 3150 | 4 | 426 | 28.3 | 28.2 | 136.5 | 216.1 | 239.3 | 258.9 | 0 | 13.3 / 22.0 | 122.0 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 3150 | 16 | 426 | 27.7 | 27.7 | 583.3 | 881.9 | 1163.5 | 1253.3 | 0 | 12.4 / 32.0 | 122.1 |
| Ingesta de ventas (analytics) | 3150 | 1 | 4974 | 331.5 | 331.6 | 2.9 | 3.6 | 4.7 | 21.9 | 0 | 58.3 / 60.0 | 122.1 |
| Ingesta de ventas (analytics) | 8429 | 4 | 6776 | 451.6 | 451.7 | 8.4 | 12.4 | 18.8 | 76.5 | 0 | 85.2 / 91.9 | 122.1 |
| Ingesta de ventas (analytics) | 15662 | 16 | 8242 | 549.2 | 549.5 | 26.2 | 45.2 | 119.7 | 180.7 | 0 | 91.9 / 97.8 | 122.1 |
| Ingesta de ventas (analytics) | 24426 | 64 | 3806 | 250.2 | 250.4 | 176.2 | 743.1 | 1126.6 | 1946.6 | 0 | 50.8 / 83.7 | 122.6 |
| Reentrega del MISMO evento (idempotencia) | 28567 | 16 | 3049 | 434.9 | 435.6 | 24.2 | 137.4 | 226.4 | 564.3 | 0 | 69.4 / 95.8 | 122.6 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 28567 | 1 | 120 | 8.0 | 8.0 | 114.5 | 173.0 | 218.6 | 220.5 | 0 | 4.1 / 8.0 | 122.6 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 28567 | 4 | 191 | 12.6 | 12.6 | 316.2 | 403.8 | 478.2 | 521.2 | 0 | 6.2 / 13.8 | 122.6 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 28567 | 1 | 45 | 3.0 | 3.0 | 332.1 | 395.4 | 452.2 | 452.2 | 0 | 2.7 / 6.0 | 122.6 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 28567 | 4 | 66 | 4.3 | 4.3 | 963.1 | 1307.6 | 1418.6 | 1418.6 | 0 | 3.4 / 8.0 | 122.6 |

#### CPU y memoria por servicio durante cada caso (promedio / máximo de CPU en % de un núcleo; memoria máxima en MB)

| Caso | Clientes | analytics | api-gateway | auth | graphql-gateway | mongo | payments |
|---|---|---|---|---|---|---|---|
| Reporte de ventas 30 días, directo a analytics | 1 | 15.6/18.0 · 121.8 MB | 0.1/2.0 · 62.1 MB | 0.1/2.0 · 77.6 MB | 0.1/2.0 · 70.0 MB | 79.7/83.9 · 419.1 MB | 0.2/2.0 · 80.1 MB |
| Reporte de ventas 30 días, directo a analytics | 4 | 23.8/27.9 · 121.9 MB | 0.1/2.0 · 62.1 MB | 0.1/2.0 · 77.6 MB | 0.1/2.0 · 70.0 MB | 162.4/171.7 · 712.2 MB | 0.2/2.0 · 80.1 MB |
| Reporte de ventas 30 días, directo a analytics | 16 | 21.2/28.0 · 122.0 MB | 0.1/2.0 · 62.1 MB | 0.1/2.0 · 77.6 MB | 0.1/2.0 · 70.0 MB | 168.3/173.9 · 974.3 MB | 0.1/2.0 · 80.1 MB |
| Reporte de ventas 92 días (máximo), directo a analytics | 1 | 8.9/14.0 · 122.0 MB | 0.1/2.0 · 62.1 MB | 0.2/2.0 · 77.6 MB | 0.1/2.0 · 70.0 MB | 108.3/181.8 · 993.0 MB | 0.1/2.0 · 80.1 MB |
| Reporte de ventas 92 días (máximo), directo a analytics | 4 | 15.5/18.0 · 122.0 MB | 0.1/2.0 · 62.1 MB | 0.1/2.0 · 77.6 MB | 0.1/2.0 · 70.0 MB | 177.0/181.8 · 967.1 MB | 0.2/2.0 · 80.1 MB |
| Reporte de ventas 92 días (máximo), directo a analytics | 16 | 13.2/31.8 · 122.0 MB | 0.1/2.0 · 62.1 MB | 0.1/2.0 · 77.6 MB | 0.1/2.0 · 70.0 MB | 179.8/185.9 · 966.7 MB | 0.2/2.0 · 80.1 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 1 | 9.7/12.0 · 122.0 MB | 10.1/14.0 · 64.2 MB | 6.1/10.0 · 78.2 MB | 16.4/20.0 · 73.0 MB | 67.6/135.8 · 968.4 MB | 0.1/2.0 · 80.1 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 4 | 17.8/22.0 · 122.0 MB | 17.6/24.0 · 66.9 MB | 11.2/17.9 · 81.9 MB | 29.5/38.0 · 75.2 MB | 94.7/113.6 · 962.8 MB | 0.2/2.0 · 80.1 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 16 | 18.4/42.0 · 122.0 MB | 20.9/42.0 · 86.7 MB | 12.0/22.0 · 90.3 MB | 29.2/45.4 · 99.6 MB | 101.7/119.9 · 942.3 MB | 0.2/2.0 · 80.1 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 1 | 7.7/10.0 · 122.0 MB | 8.2/12.0 · 86.7 MB | 4.9/8.0 · 90.3 MB | 13.1/16.0 · 99.6 MB | 74.7/87.9 · 942.9 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 4 | 13.3/22.0 · 122.0 MB | 11.7/20.0 · 86.7 MB | 7.7/12.0 · 90.3 MB | 21.8/32.0 · 99.6 MB | 130.7/149.8 · 937.4 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 16 | 12.4/32.0 · 122.1 MB | 12.8/59.4 · 86.7 MB | 6.9/14.0 · 90.3 MB | 20.8/37.6 · 100.0 MB | 137.6/153.1 · 920.3 MB | 0.2/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 1 | 58.3/60.0 · 122.1 MB | 0.1/2.0 · 86.7 MB | 0.1/2.0 · 90.3 MB | 0.1/2.0 · 100.0 MB | 27.1/34.0 · 920.4 MB | 0.2/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 4 | 85.2/91.9 · 122.1 MB | 0.1/2.0 · 86.7 MB | 0.1/2.0 · 90.3 MB | 0.1/2.0 · 100.0 MB | 34.2/75.9 · 915.0 MB | 0.2/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 16 | 91.9/97.8 · 122.1 MB | 0.1/2.0 · 86.7 MB | 0.1/2.0 · 90.3 MB | 0.1/2.0 · 100.0 MB | 26.2/30.0 · 913.3 MB | 0.1/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 64 | 50.8/83.7 · 122.6 MB | 0.1/2.0 · 86.7 MB | 0.1/2.0 · 90.3 MB | 0.1/2.0 · 100.0 MB | 17.7/27.9 · 878.9 MB | 0.1/2.0 · 80.2 MB |
| Reentrega del MISMO evento (idempotencia) | 16 | 69.4/95.8 · 122.6 MB | 0.0/0.0 · 86.7 MB | 0.1/1.9 · 90.3 MB | 0.1/2.0 · 100.0 MB | 17.3/25.9 · 861.1 MB | 0.3/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 1 | 4.1/8.0 · 122.6 MB | 5.1/8.0 · 86.7 MB | 3.2/6.0 · 90.3 MB | 7.2/11.9 · 100.0 MB | 83.3/97.8 · 857.3 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 4 | 6.2/13.8 · 122.6 MB | 7.0/19.7 · 86.7 MB | 4.2/8.0 · 90.3 MB | 10.1/18.0 · 100.0 MB | 164.4/179.9 · 851.3 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 1 | 2.7/6.0 · 122.6 MB | 3.2/8.0 · 86.7 MB | 1.9/4.0 · 90.3 MB | 4.4/8.0 · 100.0 MB | 99.2/115.9 · 843.5 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 4 | 3.4/8.0 · 122.6 MB | 4.0/15.9 · 86.7 MB | 2.6/15.9 · 90.3 MB | 5.9/23.9 · 100.0 MB | 177.3/193.8 · 839.7 MB | 0.2/2.0 · 80.2 MB |

**Idempotencia bajo carga:** el mismo evento enviado 3049 veces en paralelo; los totales del reporte NO cambiaron respecto de la primera entrega.

#### Comparación con los objetivos declarados

Los objetivos se fijaron antes de medir (ADR-004). «Medido» es el peor valor entre los casos y concurrencias que cubre cada objetivo.

| Objetivo | Medido (peor caso) | Tope | Resultado |
|---|---|---|---|
| Ingesta de una venta: p95 ≤ 100 ms con hasta 16 emisores simultáneos | 45.2 | 100 | ✓ cumple |
| Reporte de 30 días de punta a punta (navegador→gateway→auth→GraphQL→analytics): p95 ≤ 1.000 ms con hasta 4 usuarios simultáneos | 142.6 | 1000 | ✓ cumple |
| Reporte de 92 días (el máximo permitido) de punta a punta: p95 ≤ 2.000 ms con hasta 4 usuarios simultáneos | 216.1 | 2000 | ✓ cumple |
| Sin errores en ningún caso con hasta 4 clientes simultáneos | 0 | 0 | ✓ cumple |

#### Cómo leer esto

- Es una medición de ESTE entorno (sección «Entorno»). La base de datos es MongoDB real, así que el costo de las agregaciones es el de MongoDB; la red entre servicios es la del propio equipo (sin latencia de red real) y no se midió Docker.
- Los datos son sintéticos (generados con semilla fija); el reparto de ventas y de productos no es el de un restaurante real.
- El generador de carga corre en el mismo equipo y compite por CPU con los servicios: los resultados son un piso, no un techo.
- Para repetirlo con Docker y MongoDB reales: `docker compose -f docker-compose.yml -f docker-compose.carga.yml up -d` y `python scripts/load_test.py --modo externo ...` (ver README).

### 9.4 Medición de carga (10 veces el volumen proyectado)

Generado por `scripts/load_test.py`. **Todos los números salen de esta ejecución.**

#### Entorno

- **modo**: pruebas
- **so**: Linux-6.18.44-fc-v236-x86_64-with-glibc2.39
- **cpu**: Intel(R) Xeon(R) Processor
- **nucleos**: 2
- **memoria total**: 7.8 GB
- **python**: 3.13.18
- **uvicorn**: 0.54.0
- **fastapi**: 0.162.0
- **base de datos**: MongoDB real (db version v8.0.23) con autenticación y un usuario por servicio, en el mismo equipo, sin Docker; secretos en HashiCorp Vault real (Vault v2.0.0, built 2025-11-05T06:12:38Z) en modo desarrollo
- **workers por servicio**: 1
- **generador de carga**: mismo equipo que los servicios (compite por CPU)

#### Datos

- 31500 ventas vigentes repartidas en los últimos 90 días (cada una con 1 a 5 líneas); cargadas por la propia API de analytics en 80.9 s (389.3 ventas/s a 32 clientes simultáneos).
- Tamaño de los mensajes: evento «venta registrada» de 489 bytes en promedio (314–680, 1000 eventos generados); respuesta del reporte de 3020 bytes (30 días) y 7838 bytes (92 días).
- **Orden de la medición:** primero se cargan las ventas indicadas y se miden los reportes con exactamente esa cantidad (columna «Ventas en la base al empezar»); después la ingesta sostenida agrega más ventas y, al final, los reportes se repiten (casos «con la base crecida») para ver cómo cambian con el volumen.
- «Respuestas totales» cuenta también las respuestas de error, que son rápidas (un servicio que se rinde por plazo contesta de inmediato): la capacidad útil es la columna «Respuestas correctas».
- Duración de cada caso: 10 s (más 1 s de calentamiento que no se cuenta). Concurrencias: [1, 4, 16].

#### Resultados

| Caso | Ventas en la base al empezar | Clientes simultáneos | Solicitudes | Respuestas totales (req/s) | Respuestas correctas (req/s) | p50 (ms) | p95 (ms) | p99 (ms) | Máx (ms) | Errores | CPU analytics prom/máx (% de un núcleo) | Memoria analytics máx (MB) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Reporte de ventas 30 días, directo a analytics | 31500 | 1 | 95 | 9.5 | 9.5 | 105.2 | 117.2 | 122.8 | 122.8 | 0 | 4.1 / 8.0 | 125.6 |
| Reporte de ventas 30 días, directo a analytics | 31500 | 4 | 138 | 13.5 | 13.5 | 298.9 | 358.4 | 379.5 | 418.4 | 0 | 5.1 / 8.0 | 125.6 |
| Reporte de ventas 30 días, directo a analytics | 31500 | 16 | 141 | 12.9 | 12.9 | 1305.6 | 1533.6 | 1785.5 | 1861.4 | 0 | 6.2 / 27.8 | 125.7 |
| Reporte de ventas 92 días (máximo), directo a analytics | 31500 | 1 | 31 | 3.1 | 3.1 | 322.4 | 375.0 | 401.1 | 401.1 | 0 | 2.4 / 4.0 | 125.7 |
| Reporte de ventas 92 días (máximo), directo a analytics | 31500 | 4 | 45 | 4.3 | 4.3 | 958.1 | 1150.7 | 1174.9 | 1174.9 | 0 | 3.0 / 6.0 | 125.7 |
| Reporte de ventas 92 días (máximo), directo a analytics | 31500 | 16 | 57 | 4.5 | 4.5 | 3609.0 | 4585.3 | 4729.8 | 4729.8 | 0 | 2.0 / 6.0 | 125.8 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 31500 | 1 | 80 | 8.0 | 8.0 | 118.3 | 163.4 | 174.1 | 174.1 | 0 | 3.6 / 6.0 | 125.8 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 31500 | 4 | 118 | 11.6 | 11.6 | 339.1 | 500.6 | 563.0 | 595.6 | 0 | 5.4 / 10.0 | 125.8 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 31500 | 16 | 126 | 11.8 | 11.8 | 1413.6 | 1838.2 | 2171.8 | 2190.6 | 0 | 4.6 / 10.0 | 125.8 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 31500 | 1 | 27 | 2.7 | 2.7 | 353.4 | 470.5 | 485.3 | 485.3 | 0 | 2.5 / 4.0 | 125.8 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 31500 | 4 | 45 | 4.3 | 4.4 | 970.7 | 1201.6 | 1312.4 | 1312.4 | 0 | 3.4 / 10.0 | 125.8 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 31500 | 16 | 870 | 84.3 | 0.0 | 88.6 | 394.8 | 2647.7 | 2651.1 | 870 | 2.1 / 24.0 | 125.9 |
| Ingesta de ventas (analytics) | 31500 | 1 | 3456 | 345.6 | 345.6 | 2.7 | 3.5 | 4.5 | 18.6 | 0 | 59.2 / 61.9 | 125.9 |
| Ingesta de ventas (analytics) | 35266 | 4 | 4315 | 431.4 | 431.5 | 8.8 | 13.3 | 20.7 | 57.3 | 0 | 86.7 / 89.9 | 125.9 |
| Ingesta de ventas (analytics) | 40029 | 16 | 5365 | 535.8 | 536.5 | 27.8 | 45.2 | 98.4 | 150.3 | 0 | 92.3 / 95.9 | 125.9 |
| Reentrega del MISMO evento (idempotencia) | 45875 | 16 | 2771 | 552.3 | 554.2 | 25.3 | 52.4 | 138.1 | 171.5 | 0 | 91.6 / 93.9 | 125.9 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 45875 | 1 | 53 | 5.3 | 5.2 | 189.5 | 222.6 | 269.9 | 269.9 | 0 | 3.1 / 6.0 | 125.9 |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 45875 | 4 | 88 | 8.6 | 8.5 | 474.1 | 590.9 | 633.3 | 633.3 | 0 | 4.4 / 8.0 | 125.9 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 45875 | 1 | 20 | 2.0 | 2.0 | 499.1 | 603.3 | 603.3 | 603.3 | 0 | 2.1 / 4.0 | 125.9 |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 45875 | 4 | 32 | 3.1 | 3.1 | 1410.4 | 1752.9 | 1791.5 | 1791.5 | 0 | 2.6 / 11.9 | 125.9 |

#### CPU y memoria por servicio durante cada caso (promedio / máximo de CPU en % de un núcleo; memoria máxima en MB)

| Caso | Clientes | analytics | api-gateway | auth | graphql-gateway | mongo | payments |
|---|---|---|---|---|---|---|---|
| Reporte de ventas 30 días, directo a analytics | 1 | 4.1/8.0 · 125.6 MB | 0.1/2.0 · 62.2 MB | 0.1/2.0 · 77.7 MB | 0.0/0.0 · 70.1 MB | 98.3/103.9 · 336.4 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 30 días, directo a analytics | 4 | 5.1/8.0 · 125.6 MB | 0.1/2.0 · 62.2 MB | 0.1/2.0 · 77.7 MB | 0.1/2.0 · 70.1 MB | 190.9/193.9 · 459.7 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 30 días, directo a analytics | 16 | 6.2/27.8 · 125.7 MB | 0.1/2.0 · 62.2 MB | 0.1/2.0 · 77.7 MB | 0.1/2.0 · 70.1 MB | 188.9/195.8 · 492.0 MB | 0.3/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), directo a analytics | 1 | 2.4/4.0 · 125.7 MB | 0.1/2.0 · 62.2 MB | 0.1/2.0 · 77.7 MB | 0.2/2.0 · 70.1 MB | 111.5/145.9 · 505.4 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), directo a analytics | 4 | 3.0/6.0 · 125.7 MB | 0.0/0.0 · 62.2 MB | 0.0/0.0 · 77.7 MB | 0.1/2.0 · 70.1 MB | 193.9/196.5 · 509.8 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), directo a analytics | 16 | 2.0/6.0 · 125.8 MB | 0.1/2.0 · 62.2 MB | 0.2/2.0 · 77.7 MB | 0.1/2.0 · 70.1 MB | 195.2/199.8 · 511.4 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 1 | 3.6/6.0 · 125.8 MB | 4.5/8.0 · 64.2 MB | 2.7/6.0 · 78.5 MB | 6.4/10.0 · 72.3 MB | 86.6/96.0 · 512.0 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 4 | 5.4/10.0 · 125.8 MB | 6.9/25.9 · 65.9 MB | 3.8/10.0 · 81.5 MB | 9.3/19.9 · 74.1 MB | 165.4/181.9 · 521.5 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) | 16 | 4.6/10.0 · 125.8 MB | 8.1/69.4 · 83.8 MB | 3.7/19.8 · 86.2 MB | 8.2/16.0 · 82.3 MB | 167.7/191.8 · 522.6 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 1 | 2.5/4.0 · 125.8 MB | 3.2/6.0 · 83.8 MB | 1.8/4.0 · 86.2 MB | 4.8/14.0 · 82.3 MB | 99.1/113.9 · 523.2 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 4 | 3.4/10.0 · 125.8 MB | 4.0/17.9 · 83.8 MB | 2.4/10.0 · 86.2 MB | 5.3/17.9 · 82.3 MB | 179.3/195.5 · 524.5 MB | 0.1/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 16 | 2.1/24.0 · 125.9 MB | 31.8/67.2 · 84.6 MB | 13.8/37.6 · 100.5 MB | 29.6/63.9 · 98.2 MB | 107.5/197.8 · 526.1 MB | 0.1/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 1 | 59.2/61.9 · 125.9 MB | 0.0/0.0 · 84.6 MB | 0.1/2.0 · 100.5 MB | 0.1/2.0 · 98.2 MB | 20.8/24.0 · 526.5 MB | 0.1/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 4 | 86.7/89.9 · 125.9 MB | 0.1/2.0 · 84.6 MB | 0.1/2.0 · 100.5 MB | 0.1/2.0 · 98.2 MB | 32.0/44.0 · 526.6 MB | 0.2/2.0 · 80.2 MB |
| Ingesta de ventas (analytics) | 16 | 92.3/95.9 · 125.9 MB | 0.1/2.0 · 84.6 MB | 0.1/2.0 · 100.5 MB | 0.1/2.0 · 98.2 MB | 28.0/31.8 · 526.7 MB | 0.1/2.0 · 80.2 MB |
| Reentrega del MISMO evento (idempotencia) | 16 | 91.6/93.9 · 125.9 MB | 0.0/0.0 · 84.6 MB | 0.2/2.0 · 100.5 MB | 0.2/2.0 · 98.2 MB | 20.8/24.0 · 526.7 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 1 | 3.1/6.0 · 125.9 MB | 4.3/8.0 · 84.6 MB | 2.7/10.0 · 100.5 MB | 5.4/10.0 · 98.2 MB | 88.1/95.9 · 526.8 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 30 días, de punta a punta (GraphQL) — con la base crecida | 4 | 4.4/8.0 · 125.9 MB | 5.3/15.8 · 84.6 MB | 3.3/9.8 · 100.5 MB | 7.9/27.6 · 98.2 MB | 172.1/183.8 · 527.0 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 1 | 2.1/4.0 · 125.9 MB | 3.0/8.0 · 84.6 MB | 1.6/4.0 · 100.5 MB | 3.7/8.0 · 98.2 MB | 92.9/105.9 · 527.1 MB | 0.2/2.0 · 80.2 MB |
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) — con la base crecida | 4 | 2.6/11.9 · 125.9 MB | 3.3/19.9 · 84.6 MB | 1.7/10.0 · 100.5 MB | 4.4/23.9 · 98.2 MB | 182.4/197.8 · 527.2 MB | 0.2/2.0 · 80.2 MB |

#### Errores (motivo de cada uno)

`SERVICIO_NO_DISPONIBLE` es la respuesta de diseño cuando un servicio no contesta dentro de su plazo o el cortacircuitos está abierto (falla rápido en vez de acumular espera). La última columna son los segundos que tardó el sistema en volver a contestar bien (3 respuestas correctas seguidas) una vez terminada la carga.

| Caso | Clientes | Errores de | Motivos | Segundos hasta recuperarse |
|---|---|---|---|---|
| Reporte de ventas 92 días (máximo), de punta a punta (GraphQL) | 16 | 870 de 870 | `graphql:SERVICIO_NO_DISPONIBLE` ×870 | 5.0 |

**Idempotencia bajo carga:** el mismo evento enviado 2771 veces en paralelo; los totales del reporte NO cambiaron respecto de la primera entrega.

#### Comparación con los objetivos declarados

Los objetivos se fijaron antes de medir (ADR-004). «Medido» es el peor valor entre los casos y concurrencias que cubre cada objetivo.

| Objetivo | Medido (peor caso) | Tope | Resultado |
|---|---|---|---|
| Ingesta de una venta: p95 ≤ 100 ms con hasta 16 emisores simultáneos | 45.2 | 100 | ✓ cumple |
| Reporte de 30 días de punta a punta (navegador→gateway→auth→GraphQL→analytics): p95 ≤ 1.000 ms con hasta 4 usuarios simultáneos | 500.6 | 1000 | ✓ cumple |
| Reporte de 92 días (el máximo permitido) de punta a punta: p95 ≤ 2.000 ms con hasta 4 usuarios simultáneos | 1201.6 | 2000 | ✓ cumple |
| Sin errores en ningún caso con hasta 4 clientes simultáneos | 0 | 0 | ✓ cumple |

#### Cómo leer esto

- Es una medición de ESTE entorno (sección «Entorno»). La base de datos es MongoDB real, así que el costo de las agregaciones es el de MongoDB; la red entre servicios es la del propio equipo (sin latencia de red real) y no se midió Docker.
- Los datos son sintéticos (generados con semilla fija); el reparto de ventas y de productos no es el de un restaurante real.
- El generador de carga corre en el mismo equipo y compite por CPU con los servicios: los resultados son un piso, no un techo.
- Para repetirlo con Docker y MongoDB reales: `docker compose -f docker-compose.yml -f docker-compose.carga.yml up -d` y `python scripts/load_test.py --modo externo ...` (ver README).

---

## M10 Implementación, despliegue y pruebas

### 10.1 Código fuente y persistencia

```
api-gateway/        borde público (tabla de rutas, sesión, rol, origen, límites)
auth-service/       credenciales y sesiones
clients-service/    datos personales y registro
inventory-service/  catálogo, precios, disponibilidad
orders-service/     pedidos y estados
payments-service/   pagos, boletas, reembolsos
notifications-service/ correo y contacto
analytics-service/  reportes de ventas
graphql-gateway/    agregación de solo lectura
provider-sandbox/   proveedor de pagos simulado
common/             código compartido (secretos, cliente interno, errores, logs, plazos)
datos-frontend/     consultas GraphQL de las pantallas de la C2 (datos del frontend)
mongo/              creación de usuarios de base de datos (uno por servicio)
secrets/manifest.tsv inventario simbólico de secretos (sin valores)
scripts/            arranque, siembra, pruebas de humo y de carga, generadores de documentos
tests/              pruebas automáticas y de mutación
docs/               este informe, ADR, matrices, diagramas, ejemplos y evidencia
```

Cada servicio tiene su base y su usuario en MongoDB; el esquema se versiona con migraciones (`_migraciones`, ADR-005). Los datos de demostración se cargan solo si `SEED_DEMO_DATA=true`.

### 10.2 Despliegue reproducible

Desde un repositorio limpio, con Docker:

```
python scripts/bootstrap.py          # genera .env con los secretos (permisos 600, fuera de git)
docker compose up -d --build         # Vault, siembra, MongoDB, servicios y gateway
python scripts/smoke_test.py         # recorre el sistema de punta a punta; código de salida 0 solo si todo pasó
docker compose down -v               # detiene y borra también la base de datos (sin -v conserva los datos)
```

- **Referencias de secretos:** `secrets/manifest.tsv` lista las 30 referencias simbólicas (sin valores). `bootstrap.py` genera los valores aleatorios en `.env` y `seed_vault.py` los carga en Vault y crea un token de solo lectura por servicio.
- **Datos de prueba:** con `SEED_DEMO_DATA=true` (valor por omisión del compose) se cargan la carta, las zonas de despacho y las cuentas de demostración que lista el `README.md`; en cualquier uso que no sea una demostración se pone `false`.
- **Pruebas:** `pip install -r requirements/tests.txt` y `python -m pytest tests -q` (suite completa con Vault y MongoDB simulados); con servidores reales, `ASADOR_REAL=1 ASADOR_BIN=/ruta/a/bins python -m pytest tests -q`. Las dependencias están con versión fija en `requirements/`.
- **Health checks y logs:** cada servicio responde `/health` y el compose espera a que estén `healthy`; los logs son una línea JSON por solicitud con un `request_id` (cabecera `X-Request-ID`) y sin credenciales ni correos o RUN completos.

Sin Docker: `python scripts/demo_local.py` levanta el sistema completo como procesos (con Vault y MongoDB simulados, o con servidores reales si se indica `--real --bin <carpeta>`). El `README.md` de la raíz explica cada paso, las cuentas de demostración y cómo detener y limpiar.

**Todo corre en localhost**: no hay servidor ni dominio público. La puerta de entrada es `http://localhost:8000` y la página de pago del proveedor simulado, `http://localhost:8300`; ningún otro servicio publica puertos.

Docker Compose en localhost, según `docker-compose.yml` (ejecutado en Docker Desktop el 7 y el 8 de noviembre de 2026; ver `docs/evidencia/docker_humo.txt` y [`docs/evidencia/docker_2026-11-08/`](evidencia/docker_2026-11-08/README.md)):

![Despliegue con Docker Compose en localhost](diagramas/render/DEP_Compose_Local.svg)

### 10.3 Pruebas ejecutadas

| Ejecución | Pruebas | Pasaron | Fallaron | Omitidas |
|---|---|---|---|---|
| Con Vault y MongoDB **simulados** (por omisión) | 883 | 868 | 0 | 15 |
| Con HashiCorp Vault y MongoDB **reales** (sin Docker) | 887 | 886 | 0 | 1 |

| Archivo de pruebas | Simulado: pasaron / omitidas | Reales: pasaron / omitidas |
|---|---|---|
| `test_analitica.py` | 30 / 0 | 30 / 0 |
| `test_despliegue.py` | 21 / 0 | 21 / 0 |
| `test_diagrama_dsl.py` | 16 / 1 | 17 / 0 |
| `test_documentos.py` | 11 / 0 | 11 / 0 |
| `test_graphql.py` | 64 / 0 | 64 / 0 |
| `test_infraestructura_real.py` | 0 / 14 | 14 / 0 |
| `test_limites_tasa.py` | 9 / 0 | 9 / 0 |
| `test_negocio_administracion.py` | 89 / 0 | 89 / 0 |
| `test_negocio_pagos.py` | 24 / 0 | 24 / 0 |
| `test_negocio_pedidos.py` | 39 / 0 | 39 / 0 |
| `test_resiliencia.py` | 14 / 0 | 14 / 0 |
| `test_secretos_vault.py` | 39 / 0 | 38 / 1 |
| `test_segunda_capa.py` | 181 / 0 | 181 / 0 |
| `test_seguridad_acceso.py` | 191 / 0 | 192 / 0 |
| `test_sesion_vence.py` | 2 / 0 | 2 / 0 |
| `test_unidad_carreras.py` | 21 / 0 | 21 / 0 |
| `test_unidad_guardia_graphql.py` | 12 / 0 | 12 / 0 |
| `test_unidad_logs.py` | 8 / 0 | 8 / 0 |
| `test_unidad_plazos.py` | 4 / 0 | 4 / 0 |
| `test_unidad_reglas.py` | 83 / 0 | 83 / 0 |
| `test_zz_logs_y_secretos.py` | 10 / 0 | 13 / 0 |

**Casos de validación del módulo 7 y evidencia del módulo 8:** 75 de 75 verificaciones cumplieron ([detalle](evidencia/controles.md)).

La corrida con servidores reales es del 7 de noviembre de 2026, anterior al retiro del frontend de la entrega: incluye 4 pruebas del código de las páginas que ya no están en el repositorio (una sobre la política de contenido de las 8 páginas y tres de `test_zz_logs_y_secretos` sobre el código del navegador) y la prueba de cabeceras de seguridad con su nombre anterior (que terminaba en «en_api_y_paginas»). No se repitió porque este entorno ya no tiene los servidores reales.

Las pruebas parten de contratos escritos aparte del código (`tests/contratos/*.json`), de modo que no verifican al código contra sí mismo.

### 10.4 Demostración de los flujos principales

La demostración es la prueba de humo (`scripts/smoke_test.py`): recorre por HTTP, contra el sistema levantado, los flujos principales con los datos de prueba del frontend. Cubre la carta pública, el registro, la sesión, el pedido con clave de idempotencia, el pago con el proveedor simulado y su aviso firmado, la boleta, GraphQL, el aislamiento entre clientes, el personal por rol y el cierre de sesión. Se ejecutó el 5 de noviembre de 2026 con HashiCorp Vault y MongoDB reales (sin Docker) y el 7 y el 8 de noviembre de 2026 con Docker Compose ([`docs/evidencia/docker_humo.txt`](evidencia/docker_humo.txt) y [`docs/evidencia/docker_2026-11-08/05-smoke-test.txt`](evidencia/docker_2026-11-08/05-smoke-test.txt)); en todas dio 29 de 29. Esta es la ejecución sin Docker:

```text
Prueba de humo ejecutada el 2026-11-08 15:25 contra el sistema levantado con: python scripts/demo_local.py (Vault y MongoDB simulados, sin Docker), con el backend solo, sin el frontend conectado
Comando: python scripts/smoke_test.py --base http://127.0.0.1:8000 --proveedor http://127.0.0.1:8300

1. Salud
  OK     el gateway responde /health
  OK     el gateway está listo (/ready: Vault y servicios)
  OK     cada respuesta lleva un identificador de correlación
2. Público y seguridad básica
  OK     el catálogo es público
  OK     sin sesión, /api/orders responde 401
  OK     sin sesión, el panel responde 401
  OK     /api/auth/me sin sesión dice que no hay usuario
  OK     cabeceras de seguridad presentes
  OK     una solicitud que modifica datos desde otro sitio se rechaza
  OK     una ruta que no está en la tabla del gateway no se reenvía
3. Cliente: registro, sesión y pedido
  OK     el registro crea al cliente
  OK     el login entrega la sesión en una cookie HttpOnly (no en el cuerpo)
  OK     /api/clients/me devuelve el perfil propio
  OK     crear el pedido dos veces con la misma clave de idempotencia devuelve el MISMO pedido
  OK     el total lo calcula el servidor (el cliente no manda precios)
4. Pago con el proveedor simulado
  OK     se inicia el pago y entrega la página del proveedor
  OK     el cliente paga en la página del proveedor
  OK     el aviso firmado del proveedor deja el pedido «En preparación»
  OK     la boleta está disponible y el IVA cuadra
5. GraphQL (una consulta, varios servicios)
  OK     misPedidos trae el pedido con su pago y sus líneas
  OK     un cliente no puede pedir los pedidos de todos (PROHIBIDO)
  OK     la introspección de GraphQL está desactivada
6. Aislamiento entre clientes
  OK     otro cliente no ve el pedido y la respuesta es idéntica a la de un pedido inexistente
  OK     otro cliente no puede pagar ni anular el pedido ajeno
7. Personal (solo si existen las cuentas de demostración)
  OK     el administrador ve los pedidos
  OK     el cliente NO ve el panel
  OK     el panel de administración responde por GraphQL
8. Cierre de sesión
  OK     cerrar sesión
  OK     la sesión cerrada ya no sirve

29 de 29 comprobaciones correctas
código de salida: 0
```

La ejecución anterior es sobre el código final del backend, sin el frontend conectado y con servidores simulados. La misma prueba había dado 29 de 29 el 5 de noviembre con HashiCorp Vault y MongoDB reales ([`docs/evidencia/humo_reales_2026-11-05.txt`](evidencia/humo_reales_2026-11-05.txt)) y con Docker el 7 de noviembre ([`docs/evidencia/docker_humo.txt`](evidencia/docker_humo.txt)) y el 8 de noviembre, esta vez sobre el código final ([`docs/evidencia/docker_2026-11-08/05-smoke-test.txt`](evidencia/docker_2026-11-08/05-smoke-test.txt); capturas en el [módulo 7.4](#74-evidencia-de-la-ejecución-con-docker)).

La consulta protegida de un pedido, con una ejecución autorizada (control 8) y otra denegada con una cuenta distinta (control 1), está en el [módulo 7.3](#73-resultados-de-los-6-casos-de-validación) y su recorrido en el [5.4](#54-recorrido-de-una-solicitud-autorizada-y-de-una-denegada).
