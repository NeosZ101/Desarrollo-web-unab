"""Esquema GraphQL de El Asador (SOLO LECTURA).

Para qué existe: la pantalla «Mis pedidos» y el panel del administrador necesitan datos que viven en
varios servicios (pedidos, pago/boleta, imágenes del catálogo, ventas). En lugar de que el navegador
haga 4 llamadas y las una, pide UNA consulta y este gateway agrega, con DataLoader para no hacer una
llamada por pedido (problema N+1).

Seguridad:
  * No hay mutaciones: toda escritura sigue pasando por las rutas REST de cada servicio.
  * Cada campo sensible declara los roles que lo pueden pedir (permission_classes). Además, cada
    servicio de origen vuelve a aplicar roles y propiedad con la identidad que reenviamos.
  * Un cliente nunca puede pedir pedidos de otro: no existe argumento para eso y orders los acota.
  * Si un servicio secundario falla (pagos, imágenes), el campo queda en null y se avisa en
    `extensions.avisos`; el resto de la respuesta sigue siendo útil.
"""
from typing import NewType

import strawberry
from strawberry.dataloader import DataLoader
from strawberry.extensions import AddValidationRules, DisableIntrospection, MaskErrors, MaxAliasesLimiter, MaxTokensLimiter, QueryDepthLimiter
from strawberry.permission import BasePermission
from strawberry.types import Info

from common.cliente_interno import ServicioNoDisponible, cuerpo

from .limites import ErrorGraphQL, LimiteDeCosto, acotar, registrar_inesperado

# El tipo Int de GraphQL es de 32 bits (tope 2.147.483.647): una suma de ventas de muchos días lo supera y la consulta fallaba con «Error interno».
# Los montos agregados usan este escalar, que se envía como un entero JSON normal (hasta 2^53 sin perder exactitud en el navegador).
Monto = strawberry.scalar(NewType("Monto", int), name="Monto", description="Monto en pesos chilenos, entero sin el tope de 32 bits de Int",
                          serialize=int, parse_value=int)


# ----------------------------- contexto de cada consulta ------------------------------
class Contexto:
    """Se crea UNO por consulta (los cargadores no se comparten entre usuarios)."""

    def __init__(self, llamada, interno):
        self.llamada, self.interno = llamada, interno
        self.identidad = llamada.identidad
        self.avisos = set()
        self.items = DataLoader(load_fn=self._cargar_items)
        self.pagos = DataLoader(load_fn=self._cargar_pagos)

    async def pedir(self, destino, ruta, params=None):
        try:
            r = await self.interno.llamar(destino, "GET", ruta, request_id=self.llamada.request_id, identidad=self.identidad, params=params)
        except ServicioNoDisponible:
            raise ErrorGraphQL("SERVICIO_NO_DISPONIBLE", "Parte de la información no está disponible en este momento.")
        if r.status_code == 403:
            raise ErrorGraphQL("PROHIBIDO", "No tiene permisos para este dato")
        if r.status_code >= 400:
            c = cuerpo(r)
            raise ErrorGraphQL(c.get("codigo", "ERROR_DE_ORIGEN"), c.get("detail", "No se pudo obtener el dato"))
        return r

    async def _cargar_items(self, ids):
        try:
            salida = {}
            for i in range(0, len(ids), 50):
                salida.update((await self.pedir("inventory", "/internal/items", {"ids": ",".join(ids[i:i + 50])})).json())
            return [salida.get(k) for k in ids]
        except ErrorGraphQL:
            self.avisos.add("CATALOGO_NO_DISPONIBLE")
            return [None] * len(ids)

    async def _cargar_pagos(self, ids):
        try:
            por_id = {}
            for i in range(0, len(ids), 50):
                for fila in (await self.pedir("payments", "/internal/payments/by-orders", {"ids": ",".join(ids[i:i + 50])})).json():
                    por_id[fila["pedidoId"]] = fila
            return [por_id.get(k) for k in ids]
        except ErrorGraphQL:
            self.avisos.add("PAGOS_NO_DISPONIBLES")
            return [None] * len(ids)


def requiere(*roles):
    class Permiso(BasePermission):
        message = "No tiene permisos para este dato"
        error_extensions = {"codigo": "PROHIBIDO"}

        def has_permission(self, source, info: Info, **kwargs) -> bool:
            return info.context.identidad.tiene(*roles)

    Permiso.roles = roles   # visible para scripts/generar_documentos.py (la matriz de autorización sale del código)
    return Permiso


SOLO_CLIENTE = [requiere("cliente")]
PERSONAL_DESPACHO = [requiere("administrador", "despacho")]
GESTION = [requiere("administrador", "dueno")]
SOLO_ADMIN = [requiere("administrador")]
DATOS_DE_ENTREGA = [requiere("cliente", "administrador", "despacho")]   # el dueño NO ve datos personales de clientes


# ----------------------------- tipos ----------------------------------------------------
@strawberry.type
class Linea:
    item_id: str | None
    nombre: str
    cantidad: int
    precio: int

    @strawberry.field
    def subtotal(self) -> int:
        return self.precio * self.cantidad

    @strawberry.field
    async def imagen(self, info: Info) -> str | None:
        it = await info.context.items.load(self.item_id) if self.item_id else None
        return it["imagen"] if it else None

    @strawberry.field
    async def disponible(self, info: Info) -> bool | None:
        it = await info.context.items.load(self.item_id) if self.item_id else None
        return it["disponible"] if it else None


@strawberry.type
class Hito:
    estado: str
    fecha: str
    por: str


@strawberry.type
class DatosCliente:
    nombre: str
    correo: str
    telefono: str
    direccion: str
    comuna: str
    indicaciones: str


@strawberry.type
class Pago:
    id: str
    estado: str
    medio: str
    monto: int
    checkout_url: str | None
    instrucciones: str | None
    reembolso: str | None


@strawberry.type
class Boleta:
    folio: str
    total: int
    estado: str


@strawberry.type
class Pedido:
    id: strawberry.ID
    fecha: str
    origen: str
    estado: str
    subtotal: int
    despacho: int
    total: int
    medio_pago: str
    reembolso: str
    motivo_anulacion: str | None
    anulado_por: str | None
    fecha_anulacion: str | None
    lineas: list[Linea]
    historial: list[Hito]
    _cliente: strawberry.Private[dict]

    @strawberry.field(permission_classes=DATOS_DE_ENTREGA)
    def cliente(self) -> DatosCliente:
        c = self._cliente
        return DatosCliente(nombre=c["nombre"], correo=c["correo"], telefono=c["telefono"], direccion=c["direccion"],
                            comuna=c["comuna"], indicaciones=c.get("indicaciones", ""))

    @strawberry.field
    async def pago(self, info: Info) -> Pago | None:
        fila = await info.context.pagos.load(str(self.id))
        if not fila:
            return None
        p = fila["pago"]
        return Pago(id=p["id"], estado=p["estado"], medio=p["medio"], monto=p["monto"], checkout_url=p.get("checkoutUrl"),
                    instrucciones=p.get("instrucciones"), reembolso=(p.get("reembolso") or {}).get("estado"))

    @strawberry.field
    async def boleta(self, info: Info) -> Boleta | None:
        fila = await info.context.pagos.load(str(self.id))
        b = fila and fila.get("boleta")
        return Boleta(folio=b["folio"], total=b["total"], estado=b["estado"]) if b else None


def _pedido(d):
    return Pedido(
        id=d["id"], fecha=d["fecha"], origen=d.get("origen", "web"), estado=d["estado"], subtotal=d["subtotal"], despacho=d["despacho"],
        total=d["total"], medio_pago=d["pago"], reembolso=d.get("reembolso", "no_aplica"), motivo_anulacion=d.get("motivoAnulacion"),
        anulado_por=d.get("anuladoPor"), fecha_anulacion=d.get("fechaAnulacion"),
        lineas=[Linea(item_id=l.get("itemId"), nombre=l["nombre"], cantidad=l["cantidad"], precio=l["precio"]) for l in d["lineas"]],
        historial=[Hito(estado=h["estado"], fecha=h["fecha"], por=h["por"]) for h in d.get("historial", [])], _cliente=d["cliente"])


@strawberry.type
class PaginaPedidos:
    total: int
    items: list[Pedido]


@strawberry.type
class ConteoEstado:
    estado: str
    cantidad: int


@strawberry.type
class ResumenProductos:
    activos: int
    agotados: list[str]


@strawberry.type
class ResumenPagos:
    iniciados: int
    aprobados: int
    reembolsos_pendientes: int
    pagos_manuales_por_confirmar: int


@strawberry.type
class PanelAdmin:
    @strawberry.field(permission_classes=PERSONAL_DESPACHO)
    async def pedidos_por_estado(self, info: Info) -> list[ConteoEstado]:
        r = (await info.context.pedir("orders", "/admin/orders/summary")).json()["porEstado"]
        return [ConteoEstado(estado=k, cantidad=v) for k, v in r.items()]

    @strawberry.field(permission_classes=GESTION)
    async def productos(self, info: Info) -> ResumenProductos:
        r = (await info.context.pedir("inventory", "/internal/summary")).json()
        return ResumenProductos(activos=r["productosActivos"], agotados=[a["nombre"] for a in r["agotados"]])

    @strawberry.field(permission_classes=SOLO_ADMIN)
    async def pagos(self, info: Info) -> ResumenPagos:
        r = (await info.context.pedir("payments", "/internal/summary")).json()
        e = r["porEstado"]
        return ResumenPagos(iniciados=e["iniciado"], aprobados=e["aprobado"], reembolsos_pendientes=r["reembolsosPendientes"],
                            pagos_manuales_por_confirmar=r["pagosManualesPorConfirmar"])


@strawberry.type
class DiaVenta:
    fecha: str
    pedidos: int
    ventas: Monto
    ticket_promedio: int


@strawberry.type
class TotalesVenta:
    ventas: Monto
    pedidos: int
    ticket_promedio: int
    mejor_dia: str | None


@strawberry.type
class MedioVenta:
    medio: str
    pedidos: int
    ventas: Monto


@strawberry.type
class ProductoVendido:
    nombre: str
    unidades: int
    ventas: Monto


@strawberry.type
class ReporteVentas:
    desde: str
    hasta: str
    dias: list[DiaVenta]
    totales: TotalesVenta
    por_medio_pago: list[MedioVenta]
    top_productos: list[ProductoVendido]


@strawberry.type
class Query:
    @strawberry.field(permission_classes=SOLO_CLIENTE)
    async def mis_pedidos(self, info: Info, limit: int = 10, offset: int = 0) -> PaginaPedidos | None:
        r = await info.context.pedir("orders", "/orders", {"limit": acotar(limit, 1, 50), "offset": acotar(offset, 0, 10000)})
        return PaginaPedidos(total=int(r.headers.get("x-total-count", "0")), items=[_pedido(d) for d in r.json()])

    @strawberry.field(permission_classes=PERSONAL_DESPACHO)
    async def pedidos_admin(self, info: Info, estado: str = "activos", limit: int = 50, offset: int = 0) -> PaginaPedidos | None:
        r = await info.context.pedir("orders", "/admin/orders", {"estado": estado[:20], "limit": acotar(limit, 1, 100), "offset": acotar(offset, 0, 10000)})
        return PaginaPedidos(total=int(r.headers.get("x-total-count", "0")), items=[_pedido(d) for d in r.json()])

    @strawberry.field
    def panel_admin(self, info: Info) -> PanelAdmin | None:
        if not info.context.identidad.es_personal:
            raise ErrorGraphQL("PROHIBIDO", "No tiene permisos para este dato")
        return PanelAdmin()

    @strawberry.field(permission_classes=GESTION)
    async def reporte_ventas(self, info: Info, desde: str, hasta: str) -> ReporteVentas | None:
        r = (await info.context.pedir("analytics", "/internal/reports/sales", {"desde": desde[:10], "hasta": hasta[:10]})).json()
        t = r["totales"]
        return ReporteVentas(
            desde=r["desde"], hasta=r["hasta"],
            dias=[DiaVenta(fecha=d["fecha"], pedidos=d["pedidos"], ventas=d["ventas"], ticket_promedio=d["ticketPromedio"]) for d in r["dias"]],
            totales=TotalesVenta(ventas=t["ventas"], pedidos=t["pedidos"], ticket_promedio=t["ticketPromedio"], mejor_dia=t["mejorDia"]),
            por_medio_pago=[MedioVenta(medio=m["medio"], pedidos=m["pedidos"], ventas=m["ventas"]) for m in r["porMedioPago"]],
            top_productos=[ProductoVendido(nombre=p["nombre"], unidades=p["unidades"], ventas=p["ventas"]) for p in r["topProductos"]])


def _enmascarar(e) -> bool:
    """MaskErrors oculta toda EXCEPCIÓN inesperada de un resolver (devuelve «Error interno»).
    Se muestran: errores de negocio (ErrorGraphQL), de permisos (traen «codigo») y los de la propia consulta
    (sintaxis, validación, límites, variables mal escritas), que no tienen ruta porque no nacen de un resolver."""
    if e.path is None or isinstance(e.original_error, ErrorGraphQL) or (e.extensions or {}).get("codigo"):
        return False
    registrar_inesperado(e)
    return True      # lo permitido es una lista corta: todo lo demás se oculta, traiga o no una excepción asociada


MAX_PROFUNDIDAD = 6
schema = strawberry.Schema(
    query=Query,
    extensions=[
        DisableIntrospection,                             # el esquema no se puede explorar desde fuera
        QueryDepthLimiter(max_depth=MAX_PROFUNDIDAD),     # evita consultas anidadas sin fin
        MaxAliasesLimiter(max_alias_count=10),            # evita repetir el mismo campo con alias para multiplicar el trabajo
        MaxTokensLimiter(max_token_count=1200),           # tamaño máximo del documento
        AddValidationRules([LimiteDeCosto]),              # costo estimado (ver limites.py)
        MaskErrors(should_mask_error=_enmascarar, error_message="Error interno"),
    ],
)
