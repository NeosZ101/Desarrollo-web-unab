"""GraphQL Gateway (privado): agrega datos de varios servicios en una sola consulta de SOLO LECTURA.

Solo lo llama el API Gateway, con la identidad del usuario ya verificada. Reglas de este servicio:
  * Un único endpoint (POST /graphql), sin GraphiQL, sin introspección, sin suscripciones ni mutaciones.
  * Tamaño máximo de la consulta, profundidad, alias, tokens y costo estimado (ver schema.py / limites.py).
  * Tiempo máximo de ejecución y errores sin detalles internos (no se filtran trazas ni nombres de servicios).
"""
import asyncio
import json
import logging
import os
import re
from contextlib import asynccontextmanager

from fastapi import Depends, Request
from fastapi.responses import JSONResponse

from common import plazos
from common.app import crear_app
from common.cliente_interno import ClienteInterno
from common.errores import ErrorNegocio
from common.seguridad import Guardia
from common.vault_secrets import VaultSecrets

from .schema import Contexto, schema

vault = VaultSecrets()
guardia = Guardia("graphql-gateway", vault)
MAX_CUERPO = 8 * 1024
TIEMPO_MAXIMO = plazos.graphql_maximo()
interno = None


@asynccontextmanager
async def lifespan(app):
    global interno
    await guardia.precalentar()
    urls = {k: os.environ[v] for k, v in (("orders", "ORDERS_URL"), ("inventory", "INVENTORY_URL"), ("payments", "PAYMENTS_URL"), ("analytics", "ANALYTICS_URL"))}
    interno = ClienteInterno("graphql-gateway", vault, urls, timeout=plazos.upstream("graphql"),
                             pausa_circuito=float(os.environ.get("CIRCUITO_PAUSA", "5")))
    await interno.precalentar()
    log.info("GraphQL gateway listo")
    yield
    await interno.cerrar()


app, log = crear_app("graphql-gateway", lifespan)
SUGERENCIA_RE = re.compile(r"\s*Did you mean[^?]*\?")
CAMPO_RE = re.compile(r"Cannot query field '([^']{1,60})' on type '[^']{1,60}'\.?")
logging.getLogger("strawberry.execution").setLevel(logging.CRITICAL)   # el log propio basta; este copiaba el texto de la consulta


def _mensaje(texto):
    """Mensajes de validación sin datos del esquema (tipos internos, sugerencias de nombres)."""
    return CAMPO_RE.sub(r"El campo '\1' no existe.", SUGERENCIA_RE.sub("", texto)).strip()


def _error(e):
    """Formato de salida: mensaje, ruta y código. Sin ubicaciones ni sugerencias que revelen el esquema."""
    ext = e.extensions or {}
    codigo = ext.get("codigo") or ("CONSULTA_INVALIDA" if e.path is None else "ERROR_INTERNO")
    return {"message": _mensaje(e.message)[:300], "path": list(e.path) if e.path else None, "extensions": {"codigo": codigo}}


@app.post("/graphql")
async def graphql(request: Request, ll=Depends(guardia.dep(("api-gateway",), identidad="requerida"))):
    if "application/json" not in request.headers.get("content-type", ""):
        raise ErrorNegocio(415, "CONTENT_TYPE_INVALIDO", "Se requiere Content-Type: application/json")
    crudo = await request.body()
    if len(crudo) > MAX_CUERPO:
        raise ErrorNegocio(413, "CUERPO_DEMASIADO_GRANDE", "Consulta demasiado grande")
    try:
        datos = json.loads(crudo)
        query, variables, operacion = datos["query"], datos.get("variables") or {}, datos.get("operationName")
        if not isinstance(datos, dict) or not isinstance(query, str) or not isinstance(variables, dict) or not (operacion is None or isinstance(operacion, str)):
            raise ValueError
        if set(datos) - {"query", "variables", "operationName"}:
            raise ValueError
    except (ValueError, KeyError, TypeError):
        raise ErrorNegocio(400, "SOLICITUD_INVALIDA", "La consulta GraphQL no es válida")
    ctx = Contexto(ll, interno)
    try:
        resultado = await asyncio.wait_for(schema.execute(query, variable_values=variables, context_value=ctx, operation_name=operacion), TIEMPO_MAXIMO)
    except asyncio.TimeoutError:
        log.warning("consulta GraphQL fuera de tiempo", extra={"ctx": {"request_id": ll.request_id}})
        raise ErrorNegocio(504, "CONSULTA_FUERA_DE_TIEMPO", "La consulta tardó demasiado")
    salida = {"data": resultado.data}
    if resultado.errors:
        salida["errors"] = [_error(e) for e in resultado.errors]
        log.info("consulta GraphQL con errores", extra={"ctx": {"request_id": ll.request_id, "codigos": sorted({e["extensions"]["codigo"] for e in salida["errors"]})}})
    if ctx.avisos:
        salida["extensions"] = {"avisos": sorted(ctx.avisos)}
    return JSONResponse(salida)
