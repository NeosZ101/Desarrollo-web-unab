"""Límites de las consultas GraphQL: costo estimado y errores controlados.

El costo es una estimación simple pero conservadora, calculada ANTES de ejecutar nada:
  costo(campo) = 1 + costo(hijos) * multiplicador
donde el multiplicador es el argumento `limit` del campo (50 si viene en una variable, 10 si se omite
en una lista paginada). Así `misPedidos(limit: 50) { items { lineas { ... } } }` cuesta mucho más que
`misPedidos(limit: 5) { ... }` y una consulta abusiva se rechaza sin tocar ningún servicio.
"""
import logging

from graphql import FieldNode, FragmentDefinitionNode, FragmentSpreadNode, GraphQLError, InlineFragmentNode, IntValueNode
from graphql.validation import ValidationRule

COSTO_MAXIMO = 1500
PAGINADOS = {"misPedidos": 10, "pedidosAdmin": 50}
LIMITE_MAXIMO = 50


class ErrorGraphQL(Exception):
    """Error de negocio con mensaje seguro para mostrar al cliente."""

    def __init__(self, codigo, mensaje):
        super().__init__(mensaje)
        self.codigo = codigo
        self.extensions = {"codigo": codigo}


def acotar(valor, minimo, maximo):
    return max(minimo, min(int(valor), maximo))


class LimiteDeCosto(ValidationRule):
    def __init__(self, context):
        super().__init__(context)
        self._fragmentos = {}

    def enter_document(self, node, *_):
        self._fragmentos = {d.name.value: d for d in node.definitions if isinstance(d, FragmentDefinitionNode)}

    def enter_operation_definition(self, node, *_):
        costo = self._costo(node.selection_set, frozenset())
        if costo > COSTO_MAXIMO:
            self.report_error(GraphQLError(f"La consulta es demasiado costosa ({costo}; máximo {COSTO_MAXIMO}). Pide menos datos o reduce «limit».",
                                           nodes=[node], extensions={"codigo": "CONSULTA_DEMASIADO_COSTOSA"}))

    def _costo(self, seleccion, visitando):
        total = 0
        for s in seleccion.selections:
            if isinstance(s, FieldNode):
                if s.name.value.startswith("__"):
                    continue
                hijos = self._costo(s.selection_set, visitando) if s.selection_set else 0
                total += 1 + hijos * self._multiplicador(s)
            elif isinstance(s, InlineFragmentNode):
                total += self._costo(s.selection_set, visitando)
            elif isinstance(s, FragmentSpreadNode):
                nombre = s.name.value
                if nombre not in visitando and nombre in self._fragmentos:
                    total += self._costo(self._fragmentos[nombre].selection_set, visitando | {nombre})
        return total

    @staticmethod
    def _multiplicador(campo):
        for a in campo.arguments or ():   # graphql-core entrega None cuando el campo no tiene argumentos
            if a.name.value == "limit":
                if not isinstance(a.value, IntValueNode):
                    return LIMITE_MAXIMO   # viene en una variable: se asume lo peor
                try:
                    return max(1, min(int(a.value.value), LIMITE_MAXIMO))   # el servicio acota igual: nunca menos de 1 ni más de 50
                except ValueError:         # un literal de miles de dígitos no cabe en un int: también cuenta como el máximo
                    return LIMITE_MAXIMO
        return PAGINADOS.get(campo.name.value, 1)



def registrar_inesperado(e):
    """Un error que ningún resolver previó se enmascara hacia el navegador («Error interno»), pero NO puede quedar sin rastro en el log.
    Se anota el campo y el TIPO de la excepción; nunca su texto (podría traer datos o una cadena de conexión). El identificador de la
    solicitud lo agrega el formateador de logs."""
    logging.getLogger("graphql-gateway").error("error inesperado en una consulta GraphQL", extra={"ctx": {
        "campo": ".".join(str(x) for x in (e.path or ())), "tipo": type(e.original_error or e).__name__}})
