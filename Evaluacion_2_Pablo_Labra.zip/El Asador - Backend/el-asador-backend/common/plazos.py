"""Plazos máximos de espera, escalonados: cada capa se rinde ANTES que la capa de arriba.

Si el plazo de abajo fuera igual o mayor, la capa de arriba cortaría primero y el usuario recibiría un 504 genérico mientras el
servicio de abajo sigue trabajando; con plazos escalonados cada servicio alcanza a contestar un error limpio (503/504 con Retry-After).

Regla (la comprueba tests/test_unidad_plazos.py con los valores por omisión):
    (llamadas internas seguidas de la cadena más larga) × plazo interno  <  plazo del gateway
    plazo del proveedor de pagos + plazo interno                         <  plazo del gateway
    plazo máximo de GraphQL                                              <  plazo del gateway
    (procesos que leen secretos en la cadena más larga) × plazo de Vault  <  plazo del gateway   (ver common/vault_secrets.py)

UPSTREAM_TIMEOUT, GRAPHQL_TIMEOUT y PROVIDER_TIMEOUT sobrescriben los valores por omisión (las pruebas de resiliencia usan plazos de 1 a 3 s).
"""
import os

POR_OMISION = {"gateway": 6.0, "servicio": 2.0, "graphql": 2.0}   # segundos: lo que espera cada capa a la capa de abajo
GRAPHQL_MAXIMO = 5.0                                              # una consulta GraphQL completa (hasta dos tandas de llamadas internas)
PROVEEDOR = 3.0                                                   # payments → proveedor de pagos


def upstream(capa):
    """Plazo de las llamadas HTTP que hace una capa ("gateway", "servicio" o "graphql") hacia la capa de abajo."""
    return float(os.environ.get("UPSTREAM_TIMEOUT", POR_OMISION[capa]))


def graphql_maximo():
    return float(os.environ.get("GRAPHQL_TIMEOUT", GRAPHQL_MAXIMO))


def proveedor():
    return float(os.environ.get("PROVIDER_TIMEOUT", PROVEEDOR))
