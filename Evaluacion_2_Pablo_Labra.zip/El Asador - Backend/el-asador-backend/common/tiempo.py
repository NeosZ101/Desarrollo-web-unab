"""Fechas: se guardan como texto ISO-8601 en UTC y los reportes usan el día local de Santiago."""
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

TZ = ZoneInfo("America/Santiago")


def ahora():
    return datetime.now(timezone.utc)


def iso(dt=None):
    dt = dt or ahora()
    return dt.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def desde_iso(texto):
    return datetime.fromisoformat(texto.replace("Z", "+00:00"))


def fecha_local(valor=None):
    """Devuelve AAAA-MM-DD del día en Santiago para un ISO, un datetime o 'ahora'."""
    if valor is None:
        dt = ahora()
    elif isinstance(valor, str):
        dt = desde_iso(valor)
    else:
        dt = valor
    return dt.astimezone(TZ).strftime("%Y-%m-%d")


def sumar_dias(fecha, dias):
    return (datetime.strptime(fecha, "%Y-%m-%d") + timedelta(days=dias)).strftime("%Y-%m-%d")
