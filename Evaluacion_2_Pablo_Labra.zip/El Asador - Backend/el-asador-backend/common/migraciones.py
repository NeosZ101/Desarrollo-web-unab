"""Migraciones mínimas y versionadas.

Cada servicio declara una lista de (versión, descripción, función async). Al arrancar se aplican
en orden las que superan la versión guardada en la colección `_migraciones`. Son idempotentes:
reiniciar el servicio no repite ni duplica nada.
"""
import logging

from .tiempo import iso

log = logging.getLogger("migraciones")


async def migrar(db, migraciones):
    doc = await db["_migraciones"].find_one({"_id": "esquema"})
    actual = doc["version"] if doc else 0
    for version, descripcion, fn in sorted(migraciones, key=lambda m: m[0]):
        if version > actual:
            await fn(db)
            await db["_migraciones"].update_one(
                {"_id": "esquema"}, {"$set": {"version": version, "descripcion": descripcion, "aplicada": iso()}}, upsert=True)
            log.info("migración aplicada", extra={"ctx": {"version": version, "descripcion": descripcion}})
            actual = version
    return actual
