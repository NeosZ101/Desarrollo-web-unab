"""Lectura de secretos desde HashiCorp Vault (motor KV v2).

Decisiones:
  * Los secretos nunca viven en el código ni en el repositorio: se leen de Vault.
  * Se guardan en memoria con un TTL corto. Así se puede rotar un secreto en Vault
    sin reiniciar los servicios (se recoge al vencer el TTL).
  * Si Vault NO RESPONDE (red caída, sellado, 5xx, colgado) y ya hay un valor en caché, se sigue usando ese valor
    (degradación controlada). Si no hay nada en caché, se lanza SecretUnavailable.
  * Si Vault RESPONDE que el secreto fue borrado o el token revocado (404/403), el valor en caché se descarta:
    revocar un secreto tiene efecto aunque los procesos sigan vivos.
  * Un Vault COLGADO (acepta la conexión y no contesta) no puede sumar su espera a cada solicitud:
      - el plazo para hablar con Vault es corto (VAULT_TIMEOUT_SECONDS, 1 s): está en la misma red y contesta en milisegundos;
      - tras un fallo se abre una PAUSA (VAULT_RETRY_AFTER_SECONDS, 5 s): mientras dura no se le consulta, se usa la caché
        (o se falla cerrado al instante si no hay copia) y al terminar la siguiente lectura hace UNA prueba.
    Regla de plazos: VAULT_TIMEOUT × procesos de la cadena más larga < plazo del gateway (ver informe, ADR de plazos).
  * Nunca se escribe el valor de un secreto en los logs.
"""
import logging
import os
import threading
import time

import httpx

log = logging.getLogger("secretos")


class SecretUnavailable(RuntimeError):
    """No se pudo obtener el secreto y no hay valor en caché. `revocado` = Vault respondió que ya no existe o no hay permiso."""

    def __init__(self, mensaje, revocado=False):
        super().__init__(mensaje)
        self.revocado = revocado


class VaultSecrets:
    def __init__(self, addr=None, token=None, mount="secret", ttl=None, timeout=None, pausa_tras_fallo=None):
        self.addr = (addr or os.environ["VAULT_ADDR"]).rstrip("/")
        self._token = token or os.environ["VAULT_TOKEN"]
        self.mount = mount
        self.ttl = float(ttl if ttl is not None else os.environ.get("SECRET_TTL_SECONDS", "60"))
        self.timeout = float(timeout if timeout is not None else os.environ.get("VAULT_TIMEOUT_SECONDS", "1.0"))
        self.pausa = float(pausa_tras_fallo if pausa_tras_fallo is not None else os.environ.get("VAULT_RETRY_AFTER_SECONDS", "5"))
        self._cache = {}          # ruta -> (datos, instante)
        self._pausa_hasta = 0.0   # instante (monotónico) hasta el que no se vuelve a consultar a Vault tras un fallo
        self._caido = False       # para avisar UNA vez cuando Vault vuelve
        self._lock = threading.Lock()

    # ----- utilidades internas -------------------------------------------------
    def _url(self, ruta):
        return f"{self.addr}/v1/{self.mount}/data/{ruta}"

    def _vigente(self, ruta):
        item = self._cache.get(ruta)
        if item and (time.monotonic() - item[1]) < self.ttl:
            return item[0]
        return None

    def _en_pausa(self):
        return time.monotonic() < self._pausa_hasta

    def _contesto(self):
        """Vault respondió algo definitivo (valor, 403 o 404): está vivo, se cierra la pausa."""
        self._pausa_hasta = 0.0
        if self._caido:
            self._caido = False
            log.info("Vault respondió de nuevo")

    def _guardar(self, ruta, respuesta):
        if respuesta.status_code in (403, 404):   # revocado a propósito: no se sigue usando el valor viejo
            with self._lock:
                self._cache.pop(ruta, None)
            self._contesto()
            raise SecretUnavailable(f"Vault respondió {respuesta.status_code} para '{ruta}'", revocado=True)
        if respuesta.status_code != 200:
            raise SecretUnavailable(f"Vault respondió {respuesta.status_code} para '{ruta}'")
        datos = respuesta.json()["data"]["data"]
        with self._lock:
            self._cache[ruta] = (datos, time.monotonic())
        self._contesto()
        return datos

    def _fallo(self, ruta, error):
        """Vault no contestó bien: abre la pausa y usa la copia en caché; sin copia falla cerrado."""
        self._pausa_hasta = time.monotonic() + self.pausa
        self._caido = True
        item = self._cache.get(ruta)
        if item:
            log.warning("Vault no disponible para '%s' (%s); se usa el valor en caché", ruta, type(error).__name__)
            return item[0]
        raise SecretUnavailable(f"No se pudo leer '{ruta}' desde Vault") from error

    def _durante_la_pausa(self, ruta):
        """No se consulta a Vault: caché si la hay, y si no, falla cerrado al instante (sin esperar ningún plazo)."""
        item = self._cache.get(ruta)
        if item:
            log.debug("Vault en pausa; se usa el valor en caché de '%s'", ruta)
            return item[0]
        raise SecretUnavailable(f"Vault no respondió hace poco y no hay copia de '{ruta}'")

    # ----- API síncrona (auth-service y backend) -------------------------------
    def get(self, ruta):
        datos = self._vigente(ruta)
        if datos is not None:
            return datos
        if self._en_pausa():
            return self._durante_la_pausa(ruta)
        try:
            r = httpx.get(self._url(ruta), headers={"X-Vault-Token": self._token}, timeout=self.timeout)
            return self._guardar(ruta, r)
        except SecretUnavailable as e:
            if e.revocado:
                raise
            return self._fallo(ruta, e)
        except (httpx.HTTPError, KeyError, ValueError) as e:
            return self._fallo(ruta, e)

    # ----- API asíncrona (gateway) ---------------------------------------------
    async def aget(self, ruta):
        datos = self._vigente(ruta)
        if datos is not None:
            return datos
        if self._en_pausa():
            return self._durante_la_pausa(ruta)
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as c:
                r = await c.get(self._url(ruta), headers={"X-Vault-Token": self._token})
            return self._guardar(ruta, r)
        except SecretUnavailable as e:
            if e.revocado:
                raise
            return self._fallo(ruta, e)
        except (httpx.HTTPError, KeyError, ValueError) as e:
            return self._fallo(ruta, e)

    def valor(self, ruta, campo="value"):
        return self.get(ruta)[campo]

    async def avalor(self, ruta, campo="value"):
        return (await self.aget(ruta))[campo]

    # ----- espera al arrancar (Vault puede tardar unos segundos en estar listo) -
    # Al arrancar no hay caché que proteger: cada intento consulta a Vault de verdad (se ignora la pausa).
    def esperar(self, ruta, intentos=None, pausa=1.0):
        intentos = int(intentos if intentos is not None else os.environ.get("VAULT_STARTUP_RETRIES", "30"))
        for n in range(1, intentos + 1):
            self._pausa_hasta = 0.0
            try:
                self.get(ruta)
                return
            except SecretUnavailable:
                log.warning("Esperando a Vault (intento %s/%s)", n, intentos)
                time.sleep(pausa)
        raise SecretUnavailable(f"Vault no entregó '{ruta}' tras {intentos} intentos")

    async def aesperar(self, ruta, intentos=None, pausa=1.0):
        import asyncio
        intentos = int(intentos if intentos is not None else os.environ.get("VAULT_STARTUP_RETRIES", "30"))
        for n in range(1, intentos + 1):
            self._pausa_hasta = 0.0
            try:
                await self.aget(ruta)
                return
            except SecretUnavailable:
                log.warning("Esperando a Vault (intento %s/%s)", n, intentos)
                await asyncio.sleep(pausa)
        raise SecretUnavailable(f"Vault no entregó '{ruta}' tras {intentos} intentos")
