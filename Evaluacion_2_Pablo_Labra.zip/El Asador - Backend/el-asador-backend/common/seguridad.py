"""Seguridad entre servicios: ¿quién me llama? y ¿en nombre de quién?

Cada servicio privado verifica DOS cosas en cada llamada interna:
  1. Identidad de servicio: X-Service-Name + X-Service-Secret. El secreto es distinto por cada par
     llamador->destino (Vault: asador/svc/<llamador>-to-<destino>), así que un servicio comprometido
     no puede hacerse pasar por otro ni llamar rutas que no le corresponden.
  2. Contexto de usuario (solo si el llamador es de confianza): X-Authenticated-*. Estas cabeceras
     las construye el API Gateway desde la sesión verificada; el navegador nunca las controla.

Después de esto cada servicio aplica SU autorización (roles y propiedad del recurso).
"""
import hmac
import logging
import re
from dataclasses import dataclass

from fastapi import Request

from .errores import ErrorNegocio
from .vault_secrets import SecretUnavailable

log = logging.getLogger("seguridad")

ROLES_PERSONAL = ("administrador", "dueno", "despacho")
ROLES = ROLES_PERSONAL + ("cliente",)
# Servicios a los que se les acepta contexto de usuario (propagan una identidad ya verificada).
IDENTIDAD_CONFIABLE = frozenset({"api-gateway", "graphql-gateway", "orders"})
NOMBRE_RE = re.compile(r"^[a-z][a-z-]{2,23}$")
ID_RE = re.compile(r"^[A-Za-z0-9_.@+-]{1,120}$")


@dataclass(frozen=True)
class Identidad:
    user_id: str
    username: str
    roles: tuple
    client_id: str | None = None

    def tiene(self, *roles):
        return any(r in self.roles for r in roles)

    @property
    def es_personal(self):
        return self.tiene(*ROLES_PERSONAL)


@dataclass
class Llamada:
    servicio: str
    request_id: str
    identidad: Identidad | None


def cabeceras_identidad(i: Identidad):
    h = {"X-Authenticated-User": i.user_id, "X-Authenticated-Username": i.username,
         "X-Authenticated-Roles": ",".join(i.roles)}
    if i.client_id:
        h["X-Authenticated-Client"] = i.client_id
    return h


def leer_identidad(headers):
    uid = headers.get("x-authenticated-user", "")
    if not uid or not ID_RE.fullmatch(uid):
        return None
    roles = tuple(r for r in headers.get("x-authenticated-roles", "").split(",") if r in ROLES)
    if not roles:
        return None
    cliente = headers.get("x-authenticated-client") or None
    if cliente and not ID_RE.fullmatch(cliente):
        return None
    return Identidad(uid, headers.get("x-authenticated-username", "")[:120], roles, cliente)


class Guardia:
    def __init__(self, yo, vault):
        self.yo, self.vault = yo, vault
        self.llamadores = set()   # todos los servicios que alguna ruta de este servicio acepta

    async def precalentar(self):
        """Al arrancar lee de Vault el secreto de cada llamador aceptado. Si falta alguno el servicio no arranca (falla cerrado) y,
        si Vault cae más tarde, sigue atendiendo con las copias que ya tiene en memoria."""
        for c in sorted(self.llamadores):
            await self.vault.aesperar(f"asador/svc/{c}-to-{self.yo}")

    def dep(self, llamadores, identidad="ninguna", roles=()):
        """Dependencia de FastAPI.

        llamadores: servicios que pueden invocar ESTA ruta.
        identidad : "ninguna" (llamada de sistema), "opcional" o "requerida" (usuario verificado).
        roles     : si se indican, la identidad debe tener alguno (segunda capa de autorización).
        """
        permitidos = frozenset(llamadores)
        self.llamadores |= permitidos

        async def verificar(request: Request) -> Llamada:
            nombre = request.headers.get("x-service-name", "")
            presentado = request.headers.get("x-service-secret", "")
            if not NOMBRE_RE.fullmatch(nombre) or nombre not in permitidos:
                log.warning("llamador no permitido", extra={"ctx": {"request_id": request.state.request_id, "ruta": request.url.path}})
                raise ErrorNegocio(403, "LLAMADOR_NO_PERMITIDO", "Llamada no autorizada")
            try:
                esperado = await self.vault.avalor(f"asador/svc/{nombre}-to-{self.yo}")
            except SecretUnavailable as e:
                if e.revocado:   # el secreto del par fue revocado en Vault: esa credencial ya no vale
                    log.warning("secreto de servicio revocado", extra={"ctx": {"request_id": request.state.request_id, "llamador": nombre}})
                    raise ErrorNegocio(403, "SECRETO_INVALIDO", "Llamada no autorizada")
                raise ErrorNegocio(503, "SECRETOS_NO_DISPONIBLES", "Servicio temporalmente no disponible")
            if not hmac.compare_digest(presentado.encode(), esperado.encode()):
                log.warning("secreto de servicio inválido", extra={"ctx": {"request_id": request.state.request_id, "llamador": nombre}})
                raise ErrorNegocio(403, "SECRETO_INVALIDO", "Llamada no autorizada")

            ident = leer_identidad(request.headers) if (identidad != "ninguna" and nombre in IDENTIDAD_CONFIABLE) else None
            if identidad == "requerida" and ident is None:
                raise ErrorNegocio(401, "NO_AUTENTICADO", "Sesión requerida")
            if roles and not (ident and ident.tiene(*roles)):
                raise ErrorNegocio(403, "ROL_NO_AUTORIZADO", "No tiene permisos para esta operación")
            request.state.user_id = ident.user_id if ident else f"svc:{nombre}"
            return Llamada(nombre, request.state.request_id, ident)

        return verificar
