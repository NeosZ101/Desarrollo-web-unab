"""Logs en una línea JSON, con identificador de correlación y sin datos sensibles.

Regla del proyecto: en el contexto del log solo van identificadores y métricas
(request_id, user_id, ruta, status, ms). Nunca cuerpos, cabeceras, claves, tokens ni datos
personales. Como red de seguridad, cualquier clave del contexto que parezca un secreto
se reemplaza por "***".

Dos protecciones más, porque las librerías también escriben logs:
  * el texto de una EXCEPCIÓN de una librería no se imprime (podría traer una URL de base de datos o un dato personal): solo su tipo;
  * toda línea lleva el request_id de la solicitud en curso, también las que escribe una librería.
"""
import contextvars
import json
import logging
import sys
import time

RID = contextvars.ContextVar("request_id", default=None)   # lo fija el middleware de cada servicio al empezar cada solicitud
_AJENOS = ("strawberry", "graphql", "uvicorn", "asyncio", "pymongo", "motor", "httpx", "httpcore", "fastapi", "starlette", "anyio", "pydantic", "multipart")
_SENSIBLES = ("password", "clave", "token", "secret", "secreto", "authorization", "cookie", "run", "correo", "email")


def _limpiar(ctx):
    limpio = {}
    for k, v in ctx.items():
        limpio[k] = "***" if any(s in k.lower() for s in _SENSIBLES) else v
    return limpio


class JsonFormatter(logging.Formatter):
    def format(self, record):
        ajeno = record.name.split(".")[0] in _AJENOS
        # De una librería solo se escribe la plantilla del mensaje (sin los valores que se le interpolan) o, si el «mensaje» es una
        # excepción, el nombre de su clase. Los mensajes propios del proyecto ya se escriben sin datos sensibles.
        msg = (record.msg if isinstance(record.msg, str) else type(record.msg).__name__) if ajeno else record.getMessage()
        base = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "nivel": record.levelname,
            "logger": record.name,
            "msg": msg,
        }
        if record.exc_info and record.exc_info[1] is not None:
            base["error"] = type(record.exc_info[1]).__name__     # el tipo ayuda a diagnosticar; el texto no se escribe
        rid = RID.get()
        if rid:
            base["request_id"] = rid
        extra = getattr(record, "ctx", None)
        if extra:
            base.update(_limpiar(extra))
        return json.dumps(base, ensure_ascii=False)


def configurar(servicio):
    h = logging.StreamHandler(sys.stdout)
    h.setFormatter(JsonFormatter())
    raiz = logging.getLogger()
    raiz.handlers[:] = [h]
    raiz.setLevel(logging.INFO)
    logging.getLogger("httpx").setLevel(logging.WARNING)  # httpx imprime URLs; no hace falta
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").disabled = True   # cada servicio registra su propia línea
    return logging.getLogger(servicio)
