"""Errores controlados con el mismo formato en todos los servicios.

Respuesta de error:  {"detail": "<mensaje para el usuario>", "codigo": "<CODIGO>", "request_id": "..."}
Nunca incluye trazas, nombres de colecciones, rutas de archivos ni el valor que el usuario envió.
"""
import logging

from fastapi import Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

log = logging.getLogger("errores")

_TEXTOS_HTTP = {
    400: ("SOLICITUD_INVALIDA", "Solicitud inválida"),
    401: ("NO_AUTENTICADO", "Sesión requerida"),
    403: ("PROHIBIDO", "No tiene permisos para esta operación"),
    404: ("NO_ENCONTRADO", "Recurso no encontrado"),
    405: ("METODO_NO_PERMITIDO", "Método no permitido"),
    413: ("CUERPO_GRANDE", "Cuerpo demasiado grande"),
    415: ("TIPO_NO_SOPORTADO", "Tipo de contenido no soportado"),
    429: ("DEMASIADAS_SOLICITUDES", "Demasiadas solicitudes"),
}


class ErrorNegocio(Exception):
    """Error esperado: la regla de negocio o la seguridad rechazan la operación."""

    def __init__(self, status, codigo, mensaje, extra=None, headers=None):
        super().__init__(mensaje)
        self.status, self.codigo, self.mensaje = status, codigo, mensaje
        self.extra, self.headers = extra or {}, headers or {}


def cuerpo_error(request, codigo, mensaje, extra=None):
    d = {"detail": mensaje, "codigo": codigo, "request_id": getattr(request.state, "request_id", None)}
    if extra:
        d.update(extra)
    return d


# Mensajes en español para los errores de validación más comunes (por el tipo de error de pydantic).
# Los errores de reglas propias (value_error) ya traen su texto en español, sin el prefijo técnico.
_TEXTOS_VALIDACION = {
    "missing": "Falta este dato.",
    "string_too_short": "Es demasiado corto.",
    "string_too_long": "Es demasiado largo.",
    "string_pattern_mismatch": "El formato no es válido.",
    "extra_forbidden": "Este dato no se acepta.",
    "greater_than_equal": "El valor está fuera del rango permitido.",
    "less_than_equal": "El valor está fuera del rango permitido.",
    "too_short": "Faltan elementos.",
    "too_long": "Hay demasiados elementos.",
    "literal_error": "La opción elegida no es válida.",
    "int_parsing": "Debe ser un número entero.",
    "int_type": "Debe ser un número entero.",
    "bool_parsing": "Debe ser verdadero o falso.",
    "bool_type": "Debe ser verdadero o falso.",
    "string_type": "Debe ser un texto.",
    "model_attributes_type": "El formato del contenido no es válido.",
    "dict_type": "El formato del contenido no es válido.",
    "list_type": "Debe ser una lista.",
}


def _texto_validacion(err):
    if err.get("type") == "value_error":
        return str(err.get("msg", "")).removeprefix("Value error, ")[:160] or "El dato no es válido."
    return _TEXTOS_VALIDACION.get(err.get("type", ""), "El dato no es válido.")


def instalar_errores(app):
    @app.exception_handler(ErrorNegocio)
    async def _negocio(request: Request, e: ErrorNegocio):
        return JSONResponse(cuerpo_error(request, e.codigo, e.mensaje, e.extra), status_code=e.status, headers=e.headers)

    @app.exception_handler(RequestValidationError)
    async def _validacion(request: Request, e: RequestValidationError):
        campos = []
        for err in e.errors()[:20]:
            ruta = [str(p) for p in err.get("loc", ())[1:]]
            campos.append({"campo": ".".join(ruta) or "cuerpo", "mensaje": _texto_validacion(err)})
        # Filtros/parámetros de ruta inválidos -> 400; cuerpo inválido -> 422.
        solo_parametros = all(err.get("loc", ("",))[0] in ("query", "path") for err in e.errors())
        if solo_parametros:
            return JSONResponse(cuerpo_error(request, "FILTRO_INVALIDO", "Hay parámetros inválidos en la solicitud", {"campos": campos}),
                                status_code=400)
        return JSONResponse(cuerpo_error(request, "VALIDACION", "Hay datos inválidos en la solicitud", {"campos": campos}),
                            status_code=422)

    @app.exception_handler(StarletteHTTPException)
    async def _http(request: Request, e: StarletteHTTPException):
        codigo, texto = _TEXTOS_HTTP.get(e.status_code, ("ERROR", "Error"))
        return JSONResponse(cuerpo_error(request, codigo, texto), status_code=e.status_code)

    @app.exception_handler(Exception)
    async def _inesperado(request: Request, e: Exception):
        log.error("error inesperado", extra={"ctx": {"request_id": getattr(request.state, "request_id", None),
                                                    "tipo": type(e).__name__, "ruta": request.url.path}})
        return JSONResponse(cuerpo_error(request, "ERROR_INTERNO", "Error interno"), status_code=500)
