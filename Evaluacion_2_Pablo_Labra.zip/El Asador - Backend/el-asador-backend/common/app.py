"""Fábrica común de aplicaciones FastAPI para los servicios privados.

Todas incluyen: documentación desactivada, errores controlados, identificador de correlación,
una línea de log por solicitud (sin cuerpos ni datos personales) y /health + /ready.
"""
import re
import time
import uuid

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response
from starlette.requests import ClientDisconnect

from .errores import instalar_errores
from .logs import RID, configurar

RID_RE = re.compile(r"^[A-Za-z0-9-]{8,64}$")


def crear_app(nombre, lifespan=None):
    log = configurar(nombre)
    app = FastAPI(title=f"{nombre} (privado)", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
    app.state.chequeos = []  # funciones async que devuelven True si la dependencia responde
    instalar_errores(app)

    @app.middleware("http")
    async def contexto(request: Request, call_next):
        entrante = request.headers.get("x-request-id", "")
        request.state.request_id = entrante if RID_RE.fullmatch(entrante) else uuid.uuid4().hex[:16]
        request.state.user_id = None
        t0 = time.perf_counter()
        marca = RID.set(request.state.request_id)   # desde aquí TODA línea de log de esta solicitud lleva su identificador
        try:
            respuesta = await call_next(request)
        except ClientDisconnect:
            # Quien llamó (p. ej. el gateway, que cortó por su tiempo máximo) ya se fue: no hay a quién responder ni un fallo propio que
            # reportar. Se deja UNA línea JSON de aviso y no una traza suelta de uvicorn (los logs deben ser JSON, sin trazas con datos).
            log.warning("cliente desconectado", extra={"ctx": {
                "request_id": request.state.request_id, "metodo": request.method, "ruta": request.url.path,
                "ms": round((time.perf_counter() - t0) * 1000, 1)}})
            return Response(status_code=499)
        finally:
            RID.reset(marca)
        respuesta.headers["X-Request-ID"] = request.state.request_id
        respuesta.headers.setdefault("Cache-Control", "no-store")
        if request.url.path not in ("/health", "/ready"):
            log.info("solicitud", extra={"ctx": {
                "request_id": request.state.request_id, "metodo": request.method, "ruta": request.url.path,
                "status": respuesta.status_code, "ms": round((time.perf_counter() - t0) * 1000, 1),
                "user_id": request.state.user_id,
            }})
        return respuesta

    @app.get("/health")
    async def health():
        return {"status": "OK", "service": nombre}

    @app.get("/ready")
    async def ready():
        for chequeo in app.state.chequeos:
            try:
                if not await chequeo():
                    return JSONResponse({"status": "NO_LISTO", "service": nombre}, status_code=503)
            except Exception:  # noqa: BLE001 - cualquier fallo de dependencia significa "no listo"
                return JSONResponse({"status": "NO_LISTO", "service": nombre}, status_code=503)
        return {"status": "LISTO", "service": nombre}

    return app, log
