"""Cliente HTTP para llamadas entre servicios.

Cada llamada: secreto propio del par (leído de Vault), identidad de usuario ya verificada (si
corresponde), identificador de correlación, plazo máximo y un cortacircuitos simple para no
seguir golpeando a un servicio caído.
"""
import logging
import time
import uuid

import httpx

from .seguridad import cabeceras_identidad
from .vault_secrets import SecretUnavailable

log = logging.getLogger("interno")
FALLOS_PARA_ABRIR = 5


class ServicioNoDisponible(Exception):
    def __init__(self, destino, motivo, respuesta=None):
        super().__init__(f"{destino}: {motivo}")
        self.destino, self.motivo = destino, motivo
        self.respuesta = respuesta   # solo en «dependencia»: el 503 que el destino contestó, para que el gateway lo traduzca


class ClienteInterno:
    def __init__(self, yo, vault, urls, timeout=3.0, pausa_circuito=5.0):
        self.yo, self.vault, self.urls = yo, vault, urls
        self.timeout, self.pausa = timeout, pausa_circuito
        self.http = httpx.AsyncClient(timeout=httpx.Timeout(timeout, connect=1.5), limits=httpx.Limits(max_connections=100))
        self._fallos = {}   # destino -> fallos consecutivos
        self._abierto = {}  # destino -> instante hasta el que el circuito está abierto

    async def cerrar(self):
        await self.http.aclose()

    async def precalentar(self):
        """Al arrancar lee de Vault el secreto de cada destino. Si falta alguno el servicio no arranca (falla cerrado) y,
        si Vault cae más tarde, sigue llamando con las copias que ya tiene en memoria."""
        for destino in sorted(self.urls):
            await self.vault.aesperar(f"asador/svc/{self.yo}-to-{destino}")

    def _registrar(self, destino, ok):
        if ok:
            self._fallos[destino] = 0
            return
        self._fallos[destino] = self._fallos.get(destino, 0) + 1
        if self._fallos[destino] >= FALLOS_PARA_ABRIR:
            self._abierto[destino] = time.monotonic() + self.pausa
            self._fallos[destino] = FALLOS_PARA_ABRIR - 1  # tras la pausa se permite UNA prueba

    async def llamar(self, destino, metodo, ruta, *, request_id=None, identidad=None, json=None, params=None,
                     timeout=None, extra=None, contenido=None):
        """`json` envía un objeto; `contenido` envía bytes tal cual (el aviso firmado de un proveedor no se puede reserializar)."""
        if self._abierto.get(destino, 0) > time.monotonic():
            raise ServicioNoDisponible(destino, "circuito_abierto")
        try:
            secreto = await self.vault.avalor(f"asador/svc/{self.yo}-to-{destino}")
        except SecretUnavailable:
            raise ServicioNoDisponible("vault", "sin_secreto")
        h = {"X-Service-Name": self.yo, "X-Service-Secret": secreto, "Accept": "application/json",
             "X-Request-ID": request_id or uuid.uuid4().hex[:16]}
        if identidad is not None:
            h.update(cabeceras_identidad(identidad))
        if extra:
            h.update(extra)
        try:
            r = await self.http.request(metodo, self.urls[destino].rstrip("/") + ruta, json=json, content=contenido, params=params,
                                        headers=h, timeout=timeout or self.timeout)
        except httpx.TimeoutException:
            self._registrar(destino, False)
            raise ServicioNoDisponible(destino, "timeout")
        except httpx.HTTPError:
            self._registrar(destino, False)
            raise ServicioNoDisponible(destino, "conexion")
        if r.status_code == 503 and isinstance(_cuerpo(r).get("codigo"), str):
            # El destino está vivo y contestó rápido con NUESTRO formato de error: lo que falla es una dependencia SUYA. No abre nuestro
            # circuito (si no, la caída de inventario dejaría sin pedidos a todo el sitio) pero quien nos llamó igual recibe un 503.
            self._registrar(destino, True)
            raise ServicioNoDisponible(destino, "dependencia", respuesta=r)
        if r.status_code >= 500:
            self._registrar(destino, False)
            raise ServicioNoDisponible(destino, f"http_{r.status_code}")
        self._registrar(destino, True)
        if r.status_code == 403 and _cuerpo(r).get("codigo") in ("LLAMADOR_NO_PERMITIDO", "SECRETO_INVALIDO"):
            log.error("el destino rechazó nuestra credencial de servicio", extra={"ctx": {"destino": destino, "llamador": self.yo}})
            raise ServicioNoDisponible(destino, "credencial_rechazada")
        return r


def _cuerpo(r):
    try:
        d = r.json()
        return d if isinstance(d, dict) else {}
    except ValueError:
        return {}


def cuerpo(r):
    return _cuerpo(r)
