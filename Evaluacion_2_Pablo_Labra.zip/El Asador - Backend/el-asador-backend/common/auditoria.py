"""Registro de auditoría de operaciones sensibles (quién, qué, cuándo).

El detalle lleva solo identificadores y valores no personales. Un fallo al auditar se registra en
el log, pero no cambia el resultado de la operación ya realizada.
"""
import logging
import uuid

from .tiempo import iso

log = logging.getLogger("auditoria")


async def registrar(db, llamada, accion, recurso, detalle=None):
    ident = llamada.identidad if llamada else None
    try:
        await db["auditoria"].insert_one({
            "_id": uuid.uuid4().hex, "ts": iso(), "request_id": getattr(llamada, "request_id", None),
            "actor": ident.user_id if ident else f"svc:{getattr(llamada, 'servicio', 'sistema')}",
            "roles": list(ident.roles) if ident else [], "accion": accion, "recurso": recurso, "detalle": detalle or {},
        })
    except Exception as e:  # noqa: BLE001
        log.error("no se pudo auditar", extra={"ctx": {"accion": accion, "tipo": type(e).__name__}})
