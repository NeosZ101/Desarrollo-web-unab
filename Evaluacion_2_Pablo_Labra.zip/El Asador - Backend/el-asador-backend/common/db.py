"""Conexión a MongoDB.

La credencial de base de datos pertenece al servicio que la usa: cada servicio lee SU usuario
desde Vault (asador/db/<servicio>) y solo tiene permisos sobre SU base (asador_<servicio>).
El navegador y el gateway nunca la ven.
"""
import asyncio
import logging
import os
from urllib.parse import quote_plus

import motor.motor_asyncio as motor

log = logging.getLogger("db")


async def abrir_db(servicio, vault, intentos=None, pausa=1.0):
    cred = await vault.aget(f"asador/db/{servicio}")
    nombre = f"asador_{servicio}"
    host, puerto = os.environ.get("MONGO_HOST", "mongo"), os.environ.get("MONGO_PORT", "27017")
    uri = f"mongodb://{quote_plus(cred['user'])}:{quote_plus(cred['password'])}@{host}:{puerto}/{nombre}?authSource={nombre}"
    cliente = motor.AsyncIOMotorClient(uri, serverSelectionTimeoutMS=int(os.environ.get("MONGO_TIMEOUT_MS", "3000")), appname=servicio)
    db = cliente[nombre]
    intentos = int(intentos if intentos is not None else os.environ.get("MONGO_STARTUP_RETRIES", "30"))
    for n in range(1, intentos + 1):
        try:
            await db.command("ping")
            return cliente, db
        except Exception as e:  # noqa: BLE001
            log.warning("Esperando a MongoDB (intento %s/%s): %s", n, intentos, type(e).__name__)
            await asyncio.sleep(pausa)
    raise RuntimeError(f"MongoDB no respondió tras {intentos} intentos")
