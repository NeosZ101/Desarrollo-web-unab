"""Reglas puras del Auth Service (fáciles de probar sin red ni base de datos)."""
import re

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9.-]{1,190}\.[A-Za-z]{2,24}$")
# Lista mínima de claves típicas; en producción se contrastaría con una lista pública de claves filtradas.
CLAVES_COMUNES = {
    "12345678", "123456789", "1234567890", "password", "password1", "contrasena", "contraseña",
    "qwertyui", "qwerty123", "11111111", "00000000", "abcd1234", "iloveyou", "admin1234",
}
ROLES_PERSONAL = ("administrador", "dueno", "despacho")


def normalizar_username(valor):
    v = (valor or "").strip().lower()
    if not EMAIL_RE.fullmatch(v):
        raise ValueError("El usuario debe ser un correo electrónico válido")
    return v


def validar_clave(clave, username=""):
    """NIST SP 800-63B: largo mínimo y rechazo de claves obvias; sin reglas de composición artificiales."""
    if len(clave) < 8:
        raise ValueError("La contraseña debe tener al menos 8 caracteres")
    if len(clave) > 128:
        raise ValueError("La contraseña no puede superar los 128 caracteres")
    bajo = clave.lower()
    if bajo in CLAVES_COMUNES:
        raise ValueError("La contraseña es demasiado común; elige otra")
    local = username.split("@")[0].lower() if username else ""
    if username and (bajo == username.lower() or (local and bajo == local)):
        raise ValueError("La contraseña no puede ser igual al usuario")
    return clave
