"""Auth Service de El Asador (privado).

Responsabilidad: ser la autoridad de CREDENCIALES y SESIONES.
  * Autenticar (¿quién eres?) con argon2id y emitir un token opaco.
  * Introspección: token -> identidad vigente (rol y estado se leen siempre de la base).
  * Revocar sesiones (logout, cambio de clave, desactivación del usuario).
  * Mantenedor de usuarios del personal (CU2) y credenciales de clientes (solo para `clients`).
No decide permisos de negocio ni guarda datos personales del cliente (eso es de `clients`).
"""
import asyncio
import hashlib
import json
import os
import secrets
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError
from fastapi import Depends, Response
from pydantic import BaseModel, ConfigDict, Field, field_validator
from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError

from common import auditoria
from common.app import crear_app
from common.db import abrir_db
from common.errores import ErrorNegocio
from common.migraciones import migrar
from common.seguridad import Guardia
from common.tiempo import iso
from common.vault_secrets import VaultSecrets

from .reglas import ROLES_PERSONAL, normalizar_username, validar_clave

TTL_SESION = int(os.environ.get("SESSION_TTL_SECONDS", "7200"))
MAX_FALLIDOS = int(os.environ.get("MAX_LOGIN_FALLIDOS", "5"))
BLOQUEO_SEG = int(os.environ.get("LOGIN_BLOQUEO_SEGUNDOS", "900"))
SEMILLA = os.environ.get("SEED_DEMO_DATA", "false").lower() == "true"

ph = PasswordHasher()  # argon2id con sal aleatoria por contraseña
# Se verifica contra un hash falso cuando el usuario no existe: el tiempo de respuesta no revela qué cuentas existen.
HASH_FALSO = ph.hash(secrets.token_urlsafe(16))

vault = VaultSecrets()
guardia = Guardia("auth", vault)
GW = ("api-gateway",)
ADMIN = Depends(guardia.dep(GW, identidad="requerida", roles=("administrador",)))
db = None


async def _indices(d):
    await d.usuarios.create_index("username", unique=True)
    await d.usuarios.create_index("clientId", sparse=True)
    await d.sesiones.create_index("userId")
    await d.sesiones.create_index("expira")


MIGRACIONES = [(1, "índices de usuarios y sesiones", _indices)]


async def sembrar(d):
    ruta = Path(__file__).parent / "seed" / "usuarios.json"
    n = 0
    for u in json.loads(ruta.read_text(encoding="utf-8")):
        if not await d.usuarios.find_one({"_id": u["id"]}):
            await d.usuarios.insert_one({
                "_id": u["id"], "username": u["username"], "nombre": u["nombre"], "rol": u["rol"],
                "passwordHash": u["passwordHash"], "activo": True, "clientId": u.get("clientId"),
                "intentosFallidos": 0, "bloqueadoHasta": 0, "creadoEn": iso(), "actualizadoEn": iso()})
            n += 1
    return n


@asynccontextmanager
async def lifespan(app):
    global db
    await vault.aesperar("asador/db/auth")
    await guardia.precalentar()
    cliente, db = await abrir_db("auth", vault)
    await migrar(db, MIGRACIONES)
    if SEMILLA:
        log.info("datos de prueba cargados", extra={"ctx": {"usuarios_nuevos": await sembrar(db)}})
    app.state.chequeos.append(lambda: db.command("ping"))
    log.info("Auth Service listo")
    yield
    cliente.close()


app, log = crear_app("auth", lifespan)


# ----------------------------- modelos -----------------------------------------
class LoginIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    username: str = Field(min_length=3, max_length=120)
    password: str = Field(min_length=1, max_length=128)


class TokenIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    token: str = Field(min_length=10, max_length=200)


class UsuarioNuevo(BaseModel):
    model_config = ConfigDict(extra="forbid")
    username: str
    nombre: str = Field(min_length=2, max_length=80)
    rol: Literal["administrador", "dueno", "despacho"]
    password: str

    @field_validator("username")
    @classmethod
    def _u(cls, v):
        return normalizar_username(v)


class UsuarioReemplazo(BaseModel):
    """PUT: representación completa editable del usuario (el correo no cambia)."""
    model_config = ConfigDict(extra="forbid")
    nombre: str = Field(min_length=2, max_length=80)
    rol: Literal["administrador", "dueno", "despacho"]
    activo: bool
    password: str | None = None


class CredencialCliente(BaseModel):
    model_config = ConfigDict(extra="forbid")
    username: str
    password: str
    nombre: str = Field(min_length=2, max_length=120)
    clientId: str = Field(min_length=3, max_length=40)

    @field_validator("username")
    @classmethod
    def _u(cls, v):
        return normalizar_username(v)


class EstadoIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    activo: bool


def _clave(token):
    return hashlib.sha256(token.encode()).hexdigest()


def _publico(u):
    return {"id": u["_id"], "username": u["username"], "nombre": u["nombre"], "rol": u["rol"], "roles": [u["rol"]],
            "activo": u["activo"], "creadoEn": u["creadoEn"]}


def _politica(clave, username):
    try:
        validar_clave(clave, username)
    except ValueError as e:
        raise ErrorNegocio(422, "CLAVE_DEBIL", str(e))


async def _hash(clave):
    return await asyncio.get_running_loop().run_in_executor(None, ph.hash, clave)


async def _verificar(hash_, clave):
    try:
        return await asyncio.get_running_loop().run_in_executor(None, ph.verify, hash_, clave)
    except (VerificationError, InvalidHashError):
        return False


async def _revocar(user_id):
    r = await db.sesiones.delete_many({"userId": user_id})
    return r.deleted_count


# ----------------------------- sesiones ----------------------------------------
@app.post("/login")
async def login(datos: LoginIn, ll=Depends(guardia.dep(GW))):
    username = datos.username.strip().lower()
    u = await db.usuarios.find_one({"username": username})
    ahora = time.time()
    bloqueado = bool(u and u.get("bloqueadoHasta", 0) > ahora)
    coincide = await _verificar(u["passwordHash"] if u else HASH_FALSO, datos.password)
    if not (coincide and u and u["activo"] and not bloqueado):
        if u and not bloqueado:
            n = (await db.usuarios.find_one_and_update(
                {"_id": u["_id"]}, {"$inc": {"intentosFallidos": 1}}, return_document=ReturnDocument.AFTER))["intentosFallidos"]
            if n >= MAX_FALLIDOS:
                await db.usuarios.update_one({"_id": u["_id"]}, {"$set": {"bloqueadoHasta": ahora + BLOQUEO_SEG, "intentosFallidos": 0}})
                log.warning("cuenta bloqueada por intentos fallidos", extra={"ctx": {"user_id": u["_id"]}})
        log.info("login rechazado")  # sin usuario ni clave en el log
        raise ErrorNegocio(401, "CREDENCIALES_INVALIDAS", "Credenciales inválidas")

    if ph.check_needs_rehash(u["passwordHash"]):  # parámetros más fuertes que los guardados -> se actualiza el hash
        await db.usuarios.update_one({"_id": u["_id"]}, {"$set": {"passwordHash": await _hash(datos.password)}})
    await db.usuarios.update_one({"_id": u["_id"]}, {"$set": {"intentosFallidos": 0, "bloqueadoHasta": 0}})
    token = secrets.token_urlsafe(32)
    await db.sesiones.delete_many({"expira": {"$lte": ahora}})
    await db.sesiones.insert_one({"_id": _clave(token), "userId": u["_id"], "creada": iso(), "expira": ahora + TTL_SESION})
    log.info("login correcto", extra={"ctx": {"user_id": u["_id"]}})
    return {"access_token": token, "token_type": "bearer", "expires_in": TTL_SESION,
            "usuario": {"user_id": u["_id"], "username": u["username"], "nombre": u["nombre"], "roles": [u["rol"]],
                        "client_id": u.get("clientId")}}


@app.post("/introspect")
async def introspect(datos: TokenIn, ll=Depends(guardia.dep(GW))):
    ahora = time.time()
    s = await db.sesiones.find_one({"_id": _clave(datos.token)})
    if not s:
        return {"active": False}
    if s["expira"] <= ahora:
        await db.sesiones.delete_one({"_id": s["_id"]})
        return {"active": False}
    u = await db.usuarios.find_one({"_id": s["userId"]})
    if not u or not u["activo"]:
        return {"active": False}
    return {"active": True, "user_id": u["_id"], "username": u["username"], "nombre": u["nombre"], "roles": [u["rol"]],
            "client_id": u.get("clientId"), "expires_in": int(s["expira"] - ahora)}


@app.post("/logout")
async def logout(datos: TokenIn, ll=Depends(guardia.dep(GW))):
    r = await db.sesiones.delete_one({"_id": _clave(datos.token)})
    return {"revoked": r.deleted_count == 1}


# ----------------------------- mantenedor de usuarios del personal (CU2) --------
@app.get("/users")
async def listar_usuarios(limit: int = 50, offset: int = 0, ll=ADMIN):
    limit, offset = max(1, min(limit, 100)), max(0, offset)
    filtro = {"rol": {"$in": list(ROLES_PERSONAL)}}
    cur = db.usuarios.find(filtro).sort("username", 1).skip(offset).limit(limit)
    return {"total": await db.usuarios.count_documents(filtro), "items": [_publico(u) async for u in cur]}


@app.post("/users", status_code=201)
async def crear_usuario(datos: UsuarioNuevo, ll=ADMIN):
    _politica(datos.password, datos.username)
    doc = {"_id": "u-" + uuid.uuid4().hex[:12], "username": datos.username, "nombre": datos.nombre.strip(), "rol": datos.rol,
           "passwordHash": await _hash(datos.password), "activo": True, "clientId": None, "intentosFallidos": 0,
           "bloqueadoHasta": 0, "creadoEn": iso(), "actualizadoEn": iso()}
    try:
        await db.usuarios.insert_one(doc)
    except DuplicateKeyError:
        raise ErrorNegocio(409, "USUARIO_EXISTE", "Ya existe un usuario con ese correo")
    await auditoria.registrar(db, ll, "usuario.crear", f"usuario:{doc['_id']}", {"rol": datos.rol})
    return _publico(doc)


async def _personal_o_404(id):
    u = await db.usuarios.find_one({"_id": id, "rol": {"$in": list(ROLES_PERSONAL)}})
    if not u:
        raise ErrorNegocio(404, "USUARIO_NO_ENCONTRADO", "Usuario no encontrado")
    return u


async def _proteger_administradores(u, ll, nuevo_rol, nuevo_activo):
    """Evita dejar el sistema sin administrador o que el administrador se bloquee a sí mismo."""
    pierde = u["rol"] == "administrador" and u["activo"] and (nuevo_rol != "administrador" or not nuevo_activo)
    if not pierde:
        return
    if u["_id"] == ll.identidad.user_id:
        raise ErrorNegocio(409, "AUTOEDICION_NO_PERMITIDA", "No puedes quitarte tu propio acceso de administrador")
    otros = await db.usuarios.count_documents({"rol": "administrador", "activo": True, "_id": {"$ne": u["_id"]}})
    if otros == 0:
        raise ErrorNegocio(409, "ULTIMO_ADMINISTRADOR", "Debe quedar al menos un administrador activo")


@app.put("/users/{id}")
async def reemplazar_usuario(id: str, datos: UsuarioReemplazo, ll=ADMIN):
    u = await _personal_o_404(id)
    await _proteger_administradores(u, ll, datos.rol, datos.activo)
    cambios = {"nombre": datos.nombre.strip(), "rol": datos.rol, "activo": datos.activo, "actualizadoEn": iso()}
    if datos.password:
        _politica(datos.password, u["username"])
        cambios["passwordHash"] = await _hash(datos.password)
    await db.usuarios.update_one({"_id": id}, {"$set": cambios})
    if datos.password or not datos.activo or datos.rol != u["rol"]:
        await _revocar(id)  # la sesión abierta no sobrevive a un cambio de clave, rol o desactivación
    await auditoria.registrar(db, ll, "usuario.modificar", f"usuario:{id}", {"rol": datos.rol, "activo": datos.activo, "clave": bool(datos.password)})
    return _publico({**u, **cambios})


@app.delete("/users/{id}")
async def desactivar_usuario(id: str, ll=ADMIN):
    """DELETE = baja lógica: el usuario queda inactivo y sin sesiones, pero se conserva su rastro de auditoría."""
    u = await _personal_o_404(id)
    await _proteger_administradores(u, ll, u["rol"], False)
    await db.usuarios.update_one({"_id": id}, {"$set": {"activo": False, "actualizadoEn": iso()}})
    revocadas = await _revocar(id)
    await auditoria.registrar(db, ll, "usuario.desactivar", f"usuario:{id}", {"sesiones_revocadas": revocadas})
    return {"id": id, "activo": False}


# ----------------------------- credenciales de clientes (solo `clients`) --------
@app.post("/internal/credentials", status_code=201)
async def crear_credencial(datos: CredencialCliente, response: Response, ll=Depends(guardia.dep(("clients",)))):
    _politica(datos.password, datos.username)
    previo = await db.usuarios.find_one({"username": datos.username, "rol": "cliente", "clientId": datos.clientId})
    if previo and await _verificar(previo["passwordHash"], datos.password):
        # El mismo registro repetido (la respuesta anterior se perdió por un corte): devuelve la misma cuenta, no crea otra.
        response.status_code = 200
        return {"user_id": previo["_id"]}
    doc = {"_id": "u-" + uuid.uuid4().hex[:12], "username": datos.username, "nombre": datos.nombre.strip(), "rol": "cliente",
           "passwordHash": await _hash(datos.password), "activo": True, "clientId": datos.clientId, "intentosFallidos": 0,
           "bloqueadoHasta": 0, "creadoEn": iso(), "actualizadoEn": iso()}
    try:
        await db.usuarios.insert_one(doc)
    except DuplicateKeyError:
        raise ErrorNegocio(409, "USUARIO_EXISTE", "Ya existe una cuenta con ese correo")
    await auditoria.registrar(db, ll, "credencial.crear", f"usuario:{doc['_id']}", {"clientId": datos.clientId})
    return {"user_id": doc["_id"]}


@app.put("/internal/credentials/{user_id}/estado")
async def estado_credencial(user_id: str, datos: EstadoIn, ll=Depends(guardia.dep(("clients",)))):
    r = await db.usuarios.update_one({"_id": user_id, "rol": "cliente"}, {"$set": {"activo": datos.activo, "actualizadoEn": iso()}})
    if r.matched_count == 0:
        raise ErrorNegocio(404, "USUARIO_NO_ENCONTRADO", "Usuario no encontrado")
    if not datos.activo:
        await _revocar(user_id)
    await auditoria.registrar(db, ll, "credencial.estado", f"usuario:{user_id}", {"activo": datos.activo})
    return {"user_id": user_id, "activo": datos.activo}


@app.delete("/internal/credentials/{user_id}")
async def borrar_credencial(user_id: str, ll=Depends(guardia.dep(("clients",)))):
    """Compensación del registro: si no se pudo crear el perfil, se elimina la credencial recién creada."""
    r = await db.usuarios.delete_one({"_id": user_id, "rol": "cliente"})
    await _revocar(user_id)
    return {"eliminado": r.deleted_count == 1}
