#!/usr/bin/env python3
"""Prueba de humo: recorre el sistema ya levantado de punta a punta, como lo haría una persona (cliente y administrador).

  python scripts/smoke_test.py                              # contra docker compose (http://localhost:8000)
  python scripts/smoke_test.py --base http://127.0.0.1:8000 --proveedor http://127.0.0.1:8300   # contra scripts/demo_local.py

Comprueba salud, catálogo, seguridad básica (sin sesión, cabeceras, aislamiento entre clientes), registro, pedido con clave de
idempotencia, pago con el proveedor simulado (aviso firmado), boleta, GraphQL y cierre de sesión. Termina con código 0 solo si TODO pasó.
No usa nada que no sea público: las cuentas de demostración (admin, dueño, despacho) se prueban solo si existen.
Inicia sesión varias veces: con el límite por omisión (5 inicios de sesión por minuto) hay que esperar un minuto antes de repetirla.
"""
import argparse
import random
import sys
import time
import uuid

import httpx

REGION = "Región Metropolitana de Santiago"
resultados = []


def digito_verificador(n):
    suma, multiplicador = 0, 2
    for c in reversed(str(n)):
        suma += int(c) * multiplicador
        multiplicador = 2 if multiplicador == 7 else multiplicador + 1
    resto = 11 - suma % 11
    return "0" if resto == 11 else "K" if resto == 10 else str(resto)


def paso(nombre, condicion, detalle=""):
    resultados.append((nombre, bool(condicion)))
    print(f"  {'OK    ' if condicion else 'FALLÓ '} {nombre}" + (f"  [{detalle}]" if detalle and not condicion else ""), flush=True)
    return bool(condicion)


class Navegador:
    def __init__(self, base):
        self.base = base.rstrip("/")
        self.c = httpx.Client(base_url=self.base, timeout=20, headers={"Origin": self.base})

    def __getattr__(self, nombre):
        return getattr(self.c, nombre)


def esperar(condicion, segundos=40):
    limite = time.time() + segundos
    while time.time() < limite:
        try:
            if condicion():
                return True
        except httpx.HTTPError:
            pass
        time.sleep(0.5)
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://localhost:8000", help="dirección del sitio (API Gateway)")
    ap.add_argument("--proveedor", default=None, help="dirección del proveedor de pagos simulado (por defecto, la de la página de pago)")
    a = ap.parse_args()
    anon = Navegador(a.base)

    print("1. Salud")
    r = anon.get("/health")
    paso("el gateway responde /health", r.status_code == 200 and r.json().get("status") == "OK", r.text[:100])
    r = anon.get("/ready")
    paso("el gateway está listo (/ready: Vault y servicios)", r.status_code == 200, r.text[:100])
    paso("cada respuesta lleva un identificador de correlación", len(r.headers.get("x-request-id", "")) >= 8)

    print("2. Público y seguridad básica")
    r = anon.get("/api/products", params={"limit": 5})
    paso("el catálogo es público", r.status_code == 200 and len(r.json()) >= 1, r.text[:100])
    paso("sin sesión, /api/orders responde 401", anon.get("/api/orders").status_code == 401)
    paso("sin sesión, el panel responde 401", anon.get("/api/admin/orders").status_code == 401)
    paso("/api/auth/me sin sesión dice que no hay usuario", anon.get("/api/auth/me").json().get("usuario") is None)
    cab = anon.get("/api/products").headers
    paso("cabeceras de seguridad presentes", all(k in cab for k in ("content-security-policy", "x-content-type-options", "x-frame-options")))
    paso("una solicitud que modifica datos desde otro sitio se rechaza",
         httpx.post(a.base + "/api/auth/login", json={"username": "x@x.cl", "password": "x"}, headers={"Origin": "https://sitio-malicioso.example"}, timeout=10).status_code == 403)
    paso("una ruta que no está en la tabla del gateway no se reenvía", anon.get("/api/internal/orders/A-1038/payable").status_code in (404, 405))

    print("3. Cliente: registro, sesión y pedido")
    n = random.randint(30_000_000, 99_999_999)
    correo, clave = f"humo{n}@correo.cl", "clave-de-humo-123"
    cliente = Navegador(a.base)
    r = cliente.post("/api/clients/register", json={
        "run": f"{n}-{digito_verificador(n)}", "nombre": "Cliente De Humo", "telefono": "+56 9 1234 5678", "direccion": "Calle Falsa 123",
        "comuna": "Ñuñoa", "correo": correo, "nacimiento": "1990-01-01", "sexo": "Otro", "region": REGION, "provincia": "Santiago", "clave": clave})
    paso("el registro crea al cliente", r.status_code == 201, r.text[:150])
    r = cliente.post("/api/auth/login", json={"username": correo, "password": clave})
    paso("el login entrega la sesión en una cookie HttpOnly (no en el cuerpo)", r.status_code == 200 and "httponly" in r.headers.get("set-cookie", "").lower()
         and "session_token" not in r.text, r.text[:100])
    paso("/api/clients/me devuelve el perfil propio", cliente.get("/api/clients/me").status_code == 200)

    llave = uuid.uuid4().hex
    cuerpo = {"items": [{"id": "p07", "cantidad": 2}], "comuna": "Ñuñoa", "medioPago": "Servipag"}
    r1 = cliente.post("/api/orders", json=cuerpo, headers={"Idempotency-Key": llave})
    r2 = cliente.post("/api/orders", json=cuerpo, headers={"Idempotency-Key": llave})
    ok = r1.status_code in (200, 201) and r2.status_code in (200, 201) and r1.json()["id"] == r2.json()["id"]
    paso("crear el pedido dos veces con la misma clave de idempotencia devuelve el MISMO pedido", ok, f"{r1.status_code} {r1.text[:80]} / {r2.status_code}")
    if not ok:
        return terminar()
    pedido = r1.json()
    paso("el total lo calcula el servidor (el cliente no manda precios)", pedido["total"] > 0 and "precio" not in cuerpo["items"][0])

    print("4. Pago con el proveedor simulado")
    r = cliente.post(f"/api/orders/{pedido['id']}/payment")
    paso("se inicia el pago y entrega la página del proveedor", r.status_code in (200, 201) and "checkoutUrl" in r.json(), r.text[:150])
    if r.status_code not in (200, 201):
        return terminar()
    pago = r.json()
    checkout = pago["checkoutUrl"].rstrip("/")
    if a.proveedor:
        checkout = a.proveedor.rstrip("/") + "/" + checkout.split("/", 3)[3]
    r = httpx.post(checkout + "/pay", follow_redirects=False, timeout=15)
    paso("el cliente paga en la página del proveedor", r.status_code == 303, f"HTTP {r.status_code}")
    paso("el aviso firmado del proveedor deja el pedido «En preparación»",
         esperar(lambda: cliente.get(f"/api/orders/{pedido['id']}").json()["estado"] == "En preparación"))
    r = cliente.get(f"/api/orders/{pedido['id']}/receipt")
    paso("la boleta está disponible y el IVA cuadra", r.status_code == 200 and r.json().get("total") == pedido["total"], r.text[:120])

    print("5. GraphQL (una consulta, varios servicios)")
    consulta = "{ misPedidos(limit: 5) { total items { id estado total pago { estado medio } lineas { nombre cantidad } } } }"
    r = cliente.post("/api/graphql", json={"query": consulta})
    datos = r.json().get("data") or {}
    fila = next((p for p in (datos.get("misPedidos") or {}).get("items", []) if p["id"] == pedido["id"]), None)
    paso("misPedidos trae el pedido con su pago y sus líneas", r.status_code == 200 and fila is not None and fila["pago"] is not None, r.text[:200])
    r = cliente.post("/api/graphql", json={"query": "{ pedidosAdmin { total } }"})
    paso("un cliente no puede pedir los pedidos de todos (PROHIBIDO)", (r.json().get("errors") or [{}])[0].get("extensions", {}).get("codigo") == "PROHIBIDO", r.text[:150])
    r = cliente.post("/api/graphql", json={"query": "{ __schema { types { name } } }"})
    paso("la introspección de GraphQL está desactivada", r.json().get("data") is None and "errors" in r.json() and '"__schema":{' not in r.text, r.text[:150])

    print("6. Aislamiento entre clientes")
    otro_n = random.randint(30_000_000, 99_999_999)
    otro = Navegador(a.base)
    otro.post("/api/clients/register", json={
        "run": f"{otro_n}-{digito_verificador(otro_n)}", "nombre": "Otro Cliente", "telefono": "+56 9 1234 5678", "direccion": "Calle Falsa 456",
        "comuna": "Ñuñoa", "correo": f"humo{otro_n}@correo.cl", "nacimiento": "1991-01-01", "sexo": "Otro", "region": REGION, "provincia": "Santiago", "clave": clave})
    otro.post("/api/auth/login", json={"username": f"humo{otro_n}@correo.cl", "password": clave})
    ajeno = otro.get(f"/api/orders/{pedido['id']}")
    inexistente = otro.get("/api/orders/A-999999")
    paso("otro cliente no ve el pedido y la respuesta es idéntica a la de un pedido inexistente",
         ajeno.status_code == inexistente.status_code == 403 and ajeno.json()["codigo"] == inexistente.json()["codigo"], f"{ajeno.status_code}/{inexistente.status_code}")
    paso("otro cliente no puede pagar ni anular el pedido ajeno",
         otro.post(f"/api/orders/{pedido['id']}/payment").status_code in (403, 404) and otro.post(f"/api/orders/{pedido['id']}/cancellation", json={"motivo": "Ya no lo necesito"}).status_code in (403, 404))

    print("7. Personal (solo si existen las cuentas de demostración)")
    admin = Navegador(a.base)
    if admin.post("/api/auth/login", json={"username": "admin@elasador.cl", "password": "admin123"}).status_code == 200:
        r = admin.get("/api/admin/orders")
        paso("el administrador ve los pedidos", r.status_code == 200)
        paso("el cliente NO ve el panel", cliente.get("/api/admin/orders").status_code == 403)
        r = admin.post("/api/graphql", json={"query": "{ panelAdmin { pedidosPorEstado { estado cantidad } } }"})
        paso("el panel de administración responde por GraphQL", r.status_code == 200 and "errors" not in r.json(), r.text[:150])
    else:
        print("  (sin cuentas de demostración: se omite)")

    print("8. Cierre de sesión")
    paso("cerrar sesión", cliente.post("/api/auth/logout").status_code == 200)
    paso("la sesión cerrada ya no sirve", cliente.get("/api/orders").status_code == 401)
    return terminar()


def terminar():
    fallos = [n for n, ok in resultados if not ok]
    print(f"\n{len(resultados) - len(fallos)} de {len(resultados)} comprobaciones correctas")
    for n in fallos:
        print("  FALLÓ:", n)
    return 0 if not fallos else 1


if __name__ == "__main__":
    sys.exit(main())
