#!/usr/bin/env python3
"""Exporta las vistas del modelo editable docs/diagramas/El-Asador.dsl a imágenes SVG legibles.

El archivo .dsl es la fuente editable (Structurizr DSL). Este script:
  1. valida y exporta las vistas con Structurizr CLI (formato DOT),
  2. convierte cada vista a SVG con Graphviz (`dot`),
  3. escribe docs/diagramas/render/MANIFEST.json con el SHA-256 del .dsl y la lista de vistas,
  4. escribe docs/diagramas/render/INDICE.md: una tabla con cada vista, su título y lo que muestra (sale del propio .dsl).

  python scripts/exportar_diagramas.py --cli /ruta/structurizr-cli/structurizr.sh   # genera los SVG
  python scripts/exportar_diagramas.py --revisar                                    # no necesita el CLI

También se puede indicar el CLI con la variable STRUCTURIZR_CLI. Requiere Java 21 y Graphviz.
`--revisar` solo comprueba que los SVG y el manifiesto corresponden al .dsl actual (lo usa la prueba test_diagrama_dsl.py).
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
DSL = RAIZ / "docs" / "diagramas" / "El-Asador.dsl"
SALIDA = RAIZ / "docs" / "diagramas" / "render"
MANIFIESTO = SALIDA / "MANIFEST.json"
INDICE = SALIDA / "INDICE.md"
# Tipos de vista del DSL; la clave de la vista es el primer texto entre comillas de la declaración.
TIPOS = ("systemContext", "container", "component", "dynamic", "deployment")
NOMBRE_TIPO = {"systemContext": "C1 Contexto", "container": "C2 Contenedores", "component": "C3 Componentes",
               "dynamic": "Escenario dinámico", "deployment": "Despliegue"}
# declaración de una vista: tipo, (alcance), "clave" "descripción" { title "..." }
DECLARACION = re.compile(r'^\s*(%s)\s+[^"\n]*"([^"]+)"\s+"([^"]+)"\s*\{\s*\n(?:\s*title\s+"([^"]+)")?' % "|".join(TIPOS), re.M)

VISTA = re.compile(r'^\s*(%s)\s+[^"\n]*"([^"]+)"' % "|".join(TIPOS), re.M)


def sha256(ruta):
    return hashlib.sha256(Path(ruta).read_bytes()).hexdigest()


def vistas_del_dsl():
    """Lista [(tipo, clave)] en el orden en que están declaradas en el .dsl."""
    texto = DSL.read_text(encoding="utf-8")
    seccion = texto[texto.index("views {"):]
    return [(tipo, clave) for tipo, clave in VISTA.findall(seccion)]


def indice_md():
    """Tabla de vistas (con su título y descripción) construida desde el .dsl: no se escribe a mano."""
    texto = DSL.read_text(encoding="utf-8")
    texto = texto[texto.index("views {"):]
    filas = []
    for tipo, clave, descripcion, titulo in DECLARACION.findall(texto):
        descripcion = descripcion.replace("|", "\\|")
        filas.append(f"| [{clave}]({clave}.svg) | {NOMBRE_TIPO[tipo]} | {titulo or clave} | {descripcion} |")
    return "\n".join([
        "# Vistas del modelo de El Asador", "",
        "Generado por `scripts/exportar_diagramas.py` desde `docs/diagramas/El-Asador.dsl` (no editar a mano). Cada vista es un SVG vectorial:",
        "se amplía sin perder nitidez.", "",
        "| Vista | Tipo | Título | Qué muestra |", "|---|---|---|---|", *filas, ""])


def revisar():
    """Comprueba el manifiesto y los SVG sin necesidad del CLI. Devuelve la lista de problemas."""
    problemas = []
    if not MANIFIESTO.exists():
        return ["falta docs/diagramas/render/MANIFEST.json (ejecutar scripts/exportar_diagramas.py)"]
    manifiesto = json.loads(MANIFIESTO.read_text(encoding="utf-8"))
    if manifiesto.get("dsl_sha256") != sha256(DSL):
        problemas.append("el .dsl cambió después de exportar los SVG: volver a ejecutar scripts/exportar_diagramas.py")
    esperadas = [clave for _, clave in vistas_del_dsl()]
    if [v["clave"] for v in manifiesto.get("vistas", [])] != esperadas:
        problemas.append("la lista de vistas del manifiesto no coincide con la del .dsl")
    for clave in esperadas:
        svg = SALIDA / f"{clave}.svg"
        if not svg.exists() or svg.stat().st_size < 500:
            problemas.append(f"falta o está vacío el SVG de la vista {clave}")
    if not INDICE.exists() or INDICE.read_text(encoding="utf-8") != indice_md():
        problemas.append("INDICE.md no corresponde al .dsl: volver a ejecutar scripts/exportar_diagramas.py")
    sobrantes = {p.stem for p in SALIDA.glob("*.svg")} - set(esperadas)
    for clave in sorted(sobrantes):
        problemas.append(f"SVG sin vista en el .dsl: {clave}")
    return problemas


def ejecutar(cmd, **kw):
    res = subprocess.run(cmd, capture_output=True, text=True, **kw)
    if res.returncode != 0:
        sys.exit(f"falló {' '.join(map(str, cmd))}\n{res.stdout}\n{res.stderr}")
    return res


def exportar(cli):
    if not shutil.which("dot"):
        sys.exit("falta Graphviz (`dot`); instalar con apt install graphviz")
    ejecutar([cli, "validate", "-workspace", str(DSL)])
    with tempfile.TemporaryDirectory() as tmp:
        ejecutar([cli, "export", "-workspace", str(DSL), "-format", "dot", "-output", tmp])
        SALIDA.mkdir(parents=True, exist_ok=True)
        for viejo in SALIDA.glob("*.svg"):
            viejo.unlink()
        vistas = []
        for tipo, clave in vistas_del_dsl():
            dot = Path(tmp) / f"structurizr-{clave}.dot"
            if not dot.exists():
                sys.exit(f"el CLI no exportó la vista {clave}")
            svg = SALIDA / f"{clave}.svg"
            ejecutar(["dot", "-Tsvg", str(dot), "-o", str(svg)])
            vistas.append({"clave": clave, "tipo": tipo, "archivo": f"{clave}.svg"})
    version = ejecutar([cli, "version"]).stdout
    cli_version = next((l for l in version.splitlines() if l.startswith("structurizr-cli")), "structurizr-cli")
    dot_version = ejecutar(["dot", "-V"]).stderr.strip()
    MANIFIESTO.write_text(json.dumps({
        "dsl": "docs/diagramas/El-Asador.dsl",
        "dsl_sha256": sha256(DSL),
        "herramientas": {"structurizr": cli_version, "graphviz": dot_version},
        "vistas": vistas,
    }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    INDICE.write_text(indice_md(), encoding="utf-8")
    print(f"{len(vistas)} vistas exportadas a {SALIDA.relative_to(RAIZ)}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--cli", default=os.environ.get("STRUCTURIZR_CLI"), help="ruta de structurizr.sh")
    ap.add_argument("--revisar", action="store_true", help="solo comprobar que los SVG corresponden al .dsl")
    args = ap.parse_args()
    if args.revisar:
        problemas = revisar()
        for p in problemas:
            print("-", p)
        sys.exit(1 if problemas else 0)
    if not args.cli:
        sys.exit("indicar el CLI con --cli o con STRUCTURIZR_CLI")
    exportar(args.cli)


if __name__ == "__main__":
    main()
