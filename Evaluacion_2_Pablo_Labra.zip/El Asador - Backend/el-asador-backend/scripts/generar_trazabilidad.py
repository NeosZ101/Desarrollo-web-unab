#!/usr/bin/env python3
"""Matriz de trazabilidad  requisito | pantalla | servicio | prueba | resultado | evidencia  (módulo 10).

Las columnas «pantalla» y «servicio» se calculan desde la tabla de rutas del API Gateway (cada ruta declara los requisitos que cubre y las
pantallas que la usan). La columna «resultado» se calcula desde los informes JUnit de las ejecuciones guardadas en docs/evidencia/:
  junit_simulado.xml   suite completa con Vault y MongoDB simulados
  junit_real.xml       la misma suite con HashiCorp Vault y MongoDB REALES (opcional)
No se escribe ningún resultado a mano: si una prueba falla en el JUnit, la fila lo muestra.

  python scripts/generar_trazabilidad.py            # escribe docs/matrices/trazabilidad.md
  python scripts/generar_trazabilidad.py --revisar  # solo comprueba que el archivo está al día
"""
import importlib.util
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
EVIDENCIA = RAIZ / "docs" / "evidencia"
SALIDA = RAIZ / "docs" / "matrices" / "trazabilidad.md"

RF = {
    "RF1": ("Armar un pedido con los productos disponibles de la carta", "CU5 Genera pedido"),
    "RF2": ("La orden se prepara solo tras confirmar el pago", "CU6 Realizar venta"),
    "RF3": ("Anular una compra indicando el motivo", "CU7 Anular compra"),
    "RF4": ("Vender únicamente pedidos de clientes registrados (caja del cajero virtual)", "CU6 Realizar venta"),
    "RF5": ("Registro de clientes con todos sus datos y correo existente", "CU3 Administrar clientes"),
    "RF6": ("Registro de clientes en el local por el administrador", "CU3 Administrar clientes"),
    "RF7": ("Administrar la disponibilidad de cada producto", "CU4 Administrar productos"),
    "RF8": ("Boleta digital por cada venta, enviada por correo", "CU6 Realizar venta"),
    "RF9": ("Reporte de ventas por período para el dueño", "CU8 Generar reporte de ventas"),
    "RF10": ("Mantenedores de productos, usuarios y clientes", "CU2/CU3/CU4"),
    "RF11": ("Validar que el correo existe mediante una API de mensajería", "CU3 Administrar clientes"),
    "RF12": ("Autenticación de usuarios y acceso según perfil", "CU1 Autenticar usuarios"),
    "RF13": ("Orden de despacho en el orden de llegada (imprimible)", "CU9 Obtener orden de despacho"),
}

# requisito -> [(archivo de pruebas, expresión regular sobre el nombre de la prueba)]. Cada requisito debe tener al menos una prueba.
PRUEBAS = {
    "RF1": [("test_negocio_pedidos", "total|campos_que|precio_enviado|costo_de_despacho|zonas|promo|comuna|producto_inexistente|limites_de_cantidad|maximo_de_pedidos|reintent|idempotency|alcohol|crear_pedido"),
            ("test_negocio_administracion", "precio_del_pedido|producto_retirado|carta_publica"),
            ("test_unidad_reglas", "costo_de_despacho|totales_suman|precio_de_promo|despacho_nunca_baja|mayoria_de_edad"),
            ("test_graphql", "mis_pedidos_une|sin_pago_iniciado|imagenes_de_las_lineas")],
    "RF2": [("test_negocio_pagos", "."), ("test_unidad_carreras", "."), ("test_negocio_pedidos", "no_se_avanza_un_pedido_sin_pagar"),
            ("test_unidad_reglas", "solo_payments_confirma|maquina_de_estados")],
    "RF3": [("test_negocio_pedidos", "anula|anulado|motivo_de_anulacion"), ("test_negocio_pagos", "anular|reembolso|cancelado"),
            ("test_analitica", "anulacion"), ("test_unidad_reglas", "motivo_de_anulacion|estados_finales")],
    "RF4": [("test_negocio_pedidos", "crear_pedido_requiere_sesion|campos_que.*cliente"), ("test_negocio_pagos", "cliente_no_puede_marcar|confirmacion_manual_exige"),
            ("test_seguridad_acceso", "cliente_no_opera_sobre_pedidos_ajenos|perfil_de_cliente_es_siempre"), ("test_analitica", "una_venta_real")],
    "RF5": [("test_negocio_administracion", "registro_web|registro_rechaza|clave_debil|registro_repetido"),
            ("test_unidad_reglas", "run_|telefono|ubicacion|mayoria_de_edad|fecha_de_nacimiento|politica_de_claves")],
    "RF6": [("test_negocio_administracion", "dado_de_alta_en_el_local|administrador_busca|administrador_edita|alta_en_el_local|desactivar_un_cliente")],
    "RF7": [("test_negocio_administracion", "catalogo|producto_retirado|promocion_activa|carta_publica"), ("test_unidad_reglas", "imagen_de_producto")],
    "RF8": [("test_negocio_pagos", "flujo_completo"), ("test_negocio_administracion", "bandeja_enmascara"), ("test_graphql", "mis_pedidos_une")],
    "RF9": [("test_analitica", "totales|periodo|dia_sin|reporte_lo_ven|venta_real|92"), ("test_graphql", "reporte_de_ventas"), ("test_unidad_reglas", "dia_de_los_reportes")],
    "RF10": [("test_negocio_administracion", "^(?!.*(contacto|cotizacion|bandeja)).*")],
    "RF11": [("test_negocio_administracion", "registro_rechaza_datos_invalidos.*CORREO_NO_EXISTE|dado_de_alta_en_el_local|alta_en_el_local_no_acepta")],
    "RF12": [("test_seguridad_acceso", "sin_sesion_toda_ruta|rol_no_listado|rol_listado|credenciales|cookie|cerrar_sesion|origen|identidad"),
             ("test_negocio_administracion", "crea_un_usuario|cambiar_la_clave|cambiar_el_rol|desactivar_un_usuario"),
             ("test_limites_tasa", "login|cuenta_se_bloquea|bloqueo|cookie"), ("test_graphql", "exige_sesion")],
    "RF13": [("test_negocio_pedidos", "cola_de_despacho|despacho_solo_avanza|no_se_avanza|inexistente_para_el_personal"),
             ("test_graphql", "consulta_de_despacho"), ("test_unidad_reglas", "despacho_avanza_solo_en_orden")],
}
RNF = [
    ("RNF2", "Capas separadas: interfaz, reglas de negocio y datos", "cumple",
     [("test_despliegue", "publican_puertos|no_son_alcanzables|esperan_a_la_siembra|mongo_arranca_con_autenticacion"), ("test_segunda_capa", "codigo_coincide|contrato_cubre")],
     "[diagrama de componentes](../diagramas/03-componentes-y-redes.mmd), [ADR-005](../adr/ADR-005-base-de-datos-por-servicio.md)"),
    ("RNF5", "Integración entre sistemas por servicios web", "cumple",
     [("test_segunda_capa", "codigo_coincide|contrato_cubre|solo_los_llamadores"), ("test_seguridad_acceso", "secreto|servicio_privado|llamar_rutas")],
     "[llamadas entre servicios](llamadas_entre_servicios.md)"),
    ("RNF6", "API de correo para envío y validación de cuentas", "cumple con proveedor de prueba (`sandbox`); MX y SMTP no probados",
     [("test_negocio_administracion", "contacto|bandeja|registro_rechaza_datos_invalidos.*CORREO_NO_EXISTE")],
     "[ADR-012](../adr/ADR-012-pila-tecnologica.md)"),
    ("RNF7", "Cifrado de clave y control de sesiones", "cumple",
     [("test_seguridad_acceso", "cookie_de_sesion_es_httponly|cerrar_sesion|credenciales|cookie_basura"), ("test_sesion_vence", "."),
      ("test_limites_tasa", "cookie|cuenta_se_bloquea"),
      ("test_unidad_reglas", "politica_de_claves"), ("test_infraestructura_real", "argon2id")],
     "[ADR-002](../adr/ADR-002-sesion-opaca-en-cookie.md), [controles](../evidencia/controles.md). El hash argon2id en MongoDB real se comprueba solo en la ejecución con servicios reales"),
    ("RNF8", "Validaciones en todas las entradas", "cumple",
     [("test_seguridad_acceso", "inyeccion|asignacion_masiva|cuerpo_que_no|tamano|paginacion|parametros_de_ruta|entradas_que_no_son_texto"),
      ("test_unidad_reglas", "run_|telefono|ubicacion|imagen_de_producto|fecha_de_nacimiento|firma_ausente"), ("test_negocio_administracion", "rechaza"),
      ("test_graphql", "formas_de_solicitud")],
     "[modelos de entrada](servicios_y_contratos.md)"),
    ("RNF13", "Mensajes de error informativos y orientados al usuario final", "cumple",
     [("test_seguridad_acceso", "errores_nunca_filtran"), ("test_negocio_pedidos", "motivo|comuna_sin_cobertura|limites|producto_inexistente"),
      ("test_graphql", "errores_no_revelan|variable_mal_escrita")],
     "[ejemplos](../ejemplos/)"),
]


def _rutas():
    spec = importlib.util.spec_from_file_location("rutas_trazabilidad", RAIZ / "api-gateway" / "app" / "rutas.py")
    modulo = importlib.util.module_from_spec(spec)
    sys.modules["rutas_trazabilidad"] = modulo
    spec.loader.exec_module(modulo)
    return modulo


def _junit(nombre):
    ruta = EVIDENCIA / nombre
    if not ruta.exists():
        return None
    casos = []
    for tc in ET.parse(ruta).getroot().iter("testcase"):
        estado = "ok"
        if tc.find("failure") is not None or tc.find("error") is not None:
            estado = "falla"
        elif tc.find("skipped") is not None:
            estado = "omitida"
        casos.append((tc.attrib["classname"].split(".")[-1], tc.attrib["name"], estado))
    return casos


def _seleccion(casos, patrones):
    elegidos = {}
    for modulo, nombre, estado in casos:
        for archivo, regex in patrones:
            if modulo == archivo and re.search(regex, nombre):
                elegidos[(modulo, nombre)] = estado
    return elegidos


def _resultado(casos, patrones):
    if casos is None:
        return "sin ejecución guardada"
    sel = _seleccion(casos, patrones)
    if not sel:
        return "sin pruebas"
    ok = sum(1 for e in sel.values() if e == "ok")
    falla = sum(1 for e in sel.values() if e == "falla")
    omit = sum(1 for e in sel.values() if e == "omitida")
    texto = f"{ok} de {len(sel)} ✓"
    if falla:
        texto += f", {falla} ✗"
    if omit:
        texto += f", {omit} omitidas"
    return texto


def _celda_pruebas(casos, patrones):
    por_archivo = {}
    if casos is not None:
        for (modulo, _), _e in _seleccion(casos, patrones).items():
            por_archivo[modulo] = por_archivo.get(modulo, 0) + 1
    else:
        por_archivo = {a: 0 for a, _ in patrones}
    return "; ".join(f"`{a}` ({n})" for a, n in sorted(por_archivo.items()))


def generar():
    rutas = _rutas()
    simulado, real = _junit("junit_simulado.xml"), _junit("junit_real.xml")
    sin_pruebas = [rf for rf in RF if not _seleccion(simulado or [], PRUEBAS[rf])] if simulado is not None else []
    if sin_pruebas:
        raise SystemExit(f"requisitos sin ninguna prueba asociada: {sin_pruebas}")
    notas = {"RF11": "proveedor de correo de prueba (`sandbox`): el buzón «no existe» por convención de nombre o dominio; la validación por DNS MX y el envío SMTP existen en el código pero no se probaron",
             "RF13": "la impresión la hace el panel del frontend de la C2 (no incluido en esta entrega); el backend entrega la orden de despacho en el orden de llegada",
             "RF8": "el envío real por SMTP no se probó; la boleta queda en la bandeja de salida (S37)",
             }
    evidencia_extra = {"RF2": "[controles C6](../evidencia/controles.md)", "RF3": "[S24](../ejemplos/S24.json), [S33](../ejemplos/S33.json)",
                       "RF9": "[carga](../evidencia/carga.md), [GraphQL](graphql.md)", "RF12": "[controles C2, C3](../evidencia/controles.md)",
                       "RF1": "[controles M8](../evidencia/controles.md)", "RF13": "[S25](../ejemplos/S25.json), [S26](../ejemplos/S26.json)"}
    L = ["# Matriz de trazabilidad: requisito | pantalla | servicio | prueba | resultado | evidencia (M10)", "",
         "Generada por `scripts/generar_trazabilidad.py`. Pantallas y servicios salen de la tabla de rutas del API Gateway (`api-gateway/app/rutas.py`); "
         "los resultados, de los informes JUnit guardados en `docs/evidencia/` (no se escribe ningún resultado a mano).", "",
         "**Origen de los requisitos:** RF1–RF13, CU1–CU9 y RNF1–RNF16 siguen la estructura de requisitos del caso de referencia de la asignatura, "
         "adaptados a «El Asador» con lo que muestran las pantallas del frontend de la C2. Está declarado en la portada del informe.", "",
         "## Requisitos funcionales", "",
         "| Requisito | Pantallas | Servicios | Pruebas (cantidad que lo ejercitan) | Resultado (simulado) | Resultado (Vault y MongoDB reales) | Evidencia |", "|---|---|---|---|---|---|---|"]
    for rf, (titulo, cu) in RF.items():
        rs = [r for r in rutas.RUTAS if rf in r.rf]
        paginas = sorted({p for r in rs for p in r.paginas})
        pantallas = ", ".join(f"{p}" for p in paginas) or "—"
        servicios = ", ".join(r.id for r in rs) or "—"
        ejemplos = ", ".join(f"[{r.id}](../ejemplos/{r.id}.json)" for r in rs[:3]) + (", …" if len(rs) > 3 else "")
        extra = "; ".join(x for x in (evidencia_extra.get(rf), notas.get(rf)) if x)
        L.append(f"| **{rf}** {titulo} ({cu}) | {pantallas} | {servicios} | {_celda_pruebas(simulado, PRUEBAS[rf])} | {_resultado(simulado, PRUEBAS[rf])} | "
                 f"{_resultado(real, PRUEBAS[rf])} | {ejemplos}{'; ' + extra if extra else ''} |")
    L += ["", "Pantallas: " + "; ".join(f"**{k}** {v}" for k, v in rutas.PAGINAS.items()) + ".", "",
          "## Requisitos no funcionales con prueba", "",
          "| Requisito | Estado | Pruebas | Resultado (simulado) | Resultado (reales) | Evidencia |", "|---|---|---|---|---|---|"]
    for rnf, titulo, estado, patrones, evidencia in RNF:
        L.append(f"| **{rnf}** {titulo} | {estado} | {_celda_pruebas(simulado, patrones)} | {_resultado(simulado, patrones)} | {_resultado(real, patrones)} | {evidencia} |")
    L += ["", "## Requisitos no funcionales con tratamiento distinto (declarado)", "",
          "| Requisito | Tratamiento | Motivo |", "|---|---|---|",
          "| RNF1 Ambiente web | Parcial | La interfaz web es el frontend de la C2, que no forma parte del proyecto del backend y no está conectado a él; el backend expone la API que ese frontend consumirá y se prueba por HTTP. La integración se valida en la Evaluación 3. |",
          "| RNF3 Oracle y .NET/J2EE | **Desviación** | Se conservan las restricciones del curso: FastAPI + MongoDB ([ADR-012](../adr/ADR-012-pila-tecnologica.md)). |",
          "| RNF4 Procedimientos almacenados y estructura para avisos | **Desviación** | Bandeja de salida (`outbox`) con reintentos, consultable por el administrador (S37). |",
          "| RNF9 Interfaz con elementos de Windows | No aplica | La interfaz es web con Bootstrap 5. |",
          "| RNF10 Aprendizaje < 4 h; RNF11 errores < 1 % | **No medidos** | Requieren usuarios reales; no se afirma cumplimiento. |",
          "| RNF12 Manuales; RNF14 Ayuda en línea | Parcial | La ayuda en línea es parte del frontend de la C2 (no incluido en esta entrega); no hay manual de usuario separado. |",
          "| RNF15 Diseño responsivo | **No evaluable aquí** | Es una propiedad del frontend; el backend no la determina. Se valida con la integración (Evaluación 3). |",
          "| RNF16 Interfaces bien formadas | **No verificado** | Es una propiedad del frontend (no incluido en esta entrega); no se ejecutó ningún validador de HTML. |", ""]
    return "\n".join(L)


def main():
    texto = generar()
    if "--revisar" in sys.argv:
        ok = SALIDA.exists() and SALIDA.read_text(encoding="utf-8") == texto
        print("al día" if ok else "DESACTUALIZADA: ejecuta python scripts/generar_trazabilidad.py")
        return 0 if ok else 1
    SALIDA.write_text(texto, encoding="utf-8")
    print(f"escrito {SALIDA.relative_to(RAIZ)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
