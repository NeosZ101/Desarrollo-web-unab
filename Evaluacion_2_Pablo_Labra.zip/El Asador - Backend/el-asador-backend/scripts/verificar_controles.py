#!/usr/bin/env python3
"""Ejecuta contra el sistema real los 6 casos de validación del módulo 7 y la evidencia de agregación del módulo 8.

Levanta el sistema completo como procesos reales (tests/stack.py: MongoDB simulado y Vault falso por omisión; con ASADOR_REAL=1 y
ASADOR_BIN=<carpeta con vault y mongod>, servidores de verdad), manda las solicitudes por HTTP como lo haría un navegador o un atacante
y registra, para cada una: entrada, identidad, resultado esperado, resultado obtenido y componente que lo verifica.
Escribe docs/evidencia/controles.md y controles.json. Sale con código 1 si algún resultado no es el esperado.

  python scripts/verificar_controles.py

Las mismas reglas están protegidas por las pruebas automáticas (columna «prueba»); este script deja el registro legible para el informe.
"""
import json
import os
import platform
import sys
import tempfile
import time
import uuid
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import yaml

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "tests"))
sys.path.insert(0, str(RAIZ))
from ayuda import (Api, aviso, consulta_del_frontend, crear_pedido, datos_registro, enviar_aviso, esperar, estado_pedido,  # noqa: E402
                   iniciar_pago, llamadas_registradas, llamar_servicio, pagar_en_proveedor, sin_id)
from stack import Stack  # noqa: E402

DESTINO = RAIZ / "docs" / "evidencia"
ENTORNO = {"RL_GENERAL": "1000000", "RL_LOGIN": "100000", "RL_REGISTRO": "100000", "RL_FORMULARIOS": "100000", "RL_GRAPHQL": "1000000",
           "RL_WEBHOOK": "1000000", "REINTENTO_SEGUNDOS": "1"}
CAMPOS_PUBLICOS = {"id", "categoria", "nombre", "precio", "disponible", "imagen", "descripcion", "incluye", "alcohol", "personas"}

FILAS = []


def _resumen(r):
    """«403 PROHIBIDO» o «200» (el código de error de negocio, si lo hay)."""
    codigo = ""
    try:
        cuerpo = r.json()
        if isinstance(cuerpo, dict):
            codigo = cuerpo.get("codigo") or ""
            if not codigo and cuerpo.get("errors"):
                codigo = ",".join(e.get("extensions", {}).get("codigo", "") for e in cuerpo["errors"])
    except ValueError:
        pass
    return f"{r.status_code} {codigo}".strip()


def anotar(caso, entrada, identidad, esperado, r, cumple, componente, prueba, obtenido=None):
    ok = bool(cumple)
    FILAS.append({"caso": caso, "entrada": entrada, "identidad": identidad, "esperado": esperado, "obtenido": obtenido or _resumen(r),
                  "componente": componente, "prueba": prueba, "ok": ok})
    if not ok:
        print(f"  ✗ {caso} · {entrada} · {identidad}: esperado {esperado}, obtenido {obtenido or _resumen(r)}", file=sys.stderr)
    return r


def prohibido(r, estado=403, codigo=None):
    return r.status_code == estado and (codigo is None or r.json().get("codigo") == codigo)


# ======================================================================================================================
def caso1_catalogo_anonimo(gw):
    c = "C1 Catálogo anónimo"
    anon = Api(gw, registrar=False)
    r = anon.get("/api/products?limit=5")
    campos = set().union(*(set(p) for p in r.json())) if r.status_code == 200 and r.json() else set()
    anotar(c, "GET /api/products?limit=5", "anónimo (sin cookie)", "200; solo campos públicos del producto", r,
           r.status_code == 200 and campos <= CAMPOS_PUBLICOS and "set-cookie" not in r.headers, "api-gateway (ruta pública S04) + inventory",
           "test_seguridad_acceso::test_la_matriz_de_permisos_del_informe_coincide_con_el_gateway",
           obtenido=f"{r.status_code}; campos: {', '.join(sorted(campos))}; sin Set-Cookie")
    for ruta, sid in (("/api/promos", "S05"), ("/api/delivery-zones", "S20")):
        r = anon.get(ruta)
        anotar(c, f"GET {ruta}", "anónimo", "200", r, r.status_code == 200, f"api-gateway (ruta pública {sid})", "test_negocio_pedidos::test_zonas_de_despacho_publicas_coinciden_con_el_cobro")
    r = anon.get("/api/orders")
    anotar(c, "GET /api/orders (control: lo privado sigue privado)", "anónimo", "401 NO_AUTENTICADO", r, prohibido(r, 401, "NO_AUTENTICADO"),
           "api-gateway", "test_seguridad_acceso::test_sin_sesion_toda_ruta_protegida_responde_401")


def caso2_sin_sesion(gw, s):
    c = "C2 Operación protegida sin sesión válida"
    anon = Api(gw, registrar=False)
    pedido = {"items": [{"id": "p07", "cantidad": 1}], "comuna": "Ñuñoa", "medioPago": "Servipag"}
    r = anon.post("/api/orders", json=pedido, headers={"Idempotency-Key": uuid.uuid4().hex})
    anotar(c, "POST /api/orders (sin cookie)", "anónimo", "401 NO_AUTENTICADO", r, prohibido(r, 401, "NO_AUTENTICADO"), "api-gateway (tabla de rutas: exige sesión)",
           "test_seguridad_acceso::test_sin_sesion_toda_ruta_protegida_responde_401")
    inventada = Api(gw, registrar=False)
    inventada.c.cookies.set("session_token", "x" * 43, domain="127.0.0.1")
    r = inventada.post("/api/orders", json=pedido, headers={"Idempotency-Key": uuid.uuid4().hex})
    anotar(c, "POST /api/orders (cookie inventada)", "token que no existe", "401 SESION_NO_VALIDA", r, prohibido(r, 401, "SESION_NO_VALIDA"),
           "auth (introspección en cada solicitud)", "test_seguridad_acceso::test_cookie_basura_se_trata_como_sin_sesion")
    d = datos_registro()
    web = Api(gw, registrar=False)
    web.post("/api/clients/register", json=d)
    web.login(d["correo"], d["clave"])
    token = web.token
    antes = web.get("/api/clients/me")
    web.post("/api/auth/logout")
    reutilizada = Api(gw, registrar=False)
    reutilizada.c.cookies.set("session_token", token, domain="127.0.0.1")
    r = reutilizada.get("/api/clients/me")
    anotar(c, "GET /api/clients/me (token de una sesión ya cerrada)", f"cliente (antes del logout: {antes.status_code})", "401 SESION_NO_VALIDA", r,
           antes.status_code == 200 and prohibido(r, 401, "SESION_NO_VALIDA"), "auth (el logout revoca la sesión en el servidor)",
           "test_seguridad_acceso::test_cerrar_sesion_la_revoca_en_el_servidor")
    r = anon.post("/api/graphql", json={"query": "{ misPedidos(limit: 1) { total } }"})
    anotar(c, "POST /api/graphql", "anónimo", "401 NO_AUTENTICADO", r, prohibido(r, 401, "NO_AUTENTICADO"), "api-gateway (antes de llegar al GraphQL Gateway)",
           "test_graphql::test_graphql_exige_sesion")
    r = anon.get("/api/clients/me", headers={"Authorization": "Bearer " + "a" * 40})
    anotar(c, "GET /api/clients/me con «Authorization: Bearer …»", "anónimo", "401 (el sistema solo reconoce su cookie de sesión)", r, prohibido(r, 401),
           "api-gateway", "test_seguridad_acceso::test_cabeceras_de_identidad_enviadas_por_el_navegador_se_ignoran")


def caso3_rol_sin_permiso(gw, personal, cliente, pedido_id, producto):
    c = "C3 Administración desde un rol sin permiso"
    pruebas = [
        ("cliente", cliente, "POST", "/api/products", producto),
        ("cliente", cliente, "GET", "/api/users", None),
        ("cliente", cliente, "GET", "/api/clients", None),
        ("cliente", cliente, "PUT", f"/api/admin/orders/{pedido_id}/status", {"estado": "En camino"}),
        ("despacho", personal["despacho"], "POST", "/api/products", producto),
        ("despacho", personal["despacho"], "GET", "/api/admin/payments", None),
        ("despacho", personal["despacho"], "POST", f"/api/admin/orders/{pedido_id}/refund", {"referencia": "REEMB-1"}),
        ("dueno", personal["dueno"], "POST", "/api/users", {"username": "x@elasador.cl", "nombre": "X", "rol": "administrador", "password": "Clave-Segura-2026"}),
        ("dueno", personal["dueno"], "GET", "/api/clients", None),
        ("dueno", personal["dueno"], "GET", "/api/admin/orders", None),
        ("administrador", personal["administrador"], "GET", "/api/admin/outbox?limit=1", None),   # control: el rol correcto sí pasa
    ]
    for rol, api, metodo, ruta, cuerpo in pruebas:
        r = api.pedir(metodo, ruta, json=cuerpo) if cuerpo is not None else api.pedir(metodo, ruta)
        permitido = rol == "administrador"
        anotar(c, f"{metodo} {ruta.split('?')[0]}", f"sesión de {rol}", "200 (control: rol autorizado)" if permitido else "403 ROL_NO_AUTORIZADO", r,
               r.status_code == 200 if permitido else prohibido(r, 403, "ROL_NO_AUTORIZADO"), "api-gateway (rol exigido por la ruta)",
               "test_seguridad_acceso::test_un_rol_no_listado_recibe_403_en_el_gateway")
    productos = Api(gw, registrar=False).get("/api/products?limit=100").json()
    anotar(c, "efecto: no se creó ningún producto con los intentos del cliente y del despacho", "—", "el nombre del producto de prueba no existe en el catálogo", None,
           all(p["nombre"] != producto["nombre"] for p in productos), "inventory", "test_seguridad_acceso::test_el_gateway_corta_el_rol_equivocado_antes_de_molestar_al_servicio", obtenido="no existe en el catálogo")


def caso3b_segunda_capa(s):
    c = "C3 Administración desde un rol sin permiso"
    r = llamar_servicio(s, "inventory", "POST", "/products", como="api-gateway", identidad={"user": "u-x", "username": "x@x.cl", "roles": "cliente"},
                        json={"nombre": "Producto malo", "categoria": "bebidas", "precio": 1, "descripcion": "x", "imagen": "img/cerveza.svg"})
    anotar(c, "POST inventory /products con la identidad «cliente» afirmada por el propio gateway (segunda capa)", "cliente (saltándose la comprobación del gateway)",
           "403 ROL_NO_AUTORIZADO", r, prohibido(r, 403, "ROL_NO_AUTORIZADO"), "inventory (el servicio vuelve a comprobar el rol)", "test_segunda_capa::test_el_servicio_vuelve_a_comprobar_el_rol_sin_fiarse_del_gateway")


def caso4_pedido_ajeno(gw, personal):
    c = "C4 Consulta de un pedido ajeno"
    da, db_ = datos_registro(), datos_registro()
    a, b = Api(gw, registrar=False), Api(gw, registrar=False)
    for api, d in ((a, da), (b, db_)):
        api.post("/api/clients/register", json=d)
        api.login(d["correo"], d["clave"])
    pedido = crear_pedido(a, items=[{"id": "p07", "cantidad": 1}]).json()
    pid = pedido["id"]
    ajeno = b.get(f"/api/orders/{pid}")
    inexistente = b.get("/api/orders/A-999999")
    fugas = [x for x in (da["nombre"], da["direccion"], da["correo"], da["telefono"]) if x in ajeno.text]
    anotar(c, f"GET /api/orders/{pid} (pedido de otro cliente)", "cliente B", "403 PROHIBIDO, mismo cuerpo que un pedido inexistente y sin datos de A", ajeno,
           prohibido(ajeno, 403, "PROHIBIDO") and inexistente.status_code == 403 and sin_id(ajeno.json()) == sin_id(inexistente.json()) and not fugas,
           "orders (pertenencia: el cliente de la sesión debe ser el dueño del pedido)",
           "test_seguridad_acceso::test_un_cliente_no_ve_el_pedido_de_otro_y_la_respuesta_no_revela_si_existe",
           obtenido=f"{ajeno.status_code} {ajeno.json().get('codigo')}; idéntico al de A-999999 (inexistente): {sin_id(ajeno.json()) == sin_id(inexistente.json())}; datos de A en el cuerpo: {len(fugas)}")
    for metodo, ruta, cuerpo, etiqueta in (("POST", f"/api/orders/{pid}/cancellation", {"motivo": "Ya no lo necesito"}, "anular"),
                                          ("POST", f"/api/orders/{pid}/payment", None, "iniciar el pago"),
                                          ("GET", f"/api/orders/{pid}/payment", None, "ver el pago"),
                                          ("GET", f"/api/orders/{pid}/receipt", None, "ver la boleta")):
        r = b.pedir(metodo, ruta, json=cuerpo) if cuerpo else b.pedir(metodo, ruta)
        anotar(c, f"{metodo} {ruta.replace(pid, '{pedido}')} ({etiqueta})", "cliente B", "403 PROHIBIDO", r, prohibido(r, 403, "PROHIBIDO"),
               "orders / payments (pertenencia)", "test_seguridad_acceso::test_un_cliente_no_opera_sobre_pedidos_ajenos")
    r = b.gql("{ misPedidos(limit: 50) { total items { id } } }")
    ids = [p["id"] for p in r.json()["data"]["misPedidos"]["items"]]
    anotar(c, "GraphQL misPedidos", "cliente B", "200 sin el pedido de A (la lista es solo la suya)", r, r.status_code == 200 and pid not in ids,
           "graphql-gateway + orders (la identidad viaja al servicio)", "test_graphql::test_cada_cliente_ve_solo_sus_pedidos_en_graphql", obtenido=f"200; {len(ids)} pedidos propios; el de A no aparece")
    r = b.gql("{ pedidosAdmin(limit: 5) { total items { id cliente { correo } } } }")
    anotar(c, "GraphQL pedidosAdmin (pedidos de todos)", "cliente B", "PROHIBIDO y sin datos", r,
           r.status_code == 200 and "PROHIBIDO" in _resumen(r) and "@" not in r.text, "graphql-gateway (permiso por campo)", "test_graphql::test_matriz_de_permisos_de_campos_graphql")
    r = a.get(f"/api/orders/{pid}")
    anotar(c, f"GET /api/orders/{pid} (control: el dueño sí)", "cliente A (dueño)", "200 y estado «Pago pendiente»", r,
           r.status_code == 200 and r.json()["estado"] == "Pago pendiente" and len(r.json()["historial"]) == 1,
           "orders", "test_seguridad_acceso::test_el_pedido_ajeno_sigue_intacto_tras_los_intentos", obtenido=f"200; estado «{r.json()['estado']}»; sin cambios tras los intentos de B")
    r = personal["administrador"].get(f"/api/orders/{pid}")
    anotar(c, f"GET /api/orders/{pid} (control: el personal sí)", "administrador", "200", r, r.status_code == 200, "orders", "test_seguridad_acceso::test_el_personal_si_ve_cualquier_pedido_y_los_datos_de_despacho")
    return a, pedido


def caso5_acceso_directo(s):
    c = "C5 Acceso directo al backend sin identidad autorizada"
    privados = [("auth", "GET", "/users", "api-gateway"), ("clients", "GET", "/clients", "api-gateway"), ("inventory", "GET", "/internal/summary", "graphql-gateway"),
                ("orders", "GET", "/orders", "api-gateway"), ("payments", "GET", "/admin/payments", "api-gateway"), ("notifications", "GET", "/outbox", "api-gateway"),
                ("analytics", "GET", "/internal/reports/sales?desde=2026-01-01&hasta=2026-01-02", "graphql-gateway"), ("graphql-gateway", "POST", "/graphql", "api-gateway")]
    for servicio, metodo, ruta, llamador in privados:
        r = llamar_servicio(s, servicio, metodo, ruta, como=llamador, sin_credencial=True)
        anotar(c, f"{metodo} {servicio}{ruta.split('?')[0]} sin credencial de servicio", "ninguna (sin X-Service-Name/Secret)", "403 LLAMADOR_NO_PERMITIDO", r,
               prohibido(r, 403, "LLAMADOR_NO_PERMITIDO"), f"{servicio} (guardia de servicio)", "test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial")
    for servicio, metodo, ruta, llamador in privados:
        r = llamar_servicio(s, servicio, metodo, ruta, como=llamador, secreto="secreto-inventado")
        anotar(c, f"{metodo} {servicio}{ruta.split('?')[0]} con un secreto inventado", f"se declara «{llamador}»", "403 SECRETO_INVALIDO", r,
               prohibido(r, 403, "SECRETO_INVALIDO"), f"{servicio} (compara con el secreto del par en Vault)", "test_seguridad_acceso::test_servicio_privado_rechaza_secreto_equivocado")
    r = llamar_servicio(s, "inventory", "GET", "/products", como="api-gateway", secreto=s.secreto("svc/api-gateway-to-orders"))
    anotar(c, "GET inventory/products con el secreto del par «api-gateway→orders»", "se declara «api-gateway»", "403 SECRETO_INVALIDO (cada par tiene su secreto)", r,
           prohibido(r, 403, "SECRETO_INVALIDO"), "inventory", "test_seguridad_acceso::test_el_secreto_de_un_par_no_sirve_para_otro_destino")
    r = llamar_servicio(s, "orders", "GET", "/orders", como="payments", identidad={"user": "u-c0001", "username": "andrea.molina@correo.cl", "roles": "cliente", "client": "c-0001"})
    anotar(c, "GET orders/orders afirmando la identidad de un cliente, con secreto válido de «payments»", "«payments» con identidad de cliente", "403 (solo gateways pueden afirmar identidad)",
           r, prohibido(r, 403), "orders", "test_seguridad_acceso::test_solo_los_llamadores_de_confianza_pueden_afirmar_una_identidad")
    r = llamar_servicio(s, "orders", "POST", "/orders/A-1041/cancellation", como="graphql-gateway", identidad={"user": "u-c0001", "username": "andrea.molina@correo.cl", "roles": "cliente", "client": "c-0001"},
                        json={"motivo": "Ya no lo necesito"})
    anotar(c, "POST orders/…/cancellation desde el GraphQL Gateway (con su secreto)", "«graphql-gateway»", "403 LLAMADOR_NO_PERMITIDO (solo lectura)", r,
           prohibido(r, 403, "LLAMADOR_NO_PERMITIDO"), "orders", "test_seguridad_acceso::test_el_graphql_gateway_es_de_solo_lectura_aunque_tenga_su_secreto")
    # desde el navegador: cabeceras de identidad falsas que el gateway debe descartar
    gw = s.urls["api-gateway"]
    anon = Api(gw, registrar=False)
    falsas = {"X-Authenticated-User": "u-admin", "X-Authenticated-Username": "admin@elasador.cl", "X-Authenticated-Roles": "administrador",
              "X-Service-Name": "api-gateway", "X-Service-Secret": "cualquiera"}
    r = anon.get("/api/admin/orders", headers=falsas)
    anotar(c, "GET /api/admin/orders con cabeceras X-Authenticated-* y X-Service-* falsas", "navegador anónimo", "401 (el gateway las descarta; la identidad sale de la sesión)", r,
           prohibido(r, 401), "api-gateway (lista blanca de cabeceras)", "test_seguridad_acceso::test_cabeceras_de_identidad_enviadas_por_el_navegador_se_ignoran")
    # puertos publicados en el despliegue (análisis estático; docker compose no se ejecutó)
    compose = yaml.safe_load((RAIZ / "docker-compose.yml").read_text(encoding="utf-8"))
    publicados = {n: [str(p) for p in d.get("ports", [])] for n, d in compose["services"].items() if d.get("ports")}
    solo_loopback = all(p.startswith("127.0.0.1:") for ps in publicados.values() for p in ps)
    anotar(c, "docker-compose.yml: servicios con puertos publicados", "análisis estático del archivo (no se ejecutó docker compose)",
           "solo api-gateway y provider-sandbox, y solo hacia 127.0.0.1; red «interna» sin salida a Internet", None,
           set(publicados) == {"api-gateway", "provider-sandbox"} and solo_loopback and compose["networks"]["interna"].get("internal") is True,
           "Docker Compose (redes)", "test_despliegue::test_solo_el_gateway_y_el_proveedor_simulado_publican_puertos_y_solo_hacia_localhost",
           obtenido="; ".join(f"{n}: {', '.join(ps)}" for n, ps in sorted(publicados.items())) + "; interna: internal=true")


def caso6_pago_alterado(gw, s):
    c = "C6 Confirmar un pago con datos alterados del frontend"
    d = datos_registro()
    cli = Api(gw, registrar=False)
    cli.post("/api/clients/register", json=d)
    cli.login(d["correo"], d["clave"])
    # (a) intentar fijar el precio o el total en la creación del pedido
    r = cli.post("/api/orders", json={"items": [{"id": "p07", "cantidad": 1, "precio": 1}], "comuna": "Ñuñoa", "medioPago": "Servipag", "total": 1},
                 headers={"Idempotency-Key": uuid.uuid4().hex})
    anotar(c, "POST /api/orders con «precio»: 1 y «total»: 1 dentro del cuerpo", "cliente", "422 (campos no declarados se rechazan)", r, r.status_code == 422,
           "orders (modelo con extra=forbid; el precio sale del inventario)", "test_negocio_pedidos::test_un_precio_enviado_dentro_de_una_linea_se_rechaza")
    p = crear_pedido(cli, items=[{"id": "p07", "cantidad": 2}]).json()
    catalogo = {x["id"]: x["precio"] for x in Api(gw, registrar=False).get("/api/products?limit=100").json()}
    anotar(c, "POST /api/orders (pedido legítimo): ¿quién fija el total?", "cliente", "el total lo calcula el servidor con los precios del inventario", None,
           p["total"] == catalogo["p07"] * 2 + p["despacho"] and p["estado"] == "Pago pendiente", "orders + inventory", "test_negocio_pedidos::test_el_servidor_calcula_el_total_y_el_navegador_no_puede_fijarlo",
           obtenido=f"total {p['total']} = 2 × {catalogo['p07']} + despacho {p['despacho']}; estado «{p['estado']}»")
    # (b) intentar cambiar el estado o confirmar a mano desde el navegador
    for metodo, ruta, cuerpo in (("PUT", f"/api/orders/{p['id']}", {"estado": "En preparación"}), ("PUT", f"/api/admin/orders/{p['id']}/status", {"estado": "En preparación"}),
                                 ("POST", f"/api/admin/orders/{p['id']}/payment-confirmation", {"referencia": "TRF-1"}),
                                 ("POST", f"/api/orders/{p['id']}/payment-confirmed", {"pagoId": "x", "monto": p["total"]})):
        r = cli.pedir(metodo, ruta, json=cuerpo)
        anotar(c, f"{metodo} {ruta.replace(p['id'], '{pedido}')}", "cliente", "4xx (no es su operación o la ruta no existe en el gateway)", r, r.status_code in (400, 403, 404, 405),
               "api-gateway / payments", "test_negocio_pagos::test_un_cliente_no_puede_marcar_su_pedido_como_pagado")
    pago = iniciar_pago(cli, p["id"])
    # (c) aviso del proveedor falsificado
    cuerpo, cab = aviso(s, "payment.succeeded", pago)
    sin_firma = {k: v for k, v in cab.items() if k != "X-Provider-Signature"}
    r = enviar_aviso(gw, cuerpo, sin_firma)
    anotar(c, "POST /api/webhooks/provider sin firma", "anónimo", "400 AVISO_NO_VALIDO", r, prohibido(r, 400, "AVISO_NO_VALIDO"), "payments (firma HMAC del proveedor)",
           "test_negocio_pagos::test_aviso_sin_firma_o_con_firma_falsa_se_rechaza")
    r = enviar_aviso(gw, *aviso(s, "payment.succeeded", pago, secreto="clave-inventada-por-el-atacante"))
    anotar(c, "POST /api/webhooks/provider firmado con una clave inventada", "atacante", "400 AVISO_NO_VALIDO", r, prohibido(r, 400, "AVISO_NO_VALIDO"), "payments",
           "test_negocio_pagos::test_aviso_sin_firma_o_con_firma_falsa_se_rechaza")
    c2, cab2 = aviso(s, "payment.failed", pago)
    r = enviar_aviso(gw, c2.replace(b"payment.failed", b"payment.succeeded"), cab2)
    anotar(c, "POST /api/webhooks/provider con el cuerpo alterado después de firmar", "atacante", "400 AVISO_NO_VALIDO", r, prohibido(r, 400, "AVISO_NO_VALIDO"), "payments",
           "test_negocio_pagos::test_aviso_alterado_despues_de_firmar_se_rechaza")
    r = enviar_aviso(gw, *aviso(s, "payment.succeeded", pago, t=int(time.time()) - 3600))
    anotar(c, "POST /api/webhooks/provider con firma válida pero de hace 1 hora (repetición)", "atacante", "400 AVISO_NO_VALIDO (ventana de 300 s)", r,
           prohibido(r, 400, "AVISO_NO_VALIDO"), "payments", "test_negocio_pagos::test_aviso_antiguo_o_del_futuro_se_rechaza")
    r = enviar_aviso(gw, *aviso(s, "payment.succeeded", pago, monto=1))
    anotar(c, "POST /api/webhooks/provider firmado correctamente pero con monto 1", "quien conozca la clave de firma", "409 MONTO_NO_COINCIDE", r,
           prohibido(r, 409, "MONTO_NO_COINCIDE"), "payments (compara con el monto fijado por orders)", "test_negocio_pagos::test_aviso_con_monto_distinto_no_aprueba_el_pago")
    # (d) volver del proveedor con «pago aprobado» en la dirección
    r = cli.get(f"/api/orders/{p['id']}?pago=aprobado")
    anotar(c, "GET /api/orders/{pedido}?pago=aprobado (como al volver del proveedor)", "cliente", "el estado sigue «Pago pendiente»", r,
           r.status_code == 200 and r.json()["estado"] == "Pago pendiente", "orders (el estado solo cambia por payment-confirmed)",
           "test_negocio_pagos::test_volver_del_proveedor_con_pago_aprobado_en_la_url_no_paga_nada")
    estado = estado_pedido(cli, p["id"])
    cobro = cli.get(f"/api/orders/{p['id']}/payment").json()["estado"]
    anotar(c, "estado final tras todos los intentos", "—", "«Pago pendiente» y cobro «iniciado»", None, estado == "Pago pendiente" and cobro == "iniciado",
           "orders + payments", "test_negocio_pagos::test_un_cliente_no_puede_marcar_su_pedido_como_pagado", obtenido=f"pedido «{estado}»; cobro «{cobro}»")
    # (e) control: el aviso legítimo (firma, ventana y monto correctos) sí aprueba, una sola vez
    r1 = enviar_aviso(gw, *aviso(s, "payment.succeeded", pago))
    esperar(lambda: estado_pedido(cli, p["id"]) == "En preparación", mensaje="el aviso legítimo no avanzó el pedido")
    anotar(c, "POST /api/webhooks/provider legítimo (control)", "proveedor", "200 y el pedido pasa a «En preparación»", r1, r1.status_code == 200, "payments → orders",
           "test_negocio_pagos::test_aviso_firmado_legitimo_aprueba_una_sola_vez_aunque_se_repita", obtenido=f"{r1.status_code}; pedido «{estado_pedido(cli, p['id'])}»")


# ======================================================================================================================
def modulo8_agregacion(s, gw, personal):
    c = "M8 Agregación GraphQL ejecutada desde la pantalla"
    d = datos_registro()
    cli = Api(gw, registrar=False)
    cli.post("/api/clients/register", json=d)
    cli.login(d["correo"], d["clave"])
    for _ in range(3):
        crear_pedido(cli, items=[{"id": "p07", "cantidad": 1}, {"id": "p02", "cantidad": 1}])
    p = crear_pedido(cli, items=[{"id": "p07", "cantidad": 1}], medio="Servipag").json()
    pago = iniciar_pago(cli, p["id"])
    pagar_en_proveedor(pago["checkoutUrl"])
    esperar(lambda: estado_pedido(cli, p["id"]) == "En preparación", mensaje="el pedido no pasó a «En preparación»")
    consulta = consulta_del_frontend("CONSULTA_PEDIDOS")
    rid = "agregacion-" + uuid.uuid4().hex[:8]
    r = cli.post("/api/graphql", json={"query": consulta, "variables": {"desde": 0}}, headers={"X-Request-ID": rid})
    items = r.json()["data"]["misPedidos"]["items"]
    pagado = next(i for i in items if i["id"] == p["id"])
    llamadas = {srv: [l["ruta"] for l in llamadas_registradas(s, srv, rid)] for srv in ("api-gateway", "graphql-gateway", "orders", "payments", "inventory")}
    una_vez = all(len(llamadas[k]) == 1 for k in ("api-gateway", "graphql-gateway", "orders", "payments"))
    anotar(c, "POST /api/graphql con la consulta EXACTA de pedidos.js (pedido + pago + boleta + líneas)", "cliente con 4 pedidos, 1 pagado",
           "200 con datos de orders y payments (pedido + pago + boleta); cada servicio recibe UNA llamada para los 4 pedidos", r,
           r.status_code == 200 and "errors" not in r.json() and pagado["pago"]["estado"] == "aprobado" and pagado["boleta"]["folio"].startswith("B-")
           and una_vez and llamadas["inventory"] == [],
           "graphql-gateway (DataLoader por solicitud)", "test_graphql::test_una_consulta_pide_cada_servicio_una_sola_vez_sin_problema_n_mas_1",
           obtenido=f"200; {len(items)} pedidos; pedido pagado: pago «{pagado['pago']['estado']}», boleta {pagado['boleta']['folio']}; llamadas por servicio: "
                    + ", ".join(f"{k}={len(v)}" for k, v in llamadas.items()))
    FILAS[-1]["detalle"] = {"consulta": consulta, "llamadas": llamadas, "respuesta": {"misPedidos": {"total": r.json()["data"]["misPedidos"]["total"], "items": [pagado]}}}
    # panel del administrador: orders + inventory + payments en una sola consulta
    rid2 = "agregacion-" + uuid.uuid4().hex[:8]
    panel = ("query Panel { panelAdmin { pedidosPorEstado { estado cantidad } productos { activos agotados } "
             "pagos { pagosManualesPorConfirmar reembolsosPendientes } } }")
    r = personal["administrador"].post("/api/graphql", json={"query": panel}, headers={"X-Request-ID": rid2})
    ll2 = {srv: [l["ruta"] for l in llamadas_registradas(s, srv, rid2)] for srv in ("api-gateway", "graphql-gateway", "orders", "payments", "inventory")}
    datos = (r.json().get("data") or {}).get("panelAdmin") or {}
    anotar(c, "POST /api/graphql con la consulta del panel de admin.js (pedidos por estado + productos + pagos)", "administrador",
           "200 con datos de TRES servicios: orders, inventory y payments", r,
           r.status_code == 200 and "errors" not in r.json() and {"pedidosPorEstado", "productos", "pagos"} <= set(datos)
           and all(len(ll2[k]) >= 1 for k in ("orders", "inventory", "payments")), "graphql-gateway (agrega tres servicios sin acceder a sus bases)",
           "test_graphql::test_el_panel_del_pie_pide_cada_dato_a_su_servicio",
           obtenido="200; llamadas por servicio: " + ", ".join(f"{k}={len(v)}" for k, v in ll2.items()))
    FILAS[-1]["detalle2"] = {"consulta": panel, "llamadas": ll2, "respuesta": datos}
    # campos que el rol no autoriza
    r = personal["dueno"].gql("{ pedidosAdmin(limit: 1) { items { id cliente { correo telefono direccion } } } }")
    anotar(c, "GraphQL pedidosAdmin { cliente { correo telefono direccion } }", "dueño", "PROHIBIDO; ningún dato personal en la respuesta", r,
           "PROHIBIDO" in _resumen(r) and "@" not in r.text and "telefono\": \"+" not in r.text, "graphql-gateway (permiso por campo)",
           "test_graphql::test_el_dueno_no_alcanza_ningun_pedido_ni_dato_personal_por_graphql")
    r = cli.gql("{ panelAdmin { pagos { iniciados } } }")
    anotar(c, "GraphQL panelAdmin { pagos { iniciados } }", "cliente", "panelAdmin nulo y PROHIBIDO", r, r.json().get("data") == {"panelAdmin": None} and "PROHIBIDO" in _resumen(r),
           "graphql-gateway", "test_graphql::test_el_panel_para_un_cliente_es_nulo_y_prohibido")
    r = cli.gql('{ misPedidos(clienteId: "c-0002") { items { id } } }')
    anotar(c, "GraphQL misPedidos(clienteId: …) (pedir los de otro cliente por argumento)", "cliente", "CONSULTA_INVALIDA (el argumento no existe)", r,
           "CONSULTA_INVALIDA" in _resumen(r), "graphql-gateway (esquema)", "test_graphql::test_no_existe_ningun_argumento_para_pedir_pedidos_de_otro_cliente")
    r = cli.gql("{ __schema { types { name } } }")
    anotar(c, "GraphQL introspección { __schema … }", "cliente", "CONSULTA_INVALIDA sin publicar el esquema", r,
           r.json().get("data") is None and "CONSULTA_INVALIDA" in _resumen(r) and "misPedidos" not in r.text and "pedidosAdmin" not in r.text, "graphql-gateway (DisableIntrospection)",
           "test_graphql::test_la_introspeccion_esta_desactivada")
    r = cli.gql("query{ misPedidos(limit:1){ items{ lineas{ a{ b{ c{ d{ e } } } } } } } }")
    anotar(c, "GraphQL con anidamiento de más de 6 niveles", "cliente", "rechazada antes de ejecutarse (profundidad máxima 6)", r,
           r.json().get("data") is None and any("depth" in e["message"] for e in r.json().get("errors", [])), "graphql-gateway (QueryDepthLimiter)", "test_graphql::test_profundidad_maxima")
    alias = "query{ " + " ".join(f"a{i}: misPedidos(limit:1){{ total }}" for i in range(11)) + " }"
    r = cli.gql(alias)
    anotar(c, "GraphQL con 11 alias de la misma consulta", "cliente", "rechazada (máximo 10 alias)", r, r.json().get("data") is None and "11 aliases" in r.text, "graphql-gateway (MaxAliasesLimiter)",
           "test_graphql::test_maximo_de_alias")
    # acceso directo al GraphQL Gateway desde fuera
    r = llamar_servicio(s, "graphql-gateway", "POST", "/graphql", como="api-gateway", sin_credencial=True, json={"query": "{ __typename }"})
    anotar(c, "POST graphql-gateway/graphql directo, sin credencial de servicio", "ninguna", "403 LLAMADOR_NO_PERMITIDO", r, prohibido(r, 403, "LLAMADOR_NO_PERMITIDO"), "graphql-gateway (guardia de servicio)",
           "test_seguridad_acceso::test_servicio_privado_rechaza_llamadas_sin_credencial")


# ======================================================================================================================
def informe(entorno, segundos):
    total, buenos = len(FILAS), sum(1 for f in FILAS if f["ok"])
    casos = []
    for f in FILAS:
        if f["caso"] not in casos:
            casos.append(f["caso"])
    celda = lambda t: str(t).replace("|", "\\|").replace("\n", " ")   # noqa: E731
    md = ["# Evidencia de ejecución: casos de validación del módulo 7 y agregación del módulo 8", "",
          f"Generado por `scripts/verificar_controles.py` el {entorno['fecha']}. {buenos} de {total} verificaciones cumplieron lo esperado ({segundos:.0f} s).", "",
          f"**Entorno:** {entorno['sistema']}; Python {entorno['python']}; {entorno['servidores']}.", "",
          "Cada fila es una solicitud HTTP real contra el sistema levantado como procesos (gateway, auth, clients, inventory, orders, payments, notifications, analytics y GraphQL Gateway). "
          "La columna «prueba» indica la prueba automática que protege la misma regla en la suite (`tests/`).", ""]
    for caso in casos:
        md += [f"## {caso}", "", "| # | Entrada | Identidad | Resultado esperado | Resultado obtenido | Componente que lo verifica | Prueba automática | ✓ |", "|---|---|---|---|---|---|---|---|"]
        for n, f in enumerate([x for x in FILAS if x["caso"] == caso], 1):
            md.append(f"| {n} | {celda(f['entrada'])} | {celda(f['identidad'])} | {celda(f['esperado'])} | {celda(f['obtenido'])} | {celda(f['componente'])} | `{celda(f['prueba'])}` | {'✓' if f['ok'] else '✗'} |")
        md.append("")
    det = next((f["detalle"] for f in FILAS if "detalle" in f), None)
    if det:
        md += ["## Detalle de la agregación (consulta de `pedidos.js`)", "", "Consulta enviada por la pantalla «Mis pedidos»:", "", "```graphql", det["consulta"], "```", "",
               "Servicios que atendieron esa solicitud (por identificador de correlación) y rutas internas que recibieron:", "", "```json", json.dumps(det["llamadas"], ensure_ascii=False, indent=1), "```", "",
               "Parte de la respuesta (el pedido pagado):", "", "```json", json.dumps(det["respuesta"], ensure_ascii=False, indent=1), "```", ""]
    det2 = next((f["detalle2"] for f in FILAS if "detalle2" in f), None)
    if det2:
        md += ["## Detalle de la agregación de tres servicios (panel de `admin.js`)", "", "```graphql", det2["consulta"], "```", "",
               "Rutas internas que recibió cada servicio por esa solicitud:", "", "```json", json.dumps(det2["llamadas"], ensure_ascii=False, indent=1), "```", "",
               "Respuesta:", "", "```json", json.dumps(det2["respuesta"], ensure_ascii=False, indent=1), "```", ""]
    return "\n".join(md), {"entorno": entorno, "total": total, "cumplidas": buenos, "filas": [{k: v for k, v in f.items() if k not in ("detalle", "detalle2")} for f in FILAS]}


def main():
    t0 = time.time()
    with Stack(tempfile.mkdtemp(prefix="asador-controles-"), extra_env=ENTORNO) as s:
        gw = s.urls["api-gateway"]
        personal = {}
        for rol, usuario, clave in (("administrador", "admin@elasador.cl", "admin123"), ("dueno", "dueno@elasador.cl", "dueno123"), ("despacho", "despacho@elasador.cl", "despacho123")):
            api = Api(gw, registrar=False)
            assert api.login(usuario, clave).status_code == 200, rol
            personal[rol] = api
        caso1_catalogo_anonimo(gw)
        caso2_sin_sesion(gw, s)
        # el cliente del caso 4 también sirve de «cliente que intenta administrar» en el caso 3
        cliente, pedido = caso4_pedido_ajeno(gw, personal)
        producto = {"nombre": f"Producto no autorizado {uuid.uuid4().hex[:6]}", "categoria": "bebidas", "precio": 1000, "descripcion": "x", "imagen": "img/cerveza.svg"}
        caso3_rol_sin_permiso(gw, personal, cliente, pedido["id"], producto)
        caso3b_segunda_capa(s)
        caso5_acceso_directo(s)
        caso6_pago_alterado(gw, s)
        modulo8_agregacion(s, gw, personal)
        servidores = "Vault y MongoDB reales" if os.environ.get("ASADOR_REAL") == "1" else "Vault falso y MongoDB simulado en memoria (mongomock)"
    entorno = {"fecha": datetime.now(ZoneInfo("America/Santiago")).strftime("%Y-%m-%d %H:%M"), "sistema": platform.platform(), "python": platform.python_version(), "servidores": servidores}
    # el orden de casos del informe sigue la pauta: C1..C6 y luego M8
    orden = ["C1", "C2", "C3", "C4", "C5", "C6", "M8"]
    FILAS.sort(key=lambda f: orden.index(f["caso"].split()[0]))
    md, js = informe(entorno, time.time() - t0)
    DESTINO.mkdir(parents=True, exist_ok=True)
    (DESTINO / "controles.md").write_text(md, encoding="utf-8")
    (DESTINO / "controles.json").write_text(json.dumps(js, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    print(f"{js['cumplidas']}/{js['total']} verificaciones cumplidas → docs/evidencia/controles.md")
    return 0 if js["cumplidas"] == js["total"] else 1


if __name__ == "__main__":
    sys.exit(main())
