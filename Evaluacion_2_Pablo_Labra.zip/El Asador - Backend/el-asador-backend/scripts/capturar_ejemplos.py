#!/usr/bin/env python3
"""Captura UN ejemplo real (petición y respuesta) de cada servicio S01–S38 y lo guarda en docs/ejemplos/S##.json.

Levanta el sistema completo como procesos reales (tests/stack.py: MongoDB simulado y Vault falso por omisión; con ASADOR_REAL=1 y
ASADOR_BIN=<carpeta con vault y mongod>, servidores de verdad), recorre los flujos principales por HTTP como lo haría el navegador y
escribe lo que el sistema contestó. No se inventa ninguna respuesta. Se enmascara lo secreto: valores de cookie, contraseñas y firmas.

  python scripts/capturar_ejemplos.py
"""
import json
import re
import sys
import tempfile
import uuid
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "tests"))
sys.path.insert(0, str(RAIZ))
from ayuda import (Api, aviso, consulta_del_frontend, crear_pedido, datos_registro, enviar_aviso, esperar, estado_pedido,  # noqa: E402
                   hoy_santiago, iniciar_pago, pagar_en_proveedor, sumar_dias)
from stack import Stack  # noqa: E402

DESTINO = RAIZ / "docs" / "ejemplos"
ENTORNO = {"RL_GENERAL": "1000000", "RL_LOGIN": "100000", "RL_REGISTRO": "100000", "RL_FORMULARIOS": "100000", "RL_GRAPHQL": "1000000",
           "RL_WEBHOOK": "1000000", "REINTENTO_SEGUNDOS": "1"}
CAMPOS_SECRETOS = {"password", "clave", "passwordHash"}
CABECERAS_PETICION = ("content-type", "idempotency-key", "origin", "x-provider-event-id", "x-provider-signature")
CABECERAS_RESPUESTA = ("content-type", "cache-control", "x-total-count", "x-request-id", "set-cookie", "retry-after")


def _limpiar(valor):
    if isinstance(valor, dict):
        return {k: ("«secreto»" if k in CAMPOS_SECRETOS and isinstance(v, str) else _limpiar(v)) for k, v in valor.items()}
    if isinstance(valor, list):
        return [_limpiar(v) for v in valor[:3]] + (["…"] if len(valor) > 3 else [])   # un ejemplo no necesita las 100 filas
    return valor


def _cuerpo(contenido):
    if not contenido:
        return None
    try:
        return _limpiar(json.loads(contenido))
    except (ValueError, UnicodeDecodeError):
        return "«cuerpo no JSON»"


def _cookie(valor):
    return re.sub(r"(session_token=)[^;]+", r"\1«valor secreto»", valor)


class Capturador:
    def __init__(self):
        self.ejemplos = {}

    def __call__(self, sid, r, esperado=None):
        if esperado is not None and r.status_code != esperado:
            raise SystemExit(f"{sid}: se esperaba {esperado} y llegó {r.status_code}: {r.text[:300]}")
        peticion = r.request
        ruta = peticion.url.raw_path.decode()
        cabs_p = {k: ("«firma HMAC»" if k == "x-provider-signature" else v) for k, v in peticion.headers.items() if k.lower() in CABECERAS_PETICION}
        cabs_r = {k: (_cookie(v) if k.lower() == "set-cookie" else v) for k, v in r.headers.items() if k.lower() in CABECERAS_RESPUESTA}
        self.ejemplos[sid] = {"id": sid, "peticion": {"metodo": peticion.method, "ruta": ruta, "cabeceras": cabs_p, "cuerpo": _cuerpo(peticion.content)},
                              "respuesta": {"estado": r.status_code, "cabeceras": cabs_r, "cuerpo": _cuerpo(r.content)}}
        return r


def main():
    cap = Capturador()
    with Stack(tempfile.mkdtemp(prefix="asador-ejemplos-"), extra_env=ENTORNO) as s:
        gw = s.urls["api-gateway"]
        anon = Api(gw, registrar=False)
        # ---- públicos ----
        cap("S04", anon.get("/api/products?limit=3"), 200)
        cap("S05", anon.get("/api/promos"), 200)
        cap("S20", anon.get("/api/delivery-zones"), 200)
        cfg = cap("S27", anon.get("/api/event-config"), 200).json()
        cap("S28", anon.post("/api/event-quotes", json={
            "nombre": "Evento Prueba", "correo": "evento@correo.cl", "fecha": sumar_dias(hoy_santiago(), 20), "personas": 40,
            "menu": cfg["menus"][0]["id"], "bebidas": True, "ensaladas": True, "parrillero": True, "comuna": "Providencia"}), 201)
        cap("S36", anon.post("/api/contact-messages", json={"nombre": "Persona Contacto", "correo": "contacto@correo.cl", "asunto": "Sugerencia",
                                                             "mensaje": "Me gustaría sugerir más opciones vegetarianas en la carta."}), 201)
        # ---- cliente ----
        d = datos_registro()
        c = Api(gw, registrar=False)
        cap("S10", c.post("/api/clients/register", json=d), 201)
        cap("S01", c.login(d["correo"], d["clave"]), 200)
        cap("S03", c.get("/api/auth/me"), 200)
        cap("S11", c.get("/api/clients/me"), 200)
        pedido = cap("S21", crear_pedido(c, items=[{"id": "p07", "cantidad": 1}], medio="Servipag"), 201).json()
        cap("S22", c.get("/api/orders?limit=3"), 200)
        cap("S23", c.get(f"/api/orders/{pedido['id']}"), 200)
        pago = cap("S29", c.post(f"/api/orders/{pedido['id']}/payment"), 201).json()
        cap("S30", c.get(f"/api/orders/{pedido['id']}/payment"), 200)
        pagar_en_proveedor(pago["checkoutUrl"])
        esperar(lambda: estado_pedido(c, pedido["id"]) == "En preparación", mensaje="el pedido no pasó a «En preparación»")
        boleta = esperar(lambda: (lambda x: x if x.status_code == 200 else None)(c.get(f"/api/orders/{pedido['id']}/receipt")), mensaje="no se emitió la boleta")
        cap("S31", boleta, 200)
        consulta = consulta_del_frontend("CONSULTA_PEDIDOS")
        cap("S38", c.post("/api/graphql", json={"query": consulta, "variables": {"desde": 0}}), 200)
        # aviso firmado del proveedor (S35) sobre otro pedido cuyo cobro sigue iniciado
        p2 = crear_pedido(c, items=[{"id": "p07", "cantidad": 1}], medio="Servipag").json()
        pago2 = iniciar_pago(c, p2["id"])
        cuerpo, cabeceras = aviso(s, "payment.succeeded", pago2)
        cap("S35", enviar_aviso(gw, cuerpo, cabeceras), 200)
        # ---- administración ----
        a = Api(gw, registrar=False)
        a.login("admin@elasador.cl", "admin123")
        despacho = Api(gw, registrar=False)
        despacho.login("despacho@elasador.cl", "despacho123")
        cap("S12", a.get("/api/clients?limit=3"), 200)
        run = datos_registro()["run"]
        local = cap("S13", a.post("/api/clients", json={"run": run, "nombre": "Cliente Del Local", "correo": f"local{uuid.uuid4().hex[:6]}@correo.cl",
                                                         "telefono": "+56 9 5555 4444", "direccion": "Av. Siempre Viva 742", "comuna": "Santiago"}), 201).json()
        cap("S14", a.put(f"/api/clients/{local['id']}", json={"nombre": "Nombre Corregido", "telefono": "+56 9 8888 7777", "direccion": "Calle Nueva 456",
                                                               "comuna": "Providencia"}), 200)
        cap("S15", a.delete(f"/api/clients/{local['id']}"), 200)
        producto = {"nombre": f"Producto prueba {uuid.uuid4().hex[:6]}", "categoria": "bebidas", "precio": 2500,
                    "descripcion": "Producto creado para el ejemplo.", "imagen": "img/cerveza.svg"}
        nuevo = cap("S06", a.post("/api/products", json=producto), 201).json()
        cap("S07", a.put(f"/api/products/{nuevo['id']}", json={**producto, "precio": 2700}), 200)
        cap("S08", a.put(f"/api/products/{nuevo['id']}/availability", json={"disponible": False}), 200)
        cap("S09", a.delete(f"/api/products/{nuevo['id']}"), 200)
        cap("S16", a.get("/api/users?limit=3"), 200)
        u = cap("S17", a.post("/api/users", json={"username": f"persona{uuid.uuid4().hex[:6]}@elasador.cl", "nombre": "Persona De Prueba", "rol": "despacho",
                                                  "password": "Clave-Segura-2026"}), 201).json()
        cap("S18", a.put(f"/api/users/{u['id']}", json={"nombre": "Persona Renombrada", "rol": "despacho", "activo": True}), 200)
        cap("S19", a.delete(f"/api/users/{u['id']}"), 200)
        cap("S25", a.get("/api/admin/orders?limit=3"), 200)
        cap("S26", despacho.put(f"/api/admin/orders/{pedido['id']}/status", json={"estado": "En camino"}), 200)
        cap("S34", a.get("/api/admin/payments?limit=3"), 200)
        # pago manual: confirmación del administrador, anulación del cliente y reembolso
        p3 = crear_pedido(c, items=[{"id": "p07", "cantidad": 1}], medio="Transferencia bancaria").json()
        iniciar_pago(c, p3["id"])
        cap("S32", a.post(f"/api/admin/orders/{p3['id']}/payment-confirmation", json={"referencia": "TRF-100200"}), 200)
        esperar(lambda: estado_pedido(c, p3["id"]) == "En preparación", mensaje="el pago manual no movió el pedido")
        cap("S24", c.post(f"/api/orders/{p3['id']}/cancellation", json={"motivo": "Ya no lo necesito"}), 200)
        esperar(lambda: c.get(f"/api/orders/{p3['id']}").json().get("reembolso") == "pendiente", mensaje="no quedó reembolso pendiente")
        cap("S33", a.post(f"/api/admin/orders/{p3['id']}/refund", json={"referencia": "REEMB-0001"}), 200)
        cap("S37", a.get("/api/admin/outbox?limit=3"), 200)
        cap("S02", c.post("/api/auth/logout"), 200)
    DESTINO.mkdir(parents=True, exist_ok=True)
    for sid, ej in sorted(cap.ejemplos.items()):
        (DESTINO / f"{sid}.json").write_text(json.dumps(ej, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    print(f"{len(cap.ejemplos)} ejemplos escritos en {DESTINO.relative_to(RAIZ)}")


if __name__ == "__main__":
    main()
