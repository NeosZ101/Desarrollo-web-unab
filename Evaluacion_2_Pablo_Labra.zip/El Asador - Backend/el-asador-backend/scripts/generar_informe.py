#!/usr/bin/env python3
"""Arma docs/INFORME.md a partir de docs/informe/INFORME.plantilla.md.

La plantilla es texto escrito a mano (decisiones, razones, límites declarados). Todo lo que describe el sistema se incrusta desde archivos que
generan otros scripts a partir del código o de ejecuciones reales, así el informe describe la implementación ENTREGADA y no una idea de ella.

Marcas que entiende (una por línea):
  {{incluir ruta [nivel=N] [hasta="## Título"] [sin_titulo=1]}}   contenido de un .md de docs/ (los títulos se bajan a nivel N y los enlaces se reescriben)
  {{mermaid diagramas/01-dominio.mmd}}                           el diagrama como bloque ```mermaid
  {{ejemplo S21}}                                                petición y respuesta capturadas de un servicio (docs/ejemplos/S21.json)
  {{codigo ruta [lenguaje]}}                                     un archivo del repositorio como bloque de código
  {{resumen_pruebas}}                                            totales de las ejecuciones guardadas en docs/evidencia/
  {{clasificacion_de_datos}}                                     tabla de clases de datos y las rutas S## de cada una (sale de api-gateway/app/rutas.py)

  python scripts/generar_informe.py            # escribe docs/INFORME.md
  python scripts/generar_informe.py --revisar  # solo comprueba que está al día
"""
import importlib.util
import json
import os
import re
import shlex
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
DOCS = RAIZ / "docs"
PLANTILLA = DOCS / "informe" / "INFORME.plantilla.md"
SALIDA = DOCS / "INFORME.md"
MARCA = re.compile(r"^\{\{(\w+)\s*(.*?)\}\}\s*$")


def _enlaces(texto, origen):
    """Los enlaces relativos del archivo incluido se reescriben para que sigan funcionando desde docs/INFORME.md."""
    def cambiar(m):
        destino = m.group(2)
        if destino.startswith(("http://", "https://", "#", "mailto:")):
            return m.group(0)
        ruta, _, ancla = destino.partition("#")
        nuevo = os.path.relpath((origen.parent / ruta).resolve(), DOCS).replace(os.sep, "/")
        return f"{m.group(1)}({nuevo}{'#' + ancla if ancla else ''})"
    return re.sub(r"(\[[^\]]*\])\(([^)\s]+)\)", cambiar, texto)


def _bajar_titulos(texto, nivel):
    lineas, salida, dentro, primero = texto.splitlines(), [], False, None
    for linea in lineas:
        if linea.startswith("```"):
            dentro = not dentro
        m = re.match(r"^(#+)\s", linea)
        if m and not dentro:
            if primero is None:
                primero = len(m.group(1))
            linea = "#" * max(1, min(6, len(m.group(1)) - primero + nivel)) + linea[len(m.group(1)):]
        salida.append(linea)
    return "\n".join(salida)


def incluir(ruta, nivel=None, hasta=None, sin_titulo=None, desde=None):
    origen = DOCS / ruta
    texto = origen.read_text(encoding="utf-8").rstrip("\n")
    if desde:
        if "\n" + desde not in "\n" + texto:
            raise SystemExit(f"{ruta}: no existe la línea «{desde}»")
        texto = ("\n" + texto).split("\n" + desde, 1)[1]
        texto = desde + texto
    if hasta:
        if "\n" + hasta not in texto + "\n":
            raise SystemExit(f"{ruta}: no existe la línea «{hasta}»")
        texto = texto.split("\n" + hasta, 1)[0]
    if sin_titulo:
        texto = re.sub(r"^# .*\n+", "", texto, count=1)
    texto = _enlaces(texto, origen)
    return _bajar_titulos(texto, int(nivel)) if nivel else texto


def mermaid(ruta):
    return "```mermaid\n" + (DOCS / ruta).read_text(encoding="utf-8").rstrip("\n") + "\n```"


def ejemplo(sid):
    ej = json.loads((DOCS / "ejemplos" / f"{sid}.json").read_text(encoding="utf-8"))
    p, r = ej["peticion"], ej["respuesta"]
    cuerpo_p = f"\n{json.dumps(p['cuerpo'], ensure_ascii=False, indent=2)}" if p["cuerpo"] is not None else ""
    cuerpo_r = f"\n{json.dumps(r['cuerpo'], ensure_ascii=False, indent=2)}" if r["cuerpo"] is not None else ""
    return (f"**{sid}** · petición\n\n```http\n{p['metodo']} {p['ruta']}\n" + "".join(f"{k}: {v}\n" for k, v in p["cabeceras"].items()).rstrip("\n")
            + f"{cuerpo_p}\n```\n\nrespuesta\n\n```http\nHTTP {r['estado']}\n" + "".join(f"{k}: {v}\n" for k, v in r["cabeceras"].items()).rstrip("\n")
            + f"{cuerpo_r}\n```")


def codigo(ruta, lenguaje=""):
    return f"```{lenguaje}\n" + (RAIZ / ruta).read_text(encoding="utf-8").rstrip("\n") + "\n```"


def _junit(nombre):
    ruta = DOCS / "evidencia" / nombre
    if not ruta.exists():
        return None
    cuenta = {"ok": 0, "falla": 0, "omitida": 0}
    por_modulo = {}
    for tc in ET.parse(ruta).getroot().iter("testcase"):
        e = "falla" if (tc.find("failure") is not None or tc.find("error") is not None) else "omitida" if tc.find("skipped") is not None else "ok"
        cuenta[e] += 1
        m = tc.attrib["classname"].split(".")[-1].removeprefix("test_")
        por_modulo.setdefault(m, {"ok": 0, "falla": 0, "omitida": 0})[e] += 1
    return cuenta, por_modulo


def resumen_pruebas():
    simulado, real = _junit("junit_simulado.xml"), _junit("junit_real.xml")
    L = ["| Ejecución | Pruebas | Pasaron | Fallaron | Omitidas |", "|---|---|---|---|---|"]
    for nombre, datos in (("Con Vault y MongoDB **simulados** (por omisión)", simulado), ("Con HashiCorp Vault y MongoDB **reales** (sin Docker)", real)):
        if datos is None:
            L.append(f"| {nombre} | sin ejecución guardada | | | |")
            continue
        c = datos[0]
        L.append(f"| {nombre} | {sum(c.values())} | {c['ok']} | {c['falla']} | {c['omitida']} |")
    if simulado:
        modulos = sorted(simulado[1])
        L += ["", "| Archivo de pruebas | Simulado: pasaron / omitidas | Reales: pasaron / omitidas |", "|---|---|---|"]
        for m in modulos:
            s = simulado[1][m]
            r = real[1].get(m) if real else None
            L.append(f"| `test_{m}.py` | {s['ok']} / {s['omitida']} | " + (f"{r['ok']} / {r['omitida']}" if r else "—") + " |")
    con = DOCS / "evidencia" / "controles.json"
    if con.exists():
        d = json.loads(con.read_text(encoding="utf-8"))
        L += ["", f"**Casos de validación del módulo 7 y evidencia del módulo 8:** {d['cumplidas']} de {d['total']} verificaciones cumplieron "
              f"([detalle](evidencia/controles.md))."]
    return "\n".join(L)


CLASES = [("publico", "Público", "Información que ya es pública o que no identifica a nadie: carta, promociones, zonas de despacho, cierre de sesión.",
           "Sin sesión (lectura); la escritura del catálogo exige rol."),
          ("personal", "Personal", "Identifica a una persona pero con bajo daño si se filtra: nombre y correo de un usuario, de una cotización o de un mensaje de contacto.",
           "Sesión o validación de formulario; no se registra completo en los logs."),
          ("restringido", "Restringido", "Datos de clientes, pedidos, pagos, boletas, reembolsos, bandeja de salida y reportes: solo su dueño o los roles que los necesitan.",
           "Sesión, rol y pertenencia comprobados en el gateway y en el servicio; acceso a la base solo con el usuario del servicio."),
          ("secreto", "Secreto", "Credenciales: la contraseña al iniciar sesión o crear un usuario. (Los secretos de infraestructura no pasan por ninguna ruta pública: ver el inventario de secretos.)",
           "Nunca se guarda en claro (argon2id), no se registra en logs ni se devuelve en respuestas.")]


def clasificacion_de_datos():
    spec = importlib.util.spec_from_file_location("rutas_informe", RAIZ / "api-gateway" / "app" / "rutas.py")
    modulo = importlib.util.module_from_spec(spec)
    sys.modules["rutas_informe"] = modulo
    spec.loader.exec_module(modulo)
    L = ["| Clase | Qué incluye | Servicios públicos que la transportan | Protección |", "|---|---|---|---|"]
    for clave, nombre, que, como in CLASES:
        ids = [r.id for r in modulo.RUTAS if r.datos == clave]
        L.append(f"| **{nombre}** | {que} | {', '.join(ids)} ({len(ids)}) | {como} |")
    sin_clase = [r.id for r in modulo.RUTAS if r.datos not in {c[0] for c in CLASES}]
    if sin_clase:
        raise SystemExit(f"rutas con una clasificación de datos desconocida: {sin_clase}")
    return "\n".join(L)


def generar():
    salida = []
    for linea in PLANTILLA.read_text(encoding="utf-8").splitlines():
        m = MARCA.match(linea)
        if not m:
            salida.append(linea)
            continue
        nombre, resto = m.group(1), shlex.split(m.group(2))
        posicionales = [x for x in resto if "=" not in x]
        nombrados = dict(x.split("=", 1) for x in resto if "=" in x)
        if nombre == "incluir":
            salida.append(incluir(posicionales[0], **nombrados))
        elif nombre == "mermaid":
            salida.append(mermaid(posicionales[0]))
        elif nombre == "ejemplo":
            salida.append(ejemplo(posicionales[0]))
        elif nombre == "codigo":
            salida.append(codigo(*posicionales))
        elif nombre == "clasificacion_de_datos":
            salida.append(clasificacion_de_datos())
        elif nombre == "resumen_pruebas":
            salida.append(resumen_pruebas())
        else:
            raise SystemExit(f"marca desconocida en la plantilla: {linea}")
    return "\n".join(salida) + "\n"


def main():
    texto = generar()
    if "--revisar" in sys.argv:
        ok = SALIDA.exists() and SALIDA.read_text(encoding="utf-8") == texto
        print("al día" if ok else "DESACTUALIZADO: ejecuta python scripts/generar_informe.py")
        return 0 if ok else 1
    SALIDA.write_text(texto, encoding="utf-8")
    print(f"escrito {SALIDA.relative_to(RAIZ)} ({len(texto.splitlines())} líneas)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
