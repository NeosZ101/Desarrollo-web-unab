#!/usr/bin/env python3
"""Prueba de carga de la analítica: ingesta de ventas y reporte de ventas, con CPU y memoria medidos.

Sirve para decidir con DATOS (y no con intuición) si basta HTTP/JSON entre servicios o si hace falta gRPC/streaming:
ver docs/adr/ADR-004-analitica-grpc.md. No afirma nada que no haya medido: todo número del informe sale de esta ejecución.

Qué mide
  1. Carga inicial de N ventas (por defecto 30.000, repartidas en 90 días): ingesta a alta concurrencia.
  2. Reporte de ventas de 30 y de 92 días directamente contra analytics, y de punta a punta (navegador -> gateway -> auth ->
     GraphQL gateway -> analytics) con la sesión de un dueño. Se miden ANTES de la ingesta, con exactamente las N ventas indicadas.
  3. Ingesta sostenida: eventos «venta registrada» nuevos con 1, 4, 16 y 64 clientes simultáneos durante D segundos (la base crece).
  4. Reentrega: el mismo evento muchas veces en paralelo (idempotencia bajo carga) y comprobación de que el total no cambia.
  5. Los reportes de punta a punta otra vez con 1 y 4 clientes, ya con la base crecida por el paso 3.
  Para cada caso: solicitudes, rendimiento (req/s), p50/p95/p99 en milisegundos, errores, y CPU y memoria de cada servicio.

Dónde corre
  --modo pruebas   (por defecto) levanta el sistema con los mismos procesos que usan las pruebas automáticas (tests/stack.py): cada
                   servicio en su propio proceso uvicorn y MongoDB SIMULADO EN MEMORIA (mongomock). Sirve para medir el código de los
                   servicios, no el rendimiento de MongoDB: el informe lo declara así.
  --modo externo   mide un sistema ya levantado (p. ej. docker compose con docker-compose.carga.yml, que publica analytics y Vault
                   solo en 127.0.0.1). Hay que indicar las URL y los secretos (variables SECRETO_PAYMENTS_ANALYTICS,
                   SECRETO_GRAPHQL_ANALYTICS y CLAVE_DUENO); CPU y memoria de procesos del anfitrión con --pid servicio=PID, o a mano
                   con `docker stats`. (Este modo NO se ejecutó en el entorno de desarrollo, que no tiene Docker.)

Uso:
    python scripts/load_test.py                          # ~6 minutos, escribe docs/evidencia/carga.md y carga.json
    python scripts/load_test.py --ventas 5000 --duracion 5   # versión rápida para probar el script
"""
import argparse
import asyncio
import json
import os
import platform
import random
import statistics
import sys
import tempfile
import threading
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import httpx

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "tests"))
HZ = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100

PRODUCTOS = ["Parrillada para 2", "Costillar de cerdo", "Pollo a las brasas", "Choripán", "Ensalada mixta", "Papas rústicas", "Bebida 1,5 L",
             "Cerveza artesanal", "Promo familiar", "Anticuchos", "Lomo vetado", "Longaniza", "Postre del día"]
MEDIOS = ["Servipag", "Transferencia bancaria", "Depósito bancario"]
COMUNAS = ["Ñuñoa", "Providencia", "Las Condes", "Santiago", "Puente Alto", "La Florida", "Macul", "Peñalolén"]


# Objetivos declarados ANTES de medir (ver docs/adr/ADR-004-analitica-grpc.md): (descripción, caso, concurrencia máxima, métrica, tope)
OBJETIVOS = [
    ("Ingesta de una venta: p95 ≤ 100 ms con hasta 16 emisores simultáneos", "Ingesta de ventas (analytics)", 16, "p95_ms", 100),
    ("Reporte de 30 días de punta a punta (navegador→gateway→auth→GraphQL→analytics): p95 ≤ 1.000 ms con hasta 4 usuarios simultáneos",
     "Reporte de ventas 30 días, de punta a punta (GraphQL)", 4, "p95_ms", 1000),
    ("Reporte de 92 días (el máximo permitido) de punta a punta: p95 ≤ 2.000 ms con hasta 4 usuarios simultáneos",
     "Reporte de ventas 92 días (máximo), de punta a punta (GraphQL)", 4, "p95_ms", 2000),
    ("Sin errores en ningún caso con hasta 4 clientes simultáneos", None, 4, "errores", 0),
]


def evaluar_objetivos(resultados):
    filas = []
    for descripcion, caso, c_max, metrica, tope in OBJETIVOS:
        rs = [r for r in resultados if r["concurrencia"] <= c_max and (caso is None or r["caso"] == caso)]
        peor = max((r[metrica] for r in rs), default=None)
        filas.append((descripcion, peor, tope, peor is not None and peor <= tope))
    return filas


# ----------------------------- medición ------------------------------------------------------------
def percentil(ordenados, p):
    if not ordenados:
        return 0.0
    k = min(len(ordenados) - 1, max(0, round(p / 100 * len(ordenados) + 0.5) - 1))
    return ordenados[k]


class Muestreador(threading.Thread):
    """Lee cada medio segundo el CPU y la memoria de los procesos indicados (/proc). CPU en % de UN núcleo (200 % = dos núcleos llenos)."""

    def __init__(self, pids):
        super().__init__(daemon=True)
        self.pids, self.fin = pids, threading.Event()
        self.datos = {n: {"cpu": [], "rss": []} for n in pids}

    @staticmethod
    def _tiempo(pid):
        with open(f"/proc/{pid}/stat") as f:
            c = f.read().rsplit(")", 1)[1].split()
        return (int(c[11]) + int(c[12])) / HZ   # utime + stime, en segundos

    @staticmethod
    def _rss_mb(pid):
        with open(f"/proc/{pid}/status") as f:
            for linea in f:
                if linea.startswith("VmRSS:"):
                    return int(linea.split()[1]) / 1024
        return 0.0

    def run(self):
        previo = {}
        t_prev = time.monotonic()
        for n, pid in self.pids.items():
            previo[n] = self._tiempo(pid)
        while not self.fin.wait(0.5):
            ahora = time.monotonic()
            for n, pid in self.pids.items():
                try:
                    t = self._tiempo(pid)
                    self.datos[n]["cpu"].append(100 * (t - previo[n]) / (ahora - t_prev))
                    self.datos[n]["rss"].append(self._rss_mb(pid))
                    previo[n] = t
                except (OSError, IndexError, ValueError):
                    pass
            t_prev = ahora

    def resumen(self):
        return {n: {"cpu_promedio": round(statistics.mean(d["cpu"]), 1) if d["cpu"] else None, "cpu_maximo": round(max(d["cpu"]), 1) if d["cpu"] else None,
                    "memoria_maxima_mb": round(max(d["rss"]), 1) if d["rss"] else None} for n, d in self.datos.items()}


async def recuperar(sonda, tope=90.0, buenas_seguidas=3):
    """Tras una sobrecarga espera a que el sistema vuelva a contestar bien (el cortacircuitos se cierra solo y el trabajo atrasado termina).
    Devuelve los segundos que tardó, o None si no se recuperó dentro del tope. Así cada caso parte de un sistema en reposo y no hereda el anterior."""
    inicio, buenas = time.monotonic(), 0
    while time.monotonic() - inicio < tope:
        try:
            ok, _ = await sonda()
        except (httpx.HTTPError, OSError):
            ok = False
        buenas = buenas + 1 if ok else 0
        if buenas >= buenas_seguidas:
            return round(time.monotonic() - inicio, 1)
        await asyncio.sleep(0.5)
    return None


async def ejecutar(nombre, hacer, concurrencia, segundos, pids=None, calentamiento=1.0):
    """Lanza `concurrencia` clientes que llaman a `hacer()` en bucle durante `segundos`. Devuelve las métricas del caso."""
    latencias, errores, motivos = [], 0, {}
    parar = time.monotonic() + calentamiento + segundos
    inicio_medida = time.monotonic() + calentamiento
    muestreo = Muestreador(pids) if pids else None
    if muestreo:
        muestreo.start()

    async def cliente():
        nonlocal errores
        while time.monotonic() < parar:
            t0 = time.perf_counter()
            try:
                ok, motivo = await hacer()
            except (httpx.HTTPError, OSError) as e:
                ok, motivo = False, type(e).__name__
            dt = (time.perf_counter() - t0) * 1000
            if time.monotonic() >= inicio_medida:
                latencias.append(dt)
                if not ok:
                    errores += 1
                    motivos[motivo] = motivos.get(motivo, 0) + 1

    t0 = time.monotonic()
    await asyncio.gather(*(cliente() for _ in range(concurrencia)))
    real = max(time.monotonic() - max(t0, inicio_medida), 0.001)
    if muestreo:
        muestreo.fin.set()
        muestreo.join()
    lat = sorted(latencias)
    return {"caso": nombre, "concurrencia": concurrencia, "duracion_s": round(real, 1), "solicitudes": len(lat), "errores": errores, "motivos_error": motivos,
            "rendimiento_rps": round(len(lat) / real, 1), "p50_ms": round(percentil(lat, 50), 1), "p95_ms": round(percentil(lat, 95), 1),
            "p99_ms": round(percentil(lat, 99), 1), "maximo_ms": round(lat[-1], 1) if lat else 0,
            "recursos": muestreo.resumen() if muestreo else {}}


# ----------------------------- datos ------------------------------------------------------------------
def evento_venta(n, dia):
    """Un evento «venta registrada» válido (neto + IVA = total; un folio, un evento)."""
    total = random.randint(8_000, 120_000)
    neto = (total * 100 + 119 // 2) // 119
    lineas = [{"itemId": f"p{random.randint(1, 13):02d}", "nombre": random.choice(PRODUCTOS), "cantidad": random.randint(1, 4), "subtotal": 0}
              for _ in range(random.randint(1, 5))]
    reparto = total // len(lineas)
    for l in lineas:
        l["subtotal"] = reparto
    folio = f"B-{n:06d}"
    return {"eventoId": f"venta:{folio}", "ventaId": folio, "pedidoId": f"A-{2000 + n}", "fecha": f"{dia}T20:15:00-03:00", "fechaLocal": dia,
            "total": total, "neto": neto, "iva": total - neto, "medio": random.choice(MEDIOS), "comuna": random.choice(COMUNAS), "lineas": lineas}


def dias_atras(hoy, k):
    return (hoy - timedelta(days=k)).isoformat()


# ----------------------------- entorno ---------------------------------------------------------------
def describir_entorno(modo, extra):
    cpu = "desconocido"
    try:
        for linea in open("/proc/cpuinfo"):
            if linea.startswith("model name"):
                cpu = linea.split(":", 1)[1].strip()
                break
    except OSError:
        pass
    mem = "desconocida"
    try:
        for linea in open("/proc/meminfo"):
            if linea.startswith("MemTotal"):
                mem = f"{int(linea.split()[1]) / 1048576:.1f} GB"
                break
    except OSError:
        pass
    import fastapi
    import uvicorn
    return {"modo": modo, "so": platform.platform(), "cpu": cpu, "nucleos": os.cpu_count(), "memoria_total": mem, "python": platform.python_version(),
            "uvicorn": uvicorn.__version__, "fastapi": fastapi.__version__, "generador_de_carga": "mismo equipo que los servicios (compite por CPU)", **extra}


def _version(binario, opcion):
    """Primera línea con versión de un binario de ASADOR_BIN (mongod/vault), para dejarla escrita en el entorno de la medición."""
    import subprocess
    try:
        ruta = Path(os.environ.get("ASADOR_BIN", "")) / binario
        salida = subprocess.run([str(ruta), opcion], capture_output=True, text=True, timeout=20).stdout
        return next((l.strip() for l in salida.splitlines() if l.strip()), "versión desconocida")
    except (OSError, subprocess.SubprocessError):
        return "versión desconocida"


# ----------------------------- escenarios --------------------------------------------------------------
async def correr(args):
    hoy_s = date.fromisoformat(datetime.now(ZoneInfo("America/Santiago")).strftime("%Y-%m-%d"))
    resultados, entorno_extra = [], {}
    pila = None
    pids = {}
    if args.modo == "pruebas":
        from conftest import ENTORNO
        from stack import Stack
        env = {k: v for k, v in ENTORNO.items() if k.startswith("RL_")}   # sin límites de tasa: se mide el sistema, no el limitador
        env["SEED_DEMO_DATA"] = "true"
        pila = Stack(tempfile.mkdtemp(prefix="asador-carga-"), extra_env=env)
        pila.iniciar()
        gateway, analytics = pila.urls["api-gateway"], pila.urls["analytics"]
        secreto_pagos = pila.secreto("svc/payments-to-analytics")
        pids = {n: pila.proceso(n).proc.pid for n in ("analytics", "graphql-gateway", "api-gateway", "auth", "payments")}
        if os.environ.get("ASADOR_REAL") == "1":
            pids["mongo"] = pila.proceso("mongo").proc.pid       # la base de datos también consume CPU: sin medirla no se sabe dónde se va el tiempo
        if os.environ.get("ASADOR_REAL") == "1":
            base = (f"MongoDB real ({_version('mongod', '--version')}) con autenticación y un usuario por servicio, en el mismo equipo, sin Docker; "
                    f"secretos en HashiCorp Vault real ({_version('vault', 'version')}) en modo desarrollo")
        else:
            base = "mongomock (MongoDB simulado en memoria, un proceso por servicio); NO es el rendimiento de MongoDB"
        entorno_extra = {"base_de_datos": base, "workers_por_servicio": 1, "servicios_medidos": sorted(pids)}
    else:
        gateway, analytics = args.gateway, args.analytics
        secreto_pagos = os.environ["SECRETO_PAYMENTS_ANALYTICS"]
        pids = {n: int(p) for n, p in (x.split("=") for x in args.pid)}
        entorno_extra = {"base_de_datos": args.base_de_datos, "workers_por_servicio": args.workers}
    cab_pagos = {"X-Service-Name": "payments", "X-Service-Secret": secreto_pagos}
    limites = httpx.Limits(max_connections=200, max_keepalive_connections=200)
    try:
        async with httpx.AsyncClient(timeout=30, limits=limites) as http:
            # --- 1) carga inicial -----------------------------------------------------------------
            print(f"Cargando {args.ventas} ventas en 90 días...", flush=True)
            contador = iter(range(1, 10_000_000))
            pendientes = args.ventas
            sem = asyncio.Semaphore(32)
            ok_carga = 0

            async def una(n):
                nonlocal ok_carga
                async with sem:
                    r = await http.post(analytics + "/internal/events/sale-registered", json=evento_venta(n, dias_atras(hoy_s, n % 90)), headers=cab_pagos)
                    ok_carga += r.status_code == 200
            t0 = time.monotonic()
            await asyncio.gather(*(una(next(contador)) for _ in range(pendientes)))
            seg = time.monotonic() - t0
            assert ok_carga == args.ventas, f"solo {ok_carga} de {args.ventas} ventas se cargaron"
            entorno_extra["carga_inicial"] = {"ventas": args.ventas, "segundos": round(seg, 1), "ventas_por_segundo": round(args.ventas / seg, 1)}
            print(f"  listo en {seg:.1f} s ({args.ventas / seg:.0f} ventas/s)", flush=True)

            # El orden importa: los reportes se miden PRIMERO, con exactamente las N ventas declaradas. La ingesta agrega más ventas a la base y,
            # si fuera antes, los reportes se medirían con una base mucho mayor que la que el informe dice. Al final se repiten con la base crecida.
            estado = {"ventas": args.ventas}      # ventas que hay en la base al empezar cada caso

            async def caso(nombre, hacer, c, segundos):
                al_empezar = estado["ventas"]
                r = await ejecutar(nombre, hacer, c, segundos, pids)
                r["ventas_en_base"] = al_empezar
                return r

            # --- 2) mensajes y consulta de totales ------------------------------------------------------------
            secreto_gql = pila.secreto("svc/graphql-gateway-to-analytics") if pila else os.environ["SECRETO_GRAPHQL_ANALYTICS"]

            def totales(desde, hasta):
                return http.get(analytics + "/internal/reports/sales", params={"desde": desde, "hasta": hasta},
                                headers={"X-Service-Name": "graphql-gateway", "X-Service-Secret": secreto_gql, "X-Authenticated-User": "u-dueno",
                                         "X-Authenticated-Username": "dueno@elasador.cl", "X-Authenticated-Roles": "dueno"})
            d1, d2 = dias_atras(hoy_s, 29), hoy_s.isoformat()
            # tamaño de los mensajes (para decidir si importa el formato: JSON frente a un formato binario)
            muestra = [len(json.dumps(evento_venta(i, d1), ensure_ascii=False).encode()) for i in range(1000)]
            entorno_extra["mensajes"] = {
                "evento_venta_bytes": {"promedio": round(statistics.mean(muestra)), "minimo": min(muestra), "maximo": max(muestra), "muestra": len(muestra)},
                "respuesta_reporte_30_dias_bytes": len((await totales(d1, d2)).content),
                "respuesta_reporte_92_dias_bytes": len((await totales(dias_atras(hoy_s, 91), hoy_s.isoformat())).content)}

            # --- 3) reportes directos contra analytics ----------------------------------------------------------
            for dias, etiqueta in ((30, "30 días"), (92, "92 días (máximo)")):
                for c in args.concurrencias[:3]:
                    desde = dias_atras(hoy_s, dias - 1)

                    def reporte(desde=desde):
                        async def f():
                            r = await totales(desde, hoy_s.isoformat())
                            return r.status_code == 200, f"http_{r.status_code}"
                        return f
                    resultados.append(await caso(f"Reporte de ventas {etiqueta}, directo a analytics", reporte(), c, args.duracion))
                    print("  ", resumen_linea(resultados[-1]), flush=True)

            # --- 4) reportes de punta a punta (navegador -> gateway -> auth -> GraphQL -> analytics) -------------------
            navegador = httpx.AsyncClient(base_url=gateway, timeout=30, limits=limites, headers={"Origin": gateway})
            try:
                if pila:
                    login = await navegador.post("/api/auth/login", json={"username": "dueno@elasador.cl", "password": "dueno123"})
                else:
                    login = await navegador.post("/api/auth/login", json={"username": args.usuario, "password": os.environ["CLAVE_DUENO"]})
                assert login.status_code == 200, login.text
                consulta = ("query Ventas($desde: String!, $hasta: String!) { reporteVentas(desde: $desde, hasta: $hasta) "
                            "{ dias { fecha pedidos ventas ticketPromedio } totales { ventas pedidos ticketPromedio mejorDia } "
                            "porMedioPago { medio pedidos ventas } topProductos { nombre unidades ventas } } }")

                async def sonda_reporte():
                    r = await navegador.post("/api/graphql", json={"query": consulta, "variables": {"desde": dias_atras(hoy_s, 6), "hasta": hoy_s.isoformat()}})
                    return r.status_code == 200 and "errors" not in r.json(), ""

                async def reportes_punta_a_punta(sufijo, concurrencias):
                    for dias, etiqueta in ((30, "30 días"), (92, "92 días (máximo)")):
                        for c in concurrencias:
                            variables = {"desde": dias_atras(hoy_s, dias - 1), "hasta": hoy_s.isoformat()}

                            async def punta_a_punta(variables=variables):
                                r = await navegador.post("/api/graphql", json={"query": consulta, "variables": variables})
                                cuerpo = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
                                if r.status_code == 200 and "errors" not in cuerpo:
                                    return True, ""
                                if r.status_code == 200:
                                    return False, "graphql:" + ",".join(sorted({e.get("extensions", {}).get("codigo", "?") for e in cuerpo["errors"]}))
                                return False, f"http_{r.status_code}:{cuerpo.get('codigo', '?')}"
                            resultados.append(await caso(f"Reporte de ventas {etiqueta}, de punta a punta (GraphQL){sufijo}", punta_a_punta, c, args.duracion))
                            print("  ", resumen_linea(resultados[-1]), flush=True)
                            # el trabajo que el gateway abandonó por plazo sigue corriendo en analytics y MongoDB: se espera a que el sistema quede en reposo
                            resultados[-1]["recuperacion_s"] = await recuperar(sonda_reporte) if resultados[-1]["errores"] else 0.0
                            await asyncio.sleep(3)

                await reportes_punta_a_punta("", args.concurrencias[:3])

                # --- 5) ingesta sostenida (agrega ventas a la base) -------------------------------------------------
                for c in args.concurrencias:
                    def ingesta():
                        async def f():
                            n = next(contador)
                            r = await http.post(analytics + "/internal/events/sale-registered", json=evento_venta(n, dias_atras(hoy_s, n % 90)), headers=cab_pagos)
                            if r.status_code == 200:
                                estado["ventas"] += 1
                            return r.status_code == 200, f"http_{r.status_code}"
                        return f
                    resultados.append(await caso("Ingesta de ventas (analytics)", ingesta(), c, args.duracion))
                    print("  ", resumen_linea(resultados[-1]), flush=True)

                # --- 6) reentrega idempotente -----------------------------------------------------------------------------
                antes = (await totales(d1, d2)).json()["totales"]
                repetido = evento_venta(900_001, dias_atras(hoy_s, 3))
                await http.post(analytics + "/internal/events/sale-registered", json=repetido, headers=cab_pagos)
                estado["ventas"] += 1
                despues_uno = (await totales(d1, d2)).json()["totales"]

                async def reentrega():
                    r = await http.post(analytics + "/internal/events/sale-registered", json=repetido, headers=cab_pagos)
                    return r.status_code == 200 and r.json().get("duplicado") is True, f"http_{r.status_code}"
                parcial = await caso("Reentrega del MISMO evento (idempotencia)", reentrega, 16, max(3, args.duracion // 2))
                despues_mil = (await totales(d1, d2)).json()["totales"]
                parcial["consistente"] = despues_uno == despues_mil and despues_uno["pedidos"] == antes["pedidos"] + 1
                resultados.append(parcial)
                print("  ", resumen_linea(parcial), "| totales sin cambios:", parcial["consistente"], flush=True)

                # --- 7) los reportes otra vez, ahora con la base crecida por la ingesta ----------------------------------------
                await reportes_punta_a_punta(" — con la base crecida", [1, 4])
            finally:
                await navegador.aclose()
    finally:
        if pila:
            pila.detener()
    return {"entorno": describir_entorno(args.modo, entorno_extra), "resultados": resultados,
            "parametros": {"ventas": args.ventas, "duracion_por_caso_s": args.duracion, "concurrencias": args.concurrencias}}


def resumen_linea(r):
    return (f"{r['caso'][:80]:<80} c={r['concurrencia']:<3} {r['rendimiento_rps']:>7} req/s  p50={r['p50_ms']:>7} p95={r['p95_ms']:>7} "
            f"p99={r['p99_ms']:>7} ms  errores={r['errores']}")


def escribir_informe(datos, ruta):
    e = datos["entorno"]
    L = ["# Prueba de carga de la analítica", "",
         "Generado por `scripts/load_test.py`. **Todos los números salen de esta ejecución.**", "", "## Entorno", ""]
    for k in ("modo", "so", "cpu", "nucleos", "memoria_total", "python", "uvicorn", "fastapi", "base_de_datos", "workers_por_servicio", "generador_de_carga"):
        if k in e:
            L.append(f"- **{k.replace('_', ' ')}**: {e[k]}")
    ci = e.get("carga_inicial", {})
    L += ["", "## Datos", "",
          f"- {ci.get('ventas', '?')} ventas vigentes repartidas en los últimos 90 días (cada una con 1 a 5 líneas); cargadas por la propia API de analytics "
          f"en {ci.get('segundos', '?')} s ({ci.get('ventas_por_segundo', '?')} ventas/s a 32 clientes simultáneos).",
          *([f"- Tamaño de los mensajes: evento «venta registrada» de {m['evento_venta_bytes']['promedio']} bytes en promedio "
             f"({m['evento_venta_bytes']['minimo']}–{m['evento_venta_bytes']['maximo']}, {m['evento_venta_bytes']['muestra']} eventos generados); "
             f"respuesta del reporte de {m['respuesta_reporte_30_dias_bytes']} bytes (30 días) y {m['respuesta_reporte_92_dias_bytes']} bytes (92 días)."]
            if (m := e.get("mensajes")) else []),
          "- **Orden de la medición:** primero se cargan las ventas indicadas y se miden los reportes con exactamente esa cantidad (columna «Ventas en la base al empezar»); "
          "después la ingesta sostenida agrega más ventas y, al final, los reportes se repiten (casos «con la base crecida») para ver cómo cambian con el volumen.",
          "- «Respuestas totales» cuenta también las respuestas de error, que son rápidas (un servicio que se rinde por plazo contesta de inmediato): "
          "la capacidad útil es la columna «Respuestas correctas».",
          f"- Duración de cada caso: {datos['parametros']['duracion_por_caso_s']} s (más 1 s de calentamiento que no se cuenta). "
          f"Concurrencias: {datos['parametros']['concurrencias']}.", "",
          "## Resultados", "",
          "| Caso | Ventas en la base al empezar | Clientes simultáneos | Solicitudes | Respuestas totales (req/s) | Respuestas correctas (req/s) | p50 (ms) | p95 (ms) | p99 (ms) | Máx (ms) | Errores | CPU analytics prom/máx (% de un núcleo) | Memoria analytics máx (MB) |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in datos["resultados"]:
        a = r["recursos"].get("analytics", {})
        buenas = round((r["solicitudes"] - r["errores"]) / r["duracion_s"], 1) if r["duracion_s"] else 0
        L.append(f"| {r['caso']} | {r.get('ventas_en_base', '-')} | {r['concurrencia']} | {r['solicitudes']} | {r['rendimiento_rps']} | {buenas} | {r['p50_ms']} | {r['p95_ms']} | {r['p99_ms']} | "
                 f"{r['maximo_ms']} | {r['errores']} | {a.get('cpu_promedio', '-')} / {a.get('cpu_maximo', '-')} | {a.get('memoria_maxima_mb', '-')} |")
    L += ["", "## CPU y memoria por servicio durante cada caso (promedio / máximo de CPU en % de un núcleo; memoria máxima en MB)", "",
          "| Caso | Clientes | " + " | ".join(sorted({n for r in datos["resultados"] for n in r["recursos"]})) + " |", "|---|---|" + "---|" * len({n for r in datos["resultados"] for n in r["recursos"]})]
    nombres = sorted({n for r in datos["resultados"] for n in r["recursos"]})
    for r in datos["resultados"]:
        celdas = []
        for n in nombres:
            x = r["recursos"].get(n, {})
            celdas.append(f"{x.get('cpu_promedio', '-')}/{x.get('cpu_maximo', '-')} · {x.get('memoria_maxima_mb', '-')} MB")
        L.append(f"| {r['caso']} | {r['concurrencia']} | " + " | ".join(celdas) + " |")
    con_error = [r for r in datos["resultados"] if r["errores"]]
    if con_error:
        L += ["", "## Errores (motivo de cada uno)", "",
              "`SERVICIO_NO_DISPONIBLE` es la respuesta de diseño cuando un servicio no contesta dentro de su plazo o el cortacircuitos está abierto (falla rápido en vez de acumular espera). "
              "La última columna son los segundos que tardó el sistema en volver a contestar bien (3 respuestas correctas seguidas) una vez terminada la carga.", "",
              "| Caso | Clientes | Errores de | Motivos | Segundos hasta recuperarse |", "|---|---|---|---|---|"]
        for r in con_error:
            rec = r.get("recuperacion_s")
            L.append(f"| {r['caso']} | {r['concurrencia']} | {r['errores']} de {r['solicitudes']} | "
                     + ", ".join(f"`{m}` ×{n}" for m, n in sorted(r["motivos_error"].items(), key=lambda x: -x[1]))
                     + f" | {'no aplica (caso directo)' if rec is None and 'directo' in r['caso'] else ('no se recuperó en 90 s' if rec is None else rec)} |")
    idem = [r for r in datos["resultados"] if "consistente" in r]
    if idem:
        L += ["", f"**Idempotencia bajo carga:** el mismo evento enviado {idem[0]['solicitudes']} veces en paralelo; los totales del reporte "
              f"{'NO cambiaron' if idem[0]['consistente'] else 'CAMBIARON (revisar)'} respecto de la primera entrega."]
    L += ["", "## Comparación con los objetivos declarados", "",
          "Los objetivos se fijaron antes de medir (ADR-004). «Medido» es el peor valor entre los casos y concurrencias que cubre cada objetivo.", "",
          "| Objetivo | Medido (peor caso) | Tope | Resultado |", "|---|---|---|---|"]
    for descripcion, peor, tope, ok in evaluar_objetivos(datos["resultados"]):
        L.append(f"| {descripcion} | {peor if peor is not None else 'sin datos'} | {tope} | {'✓ cumple' if ok else '✗ NO cumple'} |")
    L += ["", "## Cómo leer esto", "",
          "- Es una medición de ESTE entorno (sección «Entorno»). " + ("La base de datos es MongoDB real, así que el costo de las agregaciones es el de MongoDB; " if "real" in str(e.get("base_de_datos", "")).lower() and "mongomock" not in str(e.get("base_de_datos", "")) else "Con `mongomock` la base de datos vive en la memoria del propio proceso y NO representa el rendimiento de MongoDB; ")
          + "la red entre servicios es la del propio equipo (sin latencia de red real) y no se midió Docker.",
          "- Los datos son sintéticos (generados con semilla fija); el reparto de ventas y de productos no es el de un restaurante real.",
          "- El generador de carga corre en el mismo equipo y compite por CPU con los servicios: los resultados son un piso, no un techo.",
          "- Para repetirlo con Docker y MongoDB reales: `docker compose -f docker-compose.yml -f docker-compose.carga.yml up -d` y "
          "`python scripts/load_test.py --modo externo ...` (ver README).", ""]
    ruta.parent.mkdir(parents=True, exist_ok=True)
    ruta.write_text("\n".join(L), encoding="utf-8")
    ruta.with_suffix(".json").write_text(json.dumps(datos, ensure_ascii=False, indent=1), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--modo", choices=["pruebas", "externo"], default="pruebas")
    ap.add_argument("--ventas", type=int, default=30_000)
    ap.add_argument("--duracion", type=int, default=15, help="segundos de medición por caso")
    ap.add_argument("--concurrencias", type=int, nargs="+", default=[1, 4, 16, 64])
    ap.add_argument("--salida", default=str(RAIZ / "docs" / "evidencia" / "carga.md"))
    ap.add_argument("--gateway", default="http://127.0.0.1:8000")
    ap.add_argument("--analytics", default="http://127.0.0.1:8206")
    ap.add_argument("--usuario", default="dueno@elasador.cl")
    ap.add_argument("--base-de-datos", default="MongoDB 8.0 (docker compose)")
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--pid", action="append", default=[], metavar="servicio=PID", help="proceso a medir en el modo externo (repetible)")
    args = ap.parse_args()
    random.seed(20261104)
    datos = asyncio.run(correr(args))
    escribir_informe(datos, Path(args.salida))
    print("Informe:", args.salida)


if __name__ == "__main__":
    main()
