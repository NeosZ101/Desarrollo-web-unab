#!/usr/bin/env python3
"""Crea el archivo .env con TODOS los secretos que necesita el sistema, generados al azar en esta máquina.

  python scripts/bootstrap.py            # crea .env (si ya existe, solo agrega lo que falte; nunca cambia un valor existente)
  python scripts/bootstrap.py --mostrar  # además muestra los nombres de las variables (nunca sus valores)

Qué contiene .env
  VAULT_ROOT_TOKEN          token raíz del Vault de desarrollo; solo lo usa el trabajo de siembra (vault-seed)
  VAULT_TOKEN_<SERVICIO>    token propio de cada servicio: solo puede LEER los secretos que figuran para él en secrets/manifest.tsv
  MONGO_ROOT_PASSWORD       administrador de MongoDB (ningún servicio lo conoce)
  MONGO_PASS_<SERVICIO>     contraseña del usuario de base de datos de cada servicio (u_<servicio>, permisos solo sobre SU base)

El archivo se crea con permisos 600 y está en .gitignore. Los secretos de servicio a servicio, la clave del proveedor de pagos y la
clave de firma de los avisos NO están aquí: los genera scripts/seed_vault.py directamente dentro de Vault.
"""
import os
import secrets
import stat
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "scripts"))
import seed_vault  # noqa: E402  (reutiliza la lectura del inventario de secretos)

ENV = RAIZ / ".env"


def variables_necesarias():
    filas = seed_vault.leer_manifest()
    servicios = seed_vault.servicios(filas)
    bd = sorted({seed_vault.lista(f["consumidores"])[0] for f in filas if f["tipo"] == "credencial-bd"})
    nombres = ["VAULT_ROOT_TOKEN", "MONGO_ROOT_PASSWORD"]
    nombres += [seed_vault.variable("VAULT_TOKEN", s) for s in servicios]
    nombres += [seed_vault.variable("MONGO_PASS", s) for s in bd]
    return nombres


def leer_existente():
    valores = {}
    if ENV.exists():
        for linea in ENV.read_text(encoding="utf-8").splitlines():
            if linea.strip() and not linea.lstrip().startswith("#") and "=" in linea:
                nombre, valor = linea.split("=", 1)
                valores[nombre.strip()] = valor.strip()
    return valores


def main(argv):
    existentes = leer_existente()
    nuevos = {n: secrets.token_hex(24) for n in variables_necesarias() if n not in existentes}
    if nuevos:
        cabecera = "" if ENV.exists() else ("# Secretos locales de El Asador, generados por scripts/bootstrap.py. NO se versiona ni se comparte.\n"
                                            "# Para rotar el contenido de Vault usa scripts/seed_vault.py --rotar; para empezar de cero: docker compose down -v\n")
        fd = os.open(ENV, os.O_WRONLY | os.O_CREAT | os.O_APPEND, stat.S_IRUSR | stat.S_IWUSR)
        with os.fdopen(fd, "a", encoding="utf-8") as f:
            f.write(cabecera + "".join(f"{n}={v}\n" for n, v in nuevos.items()))
        os.chmod(ENV, stat.S_IRUSR | stat.S_IWUSR)
    print(f"{ENV.name}: {len(nuevos)} variables nuevas, {len(existentes)} ya existían (permisos 600)")
    if "--mostrar" in argv:
        print("Variables:", ", ".join(sorted({**existentes, **nuevos})))
    print("Siguiente paso:  docker compose up -d --build")


if __name__ == "__main__":
    main(sys.argv[1:])
