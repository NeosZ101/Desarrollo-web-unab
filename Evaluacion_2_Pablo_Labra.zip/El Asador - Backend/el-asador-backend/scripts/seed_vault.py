#!/usr/bin/env python3
"""Carga los secretos de El Asador en Vault y crea, por cada servicio, una política y un token
con permisos mínimos (solo puede LEER las rutas que figuran para él en secrets/manifest.tsv).

Qué hace
  1. Lee secrets/manifest.tsv (inventario simbólico: referencia, consumidores, verificadores).
  2. Para cada referencia que aún no existe en Vault genera un valor aleatorio de 256 bits
     (secrets.token_urlsafe). Las credenciales de base de datos usan la clave que ya recibió
     MongoDB (variable MONGO_PASS_<SERVICIO>, creada por scripts/bootstrap.py).
  3. Escribe una política por servicio y un token cuyo id viene de VAULT_TOKEN_<SERVICIO>.

Es idempotente: no pisa secretos existentes. Para rotar uno:  seed_vault.py --rotar svc/orders-to-clients
Nunca imprime valores de secretos ni tokens.

Variables de entorno: VAULT_ADDR, VAULT_ROOT_TOKEN, VAULT_TOKEN_<SERVICIO>, MONGO_PASS_<SERVICIO>
"""
import csv
import json
import os
import secrets
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

MANIFEST = Path(os.environ.get("SECRETS_MANIFEST", Path(__file__).resolve().parent.parent / "secrets" / "manifest.tsv"))
EXTERNOS = {"mongo", "smtp-externo"}   # consumidores/verificadores que no son servicios nuestros
OPCIONALES = {"email/smtp"}            # solo se crean si el operador entrega el valor real


def http(metodo, ruta, token, cuerpo=None):
    req = urllib.request.Request(os.environ["VAULT_ADDR"].rstrip("/") + ruta, method=metodo,
                                 data=json.dumps(cuerpo).encode() if cuerpo is not None else None,
                                 headers={"X-Vault-Token": token, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            texto = r.read().decode() or "{}"
            return r.status, json.loads(texto)
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode() or "{}")
        except ValueError:
            return e.code, {}


def esperar_vault(raiz, intentos=60):
    for n in range(1, intentos + 1):
        try:
            estado, _ = http("GET", "/v1/sys/health", raiz)
            if estado in (200, 429, 472, 473):
                return
        except OSError:
            pass
        print(f"Esperando a Vault ({n}/{intentos})", flush=True)
        time.sleep(1)
    sys.exit("Vault no respondió")


def leer_manifest():
    with open(MANIFEST, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f, delimiter="\t"))


def lista(texto):
    return [x for x in texto.split(",") if x]


def servicios(filas):
    s = set()
    for f in filas:
        s.update(lista(f["consumidores"]))
        s.update(lista(f["verificadores"]))
    return sorted(s - EXTERNOS)


def variable(prefijo, servicio):
    return f"{prefijo}_{servicio.upper().replace('-', '_')}"


def politicas_del_token(raiz, token):
    """Políticas de un token que ya existe (None si no existe). Se pregunta en vez de adivinar por el texto de un error."""
    estado, cuerpo = http("POST", "/v1/auth/token/lookup", raiz, {"token": token})
    return (cuerpo.get("data") or {}).get("policies") if estado == 200 else None


def valor_nuevo(fila):
    ref = fila["ref"]
    if ref in OPCIONALES:
        return None
    campos = lista(fila["campos"])
    if fila["tipo"] == "credencial-bd":
        servicio = lista(fila["consumidores"])[0]
        clave = os.environ.get(variable("MONGO_PASS", servicio))
        if not clave:
            sys.exit(f"Falta {variable('MONGO_PASS', servicio)} (ejecuta scripts/bootstrap.py)")
        return {"user": f"u_{servicio}", "password": clave}
    return {c: secrets.token_urlsafe(32) for c in campos}


def main(argv):
    rotar = set()
    if "--rotar" in argv:
        rotar = set(argv[argv.index("--rotar") + 1:])
    raiz = os.environ["VAULT_ROOT_TOKEN"]
    esperar_vault(raiz)
    filas = leer_manifest()

    creados = existentes = 0
    for fila in filas:
        ref = fila["ref"]
        estado, _ = http("GET", f"/v1/secret/data/asador/{ref}", raiz)
        if estado == 200 and ref not in rotar:
            existentes += 1
            continue
        datos = valor_nuevo(fila)
        if datos is None:
            continue
        estado, _ = http("POST", f"/v1/secret/data/asador/{ref}", raiz, {"data": datos})
        if estado not in (200, 204):
            sys.exit(f"No se pudo escribir {ref} (HTTP {estado})")
        creados += 1
    print(f"Secretos: {creados} escritos, {existentes} ya existían")

    for servicio in servicios(filas):
        rutas = [f["ref"] for f in filas if servicio in lista(f["consumidores"]) + lista(f["verificadores"])]
        politica = {"path": {f"secret/data/asador/{r}": {"capabilities": ["read"]} for r in rutas}}
        estado, _ = http("PUT", f"/v1/sys/policies/acl/{servicio}", raiz, {"policy": json.dumps(politica)})
        if estado not in (200, 204):
            sys.exit(f"No se pudo escribir la política de {servicio} (HTTP {estado})")
        token = os.environ.get(variable("VAULT_TOKEN", servicio))
        if not token:
            sys.exit(f"Falta {variable('VAULT_TOKEN', servicio)} (ejecuta scripts/bootstrap.py)")
        existente = politicas_del_token(raiz, token)
        if existente is None:
            estado, _ = http("POST", "/v1/auth/token/create", raiz, {
                "id": token, "policies": [servicio], "no_default_policy": True, "no_parent": True,
                "renewable": False, "ttl": "720h", "display_name": servicio})
            if estado not in (200, 204):
                sys.exit(f"No se pudo crear el token de {servicio} (HTTP {estado})")
        elif set(existente) - {"default"} != {servicio}:   # alguien creó ese token a mano con otros permisos: no se acepta en silencio
            sys.exit(f"El token de {servicio} ya existe con políticas inesperadas ({', '.join(existente)}). Revócalo y vuelve a ejecutar.")
        print(f"Servicio {servicio}: política con {len(rutas)} rutas de lectura y token propio{' (ya existía)' if existente is not None else ''}")
    print("Vault listo")


if __name__ == "__main__":
    main(sys.argv[1:])
