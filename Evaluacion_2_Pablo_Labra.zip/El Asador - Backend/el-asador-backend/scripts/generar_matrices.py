#!/usr/bin/env python3
"""Genera las matrices del informe a partir del CÓDIGO y las compara con el contrato versionado.

  python scripts/generar_matrices.py              # verifica: falla si el código ya no coincide con tests/contratos/*.json
  python scripts/generar_matrices.py --escribir   # acepta los cambios: reescribe el contrato y las tablas de docs/matrices/

El contrato (tests/contratos/*.json) es la fotografía APROBADA de quién puede llamar a qué. Las pruebas lo usan como criterio
independiente: si alguien amplía un rol o un llamador en el código, las pruebas fallan hasta que el cambio se apruebe a propósito
aquí (y quede a la vista en el control de versiones).
"""
import argparse
import dataclasses
import importlib.util
import json
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "tests"))
import analisis_codigo as codigo  # noqa: E402

CONTRATOS = RAIZ / "tests" / "contratos"


def cargar_rutas():
    spec = importlib.util.spec_from_file_location("rutas_gateway", RAIZ / "api-gateway" / "app" / "rutas.py")
    modulo = importlib.util.module_from_spec(spec)
    sys.modules["rutas_gateway"] = modulo
    spec.loader.exec_module(modulo)
    return modulo


def _lista(v):
    return list(v) if isinstance(v, (tuple, list)) else v


def contrato_gateway():
    """Cada fila de la tabla RUTAS del API Gateway, tal cual (listas en lugar de tuplas para poder guardarla como JSON)."""
    salida = []
    for r in cargar_rutas().RUTAS:
        salida.append({k: _lista(v) if not isinstance(v, tuple) or not v or not isinstance(v[0], tuple) else [list(x) for x in v]
                       for k, v in dataclasses.asdict(r).items()})
    return salida


def contrato_servicios():
    """Cada ruta de cada servicio privado con sus llamadores permitidos, si exige identidad y qué roles."""
    salida = []
    for r in codigo.todas_las_rutas_privadas():
        llamadores, identidad, roles = r.guardia if r.guardia else (None, None, None)
        salida.append({"servicio": r.servicio, "metodo": r.metodo, "ruta": r.ruta, "llamadores": sorted(llamadores) if llamadores else llamadores,
                       "identidad": identidad, "roles": sorted(roles) if roles is not None else None})
    return sorted(salida, key=lambda f: (f["servicio"], f["ruta"], f["metodo"]))


def pares_de_servicios():
    return [list(p) for p in sorted(codigo.pares_aceptados())]


def contratos_actuales():
    return {"rutas_gateway": contrato_gateway(), "rutas_servicios": contrato_servicios(), "pares_de_servicios": pares_de_servicios()}


def texto(dato):
    return json.dumps(dato, ensure_ascii=False, indent=1, sort_keys=True) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--escribir", action="store_true")
    a = ap.parse_args()
    actuales = contratos_actuales()
    if a.escribir:
        CONTRATOS.mkdir(parents=True, exist_ok=True)
        for nombre, dato in actuales.items():
            (CONTRATOS / f"{nombre}.json").write_text(texto(dato), encoding="utf-8")
        print("Contrato reescrito:", ", ".join(sorted(actuales)))
        return 0
    distintos = [n for n, d in actuales.items() if not (CONTRATOS / f"{n}.json").exists() or (CONTRATOS / f"{n}.json").read_text(encoding="utf-8") != texto(d)]
    if distintos:
        print("El código ya no coincide con el contrato aprobado:", ", ".join(distintos), "\nRevisa el cambio y, si es intencional, ejecuta con --escribir.")
        return 1
    print("El código coincide con el contrato aprobado.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
