"""Lee el CÓDIGO de los servicios (sin ejecutarlos) y devuelve el contrato de cada ruta: entrada, salida y errores.

Lo usan scripts/generar_documentos.py (matrices del informe) y las pruebas que verifican que el informe sigue
describiendo la implementación. Nada de esto se escribe a mano: si el código cambia, el documento cambia.
"""
import ast
import sys
from dataclasses import dataclass, field
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "tests"))
import analisis_codigo as codigo  # noqa: E402

METODOS = ("get", "post", "put", "delete", "patch")


def _txt(nodo):
    return ast.unparse(nodo) if nodo is not None else ""


def _const(nodo):
    return nodo.value if isinstance(nodo, ast.Constant) else None


@dataclass
class Campo:
    nombre: str
    tipo: str
    reglas: str = ""
    obligatorio: bool = True


@dataclass
class ContratoRuta:
    servicio: str
    metodo: str
    ruta: str
    funcion: str
    estado_ok: int = 200
    cuerpo: str = ""                               # nombre del modelo de entrada
    campos_cuerpo: list = field(default_factory=list)
    parametros: list = field(default_factory=list)  # de ruta y de consulta: Campo
    errores: list = field(default_factory=list)     # (status, codigo)
    cabeceras: list = field(default_factory=list)   # cabeceras que el handler lee (Idempotency-Key, ...)


def _restricciones(valor):
    """Texto corto de lo que dice Field(...)/Query(...): rangos, largos, patrón."""
    if not isinstance(valor, ast.Call):
        return "", True, ""
    kw = {k.arg: k.value for k in valor.keywords if k.arg}
    partes, obligatorio, defecto = [], True, ""
    if valor.args and not (isinstance(valor.args[0], ast.Constant) and valor.args[0].value is Ellipsis):
        obligatorio, defecto = False, _txt(valor.args[0])
    if "default" in kw or "default_factory" in kw:
        obligatorio, defecto = False, _txt(kw.get("default") or kw.get("default_factory"))
    if "min_length" in kw or "max_length" in kw:
        partes.append(f"largo {_txt(kw.get('min_length')) or 0}–{_txt(kw.get('max_length')) or '∞'}")
    for k, simbolo in (("ge", "≥"), ("gt", ">"), ("le", "≤"), ("lt", "<")):
        if k in kw:
            partes.append(f"{simbolo} {_txt(kw[k])}")
    if "pattern" in kw:
        partes.append(f"formato {_txt(kw['pattern'])}")
    return ", ".join(partes), obligatorio, defecto


def _modelos(servicio):
    """Clases pydantic del servicio -> lista de Campo."""
    salida = {}
    for archivo in sorted((RAIZ / codigo.SERVICIOS[servicio]).rglob("*.py")):
        if "__pycache__" in archivo.parts:
            continue
        clases = [n for n in ast.walk(ast.parse(archivo.read_text(encoding="utf-8"))) if isinstance(n, ast.ClassDef)]
        propios = {}   # nombre -> campos declarados en la propia clase
        bases = {}
        for n in clases:
            campos = []
            for x in n.body:
                if isinstance(x, ast.AnnAssign) and isinstance(x.target, ast.Name):
                    reglas, obligatorio, defecto = _restricciones(x.value)
                    if x.value is not None and not isinstance(x.value, ast.Call):
                        obligatorio, defecto = False, _txt(x.value)
                    campos.append(Campo(x.target.id, _txt(x.annotation), reglas, obligatorio))
            propios[n.name], bases[n.name] = campos, [_txt(b) for b in n.bases]

        def es_modelo(nombre, visto=()):
            return nombre in propios and nombre not in visto and any(b == "BaseModel" or es_modelo(b, visto + (nombre,)) for b in bases[nombre])

        def todos_los_campos(nombre):   # primero los de la clase base, como los ve pydantic
            heredados = [c for b in bases[nombre] if b in propios for c in todos_los_campos(b)]
            return heredados + propios[nombre]

        for nombre in propios:
            if es_modelo(nombre):
                salida[nombre] = todos_los_campos(nombre)
    return salida


def _funciones(servicio):
    """nombre -> nodo, para todas las funciones (también las anidadas) de todos los archivos del servicio."""
    salida = {}
    for archivo in sorted((RAIZ / codigo.SERVICIOS[servicio]).rglob("*.py")):
        if "__pycache__" in archivo.parts:
            continue
        for n in ast.walk(ast.parse(archivo.read_text(encoding="utf-8"))):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                salida.setdefault(n.name, n)
    return salida


def _errores_directos(nodo):
    salida = set()
    for n in ast.walk(nodo):
        if isinstance(n, ast.Call) and _txt(n.func) == "ErrorNegocio" and len(n.args) >= 2:
            estado, cod = _const(n.args[0]), _const(n.args[1])
            if isinstance(estado, int) and isinstance(cod, str):
                salida.add((estado, cod))
    return salida


def _llamadas(nodo):
    return {n.func.id for n in ast.walk(nodo) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)}


def _errores(nodo, funciones, visitadas=None):
    visitadas = visitadas if visitadas is not None else set()
    salida = set(_errores_directos(nodo))
    for nombre in _llamadas(nodo):
        if nombre in funciones and nombre not in visitadas:
            visitadas.add(nombre)
            salida |= _errores(funciones[nombre], funciones, visitadas)
    return salida


def _cabeceras(nodo):
    """Cabeceras que lee el handler: Header(alias=...) o request.headers.get("...")."""
    salida = set()
    for n in ast.walk(nodo):
        if isinstance(n, ast.Call) and _txt(n.func) == "Header":
            for k in n.keywords:
                if k.arg == "alias" and _const(k.value):
                    salida.add(_const(k.value))
        if isinstance(n, ast.Call) and _txt(n.func).endswith("headers.get") and n.args and _const(n.args[0]):
            salida.add(_const(n.args[0]))
    return sorted(salida)


def contratos(servicio):
    modelos, funciones = _modelos(servicio), _funciones(servicio)
    salida = []
    for archivo in sorted((RAIZ / codigo.SERVICIOS[servicio]).rglob("*.py")):
        if "__pycache__" in archivo.parts:
            continue
        for n in ast.walk(ast.parse(archivo.read_text(encoding="utf-8"))):
            if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for d in n.decorator_list:
                if not (isinstance(d, ast.Call) and isinstance(d.func, ast.Attribute) and isinstance(d.func.value, ast.Name)
                        and d.func.value.id == "app" and d.func.attr in METODOS and d.args and _const(d.args[0])):
                    continue
                c = ContratoRuta(servicio, d.func.attr.upper(), _const(d.args[0]), n.name)
                for k in d.keywords:
                    if k.arg == "status_code" and isinstance(_const(k.value), int):
                        c.estado_ok = _const(k.value)
                args = n.args.args + n.args.kwonlyargs
                defaults = [None] * (len(n.args.args) - len(n.args.defaults)) + list(n.args.defaults) + list(n.args.kw_defaults)
                for a, v in zip(args, defaults):
                    anot = _txt(a.annotation)
                    if a.arg in ("request", "response", "ll", "self") or "Depends" in _txt(v) or anot in ("Request", "Response"):
                        continue
                    if anot in modelos:
                        c.cuerpo, c.campos_cuerpo = anot, modelos[anot]
                        continue
                    if "Header" in _txt(v):
                        continue
                    reglas, obligatorio, _ = _restricciones(v) if isinstance(v, ast.Call) else ("", v is None, "")
                    c.parametros.append(Campo(a.arg, anot, reglas, obligatorio))
                c.errores = sorted(_errores(n, funciones))
                c.cabeceras = _cabeceras(n)
                salida.append(c)
    return salida


def todos():
    """{(servicio, METODO, ruta): ContratoRuta} de los servicios que atienden a otros (no incluye el gateway)."""
    salida = {}
    for s in codigo.SERVICIOS:
        try:
            for c in contratos(s):
                salida[(c.servicio, c.metodo, c.ruta)] = c
        except FileNotFoundError:
            continue
    return salida


if __name__ == "__main__":
    for (s, m, r), c in sorted(todos().items()):
        print(f"{s:16} {m:6} {r:48} {c.estado_ok} cuerpo={c.cuerpo or '-'} params={[p.nombre for p in c.parametros]} err={[f'{a}:{b}' for a, b in c.errores][:6]}")
