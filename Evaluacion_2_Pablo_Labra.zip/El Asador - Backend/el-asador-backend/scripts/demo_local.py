#!/usr/bin/env python3
"""Levanta TODO el sistema en tu computador SIN Docker, para probarlo o presentarlo.

  pip install -r requirements/tests.txt
  python scripts/demo_local.py              # Vault y MongoDB SIMULADOS en memoria (los mismos que usan las pruebas automáticas)
  python scripts/demo_local.py --real       # con servidores reales: necesita los binarios de HashiCorp Vault y de MongoDB (ver --bin)

Cada servicio corre en su propio proceso, con su propio token de Vault y su propia base, y se hablan por HTTP igual que en
docker-compose.yml. Al terminar (Ctrl+C) se borra todo: los datos viven solo en memoria.
Abre SIEMPRE la misma dirección en el navegador (127.0.0.1 o localhost, no las dos): la cookie de sesión es del sitio.
"""
import argparse
import os
import signal
import sys
import tempfile
import time
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
CUENTAS = [("Administrador", "admin@elasador.cl", "admin123"), ("Dueño", "dueno@elasador.cl", "dueno123"),
           ("Despacho", "despacho@elasador.cl", "despacho123"), ("Cliente", "andrea.molina@correo.cl", "cliente123")]


def _terminar(*_):
    """Con `kill` (SIGTERM) también se limpia todo, igual que con Ctrl+C: si no, quedarían los procesos de cada servicio corriendo."""
    raise KeyboardInterrupt


def main():
    signal.signal(signal.SIGTERM, _terminar)
    ap = argparse.ArgumentParser()
    ap.add_argument("--real", action="store_true", help="usar HashiCorp Vault y MongoDB reales en vez de los simulados")
    ap.add_argument("--bin", default=".", help="carpeta con los binarios vault y mongod (solo con --real)")
    ap.add_argument("--puerto", type=int, default=8000, help="puerto del sitio (el proveedor de pagos simulado usa 8300)")
    a = ap.parse_args()
    if a.real:
        os.environ["ASADOR_REAL"], os.environ["ASADOR_BIN"] = "1", a.bin
    sys.path.insert(0, str(RAIZ / "tests"))
    from stack import Stack            # se importa después de decidir el modo

    logs = tempfile.mkdtemp(prefix="asador-demo-")
    with Stack(logs, extra_env={"SECRET_TTL_SECONDS": "30"}, puertos={"api-gateway": a.puerto, "provider-sandbox": 8300}) as s:
        print(f"\nEl Asador está funcionando  ->  {s.urls['api-gateway']}")
        print(f"Proveedor de pagos simulado ->  {s.urls['provider-sandbox']}")
        print("Servidores:", "MongoDB y Vault REALES" if a.real else "MongoDB y Vault simulados en memoria")
        print("Cuentas de demostración:")
        for rol, usuario, clave in CUENTAS:
            print(f"   {rol:<14} {usuario:<28} {clave}")
        print(f"Logs de cada servicio (una línea JSON por solicitud): {logs}")
        print("Ctrl+C para detener.\n", flush=True)
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            print("Deteniendo...")


if __name__ == "__main__":
    main()
