#!/usr/bin/env python3
"""Genera, desde el CÓDIGO, las matrices y los esquemas que cita el informe. Nada de esto se escribe a mano.

  python scripts/generar_documentos.py              # escribe docs/matrices/*.md y docs/graphql/schema.graphql
  python scripts/generar_documentos.py --verificar  # falla si lo escrito ya no coincide con el código (lo usa tests/test_documentos.py)

Fuentes: la tabla RUTAS del API Gateway, las rutas y guardias de cada servicio (lectura del código, sin ejecutarlo), los modelos
de entrada (pydantic), el manifiesto SIMBÓLICO de secretos (secrets/manifest.tsv: nombres, nunca valores) y el esquema GraphQL.
Si existe docs/ejemplos/S##.json (scripts/capturar_ejemplos.py), la columna «Salida» muestra lo que el sistema respondió de verdad.
"""
import argparse
import csv
import importlib
import json
import re
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "tests"))
sys.path.insert(0, str(RAIZ / "scripts"))
sys.path.insert(0, str(RAIZ))
import analisis_codigo as codigo  # noqa: E402
import analisis_contratos as contratos  # noqa: E402
import generar_matrices as matrices  # noqa: E402

MATRICES = RAIZ / "docs" / "matrices"
GRAPHQL = RAIZ / "docs" / "graphql"
EJEMPLOS = RAIZ / "docs" / "ejemplos"
ROLES = ("cliente", "despacho", "administrador", "dueno")

# Reglas de pertenencia / estado que el servicio aplica además del rol (la matriz de permisos las muestra junto a cada ruta).
# tests/test_documentos.py exige que toda ruta con rol «cliente» tenga su condición escrita aquí: no se puede olvidar una.
CONDICIONES = {
    "S01": "Bloqueo temporal tras varios intentos fallidos; misma respuesta y mismo trabajo (hash falso) si el usuario no existe",
    "S03": "Devuelve solo la identidad de la sesión (o null); nunca el token",
    "S06": "Catálogo: administrador y dueño",
    "S09": "No se elimina un producto que forma parte de una promoción (409 PRODUCTO_EN_PROMO)",
    "S10": "Crea cuenta de cliente (rol fijo «cliente», nunca elegido por el navegador); se comprueba que el correo exista; respuesta genérica si la cuenta ya existe",
    "S11": "No recibe identificador: devuelve el perfil del cliente de la SESIÓN",
    "S16": "Solo administrador",
    "S18": "El administrador no puede editarse a sí mismo ni dejar al sistema sin administradores (409)",
    "S19": "El administrador no puede eliminarse a sí mismo ni al último administrador (409)",
    "S21": "Cuenta de cliente activa ligada a la sesión; máx. pedidos con pago pendiente; precios, despacho y total los calcula el servidor",
    "S22": "Solo los pedidos del cliente de la sesión",
    "S23": "Cliente: solo si el pedido es SUYO (ajeno e inexistente dan el mismo 403); administrador y despacho: cualquiera",
    "S24": "Cliente: solo su pedido; solo en «Pago pendiente» o «En preparación»; en «En preparación» queda reembolso pendiente",
    "S26": "Transiciones por rol: En preparación → En camino → Entregado (despacho y administrador); nunca se salta un estado",
    "S29": "Cliente: solo su pedido en «Pago pendiente»; el monto lo entrega orders, no el navegador; un solo cobro iniciado por pedido",
    "S30": "Cliente: solo su pedido; administrador: cualquiera",
    "S31": "Cliente: solo su pedido; administrador: cualquiera; 404 mientras la boleta no se emite",
    "S32": "Solo transferencia o depósito (medios manuales) y pedido en «Pago pendiente»; exige referencia",
    "S33": "Solo pagos con reembolso pendiente; exige referencia del reembolso",
    "S35": "Firma HMAC del proveedor + ventana de tiempo + mismo monto y moneda que el cobro; evento repetido es idempotente",
    "S38": "Autorización campo por campo (ver graphql.md); además profundidad, alias, tamaño y costo acotados",
}


def _rutas():
    return matrices.cargar_rutas()


def _norm(ruta):
    return re.sub(r"\{[^}]+\}", "{}", ruta)


def _celda(texto):
    return str(texto).replace("|", "\\|").replace("\n", " ")


def _tabla(encabezado, filas):
    salida = ["| " + " | ".join(encabezado) + " |", "|" + "|".join("---" for _ in encabezado) + "|"]
    salida += ["| " + " | ".join(_celda(c) for c in fila) + " |" for fila in filas]
    return "\n".join(salida)


def _ejemplo(sid):
    ruta = EJEMPLOS / f"{sid}.json"
    return json.loads(ruta.read_text(encoding="utf-8")) if ruta.exists() else None


def _forma(valor, profundidad=0):
    """Resumen de la forma de un JSON: {campo, campo: [..]} sin los valores."""
    if isinstance(valor, dict):
        if profundidad >= 1:
            return "{…}"
        return "{" + ", ".join(f"{k}{'' if not isinstance(v, (dict, list)) else (': ' + _forma(v, profundidad + 1))}" for k, v in valor.items()) + "}"
    if isinstance(valor, list):
        return "[" + (_forma(valor[0], profundidad) if valor else "") + "]"
    return ""


def _contrato_interno(r, todos):
    return todos.get((r.destino, r.metodo, _norm(r.ruta_interna)))


# ----------------------------- servicios y contratos -----------------------------------------------------------------
def servicios_y_contratos():
    rutas, todos = _rutas().RUTAS, {(s, m, _norm(p)): c for (s, m, p), c in contratos.todos().items()}
    filas, modelos = [], {}
    for r in rutas:
        c = _contrato_interno(r, todos)
        entrada = []
        if r.params:
            entrada.append("ruta: " + ", ".join(n for n, _ in r.params))
        if r.query:
            entrada.append("consulta: " + ", ".join(r.query))
        if r.cuerpo == "json":
            nombre = c.cuerpo if c and c.cuerpo else "JSON"
            entrada.append(f"cuerpo: {nombre}")
            if c and c.campos_cuerpo:
                modelos[nombre] = c.campos_cuerpo
        elif r.cuerpo == "crudo":
            entrada.append("cuerpo: bytes tal cual (firma del proveedor)")
        if r.cabeceras:
            entrada.append("cabeceras: " + ", ".join(r.cabeceras))
        ej = _ejemplo(r.id)
        salida = f"{c.estado_ok if c else '200'}" + (f" {_forma(ej['respuesta']['cuerpo'])}" if ej and ej["respuesta"].get("cuerpo") not in (None, "") else "")
        errores = ", ".join(f"{a} {b}" for a, b in c.errores) if c else "—"
        acceso = {"anonimo": "anónimo", "sesion": "sesión", "firma": "firma del proveedor"}[r.acceso] + (f" ({', '.join(r.roles)})" if r.roles else "")
        filas.append((r.id, f"{r.metodo} {r.patron}", f"{r.destino} {r.ruta_interna}", acceso, "; ".join(entrada) or "—", salida, errores, r.datos,
                      ", ".join(r.rf) or "—", ", ".join(r.paginas) or "—", f"[S{r.id[1:]}](../ejemplos/{r.id}.json)" if ej else "—"))
    t = ["# Catálogo de servicios y contratos (M1)", "",
         "Generado por `scripts/generar_documentos.py` desde la tabla `RUTAS` del API Gateway y la lectura del código de cada servicio. "
         "Un servicio es una ruta pública que el navegador puede usar; el API Gateway no reenvía nada que no figure aquí.", "",
         "**Entrada:** de dónde sale cada dato. **Salida:** estado HTTP de éxito y forma de la respuesta capturada en una ejecución real "
         "(`docs/ejemplos/`). **Errores:** los `ErrorNegocio` que el servicio puede lanzar (estado y código), además de los 400/401/403/422/429/5xx "
         "comunes que aplican el gateway y la validación.", "",
         _tabla(("ID", "Ruta pública", "Servicio y ruta interna", "Acceso", "Entrada", "Salida", "Errores propios", "Datos", "RF", "Pantallas", "Ejemplo"), filas), ""]
    t += ["## Modelos de entrada", "", "Cada cuerpo JSON se valida con un modelo pydantic con `extra=\"forbid\"`: un campo no declarado se rechaza (422), no se ignora.", ""]
    for nombre in sorted(modelos):
        t += [f"### {nombre}", "", _tabla(("Campo", "Tipo", "Reglas", "Obligatorio"),
                                           [(c.nombre, f"`{c.tipo}`", c.reglas or "—", "sí" if c.obligatorio else "no") for c in modelos[nombre]]), ""]
    t += ["## Pantallas", "", _tabla(("ID", "Pantalla"), sorted(_rutas().PAGINAS.items())), ""]
    return "\n".join(t)


# ----------------------------- permisos por rol ----------------------------------------------------------------------
def permisos_por_rol():
    filas = []
    for r in _rutas().RUTAS:
        if r.acceso == "anonimo":
            celdas = ["sí"] * 4
            anon = "sí"
        elif r.acceso == "firma":
            celdas, anon = ["—"] * 4, "firma"
        else:
            permitidos = r.roles or ROLES
            celdas = ["sí" if x in permitidos else "no" for x in ROLES]
            anon = "no (401)"
        filas.append((r.id, r.metodo, r.patron, anon, *celdas, CONDICIONES.get(r.id, "—")))
    return "\n".join([
        "# Matriz de permisos por ruta, verbo y condición (M4)", "",
        "Generado desde `RUTAS` (rol exigido por el API Gateway). El servicio privado vuelve a comprobar el rol y la pertenencia: "
        "dos capas independientes (ver `tests/contratos/rutas_servicios.json`). «no (401)» = sin sesión; con sesión pero sin rol responde 403.", "",
        _tabla(("ID", "Verbo", "Ruta", "Anónimo", "Cliente", "Despacho", "Administrador", "Dueño", "Condición que aplica el servicio"), filas), "",
        "El dueño del negocio ve el catálogo y los reportes de ventas, pero **no** datos personales de clientes ni de entrega."])


# ----------------------------- rutas y controles ---------------------------------------------------------------------
def rutas_y_controles():
    filas = []
    for r in _rutas().RUTAS:
        escribe = r.metodo in ("POST", "PUT", "DELETE", "PATCH")
        if r.acceso == "firma":
            csrf = "no aplica (firma HMAC del proveedor)"
        elif not escribe:
            csrf = "— (solo lectura)"
        elif r.acceso == "sesion":
            csrf = "Origin/Referer obligatorio y exacto + cookie SameSite=Lax"
        else:
            csrf = "Origin/Referer exacto si viene; obligatorio si hay cookie de sesión"
        filas.append((r.id, f"{r.metodo} {r.patron}", r.acceso, r.limite, f"{r.cache} s" if r.cache else "—", r.invalida or "—", csrf,
                      ", ".join(f"{n}=`{p}`" for n, p in r.params) or "—", ", ".join(r.query) or "—", ", ".join(r.cabeceras) or "ninguna"))
    return "\n".join([
        "# Matriz de rutas y controles del API Gateway (M6)", "",
        "Lo que no está en esta tabla no se reenvía (404). Los parámetros de ruta se validan con la expresión indicada ANTES de reenviar; "
        "de la consulta solo pasan los parámetros listados; del navegador solo viajan las cabeceras listadas (el resto se descarta, "
        "y las de identidad `X-Authenticated-*` las escribe el gateway, nunca el cliente).", "",
        _tabla(("ID", "Ruta", "Acceso", "Límite de tasa", "Caché", "Invalida", "Protección CSRF", "Parámetros de ruta", "Consulta permitida", "Cabeceras reenviadas"), filas), ""])


# ----------------------------- llamadas entre servicios --------------------------------------------------------------
def llamadas_entre_servicios():
    privadas = codigo.todas_las_rutas_privadas()
    por_par = {}
    for r in privadas:
        llamadores = r.guardia[0] if r.guardia else ()
        for ll in llamadores:
            por_par.setdefault((ll, r.servicio), []).append(r)
    pares = sorted(codigo.pares_aceptados())
    filas = []
    for ll, dest in pares:
        rs = sorted(por_par.get((ll, dest), []), key=lambda x: (x.ruta, x.metodo))
        filas.append((ll, dest, f"asador/svc/{ll}-to-{dest}", "; ".join(f"{x.metodo} {x.ruta}" for x in rs) or "—"))
    return "\n".join([
        "# Llamadas entre servicios y secreto de cada par (M3 / M6)", "",
        f"{len(pares)} pares llamador→destino. Cada par usa SU secreto (`X-Service-Name` + `X-Service-Secret`, guardado en Vault bajo el nombre indicado): "
        "el secreto de un par no sirve para otro destino ni para otro llamador. Solo `api-gateway` y `graphql-gateway` pueden afirmar una identidad de usuario.", "",
        _tabla(("Llamador", "Destino", "Secreto en Vault (nombre)", "Rutas que el llamador puede usar"), filas), ""])


# ----------------------------- secretos (símbolos, nunca valores) ----------------------------------------------------
def inventario_de_secretos():
    with (RAIZ / "secrets" / "manifest.tsv").open(encoding="utf-8") as f:
        filas = list(csv.DictReader(f, delimiter="\t"))
    return "\n".join([
        "# Inventario SIMBÓLICO de secretos (M6 / M7)", "",
        "Solo nombres, quién los usa y su ciclo de vida. **Ningún valor** vive en el repositorio, en las imágenes ni en el navegador: "
        "`scripts/bootstrap.py` los genera al arrancar y `scripts/seed_vault.py` los guarda en Vault (rotar: `--rotar <ref>`).", "",
        f"{len(filas)} secretos.", "",
        _tabla(("Referencia (ruta en Vault)", "Tipo", "Campos", "Lo lee", "Lo verifica", "Finalidad", "Alcance", "Rotación y revocación"),
               [(f"`asador/{x['ref']}`", x["tipo"], x["campos"], x["consumidores"], x["verificadores"], x["finalidad"], x["alcance"], x["rotacion_y_revocacion"]) for x in filas]), ""])


# ----------------------------- GraphQL -------------------------------------------------------------------------------
def _graphql():
    codigo_gql = importlib.import_module("ayuda").cargar_paquete("graphql-gateway/app", "gql_doc")
    return importlib.import_module("gql_doc.schema"), codigo_gql


def esquema_graphql():
    m, _ = _graphql()
    return m.schema.as_str()


def graphql_md():
    m, _ = _graphql()
    lim = importlib.import_module("gql_doc.limites")
    from strawberry.schema.name_converter import NameConverter
    nc = NameConverter()
    filas = []
    for nombre, obj in vars(m).items():
        d = getattr(obj, "__strawberry_definition__", None)
        if not d:
            continue
        for f in d.fields:
            roles = [r for c in f.permission_classes for r in getattr(c, "roles", ())]
            if nombre in ("Query", "PanelAdmin") or roles:
                filas.append((nombre, nc.get_graphql_name(f), ", ".join(roles) or "cualquier sesión (el dato se acota por pertenencia)"))
    filas.sort(key=lambda x: (x[0] != "Query", x[0], x[1]))
    return "\n".join([
        "# GraphQL Gateway: operaciones y autorización por campo (M8)", "",
        "Solo lectura (el esquema no tiene `Mutation`). Se atiende por `POST /api/graphql` (S38); el navegador no puede llegar a los servicios privados. "
        "Esquema completo: [`docs/graphql/schema.graphql`](../graphql/schema.graphql).", "",
        "## Operaciones y campos con permiso propio", "", _tabla(("Tipo", "Campo", "Roles que pueden pedirlo"), filas), "",
        "Los datos personales del pedido (`Pedido.cliente`) los ven el cliente dueño, el administrador y el despacho; **el dueño no**. "
        "`misPedidos` solo devuelve pedidos del cliente de la sesión: la pertenencia la aplica el servicio `orders` con la identidad, no el resolver.", "",
        "## Límites de consulta", "",
        _tabla(("Control", "Valor", "Dónde"), [
            ("Introspección", "desactivada", "`DisableIntrospection`"), ("Profundidad máxima", m.MAX_PROFUNDIDAD, "`QueryDepthLimiter`"),
            ("Alias por consulta", 10, "`MaxAliasesLimiter`"), ("Tokens por documento", 1200, "`MaxTokensLimiter`"),
            ("Costo estimado", f"máximo {lim.COSTO_MAXIMO} (1 + hijos × `limit`)", "`LimiteDeCosto` (rechaza antes de ejecutar)"), ("Errores inesperados", "enmascarados (`Error interno`)", "`MaskErrors`"),
            ("Paginación", f"`limit` entre 1 y {lim.LIMITE_MAXIMO}, con `offset`", "`acotar()`"), ("Anti N+1", "DataLoader por solicitud", "`Contexto._cargar_items/_cargar_pagos`")]), ""])


DOCUMENTOS = {
    MATRICES / "servicios_y_contratos.md": servicios_y_contratos,
    MATRICES / "permisos_por_rol.md": permisos_por_rol,
    MATRICES / "rutas_y_controles.md": rutas_y_controles,
    MATRICES / "llamadas_entre_servicios.md": llamadas_entre_servicios,
    MATRICES / "inventario_de_secretos.md": inventario_de_secretos,
    MATRICES / "graphql.md": graphql_md,
    GRAPHQL / "schema.graphql": esquema_graphql,
}


def generar():
    return {ruta: (f() if f.__name__ != "esquema_graphql" else f()).rstrip("\n") + "\n" for ruta, f in DOCUMENTOS.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--verificar", action="store_true")
    a = ap.parse_args()
    nuevos = generar()
    if a.verificar:
        viejos = [str(r.relative_to(RAIZ)) for r, t in nuevos.items() if not r.exists() or r.read_text(encoding="utf-8") != t]
        if viejos:
            print("Desactualizados respecto del código:", ", ".join(viejos), "\nEjecuta: python scripts/generar_documentos.py")
            return 1
        print("Los documentos generados coinciden con el código.")
        return 0
    for ruta, t in nuevos.items():
        ruta.parent.mkdir(parents=True, exist_ok=True)
        ruta.write_text(t, encoding="utf-8")
        print("escrito", ruta.relative_to(RAIZ))
    return 0


if __name__ == "__main__":
    sys.exit(main())
