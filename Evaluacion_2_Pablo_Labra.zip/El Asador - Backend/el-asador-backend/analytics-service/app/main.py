"""Analytics (privado): modelo de lectura de ventas para los reportes del administrador y del dueño.

Recibe eventos de `payments` (venta registrada / venta anulada) y responde reportes por período.
  * Idempotente: el mismo evento dos veces no cambia nada (la clave natural es el folio de la venta).
  * Tolera desorden: si la anulación llega antes que el registro, la venta queda anulada igual.
  * Solo cuenta ventas VIGENTES (pago confirmado y pedido no anulado). El día es el día local de Santiago.
Los datos de reporte son agregados; no contienen RUN, correo, teléfono ni dirección de los clientes.
"""
import os
from contextlib import asynccontextmanager
from datetime import date, timedelta

from fastapi import Depends, Query
from pydantic import BaseModel, ConfigDict, Field, model_validator

from common.app import crear_app
from common.db import abrir_db
from common.errores import ErrorNegocio
from common.migraciones import migrar
from common.seguridad import Guardia
from common.tiempo import fecha_local, iso
from common.vault_secrets import VaultSecrets

SEMILLA = os.environ.get("SEED_DEMO_DATA", "false").lower() == "true"
MAX_DIAS = int(os.environ.get("REPORTE_MAX_DIAS", "92"))
vault = VaultSecrets()
guardia = Guardia("analytics", vault)
db = None
LECTORES = ("administrador", "dueno")


async def _indices(d):
    await d.ventas.create_index([("estado", 1), ("fechaLocal", 1)])
    await d.historico.create_index("fecha")


MIGRACIONES = [(1, "índices del modelo de lectura", _indices)]


def historia_de_ejemplo(hoy: date):
    """Los 28 días anteriores, con la misma regla determinista que usaba el reporte de ejemplo del frontend."""
    factor_por_dia = [1.4, 0, 0.7, 0.65, 0.8, 1.25, 1.6]   # domingo, lunes (cerrado), martes ... sábado
    for atras in range(28, 0, -1):
        f = hoy - timedelta(days=atras)
        factor = factor_por_dia[(f.weekday() + 1) % 7]
        pedidos = int(18 * factor + 0.5) + (f.day % 4) if factor else 0
        ticket = 34000 + ((f.day * 731) % 9000)
        yield {"_id": f.isoformat(), "fecha": f.isoformat(), "pedidos": pedidos, "ventas": pedidos * ticket, "origen": "ejemplo"}


async def sembrar(d):
    n = 0
    for doc in historia_de_ejemplo(date.fromisoformat(fecha_local())):
        if not await d.historico.find_one({"_id": doc["_id"]}):
            await d.historico.insert_one(doc)
            n += 1
    return n


@asynccontextmanager
async def lifespan(app):
    global db
    await vault.aesperar("asador/db/analytics")
    await guardia.precalentar()
    cliente, db = await abrir_db("analytics", vault)
    await migrar(db, MIGRACIONES)
    if SEMILLA:
        log.info("historial de ejemplo cargado", extra={"ctx": {"dias_nuevos": await sembrar(db)}})
    app.state.chequeos.append(lambda: db.command("ping"))
    log.info("Analytics listo")
    yield
    cliente.close()


app, log = crear_app("analytics", lifespan)


class LineaEv(BaseModel):
    model_config = ConfigDict(extra="forbid")
    itemId: str | None = Field(default=None, max_length=20)
    nombre: str = Field(max_length=80)
    cantidad: int = Field(ge=1, le=1000)
    subtotal: int = Field(ge=0)


class VentaRegistrada(BaseModel):
    model_config = ConfigDict(extra="forbid")
    eventoId: str = Field(pattern=r"^venta:B-\d{6}$")
    ventaId: str = Field(pattern=r"^B-\d{6}$")
    pedidoId: str = Field(pattern=r"^A-\d{3,9}$")
    fecha: str = Field(max_length=30)
    fechaLocal: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    total: int = Field(ge=0)
    neto: int = Field(ge=0)
    iva: int = Field(ge=0)
    medio: str = Field(max_length=40)
    comuna: str | None = Field(default=None, max_length=40)
    lineas: list[LineaEv] = Field(max_length=60)

    @model_validator(mode="after")
    def _coherente(self):
        if self.eventoId != f"venta:{self.ventaId}":   # el id del evento se deriva del folio: un folio, un evento
            raise ValueError("El identificador del evento no corresponde al folio de la venta")
        if self.neto + self.iva != self.total:
            raise ValueError("El neto y el IVA no suman el total de la venta")
        return self


class VentaAnulada(BaseModel):
    model_config = ConfigDict(extra="forbid")
    eventoId: str = Field(pattern=r"^reverso:B-\d{6}$")
    ventaId: str = Field(pattern=r"^B-\d{6}$")

    @model_validator(mode="after")
    def _coherente(self):
        if self.eventoId != f"reverso:{self.ventaId}":
            raise ValueError("El identificador del evento no corresponde al folio de la venta")
        return self


@app.post("/internal/events/sale-registered")
async def venta_registrada(ev: VentaRegistrada, ll=Depends(guardia.dep(("payments",)))):
    visto = await db.eventos.find_one({"_id": ev.eventoId})
    campos = ev.model_dump(exclude={"eventoId", "ventaId"})
    # $setOnInsert: si la anulación llegó antes, la venta queda "anulada" y este evento no la revive
    await db.ventas.update_one({"_id": ev.ventaId}, {"$set": campos, "$setOnInsert": {"estado": "vigente"}}, upsert=True)
    if not visto:
        await db.eventos.update_one({"_id": ev.eventoId}, {"$setOnInsert": {"tipo": "sale-registered", "recibidoEn": iso()}}, upsert=True)
    return {"ok": True, "duplicado": bool(visto)}


@app.post("/internal/events/sale-reversed")
async def venta_anulada(ev: VentaAnulada, ll=Depends(guardia.dep(("payments",)))):
    visto = await db.eventos.find_one({"_id": ev.eventoId})
    await db.ventas.update_one({"_id": ev.ventaId}, {"$set": {"estado": "anulada", "anuladaEn": iso()}}, upsert=True)
    if not visto:
        await db.eventos.update_one({"_id": ev.eventoId}, {"$setOnInsert": {"tipo": "sale-reversed", "recibidoEn": iso()}}, upsert=True)
    return {"ok": True, "duplicado": bool(visto)}


def _fecha(texto, nombre):
    try:
        return date.fromisoformat(texto)
    except ValueError:
        raise ErrorNegocio(400, "FILTRO_INVALIDO", f"«{nombre}» debe tener formato AAAA-MM-DD")


@app.get("/internal/reports/sales")
async def reporte(desde: str = Query(max_length=10), hasta: str = Query(max_length=10),
                  ll=Depends(guardia.dep(("graphql-gateway",), identidad="requerida", roles=LECTORES))):
    d1, d2, hoy = _fecha(desde, "desde"), _fecha(hasta, "hasta"), date.fromisoformat(fecha_local())
    if d1 > d2:
        raise ErrorNegocio(422, "PERIODO_INVALIDO", "La fecha «Desde» no puede ser posterior a «Hasta».")
    if d2 > hoy:
        raise ErrorNegocio(422, "PERIODO_INVALIDO", "No hay ventas en fechas futuras: elige hasta hoy.")
    if (d2 - d1).days + 1 > MAX_DIAS:
        raise ErrorNegocio(422, "PERIODO_DEMASIADO_LARGO", f"El período no puede superar {MAX_DIAS} días.")
    rango = {"$gte": d1.isoformat(), "$lte": d2.isoformat()}

    por_dia = {}
    async for h in db.historico.find({"fecha": rango}):
        por_dia[h["fecha"]] = {"pedidos": h["pedidos"], "ventas": h["ventas"]}
    grupos = await db.ventas.aggregate([
        {"$match": {"estado": "vigente", "fechaLocal": rango}},
        {"$group": {"_id": "$fechaLocal", "pedidos": {"$sum": 1}, "ventas": {"$sum": "$total"}}}]).to_list(400)
    for g in grupos:
        base = por_dia.get(g["_id"], {"pedidos": 0, "ventas": 0})
        por_dia[g["_id"]] = {"pedidos": base["pedidos"] + g["pedidos"], "ventas": base["ventas"] + g["ventas"]}

    dias, f = [], d1
    while f <= d2:
        v = por_dia.get(f.isoformat(), {"pedidos": 0, "ventas": 0})
        dias.append({"fecha": f.isoformat(), "pedidos": v["pedidos"], "ventas": v["ventas"],
                     "ticketPromedio": round(v["ventas"] / v["pedidos"]) if v["pedidos"] else 0})
        f += timedelta(days=1)
    total, pedidos = sum(x["ventas"] for x in dias), sum(x["pedidos"] for x in dias)
    mejor = max(dias, key=lambda x: x["ventas"]) if dias else None

    medios = await db.ventas.aggregate([
        {"$match": {"estado": "vigente", "fechaLocal": rango}},
        {"$group": {"_id": "$medio", "pedidos": {"$sum": 1}, "ventas": {"$sum": "$total"}}}, {"$sort": {"ventas": -1}}]).to_list(10)
    top = await db.ventas.aggregate([
        {"$match": {"estado": "vigente", "fechaLocal": rango}}, {"$unwind": "$lineas"},
        {"$group": {"_id": "$lineas.nombre", "unidades": {"$sum": "$lineas.cantidad"}, "ventas": {"$sum": "$lineas.subtotal"}}},
        {"$sort": {"unidades": -1}}, {"$limit": 5}]).to_list(5)
    return {"desde": d1.isoformat(), "hasta": d2.isoformat(), "dias": dias,
            "totales": {"ventas": total, "pedidos": pedidos, "ticketPromedio": round(total / pedidos) if pedidos else 0,
                        "mejorDia": mejor["fecha"] if mejor and mejor["ventas"] else None},
            "porMedioPago": [{"medio": m["_id"], "pedidos": m["pedidos"], "ventas": m["ventas"]} for m in medios],
            "topProductos": [{"nombre": t["_id"], "unidades": t["unidades"], "ventas": t["ventas"]} for t in top]}
